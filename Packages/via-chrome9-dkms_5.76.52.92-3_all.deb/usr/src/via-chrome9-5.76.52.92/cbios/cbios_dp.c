/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "cbios_uma.h"
#include "cbios_sub_func.h"
#include "cbios_cea_timing.h"

//=== DP1 Ctrl Registers ===
#define     DP1LTCtlReg         0xC614
#define     DP1VideoCtlReg      0xC618
#define     DP1EnableFlagReg    0xC640   
#define     DP1SWAUXReg         0xC730
#define     DP1SWAUXCmdReg      0xC734
#define     DP1NAUDCtlReg       0xC738
#define     DP1EPHYCtlReg0      0xC740
#define     DP1EPHYCtlReg1      0xC744
#define     DP1EPHYCtlReg2      0xC748

//=== DP2 Ctrl Registers ===
#define     DP2LTCtlReg         0xC694
#define     DP2EnableFlagReg    0xC6C0
#define     DP2SWAUXReg         0xC7B0
#define     DP2SWAUXCmdReg      0xC7B4
#define     DP2NAUDCtlReg       0xC7B8
#define     DP2EPHYCtlReg0      0xC7C0
#define     DP2EPHYCtlReg1      0xC7C4
#define     DP2EPHYCtlReg2      0xC7C8
#define     DP2EPHYCtlReg3      0xC7CC

//=== DP1 Write Data Buffer ===
#define     DP1AUXWriteReg0     0xC710
#define     DP1AUXWriteReg1     0xC714
#define     DP1AUXWriteReg2     0xC718
#define     DP1AUXWriteReg3     0xC71C

//=== DP1 Read Data Buffer ===
#define     DP1AUXReadReg0      0xC720
#define     DP1AUXReadReg1      0xC724
#define     DP1AUXReadReg2      0xC728
#define     DP1AUXReadReg3      0xC72C

//=== DP2 Write Data Buffer ===
#define     DP2AUXWriteReg0     0xC790
#define     DP2AUXWriteReg1     0xC794
#define     DP2AUXWriteReg2     0xC798
#define     DP2AUXWriteReg3     0xC79C

//=== DP2 Read Data Buffer ===
#define     DP2AUXReadReg0      0xC7A0
#define     DP2AUXReadReg1      0xC7A4
#define     DP2AUXReadReg2      0xC7A8
#define     DP2AUXReadReg3      0xC7AC

//=== Other Ctrl Registers ===

BOOL dpSwLinkTraining=FALSE;
BOOL dp2SwLinkTraining=FALSE;
extern UINT32 dp2LinkspeedConf;
BOOL hdmi_force_connect=FALSE;
BOOL dp1_force_connect=FALSE;
BOOL dp2_force_connect=FALSE;


//=============================================================================
// below is new sub functions
//=============================================================================

//--------------------------------------------------------------------------
//  cbSetDPPowerState
//  change DisplayPort PowerState & initial digital port associated
//     IN
//        powerstate : ON /OFF  
//--------------------------------------------------------------------------
void cbSetDPPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate)
{
    DWORD mmC280, mmC748, mmC640, mmC000, mmC740, mmC74C;
    AUX_CONTROL_UMA AUX;

    /*HDMI force connected */
    if(hdmi_force_connect){
        pcbe->DPSinkCaps[DP1].DualMode = TRUE;
        cbDbgPrint(1,"HDMI force connected!\n");
    }
    
    // HDMI
    if(pcbe->DPSinkCaps[DP1].DualMode)
    {
        if(powerstate == S3PM_ON)
        {
            cbDPInitEPHY(pcbe, DP1);
            // HDMI mode
            mmC280 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC280)) | 0x18000002;

			if(pcbe->DPSinkCaps[DP1].IsHDMIDevice)
                mmC280 &= ~0x40;  //BIT[6] = 0: normal HDMI function
            else
                mmC280 |= 0x40;  // BIT[6] = 1: DVI mode enable, only video data transmission on TMDS channels

			if(pcbe->ChipCaps.Force_HDMI_to_DVI_Mode)
                mmC280 |= 0x40;  // BIT[6] = 1: DVI mode enable, only video data transmission on TMDS channels

            WriteMMIOUlong(CB_MMIO_OFFSET(0xC280), mmC280);
            
            mmC000 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC000));
            WriteMMIOUlong(CB_MMIO_OFFSET(0xC000), mmC000 | 0x00000001);    
            
            mmC748 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC748)) & 0xFFFFFFFE;
            WriteMMIOUlong(CB_MMIO_OFFSET(0xC748), mmC748);  
            
            mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0))& ~0x06000000; //make sure Tpll/Tpll reg are off
            WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740);

            cbDelayMicroSeconds(375);

            mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0)) | 0x06000000;
            WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740);

            // HDMI AC mode
            mmC74C = ReadMMIOUlong(CB_MMIO_OFFSET(0xC74C)) | 0x40;
            WriteMMIOUlong(CB_MMIO_OFFSET(0xC74C), mmC74C);
        }

        if(powerstate == S3PM_OFF)
        {
            mmC280 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC280)) & ~0x2;
            WriteMMIOUlong(CB_MMIO_OFFSET(0xC280), mmC280);

            mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0)) & 0xFFFFFFFE;
            WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740);

            // Disable HDMI AC mode.
            mmC74C = ReadMMIOUlong(CB_MMIO_OFFSET(0xC74C)) & ~0x40;
            WriteMMIOUlong(CB_MMIO_OFFSET(0xC74C), mmC74C);
        }
    }

    else
    {
        if(powerstate == S3PM_ON)
        {
            mmC000 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC000)) | 0x1;
            WriteMMIOUlong(CB_MMIO_OFFSET(0xC000), mmC000);
            
            cbDPInitEPHY(pcbe, DP1);

            // set DPCD address 600h to 1, set sink device to D0(normal operation mode)
            AUX.Function = AUX_WRITE;
            AUX.Offset = 0x600;
            AUX.Length = 1;
            AUX.Data[0] = 0x1;
            cbDPAuxChRW(pcbe, &AUX, DP1);

            mmC748 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg2)) | 0x01;
            WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg2), mmC748);

            mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0)) & 0x3FFFFFFF;
            WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740);

            mmC74C = ReadMMIOUlong(CB_MMIO_OFFSET(0xC74C)) & ~0x60;
            WriteMMIOUlong(CB_MMIO_OFFSET(0xC74C), mmC74C);
            
            if(dpSwLinkTraining)
                cbDPLinkTrainingSW(pcbe, DP1);    
            else
                cbDPLinkTrainingHW(pcbe, DP1);

            cbDPSetupMainLink(pcbe, DP1);
        }

        if(powerstate == S3PM_OFF)
        {
            // set DPCD address 600h to 2, set sink device to D3(power down mode)
            AUX.Function = AUX_WRITE;
            AUX.Offset = 0x600;
            AUX.Length = 1;
            AUX.Data[0] = 0x2;
            cbDPAuxChRW(pcbe, &AUX, DP1);
            
            mmC640 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EnableFlagReg)) & 0xFFFFFFF6;
            WriteMMIOUlong(CB_MMIO_OFFSET(DP1EnableFlagReg), mmC640);

            mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0)) & 0xFFFFFFFE;
            WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740);
        }

        pcbe->devicepowerstate[DPbit] = powerstate;
    }

    if(powerstate == S3PM_ON)
    {
        // only enalbe ECLK free run in C3/C4 mode
        if(pcbe->ChipCaps.VT3410_HDMI_ENGINE_CLOCK_GATING)
            cbWriteRegBits(pcbe, SR_A9, BIT2 + BIT3, BIT3);
    }
}

void cbSetDP2PowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate)
{
    DWORD mmC6C0, mmC000;
    AUX_CONTROL_UMA AUX;
    BOOL LT_Status=FALSE;

    if(powerstate == S3PM_ON)
    {
        UINT32 i=0;
        mmC000 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC000)) | 0x1;
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC000), mmC000);

        //VDD on  
	    cbControlVDDSignalForEDP(pcbe, TRUE);
        
        cbDPInitEPHY(pcbe, DP2);

        // set DPCD address 600h to 1, set sink device to D0(normal operation mode)
        AUX.Function = AUX_WRITE;
        AUX.Offset = 0x600;
        AUX.Length = 1;
        AUX.Data[0] = 0x1;
        cbDPAuxChRW(pcbe, &AUX, DP2);

        do
        {
            if(dp2SwLinkTraining)
                LT_Status = cbDPLinkTrainingSW(pcbe, DP2);    
            else
                LT_Status = cbDPLinkTrainingHW(pcbe, DP2);
            if(i++ > 5) // retry count
                    break;
        }while(LT_Status == FALSE);
    
        if(LT_Status == FALSE)
            cbDbgPrint(0,"DP2 HW LinkTraining Fail!\n");

        cbDPSetupMainLink(pcbe, DP2);
    }

    if(powerstate == S3PM_OFF)
    {
        //Back Light off
		cbControlBLSignalForEDP(pcbe, FALSE);
        
        // set DPCD address 600h to 2, set sink device to D3(power down mode)
        AUX.Function = AUX_WRITE;
        AUX.Offset = 0x600;
        AUX.Length = 1;
        AUX.Data[0] = 0x2;
        cbDPAuxChRW(pcbe, &AUX, DP2);
            
        mmC6C0 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC6C0)) & 0xFFFFFFF6;
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC6C0), mmC6C0);

        //VDD off
		cbControlVDDSignalForEDP(pcbe, FALSE);	
    }

    pcbe->devicepowerstate[DP2bit] = powerstate;
}

void cbDPSetupMainLink(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{    
    DWORD mmC6C4= 0, mmC644 = 0;
    DWORD dwTemp1 = 0, dwTemp2 = 0, dwTemp3 = 0, dwTURatio = 0, DClk = 0;

    PGFXTimingTable  pTimingTbl = &(pcbe->DPSinkCaps[DPIndex].TimingTbl);

    //DClk = pTimingTbl->HTotal * pTimingTbl->VTotal * (pTimingTbl->rRateX100/100) / 10;
    BYTE CLK_M = (BYTE)((pTimingTbl->vPLL & 0xFF0000) >> 16);
    BYTE CLK_R = (BYTE)((pTimingTbl->vPLL & 0x00FF00) >> 8);
    BYTE CLK_N = (BYTE) (pTimingTbl->vPLL & 0x0000FF);
    DClk = (cbCalcClkFromMRN(pcbe, CLK_M, CLK_R, CLK_N) / 100) / 10000;

    if((pTimingTbl->HTotal == 0) || (pcbe->DPSinkCaps[DPIndex].LaneNumber == 0))
    {
        cbDbgPrint(0,"cbDPSetupMainLink : Error, zero timing table! \n");
        return;
    }

    if(DPIndex == DP1)
    {
        // MMC6C4, H width and TU size/ratio, MMC69C[30]:Bit-12 of HDisp
        // TU ratio = (Dclk * bpps) * 32768 / (Ls_clk * Lane# * 8)
        dwTemp1 = DClk * 3 * pcbe->DPSinkCaps[DPIndex].bpc;
        dwTemp2 = pcbe->DPSinkCaps[DPIndex].LaneNumber * 
                    (pcbe->DPSinkCaps[DPIndex].LinkSpeed/10000)*8;
        dwTURatio = (dwTemp1*32768)/dwTemp2; 
        mmC644 = (pcbe->DPSinkCaps[DPIndex].TUSize -1) << 11;
        mmC644 |= (dwTURatio << 17);

        mmC644 |= ((pTimingTbl->HDisEnd)
                    / pcbe->DPSinkCaps[DPIndex].LaneNumber) - 1;
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC644), mmC644);

        //WriteMMIOUlong(CB_MMIO_OFFSET(0xC69C),
        //        (ReadMMIOUlong(CB_MMIO_OFFSET(0xC69C)) & 0xBFFFFFFF));

        // MMC6C8, H line duration: H * Ls_clk / Dclk
        // dwTemp2 = pcbe->DPSinkCapability[DP_ID].LinkSpeed / TimingReg.DCLK;
        // dwTemp1 = (TimingReg.HorTotal + 5*8) - (TimingReg.HorDisEnd + 1*8);
        // dwTemp3 = ((dwTemp1 * dwTemp2) & 0x00000FFF ) << 15;
        dwTemp1 = (pTimingTbl->HTotal) - (pTimingTbl->HDisEnd);
        // Prevent being divided by zero
        dwTemp3 = ((((dwTemp1 * pcbe->DPSinkCaps[DPIndex].LinkSpeed / 10000) /
                DClk) & 0x00000FFF ) - 35) << 15;
        dwTemp3 &= 0x07ff8000;

        // dwTemp1 = (TimingReg.HorTotal + 5*8) * ulTemp2;
        dwTemp1 = (((pTimingTbl->HTotal) * pcbe->DPSinkCaps[DPIndex].LinkSpeed / 10000) /
                DClk) - 35;
        dwTemp1 &= 0x00007FFF;

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC648), (dwTemp3 | dwTemp1));

        // M/N = Dclk / Ls_clk, but N must be 32768 to work with Parade DP
        // So, N = 32768, M = Dclk * 32768 / Ls_clk
        // Mvid and Nvid are not needed if in asynchronous mode, set it anyway
        // ulTemp1 = ((TimingReg.DCLK * 1024) / pcbe->DPSinkCapability[DP_ID].LinkSpeed) * 32;
        dwTemp1 = ((DClk/10000)*32768) / (pcbe->DPSinkCaps[DPIndex].LinkSpeed / 10000) ;
                    
        if (pcbe->DPSinkCaps[DPIndex].bpc == 6)
            dwTemp1 = (dwTemp1 & 0x00FFFFFF);
        else if (pcbe->DPSinkCaps[DPIndex].bpc == 8)
            dwTemp1 = (dwTemp1 & 0x00FFFFFF) | 0x20000000;
        else if (pcbe->DPSinkCaps[DPIndex].bpc == 10)
            dwTemp1 = (dwTemp1 & 0x00FFFFFF) | 0x40000000;
        else if (pcbe->DPSinkCaps[DPIndex].bpc == 12)
            dwTemp1 = (dwTemp1 & 0x00FFFFFF) | 0x60000000;
        else if (pcbe->DPSinkCaps[DPIndex].bpc == 16)
            dwTemp1 = (dwTemp1 & 0x00FFFFFF) | 0x80000000;

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC64C), dwTemp1);

        // MMC6D0, DP HTotal attribute data
        if(pTimingTbl->Interlaced)
            dwTemp1 = (pTimingTbl->VTotal) << 16;
        else
            dwTemp1 = (pTimingTbl->VTotal) << 16;
        dwTemp1 |= (pTimingTbl->HTotal);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC650), dwTemp1);

        // MMC6D4, DP H/V start attribute data (from leading edge of Sync)
        if(pTimingTbl->Interlaced)
            dwTemp1 = ((pTimingTbl->VTotal) - pTimingTbl->VSyncStart) << 16;
        else
            dwTemp1 = ((pTimingTbl->VTotal) - pTimingTbl->VSyncStart) << 16;
        dwTemp1 |= ((pTimingTbl->HTotal) - pTimingTbl->HSyncStart);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC654), dwTemp1);

        // MMC6D8, DP H/V Sync Polarity, Width attribute data         
        dwTemp1 = (pTimingTbl->VSyncEnd - pTimingTbl->VSyncStart) << 16; 
        
        //dwTemp1 = ((TimingReg.VerSyncEnd&0x0F) - (TimingReg.VerSyncStart&0x0F)) << 16;
        dwTemp1 |= (pTimingTbl->HSyncEnd - pTimingTbl->HSyncStart);
        //cbBiosMMIOWriteReg_dst(pcbe, SR_3A, 0x00, 0x38, CBIOS_NOIGAENCODERINDEX);
        if (pTimingTbl->HPolarity & CBIOS_NEGATIVE)
        {
            //cbBiosMMIOWriteReg_dst(pcbe, SR_3A, 0x80, 0x38, CBIOS_NOIGAENCODERINDEX);
            dwTemp1 |= 0x00008000;
        }
        if (pTimingTbl->VPolarity * CBIOS_NEGATIVE)
        {
            //cbBiosMMIOWriteReg_dst(pcbe, SR_3A, 0x40, 0x38, CBIOS_NOIGAENCODERINDEX);
            dwTemp1 |= 0x80000000;
        }
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC658), dwTemp1);

        // MMC6DC, DP H/V display attribute data
        dwTemp1 = (pTimingTbl->VDisEnd) << 16;
        dwTemp1 |= (pTimingTbl->HDisEnd);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC65C), dwTemp1);

        // MMC610, DP Nvid attribute data, N=32768
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC610), 0x00008000);

        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EnableFlagReg), (ReadMMIOUlong(CB_MMIO_OFFSET(DP1EnableFlagReg)) | 0x3300000D));
       
    }
    if(DPIndex == DP2)
    {
        // MMC6C4, H width and TU size/ratio, MMC69C[30]:Bit-12 of HDisp
        // TU ratio = (Dclk * bpps) * 32768 / (Ls_clk * Lane# * 8)
        dwTemp1 = DClk * 3 * pcbe->DPSinkCaps[DPIndex].bpc;
        dwTemp2 = pcbe->DPSinkCaps[DPIndex].LaneNumber * 
                    (pcbe->DPSinkCaps[DPIndex].LinkSpeed/10000)*8;
        dwTURatio = (dwTemp1*32768)/dwTemp2; 
        mmC6C4 = (pcbe->DPSinkCaps[DPIndex].TUSize -1) << 11;
        mmC6C4 |= (dwTURatio << 17);

        mmC6C4 |= ((pTimingTbl->HDisEnd)
                    / pcbe->DPSinkCaps[DPIndex].LaneNumber) - 1;
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC6C4), mmC6C4);

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC69C),
                (ReadMMIOUlong(CB_MMIO_OFFSET(0xC69C)) & 0xBFFFFFFF));

        // MMC6C8, H line duration: H * Ls_clk / Dclk
        // dwTemp2 = pcbe->DPSinkCapability[DP_ID].LinkSpeed / TimingReg.DCLK;
        // dwTemp1 = (TimingReg.HorTotal + 5*8) - (TimingReg.HorDisEnd + 1*8);
        // dwTemp3 = ((dwTemp1 * dwTemp2) & 0x00000FFF ) << 15;
        dwTemp1 = (pTimingTbl->HTotal) - (pTimingTbl->HDisEnd);
        // Prevent being divided by zero
        dwTemp3 = ((((dwTemp1 * pcbe->DPSinkCaps[DPIndex].LinkSpeed / 10000) /
                DClk) & 0x00000FFF ) - 35) << 15;
        dwTemp3 &= 0x07ff8000;

        // dwTemp1 = (TimingReg.HorTotal + 5*8) * ulTemp2;
        dwTemp1 = (((pTimingTbl->HTotal) * pcbe->DPSinkCaps[DPIndex].LinkSpeed / 10000) /
                DClk) - 35;
        dwTemp1 &= 0x00007FFF;

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC6C8), (dwTemp3 | dwTemp1));

        // M/N = Dclk / Ls_clk, but N must be 32768 to work with Parade DP
        // So, N = 32768, M = Dclk * 32768 / Ls_clk
        // Mvid and Nvid are not needed if in asynchronous mode, set it anyway
        // ulTemp1 = ((TimingReg.DCLK * 1024) / pcbe->DPSinkCapability[DP_ID].LinkSpeed) * 32;
        dwTemp1 = ((DClk/10000)*32768) / (pcbe->DPSinkCaps[DPIndex].LinkSpeed / 10000) ;
                    
        if (pcbe->DPSinkCaps[DPIndex].bpc == 6)
            dwTemp1 = (dwTemp1 & 0x00FFFFFF);
        else if (pcbe->DPSinkCaps[DPIndex].bpc == 8)
            dwTemp1 = (dwTemp1 & 0x00FFFFFF) | 0x20000000;
        else if (pcbe->DPSinkCaps[DPIndex].bpc == 10)
            dwTemp1 = (dwTemp1 & 0x00FFFFFF) | 0x40000000;
        else if (pcbe->DPSinkCaps[DPIndex].bpc == 12)
            dwTemp1 = (dwTemp1 & 0x00FFFFFF) | 0x60000000;
        else if (pcbe->DPSinkCaps[DPIndex].bpc == 16)
            dwTemp1 = (dwTemp1 & 0x00FFFFFF) | 0x80000000;

        // bit[27] "VESA/CEA range"
        //if (pcbe->DPSinkCaps[DPIndex].DynamicRange == 1)
        //    dwTemp1 |= 0x08000000;

        // bit[28] "YCbCr colorimetry" ITU-R BT601-5/ITU-R BT709-5
        //if (pcbe->DPSinkCaps[DPIndex].YCbCrCoefficients == 1)
        //    dwTemp1 |= 0x10000000;

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC6CC), dwTemp1);

        // MMC6D0, DP HTotal attribute data
        if(pTimingTbl->Interlaced)
            dwTemp1 = (pTimingTbl->VTotal) << 16;
        else
            dwTemp1 = (pTimingTbl->VTotal) << 16;
        dwTemp1 |= (pTimingTbl->HTotal);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC6D0), dwTemp1);

        // MMC6D4, DP H/V start attribute data (from leading edge of Sync)
        if(pTimingTbl->Interlaced)
            dwTemp1 = ((pTimingTbl->VTotal) - pTimingTbl->VSyncStart) << 16;
        else
            dwTemp1 = ((pTimingTbl->VTotal) - pTimingTbl->VSyncStart) << 16;
        dwTemp1 |= ((pTimingTbl->HTotal) - pTimingTbl->HSyncStart);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC6D4), dwTemp1);

        // MMC6D8, DP H/V Sync Polarity, Width attribute data
        dwTemp1 = (pTimingTbl->VSyncEnd - pTimingTbl->VSyncStart) << 16;
        
        //dwTemp1 = ((TimingReg.VerSyncEnd&0x0F) - (TimingReg.VerSyncStart&0x0F)) << 16;
        dwTemp1 |= (pTimingTbl->HSyncEnd - pTimingTbl->HSyncStart);
        //cbBiosMMIOWriteReg_dst(pcbe, SR_3A, 0x00, 0x38, CBIOS_NOIGAENCODERINDEX);
        if (pTimingTbl->HPolarity & CBIOS_NEGATIVE)
        {
            //cbBiosMMIOWriteReg_dst(pcbe, SR_3A, 0x80, 0x38, CBIOS_NOIGAENCODERINDEX);
            dwTemp1 |= 0x00008000;
        }
        if (pTimingTbl->VPolarity * CBIOS_NEGATIVE)
        {
            //cbBiosMMIOWriteReg_dst(pcbe, SR_3A, 0x40, 0x38, CBIOS_NOIGAENCODERINDEX);
            dwTemp1 |= 0x80000000;
        }
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC6D8), dwTemp1);

        // MMC6DC, DP H/V display attribute data
        dwTemp1 = (pTimingTbl->VDisEnd) << 16;
        dwTemp1 |= (pTimingTbl->HDisEnd);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC6DC), dwTemp1);

        // MMC690, DP Nvid attribute data, N=32768
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC690), 0x00008000);

        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EnableFlagReg), 0x3300000D);

        cbControlBLSignalForEDP(pcbe, TRUE);
       
    }   
}

void cbDPDeviceDetect(PCBIOS_EXTENSION pcbe, IN UINT32 detectDev, OUT BOOL *pbAttached)
{
    DWORD mmC730 = 0, mmC7B0 = 0;
    AUX_CONTROL_UMA AUX;
    BOOL IsHDMI, LinkTrainingLost = FALSE;
    BYTE EDID_buff[EDID1_X_BLOCKSIZE*2];
    CBIOS_PARAM_GET_EDID CBParamGetEdid;
    DWORD               LaneAlign = 0;
    DWORD               RequestVoltage[4];
    DWORD               RequestPreEmph[4];
    DWORD               LaneStatus[4];
    DWORD               i = 0;

    //cbDelayMicroSeconds(500);
     
    if(detectDev != S3_DP2) 
    {
        cbDPDualModeDetect(pcbe, DP1);

        if(pcbe->DPSinkCaps[DP1].DualMode)
        {
            if(detectDev == S3_DP)
            {
                *pbAttached = FALSE;
                return;
            }
            else
            {   
                CBParamGetEdid.DisplayDeviceDWord = detectDev;
                CBParamGetEdid.EdidBuffer = EDID_buff;
                CBParamGetEdid.EdidBufferLen = EDID1_X_BLOCKSIZE*2;
                CBParamGetEdid.type = EDID_DIGITAL;
                if(cbIsEDIDCKMSame(pcbe, detectDev, &CBParamGetEdid))
                {
                    cbDbgPrint(0,"cbDPDeviceDetect : EDID check sum byte same as previous!\n");
                }
                else
                {
                    if(!cbGetEDID_UMA(pcbe, &CBParamGetEdid))
                    {
                        //EDID NOT valid
                        *pbAttached = FALSE;
                        return;
                    }
                }
                
                //If we got real EDID or EDID buffer is valid, then distiguish HDMI/DVI
                IsHDMI = cbIsHDMIOUIExistInEDID(CBParamGetEdid.EdidBuffer, CBParamGetEdid.EdidBufferLen);
                if(detectDev & S3_HDMI)
                {
                    *pbAttached = IsHDMI;
                }
                else
                {
                    //HDMI connected, so DVI/DVI2 set to NOT connected
                    *pbAttached = !IsHDMI;
                }
            }      
        }
        else    // not Dual-Mode
        {
            if(detectDev == S3_DP)
            {
                // VT3410 A2 has fixed hotplug function. We can easily jude if there is any device attaced on.
                if(!pcbe->ChipCaps.DP_FOR_410_A0_A1)
                {
                    mmC730 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1SWAUXReg));
                    if((mmC730 & 0x40000000) == 0x00000000)
                    {
                        cbDbgPrint(0,"DP device HPD : %d\n", ((mmC730 >> 30) & 0xF));
                        *pbAttached = FALSE;
                        return;
                    }
                }
                
                // check if we can get DPCD
                cbDPInitEPHY(pcbe, DP1);

                AUX.Function = AUX_READ;
                AUX.Offset = 0;
                AUX.Length = 0xC;

                if(cbDPAuxChRW(pcbe, &AUX, DP1))
                {
                    *pbAttached = TRUE;
                    cbDPInitSettings(pcbe, DP1);

                    // IRQ
                    cbDPGetTrainingData(pcbe, DP1, LaneStatus, &LaneAlign, RequestVoltage, RequestPreEmph);
                    if(!LaneAlign) LinkTrainingLost = TRUE;
                    if(!LinkTrainingLost)
                    {
                        for(i = 0; i < pcbe->DPSinkCaps[DP1].LaneNumber; i++)
                        {
                            if(LaneStatus[i] != 0x7)
                                LinkTrainingLost = TRUE;
                        }
                    }
                    if(LinkTrainingLost && pcbe->devicepowerstate[DPbit] == S3PM_ON)
                    {
                        //cbSetDPPowerState(pcbe, S3PM_OFF);
                        CBParamGetEdid.DisplayDeviceDWord = detectDev;
                        CBParamGetEdid.EdidBuffer = EDID_buff;
                        CBParamGetEdid.EdidBufferLen = EDID1_X_BLOCKSIZE*2;
                        CBParamGetEdid.type = EDID_DIGITAL;
                        cbGetEDID_UMA(pcbe, &CBParamGetEdid);
                        cbSetDPPowerState(pcbe, pcbe->devicepowerstate[DPbit]);
                    }
                }
                else
                    *pbAttached = FALSE;
            }
            else    // DP detect
                *pbAttached = FALSE;
        }
    }
    else    // DP2
    { 
        if(pcbe->ChipCaps.UseEDPOnDP2 && pcbe->IsFirstTimeDetecDP2onEDP == TRUE)
        {
            if(pcbe->devicepowerstate[DP2bit] == S3PM_OFF)
		        cbControlVDDSignalForEDP(pcbe, TRUE);
        }
        else
        {   
            //In case of using EDP on DP2, device of DP2 always returns connected. 
            if(pcbe->ChipCaps.UseEDPOnDP2)
            {
    			*pbAttached = TRUE; 
    				return;	
            }
        }
        
        // VT3410 A2 has fixed hotplug function. We can easily jude if there is any device attaced on.
        if(!pcbe->ChipCaps.DP_FOR_410_A0_A1)
        {
            mmC7B0 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2SWAUXReg));
            if((mmC7B0 & 0xC0000000) == 0x80000000)
            {
                cbDbgPrint(0,"DP2 device HPD : %d\n", ((mmC7B0 >> 30) & 0xF));
                *pbAttached = FALSE;
                return;
            }
        }
        
        // check if we can get DPCD
        cbDPInitEPHY(pcbe, DP2);

        AUX.Function = AUX_READ;
        AUX.Offset = 0;
        AUX.Length = 0xC;

        if(cbDPAuxChRW(pcbe, &AUX, DP2))
        {
            *pbAttached = TRUE;
            cbDPInitSettings(pcbe, DP2);

            // IRQ
            cbDPGetTrainingData(pcbe, DP2, LaneStatus, &LaneAlign, RequestVoltage, RequestPreEmph);
            if(!LaneAlign) LinkTrainingLost = TRUE;
            if(!LinkTrainingLost)
            {
                for(i = 0; i < pcbe->DPSinkCaps[DP2].LaneNumber; i++)
                {
                    if(LaneStatus[i] != 0x7)
                        LinkTrainingLost = TRUE;
                }
            }
            if(LinkTrainingLost && pcbe->devicepowerstate[DP2bit] == S3PM_ON)
                cbSetDP2PowerState(pcbe, pcbe->devicepowerstate[DP2bit]);
        }
        else
            *pbAttached = FALSE;

        if(pcbe->ChipCaps.UseEDPOnDP2 && pcbe->IsFirstTimeDetecDP2onEDP == TRUE)
        {
            if(pcbe->devicepowerstate[DP2bit] == S3PM_OFF)
            {
                cbControlVDDSignalForEDP(pcbe, FALSE);
            }
            pcbe->IsFirstTimeDetecDP2onEDP = FALSE;
        }
    }
}

void cbDPDualModeDetect(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{
    I2C_CONTROL_UMA i2c;

    i2c.SlaveAddr = 0xA0;
    i2c.IndexData = 0x00;
    i2c.Flags = 0;

    if(cbHDMII2CReadByte(pcbe, &i2c) == TRUE)
        pcbe->DPSinkCaps[DPIndex].DualMode = TRUE;
    else
        pcbe->DPSinkCaps[DPIndex].DualMode = FALSE;

    if(cbHDMII2CReadByte(pcbe, &i2c) == TRUE)
        pcbe->DPSinkCaps[DPIndex].DualMode = TRUE;
    else
        pcbe->DPSinkCaps[DPIndex].DualMode = FALSE;

    if(cbHDMII2CReadByte(pcbe, &i2c) == TRUE)
        pcbe->DPSinkCaps[DPIndex].DualMode = TRUE;
    else
        pcbe->DPSinkCaps[DPIndex].DualMode = FALSE;
    
}

void cbDPLinkTrainginPreset(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{
    ULONG       mmC618, mmC698, mmC740, mmC7CC, mmC74C, dwTemp;
    DWORD       BitRate = pcbe->DPSinkCaps[DPIndex].LinkSpeed;
    DWORD       LaneNum = pcbe->DPSinkCaps[DPIndex].LaneNumber;

    if(DPIndex == DP1)
    {
                //---------------HW Link Training Core----------------
        // reset HW Link Training
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1NAUDCtlReg),
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP1NAUDCtlReg)) | 0x80000000));
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1NAUDCtlReg),
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP1NAUDCtlReg)) & 0x7FFFFFFF));

        mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0)) & 0x3FF800FF;
        if(pcbe->DPSinkCaps[DPIndex].LinkSpeed == 1620000)
            mmC740 |= 0x0004BE01;
        else
            mmC740 |= 0x00029E01;         // for 2.7 Ghz max capability
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740);

        // set LinkSpeed and LaneCount to LinkTraining Control Register
        dwTemp = ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) & 0xFFFF0000;
        dwTemp |= (BitRate == 2700000) ? 0x00002002 : 0;
        dwTemp |= (LaneNum << 7);
        dwTemp = ((dwTemp & 0x7FFFFFFF) | 0x0000003C);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg), dwTemp);

        // for DP1, SW LT control should set C74C[0] = 0
        mmC74C = ReadMMIOUlong(CB_MMIO_OFFSET(0xC74C)) & ~0x1;
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC74C), mmC74C);

        cbDPResetAux(pcbe, DPIndex);

        // reset PISO
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg1),
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg1)) & 0x00FFFFFF) | 0xFF000000);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg1),
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg1)) & 0x00FFFFFF) | 0xAA000000);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg1),
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg1)) & 0x00FFFFFF) | 0x00000000);

        mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0))& ~0x06000000; //make sure Tpll/Tpll reg are off
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740);

        cbDelayMicroSeconds(375);

        mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0)) | 0x06000000;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740);

        mmC618 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC618)) | 0x1;
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC618), mmC618); 
    }
    if(DPIndex == DP2)
    {
                //---------------HW Link Training Core----------------
        // reset HW Link Training
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2NAUDCtlReg),
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP2NAUDCtlReg)) | 0x80000000));
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2NAUDCtlReg),
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP2NAUDCtlReg)) & 0x7FFFFFFF));

        mmC7CC = ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg3)) & 0x0C7000FF;
        //  1.6 G
        if(pcbe->DPSinkCaps[DPIndex].LinkSpeed == 1620000)
            mmC7CC |= 0x0002BE00;
        else    // 2.7G
            mmC7CC |= 0x00019E00;
        mmC7CC |= 0xF1080001;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg3), mmC7CC);
        
        // set LinkSpeed and LaneCount to LinkTraining Control Register
        dwTemp = ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) & 0xFFFF0000;
        dwTemp |= (BitRate == 2700000) ? 0x00002002 : 0;
        dwTemp |= (LaneNum << 7);
        dwTemp = ((dwTemp & 0x7FFFFFFF) | 0x0000003C);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg), dwTemp);

        // for DP2, SW LT control should set C74C[0] = 1
        mmC74C = (ReadMMIOUlong(CB_MMIO_OFFSET(0xC74C)) & ~0x1) | 0x1;
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC74C), mmC74C);

        cbDPResetAux(pcbe, DPIndex);

        // reset PISO
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2),
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2)) & 0xFFFFFF00) | 0x000000FF);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2),
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2)) & 0xFFFFFFFF) | 0x000000AA);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2),
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2)) & 0xFFFFFFFF) | 0x00000000);

        mmC698 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC698)) | 0x1;
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC698), mmC698); 
    }
}

BOOL cbDPLinkTrainingHW(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{
    BOOL                bStatus = FALSE;
    AUX_CONTROL_UMA     AUX;
    DWORD               BitRate = pcbe->DPSinkCaps[DPIndex].LinkSpeed;
    DWORD               LaneNum = pcbe->DPSinkCaps[DPIndex].LaneNumber;
    DWORD               i = 0;

    DWORD               dwHwTimerBefore = 0, dwHwTimerAfter = 0;
    
    // Set LINK_BW_SET and LANE_COUNT_SET fields of DPCD
    AUX.Function = AUX_WRITE;
    AUX.Offset = 0x100;
    AUX.Length = 0x2;
    AUX.Data[0] = (BitRate == 2700000) ? 0x0A : 0x06;
    AUX.Data[1] = (BYTE)(LaneNum);
    AUX.Data[1] |= (pcbe->DPSinkCaps[DPIndex].EnhancedMode) ? 0x80 : 0x0;

    //PAC DP2 issue, Fixed the link speed to 162MHz, because PAC DP-2 is a fixed value.
    if((DPIndex == DP2)&&(dp2LinkspeedConf == 162)){
        pcbe->DPSinkCaps[DPIndex].LinkSpeed = 1620000;
        AUX.Data[0] =0x06;
        BitRate = 1620000;
    }        
        
    if(!cbDPAuxChRW(pcbe, &AUX, DPIndex)){
        cbDbgPrint(0,"cbDPLinkTrainingHW: AUX Error before Link Training!!\n");
        return FALSE;
    }

    // reset Aux, PISO, enable Scramble
    cbDPLinkTrainginPreset(pcbe, DPIndex);

    if(DPIndex == DP1)
    {
        //Enable LT timer
        dwHwTimerBefore = ReadMMIOUlong(CB_MMIO_OFFSET(DP1SWAUXReg)) & 0x03FFFFC0;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1SWAUXReg), ReadMMIOUlong(CB_MMIO_OFFSET(DP1SWAUXReg)) | 0x20);
            
        // Enable HW Link Training
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg), 
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) | 0x00000001));
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg), 
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) & 0xFFFFFFFE));

        i = 0;
        do
        {
            cbDelayMicroSeconds(50);
            dwHwTimerAfter = ReadMMIOUlong(CB_MMIO_OFFSET(DP1SWAUXReg)) & 0x03FFFFC0;
            dwHwTimerAfter = (0x04000000 - dwHwTimerBefore + dwHwTimerAfter) % 0x04000000;
            dwHwTimerAfter >>= 6;
            dwHwTimerAfter /= 27;
            i++;

            if(ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) & 0x80000000)
            {
                if((ReadMMIOUlong(CB_MMIO_OFFSET(DP1EnableFlagReg)) & 0x30000000) == 0x30000000)
                {
                    WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg), ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) & 0x7FFFFFFE);
                    bStatus = TRUE;
                    break;
                }
            }
        }while(dwHwTimerAfter < 30000);

        if(BitRate == 2700000 && !bStatus)
        {
            PGFXTimingTable  pTimingTbl = &(pcbe->DPSinkCaps[DPIndex].TimingTbl);
            DWORD DClk = 0;

            //DClk = pTimingTbl->HTotal * pTimingTbl->VTotal * (pTimingTbl->rRateX100/100) / 10;
            BYTE CLK_M = (BYTE)((pTimingTbl->vPLL & 0xFF0000) >> 16);
            BYTE CLK_R = (BYTE)((pTimingTbl->vPLL & 0x00FF00) >> 8);
            BYTE CLK_N = (BYTE) (pTimingTbl->vPLL & 0x0000FF);
            
            //clear last link training fail status
            WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg), 
                    (ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) & 0x7FFFFFFE));

            // check for down speed acceptable
        	DClk = cbCalcClkFromMRN(pcbe, CLK_M, CLK_R, CLK_N);
        	DClk /= 1000000;
        	if((DClk*4) > (LaneNum*162))
        	{
        	    cbDbgPrint(0,"cbDPLinkTrainingHW: Can't down speed for current bandwidth required!!\n");
        	    return bStatus;
        	}
        	
            //clear link training pattern
                        
            pcbe->DPSinkCaps[DPIndex].LinkSpeed = 1620000;
            // Set LINK_BW_SET and LANE_COUNT_SET fields of DPCD
            AUX.Function = AUX_WRITE;
            AUX.Offset = 0x100;
            AUX.Length = 0x3;
            AUX.Data[0] = 0x06;
            AUX.Data[1] = (BYTE)(LaneNum);
            AUX.Data[1] |= (pcbe->DPSinkCaps[DPIndex].EnhancedMode) ? 0x80 : 0x0;
            AUX.Data[2] = 0;
            if(!cbDPAuxChRW(pcbe, &AUX, DPIndex)){
                cbDbgPrint(0,"cbDPLinkTrainingHW: AUX Error before Link Training!!\n");
                return FALSE;
            }

            // reset Aux, PISO, enable Scramble
            cbDPLinkTrainginPreset(pcbe, DPIndex);

            // Enable HW Link Training
            WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg), 
               (ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) | 0x00000001));
            WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg), 
                (ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) & 0xFFFFFFFE));
        }   
    }
    if(DPIndex == DP2)
    { 
        //Enable LT timer
        dwHwTimerBefore = ReadMMIOUlong(CB_MMIO_OFFSET(DP2SWAUXReg)) & 0x03FFFFC0;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2SWAUXReg), ReadMMIOUlong(CB_MMIO_OFFSET(DP2SWAUXReg)) | 0x20);
            
        // Enable HW Link Training
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg), 
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) | 0x00000001));
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg), 
            (ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) & 0xFFFFFFFE));

        i = 0;
        do
        {
            cbDelayMicroSeconds(50);
            dwHwTimerAfter = ReadMMIOUlong(CB_MMIO_OFFSET(DP2SWAUXReg)) & 0x03FFFFC0;
            dwHwTimerAfter = (0x04000000 - dwHwTimerBefore + dwHwTimerAfter) % 0x04000000;
            dwHwTimerAfter >>= 6;
            dwHwTimerAfter /= 27;
            i++;

            if(ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) & 0x80000000)
            {
                if((ReadMMIOUlong(CB_MMIO_OFFSET(DP2EnableFlagReg)) & 0x30000000) == 0x30000000)
                {
                    WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg), ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) & 0x7FFFFFFE);
                    bStatus = TRUE;
                    break;
                }
            }
        }while(dwHwTimerAfter < 30000);

        if(BitRate == 2700000 && !bStatus)
        {
            PGFXTimingTable  pTimingTbl = &(pcbe->DPSinkCaps[DPIndex].TimingTbl);
            DWORD DClk = 0;

            //DClk = pTimingTbl->HTotal * pTimingTbl->VTotal * (pTimingTbl->rRateX100/100) / 10;
            BYTE CLK_M = (BYTE)((pTimingTbl->vPLL & 0xFF0000) >> 16);
            BYTE CLK_R = (BYTE)((pTimingTbl->vPLL & 0x00FF00) >> 8);
            BYTE CLK_N = (BYTE) (pTimingTbl->vPLL & 0x0000FF);
            
            //clear last link training fail status
            WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg), 
                (ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) & 0x7FFFFFFE));


            // check for down speed acceptable
        	DClk = cbCalcClkFromMRN(pcbe, CLK_M, CLK_R, CLK_N);
        	DClk /= 1000000;
        	if((DClk*4) > (LaneNum*162))
        	{
        	    cbDbgPrint(0,"cbDPLinkTrainingHW: Can't down speed for current bandwidth required!!\n");
        	    return bStatus;
        	}
        
            //clear link training pattern
                        
            pcbe->DPSinkCaps[DPIndex].LinkSpeed = 1620000;
            // Set LINK_BW_SET and LANE_COUNT_SET fields of DPCD
            AUX.Function = AUX_WRITE;
            AUX.Offset = 0x100;
            AUX.Length = 0x3;
            AUX.Data[0] = 0x06;
            AUX.Data[1] = (BYTE)(LaneNum);
            AUX.Data[1] |= (pcbe->DPSinkCaps[DPIndex].EnhancedMode) ? 0x80 : 0x0;
            AUX.Data[2] = 0;
            if(!cbDPAuxChRW(pcbe, &AUX, DPIndex)){
                cbDbgPrint(0,"cbDPLinkTrainingHW: AUX Error before Link Training!!\n");
                return FALSE;
            }

            // reset Aux, PISO, enable Scramble
            cbDPLinkTrainginPreset(pcbe, DPIndex);

            // Enable HW Link Training
            WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg), 
                (ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) | 0x00000001));
            WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg), 
                (ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) & 0xFFFFFFFE));
        }
    }

    return bStatus;
}

BOOL cbDPLinkTrainingSW(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{
    AUX_CONTROL_UMA     AUX;
    BOOL                bStatus = TRUE;

    // ========= STEP 1. CR pattern
    //      Update TRAINING_PATTERN_SET and TRAINING_LANEx_SET fields of DPCD.
    //      First set voltage swing level 0, pre-Emphasis = 0.
    bStatus = cbDPLinkTrainingSW_CR(pcbe, DPIndex);

    // ========= STEP 2. EQ pattern
    if(bStatus)
        bStatus = cbDPLinkTrainingSW_EQ(pcbe, DPIndex);

    // ========= STEP 3. if Link Training failed, down Link Rate
    if(!bStatus && pcbe->DPSinkCaps[DPIndex].LinkSpeed == 2700000)    
    {
        // Link Training fail at CR Statge, try to lower link rate
        cbDbgPrint(0,"cbDPLinkTrainingSW : Link training Fail at link speed 2.7 Gbps\n");
        pcbe->DPSinkCaps[DPIndex].LinkSpeed = 1620000;

        cbDbgPrint(0,"cbDPInitSettings : Lane Count = %d, Link Speed = %d\n", pcbe->DPSinkCaps[DPIndex].LaneNumber, pcbe->DPSinkCaps[DPIndex].LinkSpeed);
        // ========= STEP 3-1. CR pattern
        bStatus = cbDPLinkTrainingSW_CR(pcbe, DPIndex);

        // ========= STEP 3-2. EQ pattern
        if(bStatus)
            bStatus = cbDPLinkTrainingSW_EQ(pcbe, DPIndex);
    }

    // ========= STEP 4. End of Link Training, set TRAINING_PATTERN_SET = 11b
    if(DPIndex == DP1)
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg),
            ((ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) & 0xFFFFE7FF) | 0x00001800));
    if(DPIndex == DP2)
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg),
            ((ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) & 0xFFFFE7FF) | 0x00001800));

    AUX.Function = AUX_WRITE;
    AUX.Offset = 0x102;
    AUX.Length = 0x1;
    AUX.Data[0] = 0x0;
    if(!cbDPAuxChRW(pcbe, &AUX, DPIndex))
        cbDbgPrint(0,"cbDPLinkTrainingSW: AUX Error after Link Training!!\n");

    if(bStatus)
        cbDbgPrint(0,"cbDPLinkTrainingSW: Successful Link Training by SW!!\n");
    else
        cbDbgPrint(0,"cbDPLinkTrainingSW: Unsuccessful Link Training by SW...\n");

    return bStatus;
}

BOOL cbDPLinkTrainingSW_CR(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{
    DWORD               BitRate = pcbe->DPSinkCaps[DPIndex].LinkSpeed;
    DWORD               LaneNum = pcbe->DPSinkCaps[DPIndex].LaneNumber;
    DWORD               LaneAlign = 0;
    AUX_CONTROL_UMA     AUX;
    BOOL                bStatus = TRUE;
    DWORD               CurrentVoltage, RequestVoltage[4];
    DWORD               CurrentPreEmph, RequestPreEmph[4];
    DWORD               LaneStatus[4];
    DWORD               CrSameVoltageCheck[4];
    BOOL                bNeedAdjustSetting = TRUE;
    DWORD               i, CurrentSetting = 0;
    BOOL                MaxVoltageReached = FALSE;

    if(DPIndex >= CBIOS_MAX_DP_DEVICES_NUM)
    {
        cbDbgPrint(1, "cbDPLinkTrainingSW_CR: DPIndex is out of range!\n");
        return FALSE;
    }

    // reset Aux, PISO, enable Scramble
    cbDPLinkTrainginPreset(pcbe, DPIndex);

    // Set LINK_BW_SET and LANE_COUNT_SET fields of DPCD
    // Set TRAINING_PATTERN_SET to 01h indicates CR stage starts (102h [1:0])
    AUX.Function = AUX_WRITE;
    AUX.Offset = 0x100;
    AUX.Length = 0x3;
    AUX.Data[0] = (BitRate == 2700000) ? 0x0A : 0x06;
    AUX.Data[1] = (BYTE)(LaneNum);
    AUX.Data[1] |= (pcbe->DPSinkCaps[DPIndex].EnhancedMode) ? 0x80 : 0x0;
    AUX.Data[2] = 0x01;
    if(!cbDPAuxChRW(pcbe, &AUX, DPIndex))
        cbDbgPrint(0,"cbDPLinkTrainingSW_CR: AUX Error before Link Training!!\n");

	cbDelayMicroSeconds(500);
    // Begin CR: [10]=1: enable SW link training; clear[29:14]
    if(DPIndex == DP1)
    {
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg), (ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) & ~0x3FFFC000));
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg), (ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) | 0x00000C00));
    }
    if(DPIndex == DP2)
    {
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg), (ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) & ~0x3FFFC000));
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg), (ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) | 0x00000C00));
    }

    // Set Request Voltage Swing/Pre-Emphasis = 0
    for(i = 0; i < 4; i++)
    {
        RequestVoltage[i] = 0;
        RequestPreEmph[i] = 0;
        CrSameVoltageCheck[i] = 0;
    }

    while(bNeedAdjustSetting)  // Clock Recovery Pattern Training
    {
        // ========= STEP 1. Set current Voltage Swing/Pre-Emphasis
        bStatus = cbDPSetTrainingData(pcbe, DPIndex, RequestVoltage, RequestPreEmph);
        if(!bStatus)
        {
            cbDbgPrint(0,"cbDPLinkTrainingSW_CR: Set Lane Status/ Voltage Swing/ Pre-Emphasis FAIL!\n");
            return bStatus;
        }

        // ======== STEP 2. Get current Settings
        if(DPIndex == DP1)
            CurrentSetting = ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg));
        if(DPIndex == DP2)
            CurrentSetting = ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg));

        CurrentVoltage = (CurrentSetting >> 14) & 0x3;
        CurrentPreEmph = (CurrentSetting >> 16) & 0x3;
        
        // ========= STEP 3. Check current lane status
        // get DPCD 202-207, Lane Status/Voltage Swing/Pre-Emphasis
        cbDelayMicroSeconds(100);
        bStatus = cbDPGetTrainingData(pcbe, DPIndex, LaneStatus, &LaneAlign, RequestVoltage, RequestPreEmph);
        if(!bStatus)
        {
            cbDbgPrint(0,"cbDPLinkTrainingSW_CR: Get Lane Status/ Voltage Swing/ Pre-Emphasis FAIL!\n");
            return bStatus;
        }
        
        // Assume CR Done for all Lanes
        bNeedAdjustSetting = FALSE; 
        
        if(CurrentVoltage == 0x3)
            MaxVoltageReached = TRUE;
        // Record same voltage swing setting failure times
        CrSameVoltageCheck[CurrentVoltage]++;
        
        for(i = 0; i < LaneNum; i++)
        {
            CurrentVoltage = (CurrentSetting >> (14 + i*4)) & 0x3;

            // Check Lane CR Status
            if(!(LaneStatus[i] & BIT0))
            {
                bNeedAdjustSetting = TRUE;          // need to adjust Voltage swing settings
                cbDbgPrint(0,"cbDPLinkTrainingSW_CR: CurrentVoltage[%d] = %d, RequestVoltage[%d] = %d\n", i, CurrentVoltage, i, RequestVoltage[i]);
            }
        }

        if(MaxVoltageReached && bNeedAdjustSetting)
        {
            bStatus = FALSE;
            cbDbgPrint(0,"cbDPLinkTrainingSW_CR: Check MAX Voltage Swing Settings FAIL!\n");
            return bStatus;
        }

        if(CrSameVoltageCheck[CurrentVoltage] == 5 && bNeedAdjustSetting)
        {
            bStatus = FALSE;
            cbDbgPrint(0,"cbDPLinkTrainingSW_CR: Same Voltage Swing Settings over 5 times FAIL!\n");
            return bStatus;
        }
    }

    return bStatus;
}

BOOL cbDPLinkTrainingSW_EQ(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{
    DWORD               LaneNum = pcbe->DPSinkCaps[DPIndex].LaneNumber;
    DWORD               LaneAlign = 0;
    AUX_CONTROL_UMA     AUX;
    BOOL                bStatus = TRUE;
    BOOL                bNeedAdjustSetting = TRUE;
    DWORD               RequestVoltage[4];
    DWORD               RequestPreEmph[4];
    DWORD               LaneStatus[4];
    DWORD               i, LoopCount = 0, CurrentSetting = 0;

    // Begin "EQ": equlization [12:11]=10b: set "Channel Equalization" state
    if(DPIndex == DP1)
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg),
            ((ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) & 0xFFFFE7FF) | 0x00001000));
    if(DPIndex == DP2)
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg),
            ((ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) & 0xFFFFE7FF) | 0x00001000));

    // DPCD102h=02h, Training Pattern 2
    AUX.Function = AUX_WRITE;
    AUX.Offset = 0x102;
    AUX.Length = 0x1;
    AUX.Data[0] = 0x2;
    if(!cbDPAuxChRW(pcbe, &AUX, DPIndex))
        cbDbgPrint(0,"cbDPLinkTrainingSW_EQ: AUX Error before Link Training!!\n");

    // get current Voltage Swing/Pre-Emphasis
    if(DPIndex == DP1)
        CurrentSetting = ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg));
    if(DPIndex == DP2)
        CurrentSetting = ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg));
        
    for(i = 0; i < LaneNum; i++)
    {
        RequestVoltage[i] = (CurrentSetting >> (14 + i*4)) & 0x3;
        RequestPreEmph[i] = (CurrentSetting >> (16 + i*4)) & 0x3;
    }

    while(bNeedAdjustSetting)
    {      
        // ========== STEP 1.  Set current Voltage Swing/Pre-Emphasis
        bStatus = cbDPSetTrainingData(pcbe, DPIndex, RequestVoltage, RequestPreEmph);
        if (!bStatus)
        {
            cbDbgPrint(0,"cbDPLinkTrainingSW_EQ: Set Lane Status/ Voltage Swing/ Pre-Emphasis FAIL!\n");
            return bStatus;
        }
        
        // ========== STEP 2.  Check Current Lane Status
        cbDelayMicroSeconds(400);
        bStatus = cbDPGetTrainingData(pcbe, DPIndex, LaneStatus, &LaneAlign ,RequestVoltage, RequestPreEmph);
        if (!bStatus)
        {
            cbDbgPrint(0,"cbDPLinkTrainingSW_EQ: Get Lane Status/ Voltage Swing/ Pre-Emphasis FAIL!\n");
            return bStatus;
        }

        for (i = 0; i < LaneNum; i++)
        {
            // Check Lane CR status
            if(!(LaneStatus[i] & BIT0)) // CR Done bits lost
            {
                bStatus = FALSE;
                cbDbgPrint(0,"cbDPLinkTrainingSw_EQ: CR_DONE bits lost when EQ!\n");
                return bStatus;
            }
        }

        // Assume all Lanes are normal
        bNeedAdjustSetting = FALSE;
        // Check interlane_aligned bit
        if (!LaneAlign)
        {
            bNeedAdjustSetting = TRUE;
        }
        else
        {
            // check LANEx_CHANNEL_EQ_DONE and LANEx_SYMBOL_LOCKED
            for (i = 0; i < LaneNum; i++)
            {
                if((LaneStatus[i] & 0x6) != 0x6)
                {
                    bNeedAdjustSetting = TRUE;
                    break;
                }
            }
        }

        LoopCount++;
        if (LoopCount > 5)
        {
            cbDbgPrint(0, "cbDPLinkTrainingSw_EQ: EQ can't be done within 5 loop!\n");
            bStatus = FALSE;
            break;
        }
    }

    return bStatus;
}

BOOL cbDPGetTrainingData(PCBIOS_EXTENSION pcbe, 
                            DWORD  DPIndex, 
                            DWORD  LaneStatus[4],
                            DWORD* LaneAlign,
                            DWORD  RequestVoltage[4], 
                            DWORD  RequestPreEmph[4])
{
    AUX_CONTROL_UMA     AUX;
    DWORD               LaneNum = pcbe->DPSinkCaps[DPIndex].LaneNumber, i;
    BOOL                bStatus = TRUE;

    // aid for DP CTS. must read 0x200~0x205 while IRQ HPD
    AUX.Function = AUX_READ;
    AUX.Offset = 0x200;
    AUX.Length = 0x6;
    bStatus = cbDPAuxChRW(pcbe, &AUX, DPIndex);

    AUX.Function = AUX_READ;
    AUX.Offset = 0x202;
    AUX.Length = 0x6;
    bStatus = cbDPAuxChRW(pcbe, &AUX, DPIndex);

    // Get Lace Status/ Request Voltage Swing/ Request Pre-Emphasis
    LaneStatus[0] = AUX.Data[0] & 0xF;              // 202h [3:0]
    LaneStatus[1] = (AUX.Data[0] >> 4) & 0xF;       // 202h [7:4]
    LaneStatus[2] = AUX.Data[1] & 0xF;              // 203h [3:0]
    LaneStatus[3] = (AUX.Data[1] >> 4) & 0xF;       // 203h [7:4]

    *LaneAlign = AUX.Data[2] & BIT0;                // 204h [0]

    RequestVoltage[0] = AUX.Data[4] & 0x3;          // 206h [1:0]
    RequestPreEmph[0] = (AUX.Data[4] >> 2) & 0x3;   // 206h [3:2]
    RequestVoltage[1] = (AUX.Data[4] >> 4) & 0x3;   // 206h [5:4]
    RequestPreEmph[1] = (AUX.Data[4] >> 6) & 0x3;   // 206h [7:6]
    RequestVoltage[2] = AUX.Data[5] & 0x3;          // 207h [1:0]
    RequestPreEmph[2] = (AUX.Data[5] >> 2) & 0x3;   // 207h [3:2]
    RequestVoltage[3] = (AUX.Data[5] >> 4) & 0x3;   // 207h [5:4]
    RequestPreEmph[3] = (AUX.Data[5] >> 6) & 0x3;   // 207h [7:6]

    // refer to DP spec 1.1a 3.5.3.4
    for(i = 0; i < LaneNum; i++)
    {
        while(RequestVoltage[i] + RequestPreEmph[i] > 3)
        {
            RequestPreEmph[i]--;
            cbDbgPrint(0,"cbDPGetTrainingData: Voltaget + PreEmp > 3 \n");
        }
    }

    return bStatus;
}

BOOL cbDPSetTrainingData(PCBIOS_EXTENSION pcbe, 
                            DWORD DPIndex, 
                            DWORD RequestVoltage[4], 
                            DWORD RequestPreEmph[4])
{
    AUX_CONTROL_UMA     AUX;
    DWORD               LaneNum = pcbe->DPSinkCaps[DPIndex].LaneNumber, i;
    DWORD               RequestSetting = 0;
    DWORD               DPCTLReg = 0;
    BOOL                bStatus = TRUE;

    if(DPIndex == DP1)
        DPCTLReg = (ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) & 0xC0003FFF);
    if(DPIndex == DP2)
        DPCTLReg = (ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) & 0xC0003FFF);

    for(i = 0; i < LaneNum; i++)
    {
        RequestSetting |= ((RequestVoltage[i] + RequestPreEmph[i]) << (i * 4));

        // Check Max. Voltage Swing
        if (RequestVoltage[i] == 0x3)
        {
            RequestVoltage[i] |= 0x4; // Max Swing Reached.
        }

        // Check Max. Pre_emphasis
        if (RequestPreEmph[i] == 0x3)
        {
            RequestPreEmph[i] |= 0x4; // Max Pre_emphasis Reached.
        }

        AUX.Data[i] = (BYTE)(RequestVoltage[i]);
        AUX.Data[i] |= (RequestPreEmph[i] << 3); 
    }

    // adjust driver setting
    if(DPIndex == DP1)
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg), ((RequestSetting << 14) | DPCTLReg));
    if(DPIndex == DP2)
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg), ((RequestSetting << 14) | DPCTLReg));

    // Update TRAINING_LANEx_SET  103h~106h
    AUX.Function = AUX_WRITE;
    AUX.Offset = 0x103;
    AUX.Length = LaneNum;
    bStatus = cbDPAuxChRW(pcbe, &AUX, DPIndex);

    cbDPTuningSettings(pcbe, DPIndex, RequestVoltage[0], RequestPreEmph[0]);

    return bStatus;
}

void cbDPTuningSettings(PCBIOS_EXTENSION pcbe, 
                            DWORD DPIndex, 
                            DWORD RequestVoltage, 
                            DWORD RequestPreEmph)
{
    DWORD               mmC748 = 0;

    RequestVoltage &= 0x3;
    RequestPreEmph &= 0x3;

    if(DPIndex == DP1)
    {
        mmC748 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg2)) & 0xFFFFC00D;
        
        // eye settings, according to differential voltage & de-emphasis
        switch(RequestPreEmph)
        {
        case 0:
            // 0 dB:
            switch(RequestVoltage)
            {
            // 400 mV C748[8:4]=10001, C748[1]=0
            case 0:
                mmC748 |= 0x0110;
                break;
            // 600 mV C748[8:4]=10011, C748[1]=1
            case 1:
                mmC748 |= 0x0132;
                break;
            // 800 mV C748[8:4]=11001, C748[1]=1
            case 2:
                mmC748 |= 0x0192;
                break;
            // 1200 mV C748[8:4]=01011, C748[1]=0
            case 3:
                mmC748 |= 0x00B0;
                break;
            default:
                mmC748 |= 0x0000;
                break;
            }
            break;
            
        case 1:
            // 3.5 dB:
            switch(RequestVoltage)
            {
            // 400 mV C748[8:4]=10000, C748[1]=1, C748[13:9]=00011
            case 0:
                mmC748 |= 0x0702;
                break;
            // 600 mV C748[8:4]=10111, C748[1]=1, C748[13:9]=00100
            case 1:
                mmC748 |= 0x0972;
                break;
            // 800 mV C748[8:4]=11111, C748[1]=1, C748[13:9]=01000 
            case 2:
                mmC748 |= 0x11F2;
                break;
            default:
                mmC748 |= 0x0000;
                break;
            }   
            break;
            
        case 2:
            // 6 dB:
            switch(RequestVoltage)
            {
            // 400 mV C748[8:4]=10011, C748[1]=1, C748[13:9]=01000
            case 0:
                mmC748 |= 0x1132;
                break;
            // 600 mV C748[8:4]=00000, C748[1]=0, C748[13:9]=01101
            case 1:
                mmC748 |= 0x1A00;
                break;
            default:
                mmC748 |= 0x0000;
                break;
            }
            break;
            
        case 3:
            // 9.5 dB:
            switch(RequestVoltage)
            {
            // 400 mV C748[8:4]=11001, C748[1]=1, C748[13:9]=01111
            case 0:
                mmC748 |= 0x1F92;
                break;
            default:
                mmC748 |= 0x0000;
                break;
            }
            break;
            
        default:
            break;
        }

        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg2), mmC748);
    }

    
}

void cbDPInitEPHY(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{
    if(DPIndex == DP1)
    {
        DWORD mmC740, mmC744, mmC748, mmC640, mmC618, mmC738;
        // enable Bandgap
        mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0)) & 0xFFF800E7;
        if(pcbe->DPSinkCaps[DPIndex].LinkSpeed == 2700000)
            mmC740 |= 0x00029E01;
        else
            mmC740 |= 0x0004BE01;         // for 2.7 Ghz max capability
        mmC740 |= 0x00000018; // MPLL_ISEL:C740[4:3] = 11 (37.5uA)
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740);
        cbDelayMicroSeconds(375);

        // start AUX channel, CMOP is on, Tx and Rx are off
        mmC748 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg2)) & ~0x0000C000;
        mmC748 |= 0x00004000;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg2), mmC748);
        cbDelayMicroSeconds(1500); // need 1.5 ms to start from P0 to P1

        mmC748 &= ~0x0000C000;
        mmC748 |= 0x00008000;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg2), mmC748);
        cbDelayMicroSeconds(1500); // need 1.5 ms to start from P0 to P1

        // enable Mpll and Mpll reg power
        mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0));// & ~0x06000006; //make sure Tpll/Tpll reg are off
        mmC740 |= 0x00000006;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740);
        cbDelayMicroSeconds(375);

        mmC744 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg1));
        mmC744 |= 0x00FFFF00;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg1), mmC744);
        cbDelayMicroSeconds(1500);

        mmC640 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EnableFlagReg)) | 0x00000001; // enable DP
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EnableFlagReg), mmC640);
        cbDelayMicroSeconds(375);

        // enable Tpll and Tpll reg power
        mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0)) | 0x06000000;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740);
        cbDelayMicroSeconds(375);

        // set DRV mode to DisplayPort
        cbDPDualModeDetect(pcbe, DPIndex);
        if(pcbe->DPSinkCaps[DPIndex].DualMode)
            mmC748 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg2)) & ~0x00000001;
        else
            mmC748 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg2)) | 0x00000001;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg2), mmC748);
        cbDelayMicroSeconds(750);

        // set Audio settings
        mmC738 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1NAUDCtlReg)) | 0x2A000000;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1NAUDCtlReg), mmC738);

        mmC618 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC618)) | 0x1;
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC618), mmC618); 
        
    }
    if(DPIndex == DP2)
    {       
        DWORD mmC7CC, mmC7C8, mmC7C0, mmC7C4, mmC6C0, mmC698, mmC7B8;

        mmC7C0 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg0)) | 0x1;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg0), mmC7C0);

        mmC7CC = ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg3)) & 0x0C7000FF;

        //PAC DP2 issue, Fixed the link speed to 162MHz, because PAC DP-2 is a fixed value.
        if((DPIndex == DP2)&&(dp2LinkspeedConf == 162))
            pcbe->DPSinkCaps[DPIndex].LinkSpeed = 1620000;
        
        //  1.6 G
        if(pcbe->DPSinkCaps[DPIndex].LinkSpeed == 1620000)
            mmC7CC |= 0x0002BE00;
        else    // 2.7G
            mmC7CC |= 0x00019E00;
        mmC7CC |= 0xF1080001;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg3), mmC7CC);

        // start AUX channel, CMOP is on, Tx and Rx are off
        mmC7C8 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2)) & ~0x30000000;
        mmC7C8 |= 0x10000000;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2), mmC7C8);
        //need 1.5 ms to start from P0 to P1
        cbDelayMicroSeconds(1500);

        mmC7C8 &= ~0x30000000;
        mmC7C8 |= 0x20000000;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2), mmC7C8);
        // need 1.5 ms to start from P0 to P1
        cbDelayMicroSeconds(1500);

        // enable Tpll and Tpll reg power
        mmC7CC = ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg3)) & ~0x02000000;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg3), mmC7CC);

        // [19:8] Tx power status default settings for all 4 lanes
        mmC7C0 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg0))& 0xFFF000FF;
        mmC7C0 |= 0x0000AA00;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg0), mmC7C0);
/*
        // [7:0] Tx power down mode for all 4 lanes
        // [15:8] HDMI TX output voltage swing 1200 mV for all 4 lanes
        mmC7C8 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2)) & 0xFFFF0000;
        mmC7C8 |= 0x0000FFFF;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2), mmC7C8);
        cbDelayMicroSeconds(1500); // need to wait 1.5 ms

        // [7:0] Tx power control function CMOP on / PISO off for all 4 lanes
        mmC7C8 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2)) & 0xFFFFFFAA;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2), mmC7C8);
        cbDelayMicroSeconds(1500); // need to wait 1.5 ms

        // [7:0] Tx power control function on for all 4 lanes
        mmC7C8 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2)) & 0xFFFFFF00;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg2), mmC7C8);
        cbDelayMicroSeconds(100); // need to wait 100 ns        
*/
        // [19:16] Tx transmit data for all 4 lanes
        if(!pcbe->ChipCaps.DP_FOR_410_A0_A1)
        {
            mmC7C4 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg1));
            mmC7C4 |= 0x000F0000;
        }
        else
        {
            //for 410 A0, DP2 EPHY manual setting temporary
            mmC7C4 = 0x010F604A;
            // for 410 A0 HW DP LPHY/EPHY issue
            // EPHY speed manual set enable of Lane 0
            mmC7CC = ReadMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg3)) | 0x000000C0;
            WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg3), mmC7CC);
        }
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EPHYCtlReg1), mmC7C4);

        // [0] DP2 enable
        mmC6C0 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2EnableFlagReg)) | 0x00000001;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2EnableFlagReg), mmC6C0);

        // set Audio settings
        mmC7B8 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2NAUDCtlReg)) | 0x2A000000;
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2NAUDCtlReg), mmC7B8);

        mmC698 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC698)) | 0x1;
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC698), mmC698);                  
    }
}

void cbDPSetAuxWriteBuffer(PCBIOS_EXTENSION pcbe, IN PAUX_CONTROL_UMA pAUX, DWORD DPIndex)
{
    DWORD   i = 0;
    DWORD   mmC710 = 0, mmC714 = 0, mmC718 = 0, mmC71C = 0;
    DWORD   mmC790 = 0, mmC794 = 0, mmC798 = 0, mmC79C = 0;

    if(DPIndex == DP1)
    {
        //  first clear write buffer
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1AUXWriteReg0), 0x00000000);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1AUXWriteReg1), 0x00000000);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1AUXWriteReg2), 0x00000000);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1AUXWriteReg3), 0x00000000);

        // Clear Data[i] over pAUX->Lenth
        for(i = pAUX->Length; i < 0x10; i++)
            pAUX->Data[i] = 0x00;

        mmC710 = (pAUX->Data[3]<<24) | (pAUX->Data[2]<<16) | (pAUX->Data[1]<<8) | pAUX->Data[0];
        mmC714 = (pAUX->Data[7]<<24) | (pAUX->Data[6]<<16) | (pAUX->Data[5]<<8) | pAUX->Data[4];
        mmC718 = (pAUX->Data[11]<<24) | (pAUX->Data[10]<<16) | (pAUX->Data[9]<<8) | pAUX->Data[8];
        mmC71C = (pAUX->Data[15]<<24) | (pAUX->Data[14]<<16) | (pAUX->Data[13]<<8) | pAUX->Data[12];

        WriteMMIOUlong(CB_MMIO_OFFSET(DP1AUXWriteReg0), mmC710);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1AUXWriteReg1), mmC714);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1AUXWriteReg2), mmC718);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1AUXWriteReg3), mmC71C);
    }
    if(DPIndex == DP2)
    {
        //  first clear write buffer
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2AUXWriteReg0), 0x00000000);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2AUXWriteReg1), 0x00000000);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2AUXWriteReg2), 0x00000000);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2AUXWriteReg3), 0x00000000);

        // Clear Data[i] over pAUX->Lenth
        for(i = pAUX->Length; i < 0x10; i++)
            pAUX->Data[i] = 0x00;

        mmC790 = (pAUX->Data[3]<<24) | (pAUX->Data[2]<<16) | (pAUX->Data[1]<<8) | pAUX->Data[0];
        mmC794 = (pAUX->Data[7]<<24) | (pAUX->Data[6]<<16) | (pAUX->Data[5]<<8) | pAUX->Data[4];
        mmC798 = (pAUX->Data[11]<<24) | (pAUX->Data[10]<<16) | (pAUX->Data[9]<<8) | pAUX->Data[8];
        mmC79C = (pAUX->Data[15]<<24) | (pAUX->Data[14]<<16) | (pAUX->Data[13]<<8) | pAUX->Data[12];

        WriteMMIOUlong(CB_MMIO_OFFSET(DP2AUXWriteReg0), mmC790);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2AUXWriteReg1), mmC794);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2AUXWriteReg2), mmC798);
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2AUXWriteReg3), mmC79C);
    }
}

void cbDPGetAuxReadBuffer(PCBIOS_EXTENSION pcbe, IN PAUX_CONTROL_UMA pAUX, DWORD DPIndex)
{
    DWORD   mmC720 = 0, mmC724 = 0, mmC728 = 0, mmC72C = 0;
    DWORD   mmC7A0 = 0, mmC7A4 = 0, mmC7A8 = 0, mmC7AC = 0;

    if(DPIndex == DP1)
    {
        //  first clear write buffer
        mmC720 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1AUXReadReg0));
        mmC724 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1AUXReadReg1));
        mmC728 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1AUXReadReg2));
        mmC72C = ReadMMIOUlong(CB_MMIO_OFFSET(DP1AUXReadReg3));

        pAUX->Data[0] = (BYTE)(mmC720) & 0xFF;
        pAUX->Data[1] = (BYTE)(mmC720>>8) & 0xFF;
        pAUX->Data[2] = (BYTE)(mmC720>>16) & 0xFF;
        pAUX->Data[3] = (BYTE)(mmC720>>24) & 0xFF;

        pAUX->Data[4] = (BYTE)(mmC724) & 0xFF;
        pAUX->Data[5] = (BYTE)(mmC724>>8) & 0xFF;
        pAUX->Data[6] = (BYTE)(mmC724>>16) & 0xFF;
        pAUX->Data[7] = (BYTE)(mmC724>>24) & 0xFF;

        pAUX->Data[8] = (BYTE)(mmC728) & 0xFF;
        pAUX->Data[9] = (BYTE)(mmC728>>8) & 0xFF;
        pAUX->Data[10] = (BYTE)(mmC728>>16) & 0xFF;
        pAUX->Data[11] = (BYTE)(mmC728>>24) & 0xFF;

        pAUX->Data[12] = (BYTE)(mmC72C) & 0xFF;
        pAUX->Data[13] = (BYTE)(mmC72C>>8) & 0xFF;
        pAUX->Data[14] = (BYTE)(mmC72C>>16) & 0xFF;
        pAUX->Data[15] = (BYTE)(mmC72C>>24) & 0xFF;
    }
    if(DPIndex == DP2)
    {
        //  first clear write buffer
        mmC7A0 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2AUXReadReg0));
        mmC7A4 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2AUXReadReg1));
        mmC7A8 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2AUXReadReg2));
        mmC7AC = ReadMMIOUlong(CB_MMIO_OFFSET(DP2AUXReadReg3));

        pAUX->Data[0] = (BYTE)(mmC7A0) & 0xFF;
        pAUX->Data[1] = (BYTE)(mmC7A0>>8) & 0xFF;
        pAUX->Data[2] = (BYTE)(mmC7A0>>16) & 0xFF;
        pAUX->Data[3] = (BYTE)(mmC7A0>>24) & 0xFF;

        pAUX->Data[4] = (BYTE)(mmC7A4) & 0xFF;
        pAUX->Data[5] = (BYTE)(mmC7A4>>8) & 0xFF;
        pAUX->Data[6] = (BYTE)(mmC7A4>>16) & 0xFF;
        pAUX->Data[7] = (BYTE)(mmC7A4>>24) & 0xFF;

        pAUX->Data[8] = (BYTE)(mmC7A8) & 0xFF;
        pAUX->Data[9] = (BYTE)(mmC7A8>>8) & 0xFF;
        pAUX->Data[10] = (BYTE)(mmC7A8>>16) & 0xFF;
        pAUX->Data[11] = (BYTE)(mmC7A8>>24) & 0xFF;

        pAUX->Data[12] = (BYTE)(mmC7AC) & 0xFF;
        pAUX->Data[13] = (BYTE)(mmC7AC>>8) & 0xFF;
        pAUX->Data[14] = (BYTE)(mmC7AC>>16) & 0xFF;
        pAUX->Data[15] = (BYTE)(mmC7AC>>24) & 0xFF;
    }
}

BOOL cbDPI2CWriteDDCBytes(PCBIOS_EXTENSION pcbe, DWORD DPIndex, PAUX_CONTROL_UMA pAUX, PBYTE pBuffer, DWORD Length)
{
    BOOL    bStatus = FALSE;
    DWORD   i = 0, j = 0, value = 0, Retry = 0, MAX_RETRY_COUNT = 20, SWAUXCmdReg = 0, AUXWriteReg0 = 0;

    if(pAUX->Function != I2C_WRITE)
    {
        cbDbgPrint(1,"cbDPI2CReadDDCBytes: Command error!!\n");
        return FALSE;
    }

    if(DPIndex == DP1)
    {
        SWAUXCmdReg = DP1SWAUXCmdReg;
        AUXWriteReg0 = DP1AUXWriteReg0;
    }
    if(DPIndex == DP2)
    {
        SWAUXCmdReg = DP2SWAUXCmdReg;
        AUXWriteReg0 = DP2AUXWriteReg0;
    }

    cbDPResetAux(pcbe, DPIndex);

    for(i = 0; Length > 16*i; i++)
    {
        bStatus = FALSE;
        Retry = 0;
        while(bStatus == FALSE && Retry <= MAX_RETRY_COUNT)
        {
            value = 0;
            
            if(Length > 16*(i+1))
            {
            	pAUX->Length = 16;
            	value |= I2C_MOT;
            }
            else
            	pAUX->Length = Length - 16*i;
           
	        //
	        value |= pAUX->Function;                       // I2C R/W command;
	        value |= pAUX->Length << 4;                    // I2C offset length
	        value |= ((pAUX->I2cPort >> 1) & 0xFF) << 12;  // I2C slave address

            for(j = 0; j < pAUX->Length; j++)
            	pAUX->Data[j] = *(pBuffer + i*16 + j);
            
	        cbDPSetAuxWriteBuffer(pcbe, pAUX, DPIndex);

	        WriteMMIOUlong(CB_MMIO_OFFSET(SWAUXCmdReg), value); // write command to command buffer

	        cbDPSWAuxRequest(pcbe, DPIndex);
	        // for 410 A0/A1 DP AUX issue
	        if(!pcbe->ChipCaps.DP_FOR_410_A0_A1)
	        {
	            bStatus = cbDPAuxReplyStatus(pcbe, DPIndex);
	        }
	        else
	        {
	            cbDPHWUseAuxCh(pcbe, DPIndex);
	            cbDelayMicroSeconds(1000);
	        }
	        Retry++;
        }
     }
    return bStatus;
}

BOOL cbDPI2CReadDDCBytes(PCBIOS_EXTENSION pcbe, DWORD DPIndex, PAUX_CONTROL_UMA pAUX, PBYTE pBuffer, DWORD Length)
{
    BOOL    bStatus = FALSE;
    DWORD   i = 0, j = 0, value = 0, Retry = 0, MAX_RETRY_COUNT = 20, SWAUXCmdReg = 0, AUXWriteReg0 = 0;

    if(pAUX->Function != I2C_READ)
    {
        cbDbgPrint(1,"cbDPI2CReadDDCBytes: Command error!!\n");
        return FALSE;
    }

    if(DPIndex == DP1)
    {
        SWAUXCmdReg = DP1SWAUXCmdReg;
        AUXWriteReg0 = DP1AUXWriteReg0;
    }
    if(DPIndex == DP2)
    {
        SWAUXCmdReg = DP2SWAUXCmdReg;
        AUXWriteReg0 = DP2AUXWriteReg0;
    }

    cbDPResetAux(pcbe, DPIndex);

    for(i = 0; Length > 16*i; i++)
    {
        bStatus = FALSE;
        Retry = 0;
        while(bStatus == FALSE && Retry <= MAX_RETRY_COUNT)
        {
	        value = 0;

	        if(Length > 16*(i+1))
            {
            	pAUX->Length = 16;
            	value |= I2C_MOT;
            }
            else
            	pAUX->Length = Length - 16*i;
	        //
	        value |= pAUX->Function;                       // I2C R/W command;
	        value |= pAUX->Length << 4;                    // I2C offset length
	        value |= ((pAUX->I2cPort >> 1) & 0xFF) << 12;  // I2C slave address

	        WriteMMIOUlong(CB_MMIO_OFFSET(SWAUXCmdReg), value); // write command to command buffer

	        cbDPSWAuxRequest(pcbe, DPIndex);
	        // for 410 A0/A1 DP AUX issue
	        if(!pcbe->ChipCaps.DP_FOR_410_A0_A1)
	        {
	            bStatus = cbDPAuxReplyStatus(pcbe, DPIndex);
	        }
	        else
	        {
	            cbDPHWUseAuxCh(pcbe, DPIndex);
	            cbDelayMicroSeconds(1000);
	        }

	        Retry++;
        }

        cbDPGetAuxReadBuffer(pcbe, pAUX, DPIndex);
	    for(j = 0; j < pAUX->Length; j++)
	        *(pBuffer + i*16 + j) = pAUX->Data[j];
     }
 
    return bStatus;
}

//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
BOOL cbDPAuxChRW(PCBIOS_EXTENSION pcbe, IN PAUX_CONTROL_UMA pAUX, DWORD DPIndex)
{
    BOOL    bStatus = FALSE;
    DWORD   value = 0, Retry = 0, MAX_RETRY_COUNT = 20, SWAUXCmdReg = 0, AUXWriteReg0 = 0;

    if(pAUX->Length > 0x10)
    {
        cbDbgPrint(1,"AUX Command Length > 0x10 error!!\n");
        return FALSE;
    }
    
    if(DPIndex == DP1)
    {
        SWAUXCmdReg = DP1SWAUXCmdReg;
        AUXWriteReg0 = DP1AUXWriteReg0;
    }
    if(DPIndex == DP2)
    {
        SWAUXCmdReg = DP2SWAUXCmdReg;
        AUXWriteReg0 = DP2AUXWriteReg0;
    }

    cbDPResetAux(pcbe, DPIndex);
    
    // AUX CH as I2C transaction
    if(pAUX->Function == I2C_READ || pAUX->Function == I2C_WRITE)
    {
        while(bStatus == FALSE && Retry <= MAX_RETRY_COUNT)
        {
            value = 0x00050004;
	        WriteMMIOUlong(CB_MMIO_OFFSET(SWAUXCmdReg), value);
	        WriteMMIOUlong(CB_MMIO_OFFSET(AUXWriteReg0), pAUX->Offset);

	        cbDPSWAuxRequest(pcbe, DPIndex);
            // for 410 A0/A1 DP AUX issue
            if(!pcbe->ChipCaps.DP_FOR_410_A0_A1)
            {
                bStatus = cbDPAuxReplyStatus(pcbe, DPIndex);
            }
            else
            {
                cbDPHWUseAuxCh(pcbe, DPIndex);
                cbDelayMicroSeconds(1000);
            }

	        value = 0;
            // write I2C offset
            value |= I2C_WRITE;                            // I2C R/W command;
            value |= 0x1 << 4;                             // I2C offset length
            value |= ((pAUX->I2cPort >> 1) & 0xFF) << 12;  // I2C slave address
            value |= I2C_MOT;

            WriteMMIOUlong(CB_MMIO_OFFSET(SWAUXCmdReg), value); // write command to command buffer
            WriteMMIOUlong(CB_MMIO_OFFSET(AUXWriteReg0), pAUX->Offset);
                
            cbDPSWAuxRequest(pcbe, DPIndex);
            // for 410 A0/A1 DP AUX issue
            if(!pcbe->ChipCaps.DP_FOR_410_A0_A1)
            {
                bStatus = cbDPAuxReplyStatus(pcbe, DPIndex);
            }
            else
            {
                cbDPHWUseAuxCh(pcbe, DPIndex);
                cbDelayMicroSeconds(1000);
            }

            value = 0;
            //
            value |= pAUX->Function;                       // I2C R/W command;
            value |= pAUX->Length << 4;                    // I2C offset length
            value |= ((pAUX->I2cPort >> 1) & 0xFF) << 12;  // I2C slave address

            if(pAUX->Function == I2C_WRITE)
                cbDPSetAuxWriteBuffer(pcbe, pAUX, DPIndex);

            WriteMMIOUlong(CB_MMIO_OFFSET(SWAUXCmdReg), value); // write command to command buffer

            cbDPSWAuxRequest(pcbe, DPIndex);
            // for 410 A0/A1 DP AUX issue
            if(!pcbe->ChipCaps.DP_FOR_410_A0_A1)
            {
                bStatus = cbDPAuxReplyStatus(pcbe, DPIndex);
            }
            else
            {
                cbDPHWUseAuxCh(pcbe, DPIndex);
                cbDelayMicroSeconds(1000);
            }
            Retry++;
        }
            
        if(pAUX->Function == I2C_READ)
            cbDPGetAuxReadBuffer(pcbe, pAUX, DPIndex);
    }
    else    // AUX CH
    {
        while(bStatus == FALSE && Retry <= MAX_RETRY_COUNT)
        {
            value = 0;
	        value |= pAUX->Function;       // AUX R/W command;
	        value |= (pAUX->Length) << 4;  // AUX data length
	        value |= (pAUX->Offset) << 12; // DPCD offset
	            
	        if(pAUX->Function == AUX_WRITE)
	            cbDPSetAuxWriteBuffer(pcbe, pAUX, DPIndex);
	            
	        WriteMMIOUlong(CB_MMIO_OFFSET(SWAUXCmdReg), value); // write command to command buffer

	        cbDPSWAuxRequest(pcbe, DPIndex);
            // for 410 A0/A1 DP AUX issue
            if(!pcbe->ChipCaps.DP_FOR_410_A0_A1)
            {
                bStatus = cbDPAuxReplyStatus(pcbe, DPIndex);
            }
            else
            {
                cbDPHWUseAuxCh(pcbe, DPIndex);
                cbDelayMicroSeconds(1000);
            }
            Retry++;
        }
        if(pAUX->Function == AUX_READ)
            cbDPGetAuxReadBuffer(pcbe, pAUX, DPIndex);
    }
            
    // return AUX CH control to HW
    cbDPHWUseAuxCh(pcbe, DPIndex);

    return bStatus;
}

void cbDPHWUseAuxCh(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{
    DWORD   SWAUXReg=DP1SWAUXReg;   // default AUX register

    if(DPIndex == DP1)
        SWAUXReg = DP1SWAUXReg;
    if(DPIndex == DP2)
        SWAUXReg = DP2SWAUXReg;
        
    WriteMMIOUlong(CB_MMIO_OFFSET(SWAUXReg), (ReadMMIOUlong(CB_MMIO_OFFSET(SWAUXReg)) & 0xFFFFFFF0));
}

//---------------------------------------------------------------------------
//  Used to Fire AUX CH command
//---------------------------------------------------------------------------
void cbDPSWAuxRequest(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{
    if(DPIndex == DP1)
    {
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1SWAUXReg), 
        	(ReadMMIOUlong(CB_MMIO_OFFSET(DP1SWAUXReg)) & 0xFFFFFFF0) | 0x03);

	    cbDelayMicroSeconds(1000);
	    
	    if((ReadMMIOUlong(CB_MMIO_OFFSET(DP1SWAUXReg)) & 0x3C000000) != 0)
	    	WriteMMIOUlong(CB_MMIO_OFFSET(DP1SWAUXReg), 0);
    }
    if(DPIndex == DP2)
    {
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2SWAUXReg), 
        	(ReadMMIOUlong(CB_MMIO_OFFSET(DP2SWAUXReg)) & 0xFFFFFFF0) | 0x03);

	    cbDelayMicroSeconds(1000);
	    
	    if((ReadMMIOUlong(CB_MMIO_OFFSET(DP2SWAUXReg)) & 0x3C000000) != 0)
	    	WriteMMIOUlong(CB_MMIO_OFFSET(DP2SWAUXReg), 0);
    }
}

BOOL cbDPAuxReplyStatus(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{
    DWORD   mmC730 = 0, mmC7B0 = 0;
    BOOL    bStatus = FALSE;

    if(DPIndex == DP1)
    {
         mmC730 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1SWAUXReg)) & 0xF;
         if(mmC730 & BIT2)
         {
            bStatus = TRUE;
         }
         else if(mmC730 & BIT3)
         {
            bStatus = FALSE;
            //cbDbgPrint(0, "cbDPAuxReplyStatus : AUX CH time out!\n");
         }
         else
         {
            bStatus = FALSE;
            //cbDbgPrint(0, "cbDPAuxReplyStatus : AUX CH UNKNOWN ERROR  %d!\n", (mmC730 & 0xF));
         }
    }
    if(DPIndex == DP2)
    {
         mmC7B0 = ReadMMIOUlong(CB_MMIO_OFFSET(DP2SWAUXReg)) & 0xF;
         if(mmC7B0 & BIT2)
         {
            bStatus = TRUE;
         }
         else if(mmC7B0 & BIT3)
         {
            bStatus = FALSE;
            //cbDbgPrint(0, "cbDPAuxReplyStatus : AUX CH time out!\n");
         }
         else
         {
            bStatus = FALSE;
            //cbDbgPrint(0, "cbDPAuxReplyStatus : AUX CH UNKNOWN ERROR  %d!\n", (mmC7B0 & 0xF));
         }
    }

    return bStatus;
}

void cbDPInitSettings(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{
    AUX_CONTROL_UMA AUX;

    AUX.Function = AUX_READ;
    AUX.Offset = 0x1;
    AUX.Length = 0x2;
    cbDPAuxChRW(pcbe, &AUX, DPIndex);

    // check Link Speed
    if(AUX.Data[0] == 0x0A)
        pcbe->DPSinkCaps[DPIndex].LinkSpeed = 2700000;  // 270 Mhz
    else
        pcbe->DPSinkCaps[DPIndex].LinkSpeed = 1620000;  // 162 Mhz

    //PAC DP2 issue, Fixed the link speed to 162MHz, because PAC DP-2 is a fixed value.
    if((DPIndex == DP2)&&(dp2LinkspeedConf == 162)){
        pcbe->DPSinkCaps[DPIndex].LinkSpeed = 1620000;
        AUX.Data[0] =0x06;
    }        
    
    // check Lane Count
    if( (AUX.Data[1] & 0xF) == 0x1 ||
        (AUX.Data[1] & 0xF) == 0x2 ||
        (AUX.Data[1] & 0xF) == 0x4 )
        pcbe->DPSinkCaps[DPIndex].LaneNumber = (AUX.Data[1] & 0xF);
    else
        pcbe->DPSinkCaps[DPIndex].LaneNumber = 4;
            
    pcbe->DPSinkCaps[DPIndex].bpc = 8;      // DP_Default_bpc;
    pcbe->DPSinkCaps[DPIndex].EnhancedMode = 0x01;
    pcbe->DPSinkCaps[DPIndex].AsyncMode = 0x01;
    pcbe->DPSinkCaps[DPIndex].ColorFormat = 0;
    pcbe->DPSinkCaps[DPIndex].DynamicRange = 0;
    //pcbe->DPSinkCaps[DPIndex].YCbCrCoefficients = 0;
    pcbe->DPSinkCaps[DPIndex].TUSize = 48;  // DP_Default_TUSize;
    pcbe->DPSinkCaps[DPIndex].DualMode = 0x00;
    //pcbe->DPSinkCaps[DPIndex].LT_Status = 0;

    cbDbgPrint(0,"cbDPInitSettings : Lane Count = %d, Link Speed = %d\n", pcbe->DPSinkCaps[DPIndex].LaneNumber, pcbe->DPSinkCaps[DPIndex].LinkSpeed);
}

void cbDPResetAux(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{
    // 410 A2 resetAUX will cause AUX CH random fail and cannot recovery.
    // skip this function  in A2 first.
    if(!pcbe->ChipCaps.DP_FOR_410_A0_A1)
        return;
    
    if(DPIndex == DP1)
    {
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1NAUDCtlReg), (ReadMMIOUlong(CB_MMIO_OFFSET(DP1NAUDCtlReg)) | 0x40000000));
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1NAUDCtlReg), (ReadMMIOUlong(CB_MMIO_OFFSET(DP1NAUDCtlReg)) & ~0x40000000));
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg), (ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) | 0x00000040));
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg), (ReadMMIOUlong(CB_MMIO_OFFSET(DP1LTCtlReg)) & ~0x00000040));
    }
    if(DPIndex == DP2)
    {
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2NAUDCtlReg), (ReadMMIOUlong(CB_MMIO_OFFSET(DP2NAUDCtlReg)) | 0x40000000));
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2NAUDCtlReg), (ReadMMIOUlong(CB_MMIO_OFFSET(DP2NAUDCtlReg)) & ~0x40000000));
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg), (ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) | 0x00000040));
        WriteMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg), (ReadMMIOUlong(CB_MMIO_OFFSET(DP2LTCtlReg)) & ~0x00000040));
    }
    cbDelayMicroSeconds(200);
}

void cbUpdateHDMIEPHYReg(PCBIOS_EXTENSION pcbe, PGFXTimingTable pTimingTbl)
{
    DWORD mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0)) & 0x3FFFFFFF;
    DWORD mmC280 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC280)) & 0xFF80DBFF;
    DWORD mmC284 = 0, mmC748 = 0;
    DWORD pixclock = 0, gap_delay = 0, max_packet = 0;

    if(pTimingTbl == NULL)
    {
        cbDbgPrint(0,"cbUpdateHDMIEPHYReg : HDMI timing table is NULL!\n");
        return;
    }

    pixclock = cbCalcClkFromDWORDMRN(pcbe, pTimingTbl->vPLL);
    pcbe->Internal_HDMI_pclk = pixclock;
                
    if(pixclock >= 135000000)
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740 | 0x00000000);
    else if(pixclock < 135000000 && pixclock >= 67500000)
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740 | 0x40000000);
    else if(pixclock < 67500000 && pixclock >= 33750000)
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740 | 0x80000000);
    else
        WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740 | 0xC0000000);

    if(pTimingTbl->HPolarity == CBIOS_NEGATIVE)
        mmC280 |= BIT10;
    if(pTimingTbl->VPolarity == CBIOS_NEGATIVE)
        mmC280 |= BIT13;

    if(pcbe->DPSinkCaps[DP1].IsHDMIDevice)
        mmC280 &= ~0x40;
    else
        mmC280 |= 0x40;

    // caculate correct gap_delay of mm_c280[22:16]
    if(pTimingTbl->HSyncStart - pTimingTbl->HDisEnd > ( 58 - 11 ))
        gap_delay = 0;
    else
        gap_delay = 58 - (pTimingTbl->HSyncStart - pTimingTbl->HDisEnd) - 11;

    // caculate max_packet 
    max_packet = (pTimingTbl->HBlankEnd - pTimingTbl->HSyncStart - 16 - 11 - gap_delay) / 32;

    if(gap_delay == 0)
        gap_delay = pTimingTbl->HBlankEnd - pTimingTbl->HSyncStart - (32 * max_packet + 16 + 11);

    mmC280 |= (gap_delay << 16);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC280), mmC280);

    mmC284 = 0x00000102 | (max_packet << 28);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC284), mmC284);

    // adjust current driving based on DCLK
    mmC748 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC748)) & 0xFFFFFE0D;
    if(pixclock > 65000000)
        mmC748 |= 0x180;
    else
        mmC748 |= 0x160;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC748), mmC748);

    mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0))& ~0x06000000; //make sure Tpll/Tpll reg are off
    WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740);

    cbDelayMicroSeconds(375);

    mmC740 = ReadMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0)) | 0x06000000;
    WriteMMIOUlong(CB_MMIO_OFFSET(DP1EPHYCtlReg0), mmC740);

}

void cbSetHDAudioConnectStatus(PCBIOS_EXTENSION pcbe, BOOL bEnable)
{
    ULONG PresentBit, UnSolicited;
    ULONG PinSenseResponse = 0x80000000;       // pin sense control
    ULONG PinSenseResponseMask = 0x80000000;   // mask for pin sense control

    if((ReadMMIOUlong(CB_MMIO_OFFSET(0xC468)) & 0x00f00000) == 0x00100000)
    {
        PinSenseResponse = 0x80778866;
        PinSenseResponseMask = 0xfffffffe;            
    }
    PresentBit = bEnable ? PinSenseResponse : 0;
    if((ReadMMIOUlong(CB_MMIO_OFFSET(0xC464)) & PinSenseResponseMask) == PresentBit)
        return;
    // Change PresentBit 
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC464), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC464)) & ~PinSenseResponseMask) | PresentBit);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC4D0), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC4D0)) | 0x20));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC4D0), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC4D0)) & ~0x00000020));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC4D4), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC4D4)) & 0x00ffffff) | 0x06000000 );
    if((ReadMMIOUlong(CB_MMIO_OFFSET(0xC4D8)) & PinSenseResponseMask) == PresentBit)
    {    // change PresentBit success
         // Send Unsolicited response
         WriteMMIOUlong(CB_MMIO_OFFSET(0xC4D4),(ReadMMIOUlong(CB_MMIO_OFFSET(0xC4D4)) & 0x00ffffff) | 0x04000000 );
         UnSolicited = ReadMMIOUlong(CB_MMIO_OFFSET(0xC4D8));
         if(UnSolicited & 0x80)
         {    // Unsolicited response enabled
              WriteMMIOUlong(CB_MMIO_OFFSET(0xC420),((UnSolicited&0x3f) << 26) | 1); // the '1' has no meaning for hdaudio driver
              WriteMMIOUlong(CB_MMIO_OFFSET(0xC418), ReadMMIOUlong(CB_MMIO_OFFSET(0xC418)) | 0x8); 
          }
    }        
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC4D4),(ReadMMIOUlong(CB_MMIO_OFFSET(0xC4D4)) & 0x00ffffff));
}

BOOL cbGetRefreshRatesForDP (
    IN PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN OUT RefreshRateInfo *pRRatesInfoBuf,
    IN OUT DWORD *pBufSize
)
{

    if (!pRRatesInfoBuf || !pBufSize)
    {
        cbDbgPrint(0, "cbGetRefreshRatesForDP: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    if(dispDev == S3_DP)
    {
        if (pcbe->devicetimingtype[DPbit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeRefreshRatesForResolution(pcbe, 
                                                                          S3_DP,
                                                                          H_Res,
                                                                          V_Res,
                                                                          pRRatesInfoBuf,
                                                                          *pBufSize,
                                                                          NULL))
            {
                return FALSE;
            }
        }
        else if (pcbe->devicetimingtype[DPbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT 
            //    if Est / STD resolution == EDID detailed resolution
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target timing
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_DP,
                                                    H_Res,
                                                    V_Res,
                                                    pRRatesInfoBuf,
                                                    *pBufSize,
                                                    NULL))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe, 
                                                            H_Res,
                                                            V_Res,
                                                            pRRatesInfoBuf,
                                                            *pBufSize,
                                                            NULL))
                {
                    return FALSE;
                }
            }                
        }        
        else if (pcbe->devicetimingtype[DPbit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_DP,
                                                                  pRRatesInfoBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe, 
                                                            H_Res,
                                                            V_Res,
                                                            pRRatesInfoBuf,
                                                            *pBufSize,
                                                            NULL))
                {
                    return FALSE;
                }
            }
        }
        else
        {
            return FALSE;
        }                


    }
    else if(dispDev == S3_DP2)
    {
        if (pcbe->devicetimingtype[DP2bit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeRefreshRatesForResolution(pcbe, 
                                                                          S3_DP2,
                                                                          H_Res,
                                                                          V_Res,
                                                                          pRRatesInfoBuf,
                                                                          *pBufSize,
                                                                          NULL))
            {
                return FALSE;
            }
        }
        else if (pcbe->devicetimingtype[DP2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT 
            //    if Est / STD resolution == EDID detailed resolution
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target timing
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_DP2,
                                                    H_Res,
                                                    V_Res,
                                                    pRRatesInfoBuf,
                                                    *pBufSize,
                                                    NULL))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe, 
                                                            H_Res,
                                                            V_Res,
                                                            pRRatesInfoBuf,
                                                            *pBufSize,
                                                            NULL))
                {
                    return FALSE;
                }
            }                
        }        
        else if (pcbe->devicetimingtype[DP2bit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_DP2,
                                                                  pRRatesInfoBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe, 
                                                            H_Res,
                                                            V_Res,
                                                            pRRatesInfoBuf,
                                                            *pBufSize,
                                                            NULL))
                {
                    return FALSE;
                }
            }
        }
        else
        {
            return FALSE;
        }                
    }
    else
    {
        cbDbgPrint(0,"cbGetRefreshRatesForDP : Error, incorrectly parameter !\n");
        return FALSE;
    }

    return TRUE;
}

void cbDPIRQHandler(PCBIOS_EXTENSION pcbe, DWORD DPIndex)
{
    DWORD               LaneAlign = 0, i = 0;
    DWORD               RequestVoltage[4];
    DWORD               RequestPreEmph[4];
    DWORD               LaneStatus[4];
    BOOL                LinkTrainingLost = FALSE, RebuildLink = FALSE;


    cbDPGetTrainingData(pcbe, DPIndex, LaneStatus, &LaneAlign, RequestVoltage, RequestPreEmph);
    // IRQ, Link Lost case
    cbDPGetTrainingData(pcbe, DPIndex, LaneStatus, &LaneAlign, RequestVoltage, RequestPreEmph);
    if(!LaneAlign) LinkTrainingLost = TRUE;
    if(!LinkTrainingLost)
    {
        for(i = 0; i < pcbe->DPSinkCaps[DPIndex].LaneNumber; i++)
        {
            if(LaneStatus[i] != 0x7)
                LinkTrainingLost = TRUE;
        }
    }

     if(DPIndex == DP1 && LinkTrainingLost && pcbe->devicepowerstate[DPbit] == S3PM_ON)
        RebuildLink = TRUE;
     if(DPIndex == DP2 && LinkTrainingLost && pcbe->devicepowerstate[DP2bit] == S3PM_ON)
        RebuildLink = TRUE;
        if(RebuildLink)
        {
            if(((DPIndex == DP1)&&dpSwLinkTraining)||((DPIndex == DP2)&&dp2SwLinkTraining))
                cbDPLinkTrainingSW(pcbe, DPIndex);    
            else
                cbDPLinkTrainingHW(pcbe, DPIndex);

            cbDPSetupMainLink(pcbe, DPIndex);
        }
}

