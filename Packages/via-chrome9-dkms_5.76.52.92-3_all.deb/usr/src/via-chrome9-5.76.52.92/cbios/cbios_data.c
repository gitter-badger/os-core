/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "cbios_uma.h"
#include "cbios_sub_func.h"

BYTE tv_output_type;
BYTE tv_regional_standard;
BOOL hdtv_enabled;
BOOL hdtv_1080i_enabled;

CBREGISTER UMA_ModeCommon[] =
{
    // group, mask, index, data

    // standard registers
    {ZSR,   0xFF, 0x00, 0x03},  // disable sync/async reset
    {ZSR,   0x09, 0x01, 0x01},  //8 dot clocks (8 horizontal pixels) 
                                //sr01[3] = 1: clock divided by 2;
                                //in vesa mode this bit should be 0, or the screen will be crushed
    {ZCR,   0x9F, 0x09, 0x00},  // [7]: double scan line, must disable
                                // max scan line (for text mode)
                                // (for VESA mode or GFX mode) we should set max scan line to 0
                                // means one line for one pixel line
    {ZCR,   0xF0, 0x11, 0x10},  // vertical interrupt

    {ZGR,   0xFF, 0x00, 0x00},
    {ZGR,   0xFF, 0x01, 0x00},
    {ZGR,   0xFF, 0x02, 0x00},
    {ZGR,   0xFF, 0x03, 0x00},
    {ZGR,   0xFF, 0x04, 0x00},
    {ZGR,   0xFF, 0x05, 0x00},
    {ZGR,   0xFF, 0x06, 0x05},
    {ZGR,   0xFF, 0x07, 0x0F},
    {ZGR,   0xFF, 0x08, 0xFF},

    {ZMISC, 0x0F, 0x00, 0x0F},   // clock,memo access, CRTC reg select

    // extended registers
    {ZSR,   0x72, 0x15, 0x32},
    //{SR,   0xBF, 0x16, 0x08}, // FIFO, use less?
    //{SR,   0xFF, 0x17, 0x1F}, // FIFO, use less?
    //{SR,   0xFF, 0x18, 0x4E}, // FIFO, use less?
    {ZSR,   0xFC, 0x1A, 0x08},
    //{CR,   0xFF, 0x32, 0x01}, // gamma, flip, seem like should let driver control
    {ZCR,   0x0F, 0x33, 0x06},   // bit7 gamma

    {ZGR,   0xFF, 0x20, 0x00},   // 64K mome block selection under specific platform
    {ZGR,   0xFF, 0x21, 0x00},   // 64K mome block selection under specific platform
    {ZGR,   0xFF, 0x22, 0x00},   // 64K mome block selection under specific platform

    {ZAR,   0xFF, 0x10, 0x01},   // set standard register to GFX mode as default
    {ZAR,   0xFF, 0x11, 0x00},   // set border color to black

    {ZCR,   BIT5, 0x4E, BIT5},   //we set ScratchPad8[5] to indicate that 
                                 //we have set vesa mode and should lock 
                                 //standard CR regs for vbios when specific platform fullscreen

    {0xFF, 0xFF, 0xFF, 0xFF}        // end-of-table
};

//=============================================================================
//=============================================================================
//  Memory utility
//      Get/Set/Modified memory information
//=============================================================================
// cbGetMemorySizeIn64K
//   This routine return memory size for scratch pad register setting
//   Entry:
//              PHW_DEVICE_EXTENSION HwDeviceExtension
//   Exit:
//              WORD MemSize
//   Modified:
//=============================================================================
//SR 39 needs refine
WORD cbGetMemorySizeIn64K(PCBIOS_EXTENSION pcbe)
{

    ULONG   MemSize = 0;
    ULONG   byTemp;

    // Default memory size 64MB(MemSize = 0x400)
    // MemSize = 0x400;

    // The SR39 is memory size 
    byTemp = (ULONG) pcbe->sPad_C.Mem_Size;
	cbGetSysBiosInfo(pcbe);

	if (byTemp != 0x0)
    {
        // Memory Size unit from 4MB -> 64KB
	    if(pcbe->SysBiosInfo.Header.Version >= 0x03)
	    {
			MemSize = (((0x1 << (ULONG)byTemp) * 1024)/64);
	    }
		else
			MemSize = (((ULONG)byTemp * 4096) / 64);  //old defined
    }

    return ((WORD)MemSize);
}

//=============================================================================
// cbQueryChipInfo_UMA
//   This function will return Chip Information
//   Entry:
//              PHW_DEVICE_EXTENSION HwDeviceExtension
//              PVIDEO_X86_BIOS_ARGUMENTS biosArguments
//   Exit:
//              EBX = BIOS information
//               AX = VBE return status
//              EBX = Bit[31:28]    Core Base Version
//                  = Bit[27]       0 = Laptop BIOS; 1 = Desktop BIOS
//                  = Bit[26]       0 = built from trunk, 1 = built from branch
//                  = Bit[25:24]    Reserved
//                  = Bit[23:16]    Product ID                   (No Implement)
//                  = Bit[15:8]     Major BIOS Version Number
//                  = Bit[7:0]      Minor BIOS Version Number
//               CX = Bit[15:8]     Type of External TV Encoder
//                                  0 = no TV encoder
//                                  1 = VT1621
//                                  2 = VT1622
//                                  3 = CH7009
//                                  4 = CH7017
//                                  5 = SAA7108AE
//                                  6 = CH7005
//                                  7 = VT1622A
//                  = Bit[7:0]      TV Encoder Address
//              EDI = Bit[31:28]    Process ID                   (No Implement)
//                  = Bit[27:24]    Memory size required of integrated TV (0~15 MB)
//                  = Bit[23:16]    Revision ID
//                  = Bit[15:0]     PCI Device ID
//              ESI = Bit[31]       1 = Bus Master Supported, 0 = not Supported
//                  = Bit[30]       CRT+LCD Duo View. 1=Support, 0=Not Support
//                  = Bit[29]       CRT+DVI Duo View. 1=Support, 0=Not Support
//                  = Bit[28]       CRT+TV Duo View.  1=Support, 0=Not Support
//                  = Bit[27]       CRT+HDTV Duo View. 1=Support, 0=Not Support
//                  = Bit[26]       LCD+LCD2 Duo View. 1=Support, 0=Not Support
//                  = Bit[30:23]    Reserved
//                  = Bit[22]       CRT2 dsiplay (2nd CRT) support
//                  = Bit[21]       DVI Display Supported
//                  = Bit[20]       DVI2 Dipslay Supported
//                  = Bit[19]       LCD2 Display Supported
//                  = Bit[18]       TV Display Supported
//                  = Bit[17]       LCD Display Supported
//                  = Bit[16]       CRT Display Supported
//                  = Bit[15:0]     Installed Video Memory in number of 64K
//                                  block
//   Modified:
//=============================================================================
VOID cbQueryChipInfo_UMA( PCBIOS_EXTENSION pcbe,
                          PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    ULONG encodertype = 0; //Initialize and set default value to Zero(None)
    ULONG SupportDevices = (ULONG)(pcbe->SupportDevices);
    
    if(SupportDevices & S3_TV) //Find the TV Encoder type only if we support TV
    {
        if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
        {
            cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
            encodertype = 0;
        }
    }
    
    //BIOS Core Version
    biosArguments->Ebx  = Core_Base_Version << 28 ;
    //BIOS Type
    if (NULL != pcbe->pVCPInfo)
    {
        PVCPInfo pVCP = pcbe->pVCPInfo;
        PBYTE pRom = pcbe->RomData;

        biosArguments->Ebx = (ULONG)(*(pRom+VBIOS_VERSION_OFFSET) << 24);
        biosArguments->Ebx += (ULONG)(*(pRom+VBIOS_VERSION_OFFSET+1) << 16);
        biosArguments->Ebx += (ULONG)(*(pRom+VBIOS_VERSION_OFFSET+2) << 8);
        biosArguments->Ebx += (ULONG)(*(pRom+VBIOS_VERSION_OFFSET+3));

        // DuoView support Caps
        biosArguments->Esi |= pVCP->duoViewCaps & (BIT30+BIT29+BIT28+BIT27+BIT26+BIT25);
        biosArguments->Esi ^= BIT27+BIT28;
    }

    // Type of TV Encoder(so far, only support vt1625)
    biosArguments->Ecx |= encodertype << 8;

    biosArguments->Edx = 0x0330;

    // Chip ID & Revision ID
    biosArguments->Edi = 0x3230 + (0 << 16); // 336 PCI DEVICE ID

    // Internal TV reserve 10M memory
    if(pcbe->pVCPInfo != NULL)
    {
        if((pcbe->pVCPInfo->version >= VCP1_5) &&
            (pcbe->pVCPInfo->miscConfigure & INTERNAL_TV_SUPPORT))
        {
            biosArguments->Edi +=  0x0A << 24;
        }
    }
    
    //Supported devices
    //Function:cbCBIOSInfoInit will get Supported Devices,so just use it at here
    SupportDevices = SupportDevices<<16;
    biosArguments->Ecx |= SupportDevices & 0xFFFF0000;
    //Copy device bit to ESI, and set Extend device bit: BIT23
    biosArguments->Esi |= (SupportDevices & 0xFFFF0000) | BIT23;

    // We default report this bit for all chip
    biosArguments->Esi |= BIT31;

    biosArguments->Esi += (DWORD)cbGetMemorySizeIn64K(pcbe);

}

//=============================================================================
// cbGetBIOSInfo_UMA
//   This function will return vBIOS Misc Information
//   Entry:
//              PHW_DEVICE_EXTENSION HwDeviceExtension
//              PVIDEO_X86_BIOS_ARGUMENTS biosArguments
//   Exit:
//               AX = VBE return status
//              ECX = Bit[31:3]     Reserved
//                    Bit[2]        Validate modes support control  
//                                  0 = Generic case
//                                  1 = Skip ValidateSupportMode control
//               SI = Bit[15:8]     Type of External TV Encoder
//                                  00: None
//                                  11: VT1621
//                                  12: VT1622
//                                  13: VT1622A
//                     Bit[7:0]     LVDS / TMDS Transmitter for Digital Interface
//                     Bit[7:4]     DI1
//                                  00 : None
//                                  01 : VT3191
//                                  07 : HARDWIRED LVDS ( or none Transmitter )
//                                  09 : VT3192
//                                  0B : SiI164
//                                  0C : SiI168
//                                  0F : Hardwired Transmitter
//                     Bit[3:0]     DI0
//                                  00 : None
//                                  01 : VT3191
//                                  07 : HARDWIRED LVDS ( or none Transmitter )
//                                  09 : VT3192
//                                  0B : SiI164
//                                  0C : SiI168
//                                  0F : Hardwired Transmitter
//                DI = Bit[1:0]     HDMI Tx Type
//                                  00 : None
//                                  01 : AD9389B_HDMI
//                                  02 : SIL9022_HDMI
//                                  03 : ITE6610_HDMI
//
//=============================================================================
VOID cbGetBIOSInfo_UMA(PCBIOS_EXTENSION pcbe, PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    int i;
    PDigitalPortInfo PDIPort = pcbe->DIPort;

    // fixed value
    biosArguments->Ebx = 0x0;
    biosArguments->Ecx = 0x0;
    biosArguments->Edx = 0x0;
    biosArguments->Esi = 0x0;

    if(pcbe->SupportDevices & (S3_DVI + S3_LCD2))
    {
        if((pcbe->pVCPInfo->version >= VCP1_8) && (pcbe->pVCPInfo->miscConfigure3 & NEW_DIPOPRT_TX_SCRATCHPAD))
        {
            for(i=0;i<DigitalPortNUM;i++)
            {
                if(PDIPort[i].PortInfo.device & (S3_DVI + S3_LCD2))
                {
                    biosArguments->Esi = (PDIPort[i].PortInfo.TXType & 0x0F); // mask[3:0] for compatible this interface
                    break;
                }
            }
        }
        else
        {
            biosArguments->Esi = pcbe->sPad_3.Tx0;
        }
    }
    
    if (pcbe->SupportDevices & (S3_LCD + S3_DVI2))
    {
        if((pcbe->pVCPInfo->version >= VCP1_8) && (pcbe->pVCPInfo->miscConfigure3 & NEW_DIPOPRT_TX_SCRATCHPAD))
        {
            for(i=0;i<DigitalPortNUM;i++)
            {
                if(PDIPort[i].PortInfo.device & (S3_LCD + S3_DVI2))
                {
                    biosArguments->Esi |= (PDIPort[i].PortInfo.TXType & 0x0F) << 4; // mask[3:0] for compatible this interface
                    break;
                }
            }
        }
        else
        {
            biosArguments->Esi |= pcbe->sPad_3.Tx1 << 4;
        }
    }
    
    if (pcbe->SupportDevices & (S3_TV+S3_HDTV))
    {
        // So far TV only support VT1625A(AMR port)
        biosArguments->Esi |= 0x1100; // type 17
    }
    if(pcbe->SupportDevices & (S3_HDMI+S3_HDMI2))
    {
        if((pcbe->pVCPInfo->version >= VCP1_8) && (pcbe->pVCPInfo->miscConfigure3 & NEW_DIPOPRT_TX_SCRATCHPAD))
        {
        //transfer the bit definition, make compatible for 9389 = 1, 9022=2, 6610=3
            switch(pcbe->sPad_3.Tx)
            {
                case AD9389B:
                    biosArguments->Edi = HDMI_AD9389B;
                    break;
                default:
                    biosArguments->Edi = HDMI_TX_NONE;
                    break;
            }
        }
        else
        {
            biosArguments->Edi = pcbe->sPad_6.HDMITXType;
        }
    }
}

//=============================================================================
// cbgetMiscInfo_UMA
//   This function will return vBIOS Misc Information
//   Entry:
//              PHW_DEVICE_EXTENSION HwDeviceExtension
//              PVIDEO_X86_BIOS_ARGUMENTS biosArguments
//   Exit:
//               AX = VBE return status
//              EDX = MISC2
//              ECX = Bit[31:3]     Reserved
//                    Bit[2]        Validate modes support control  
//                                  0 = Generic case
//                                  1 = Skip ValidateSupportMode control
//
//   Modified:
//
//=============================================================================
VOID cbgetMiscInfo_UMA(PCBIOS_EXTENSION pcbe,
                        PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    if (NULL != pcbe->pVCPInfo)
    {
        biosArguments->Ecx = pcbe->pVCPInfo->miscConfigure;
        if ( (pcbe->pVCPInfo->version >= VCP1_5) && 
             (pcbe->ChipCaps.S3_device_define_for_324) ) // For 324, we use s3_define in cbios
        {
            biosArguments->Ecx |= BIT0; // S3_Device_define bit
        }
        if (pcbe->pVCPInfo->version >= VCP1_2)
        {
            // VCP 1_2 added miscConfigure2
            biosArguments->Edx = pcbe->pVCPInfo->miscConfigure2;
        }
        else
        {
            biosArguments->Edx = 0;
        }
        if (pcbe->pVCPInfo->version >= VCP1_6)
        {
            // VCP 1_6 added miscConfigure3
            biosArguments->Edi = pcbe->pVCPInfo->miscConfigure3;
        }
        else
        {
            biosArguments->Edi = 0;
        }
        biosArguments->Esi = pcbe->pVCPInfo->duoViewCaps;
    }
    else
    {
        biosArguments->Ecx = 0x0;
    }
    
    // always report LCD on IGA2 only enable bit
    // for driver can handle IGA2 LUT even not support 6bit
    biosArguments->Ecx |= BIT4;
}

/*****************************************************************************************/
//
//Function:cbIsModeAvailable
//Discription:
//      Check if there is available timing(refresh rate timing table) for the specified mode
//Return:
//      TRUE --- Available, there is at least one available timing(refresh rate)
//      FALSE--- Not available, there is no available timing(refresh rate) for this mode
//
/*****************************************************************************************/
BOOL cbIsModeAvailable(PCBIOS_EXTENSION pcbe, IN DWORD dispDev, IN PVESA_INFO pVesaInfo)
{
    BYTE i;
    PVESA_VPIT pVesaVPIT = (PVESA_VPIT)((PBYTE)pVesaInfo + sizeof(VESA_INFO));
    for(i = 0; i < pVesaInfo->RRateCount; i++)
    {
        if(!cbIsDClkOverLimit(pcbe, dispDev,
                         cbCalcClkFromDWORDMRN(pcbe, pVesaVPIT->PLL) ) )
        {
            if(!(pVesaVPIT->Attribute & ATT_DISABLE))
                return TRUE;
        }
        pVesaVPIT++;
    }
    return FALSE;
}

/*****************************************************************************************/
//
//Function:cbGetSysBiosInfo
//Discription:
//      This function will init pcbe scratch pad and related HW registers from system bios info
//Return:
//      TRUE --- Success, init success, in system bios info valid case
//      FALSE--- Fail, system bios info invalid, init fail
//
/*****************************************************************************************/
BOOL cbGetSysBiosInfo(PCBIOS_EXTENSION pcbe)
{
    BOOL status = TRUE;
    // Add one assert for System bios too old, SysBiosInfo Invalid
    // No assert, but with dbg print info.
    if (!pcbe->SysBiosInfoValid)
    {
        cbDbgPrint(0, "System bios too old, no sysInfo exist!\n");
    }
    
    cbWriteRegBits(pcbe, CR_4B, BIT0+BIT1+BIT2, TV_V_OVER); //For 324, set TV to over scan as default

    if (pcbe->SysBiosInfoValid == TRUE)
    {
        // For bootup device, we prefer to sync it from vbios in MAMM Primary case .
        // For MAMM secondary case, we do not use Boot up device CMOS setting 

        // For SysBIOSInfo: FBStartingAddr, it will be used in function: VBE_4F14_000D_GetStartAddressOfFB
        // For SysBIOSInfo: DualMemoCtrl, it was used in chip:VT3293 in vbios, and we do not take care of it by now
        // So, at here, we do not update all these bits
        
        // for TV input Mode, we just use one bit
        BYTE MemDataRateIdx ;

        if ( pcbe->pVCPInfo != NULL )
        {
            if(pcbe->pVCPInfo->BIOSSupportDev & (S3_TV+S3_TV2+S3_HDTV))
            {
                pcbe->sPad_5.TVInputMode =(BYTE)(pcbe->SysBiosInfo.HDTV_TV_Config & BIT0);
                // for TV type, we just use lower three bits in scratch pad
                pcbe->sPad_8.TV_Type = (BYTE)((pcbe->SysBiosInfo.HDTV_TV_Config & (BIT2+BIT3+BIT4)) >> 2);
                tv_regional_standard = pcbe->sPad_8.TV_Type;
                pcbe->sPad_5.TV_Contraction = TV_V_OVER; //(BYTE)((pcbe->SysBiosInfo.HDTV_TV_Config & (BIT5+BIT6+BIT7)) >> 5);
                pcbe->sPad_7.TVOutType = (BYTE)((pcbe->SysBiosInfo.HDTV_TV_Config & 0x7f00) >> 8);
                tv_output_type = pcbe->sPad_7.TVOutType ;
                pcbe->sPad_5.enableDotCrawl = (BYTE)((pcbe->SysBiosInfo.HDTV_TV_Config & BIT15) >> 15);
                // for HDTV type, we just use lower three bits in scratch pad
                pcbe->sPad_11.HDTV_Type = (BYTE)((pcbe->SysBiosInfo.HDTV_TV_Config & (BIT16+BIT17+BIT18)) >> 16);
                pcbe->sPad_11.HDTVOutputType = ((pcbe->SysBiosInfo.HDTV_TV_Config & BIT26) == 0) ? 1 : 0;

                //Update related hardware scratch pad registers:sPad_5/7/8/11
                cbWriteRegBits(pcbe, CR_4B, BIT0+BIT1+BIT2+BIT6+BIT7, STRUCT_BYTE(pcbe->sPad_5, 0));
                cbWriteRegBits(pcbe, CR_4D, 0x7f, STRUCT_BYTE(pcbe->sPad_7, 0));
                cbWriteRegBits(pcbe, CR_4E, BIT0+BIT1+BIT2, STRUCT_BYTE(pcbe->sPad_8, 0));
                cbWriteRegBits(pcbe, CR_3C, BIT0+BIT1+BIT2+BIT3, STRUCT_BYTE(pcbe->sPad_11, 0));

                /*configure TV registers by kernel configure file for no CMOS setting case*/
                {
                    UINT32 ConfValue=0;
                    PCHAR ConfName = "tv_device_type";
                    PCHAR ConfFile = "/etc/X11/via_kernel.conf";  
                    UINT8 Conf_TVOutType=0;
                    UINT8 Conf_TVInputMode=0;
                    UINT8 Conf_HDTV_Type=0;
                    UINT8 Conf_HDTVOutputType=0;
                    
                    //tv_device_type 0/1: TV/HDTV
                    if(CBIOS_OK == CBiosGetConfFileInfo(pcbe, ConfFile, ConfName, &ConfValue)){
                        cbDbgPrint(1, "configure tv_device_type to %d .\n", ConfValue);
                        hdtv_enabled= ConfValue; 
                    }	
					
                    //tv_regional_standard 0/1: NTSC/PAL
                    ConfName = "tv_regional_standard";
                    if(CBIOS_OK == CBiosGetConfFileInfo(pcbe, ConfFile, ConfName, &ConfValue)){
                        cbDbgPrint(1, "configure tv_regional_standard to %d .\n", ConfValue);
                        tv_regional_standard= ConfValue; 
                    }	
			
                    //tv_output_connect 0/1/2/3: Composite/SVideo/RGB/YCbCr    
                    ConfName = "tv_output_connect";
                    if(CBIOS_OK == CBiosGetConfFileInfo(pcbe, ConfFile, ConfName, &ConfValue)){
                        cbDbgPrint(1, "configure tv_output_connect to %d .\n", ConfValue);
                        switch(ConfValue){
                            case 0:
                                Conf_TVOutType=TV_CVBS;
                                break;
                            case 1:
                                Conf_TVOutType=TV_SVideo1;
                                break;
                            case 2:
                                Conf_TVOutType=TV_RGB;
                                Conf_TVInputMode=0;//RGB
                                break;
                            case 3:
                                Conf_TVOutType=TV_Ycbcr;
                                Conf_TVInputMode=0;//RGB
                                break;
                            default:
                                Conf_TVOutType=TV_RGB;
                                break;
                        }                    
                        if(hdtv_enabled)
                            tv_output_type=TV_RGB;
                        else 
                            tv_output_type=TV_SVideo1;
                            
                    }	     

                    //hdtv_display_timing 0/1: 720P/1080I 
                    ConfName = "hdtv_display_timing";
                    if(CBIOS_OK == CBiosGetConfFileInfo(pcbe, ConfFile, ConfName, &ConfValue)){
                        cbDbgPrint(1, "configure hdtv_display_timing to %d .\n", ConfValue);
                        Conf_HDTV_Type= ConfValue; 
                        if(Conf_HDTV_Type==1){
                            Conf_HDTV_Type= HDTV1080I;
                            hdtv_1080i_enabled=TRUE;
                        }
                        else    
                            Conf_HDTV_Type= HDTV720P;
                    }	

                    //hdtv_data_type 0/1: RGB/YPrPb  
                    ConfName = "hdtv_data_type";
                    if(CBIOS_OK == CBiosGetConfFileInfo(pcbe, ConfFile, ConfName, &ConfValue)){
                        cbDbgPrint(1, "configure hdtv_data_type to %d .\n", ConfValue);
                        Conf_HDTVOutputType= ConfValue;
                    }	 

                    if(Conf_TVOutType){
                        pcbe->sPad_5.TVInputMode =Conf_TVInputMode;   //BYTE    TVInputMode     : 1;    // 0:RGB input 1:YcbCr input
                        // for TV type, we just use lower three bits in scratch pad
                        pcbe->sPad_8.TV_Type = tv_regional_standard;
                        //pcbe->sPad_5.TV_Contraction = TV_V_OVER; //(BYTE)((pcbe->SysBiosInfo.HDTV_TV_Config & (BIT5+BIT6+BIT7)) >> 5);
                        pcbe->sPad_7.TVOutType =Conf_TVOutType;
                        // for HDTV type, we just use lower three bits in scratch pad
                        pcbe->sPad_11.HDTV_Type = Conf_HDTV_Type;
                        pcbe->sPad_11.HDTVOutputType =  Conf_HDTVOutputType;

                        //Update related hardware scratch pad registers:sPad_5/7/8/11
                        cbWriteRegBits(pcbe, CR_4B, BIT0+BIT1+BIT2+BIT6+BIT7, STRUCT_BYTE(pcbe->sPad_5, 0));
                        cbWriteRegBits(pcbe, CR_4D, 0x7f, STRUCT_BYTE(pcbe->sPad_7, 0));
                        cbWriteRegBits(pcbe, CR_4E, BIT0+BIT1+BIT2, STRUCT_BYTE(pcbe->sPad_8, 0));
                        cbWriteRegBits(pcbe, CR_3C, BIT0+BIT1+BIT2+BIT3, STRUCT_BYTE(pcbe->sPad_11, 0));
                    }
                }    
            }
            if(pcbe->pVCPInfo->BIOSSupportDev & S3_LCD)
            {
                // if SPWG support scratch pad register should be udpated from cbCBIOSInfoInit
                if ((pcbe->pVCPInfo->version >= VCP1_2) && 
                    (pcbe->pVCPInfo->miscConfigure2 & SPWG_LCD_NOT_Support))
                {
                    pcbe->sPad_4.LCD_DVI2_PanelID = pcbe->SysBiosInfo.LCDPanelID;

                    //if systembios info valid on LCD2 panel ID, use it
                    //else use vbios scratch pad result on LCD2 panel ID
                    if(pcbe->pVCPInfo->BIOSSupportDev & S3_LCD2)
                    {
                        if(pcbe->SysBiosInfo.Header.Length >= LCD2_ID_AVAILABLE_LENGTH)
                        {
                            pcbe->sPad_4.DVI_LCD2_PanelID = pcbe->SysBiosInfo.LCD2PanelID;
                        }
                    }
                    cbWriteRegByte(pcbe, CR_3F, STRUCT_BYTE(pcbe->sPad_4, 0));
                }
            }
        }
        
        pcbe->sPad_C.Mem_Size = pcbe->SysBiosInfo.FBSize;
        //By now,Cbios read this value from SR39 directly,do not use cbios data structure,need refine
        cbWriteRegByte(pcbe, SR_39, STRUCT_BYTE(pcbe->sPad_C, 0));

        MemDataRateIdx = (pcbe->SysBiosInfo.DRAMDataRateIdx & (BIT4+BIT5+BIT6+BIT7))>>4;
        if(MemDataRateIdx == 0)
        {
            //System bios info error, then set to default value: DDR400(Index = 06)
            MemDataRateIdx = 6;
        }
        pcbe->sPad_2.Mem_Data_Rate = MemDataRateIdx;
        cbWriteRegBits(pcbe, CR_3D, BIT4+BIT5+BIT6+BIT7, STRUCT_BYTE(pcbe->sPad_2, 0));

        if(pcbe->pVCPInfo->BIOSSupportDev & S3_LCD)
        {
            if(pcbe->SysBiosInfo.Header.Length >= SSCCtrl_AVAILABLE_LENGTH)
            {
                // SSC relative settings from systembios info valid, it is first priority.
                pcbe->ChipCaps.SSC_Enable = (pcbe->SysBiosInfo.SSCCtrl & BIT0) ? TRUE : FALSE;
                pcbe->ChipCaps.SSC_Using_External = (pcbe->SysBiosInfo.SSCCtrl & BIT1) ? TRUE : FALSE;
                pcbe->ChipCaps.SSC_Using_Fifo_Mode = (pcbe->SysBiosInfo.SSCCtrl & BIT2) ? TRUE : FALSE;
                pcbe->SSC_Spreading_Range = (pcbe->SysBiosInfo.SSCCtrl & (BIT5+BIT4)) >> 4;

                // update to scratch pad
                pcbe->shPad_1.SSC_ENABLE = pcbe->ChipCaps.SSC_Enable ? TRUE : FALSE;
                pcbe->shPad_1.SSC_PATH_EXTERNAL = pcbe->ChipCaps.SSC_Using_External ? TRUE : FALSE;
                pcbe->shPad_1.SSC_MODE_FIFO = pcbe->ChipCaps.SSC_Using_Fifo_Mode ? TRUE : FALSE;
                pcbe->shPad_1.SSC_VALID = TRUE;
            }
        }
    }
    else
    {
        status = FALSE;
    }
    return status;
}

/*****************************************************************************************
* Function:cbCbiosChipCapsInit
* Discription:
*     This function will init CBIOS chip Caps for some chip related feature or limitation
* Return:
*     None
*
*****************************************************************************************/
void cbCbiosChipCapsInit(PCBIOS_EXTENSION pcbe)
{
    /*--------------------------------------------------------------------
        *    Update Cbios Chip Caps info
        *-------------------------------------------------------------------- */
    switch (pcbe->PCIDeviceID) {
    case PCI_ID_VT3324:
        pcbe->ChipCaps.tv_two_clk_ctrl_sup = TRUE;
        pcbe->ChipCaps.IGA2Seq_SeparateDI_control = TRUE;
        pcbe->ChipCaps.DIPort_data_ctrl = TRUE;
        pcbe->ChipCaps.S3_device_define_for_324 = TRUE;
        /* CRT sense sequence : 
               * For vt3290(NEW_DAC_SENSE_FLOW: SR40[7]=1 --> SR40[7] = 0  --> check 3C2[4]
               * For 259/204(products before 290): SR40[7]=1 --> check 3C2[4] --> SR40[7]=0 */
        pcbe->ChipCaps.New_crt_dac_sense_flow = TRUE;
        pcbe->ChipCaps.DVP1_DPA_Value_Adjust = TRUE;
        pcbe->ChipCaps.CR6B_ONOFF_SCRN_NOT_IN_VBLANK = TRUE;
        pcbe->ChipCaps.DISABLE_INTERRUPT_IN_PAD_ONOFF = TRUE;
        break;
    case PCI_ID_VT3336:
        pcbe->ChipCaps.PAD_on_off_in_SW_PS = TRUE;
        pcbe->ChipCaps.VEE_on_off_by_GPIO0 = TRUE;
        pcbe->ChipCaps.ALWAYS_ON_CR_CLOCK_AFTER_S3 = TRUE;
        break;
    case PCI_ID_VT3353: /* use 3353 as default chip caps */
        pcbe->ChipCaps.tv_two_clk_ctrl_sup = TRUE;
        pcbe->ChipCaps.IGA2Seq_SeparateDI_control = TRUE;
        pcbe->ChipCaps.DIPort_data_ctrl = TRUE;
        pcbe->ChipCaps.for_inside_tmds_sense_fail = TRUE;
        pcbe->ChipCaps.for_killnumber_control = TRUE;
        pcbe->ChipCaps.for_track_FIFO_Number_control = TRUE;
        pcbe->ChipCaps.Inside_TMDS_Sense_SR3E = TRUE;
        /* CRT sense sequence : 
               * For vt3290(NEW_DAC_SENSE_FLOW: SR40[7]=1 --> SR40[7] = 0  --> check 3C2[4]
               * For 259/204(products before 290): SR40[7]=1 --> check 3C2[4] --> SR40[7]=0 */
        pcbe->ChipCaps.New_crt_dac_sense_flow = TRUE;
        pcbe->ChipCaps.INLVDS_Polarity_Control = TRUE;   
        pcbe->ChipCaps.GET_ECK_DEPENDON_SYSINFO = TRUE;
        pcbe->ChipCaps.CR6B_ONOFF_SCRN_NOT_IN_VBLANK = TRUE;
        pcbe->ChipCaps.Disable_Free_Run_ECK_In_Idle_Mode = TRUE;
        break;
    case PCI_ID_VT3364:
        pcbe->ChipCaps.PAD_on_off_in_SW_PS = TRUE;
        pcbe->ChipCaps.VEE_on_off_by_GPIO0 = TRUE;
        pcbe->ChipCaps.FOR_364_ECLK = TRUE;
        pcbe->ChipCaps.ALWAYS_ON_CR_CLOCK_AFTER_S3 = TRUE;
        break;
    case PCI_ID_VT3409P:
        pcbe->ChipCaps.PAD_on_off_in_SW_PS = TRUE;
        pcbe->ChipCaps.tv_two_clk_ctrl_sup = TRUE;
        pcbe->ChipCaps.IGA2Seq_SeparateDI_control = TRUE;
        pcbe->ChipCaps.DIPort_data_ctrl = TRUE;
        pcbe->ChipCaps.for_track_FIFO_Number_control = TRUE;
        pcbe->ChipCaps.for_killnumber_control = TRUE;
        /* CRT sense sequence : 
               * For vt3290(NEW_DAC_SENSE_FLOW: SR40[7]=1 --> SR40[7] = 0  --> check 3C2[4]
               * For 259/204(products before 290): SR40[7]=1 --> check 3C2[4] --> SR40[7]=0 */
        pcbe->ChipCaps.New_crt_dac_sense_flow = TRUE;
        pcbe->ChipCaps.INLVDS_Polarity_Control = TRUE;        
        pcbe->ChipCaps.GET_ECK_DEPENDON_SYSINFO = TRUE;
        pcbe->ChipCaps.FOR_409_S3_RESUME_PLL = TRUE;
        pcbe->ChipCaps.FOR_409_TTL_PANEL = TRUE;
        pcbe->ChipCaps.Is_killnumber_409_setting = TRUE;
        pcbe->ChipCaps.SSC_PATH_CONTROL = TRUE;
        pcbe->ChipCaps.HDMI_SUPPORT_DUPLICATE_MODE = FALSE;
        break;
    case PCI_ID_VT3410:
        pcbe->ChipCaps.PAD_on_off_in_SW_PS = TRUE;
        pcbe->ChipCaps.tv_two_clk_ctrl_sup = TRUE;
        pcbe->ChipCaps.IGA2Seq_SeparateDI_control = TRUE;
        pcbe->ChipCaps.DIPort_data_ctrl = TRUE;
        pcbe->ChipCaps.for_track_FIFO_Number_control = TRUE;
        /* CRT sense sequence : 
               * For vt3290(NEW_DAC_SENSE_FLOW: SR40[7]=1 --> SR40[7] = 0  --> check 3C2[4]
               * For 259/204(products before 290): SR40[7]=1 --> check 3C2[4] --> SR40[7]=0 */
        pcbe->ChipCaps.New_crt_dac_sense_flow = TRUE;
        pcbe->ChipCaps.INLVDS_Polarity_Control = TRUE;
        pcbe->ChipCaps.GET_ECK_DEPENDON_SYSINFO = TRUE;
        pcbe->ChipCaps.FOR_409_TTL_PANEL = TRUE;
        pcbe->ChipCaps.SSC_PATH_CONTROL = TRUE;
        pcbe->ChipCaps.SSC_INTERNAL_PATH_CONTROL = TRUE;
        pcbe->ChipCaps.IGA1_Support_Upscale = TRUE;
        pcbe->ChipCaps.IGA12_Support_Downscale = TRUE;
        pcbe->ChipCaps.IGA1_Support_Pixel_Timing = TRUE;
        pcbe->ChipCaps.VDCLK_Support = TRUE;
        pcbe->ChipCaps.NEW_EXTERN_TIMING_LOCK = TRUE;
        pcbe->ChipCaps.InternalDP_Support = TRUE;
        pcbe->ChipCaps.EXTEND_DEVICE_DEFINE = TRUE;
        pcbe->ChipCaps.NEW_PWM_SRC_CLOCK_SEL = TRUE;
        pcbe->ChipCaps.I2C_HWMasteringCR_Mode = FALSE;
        /* 410 A2 fix this issue */
        if (pcbe->ChipRevision < 0x02) {
            /* check is it A0 or A1 */
            pcbe->ChipCaps.HW_FETCHCNT_ADD24 = TRUE;
            pcbe->ChipCaps.DP_FOR_410_A0_A1 = TRUE;
        }
        pcbe->ChipCaps.VT3410_HDMI_ENGINE_CLOCK_GATING = TRUE;
        pcbe->ChipCaps.HDMI_SUPPORT_DUPLICATE_MODE = FALSE;
        break;
    default:
        cbDbgPrint(0, "No default ChipCapsInit! \n");
        break;
    }
    
    /* Enable this feature for all chips, temporary solution
        * refine it when refine cbios misc related functions */
    pcbe->ChipCaps.S1_power_saving_sup = TRUE;

    /* ---------------------------------------------------------
        * SSC misc init
        * for SSC status. we need to get two kinds of informations
        * 1. currently, SSC on / off status from register stating
        * 2. SSC setting configurations from VBIOS ROMIMAGE
        * --------------------------------------------------------- */
    pcbe->ChipCaps.SSC_Enable = FALSE;
    pcbe->ChipCaps.SSC_Using_External = TRUE;
    pcbe->ChipCaps.SSC_Using_Fifo_Mode = FALSE;
    pcbe->SSC_Spreading_Range = 0;
    if (pcbe->pVCPInfo->BIOSSupportDev & S3_LCD) {
        BYTE data;
        if (pcbe->pVCPInfo->miscConfigure2 & IGA2_SSC_ENABLE) {
            pcbe->ChipCaps.SSC_Enable=TRUE;
            if (pcbe->pVCPInfo->miscConfigure2 & SSC_Fifo_Mode) {
                pcbe->ChipCaps.SSC_Using_Fifo_Mode=TRUE;
            }
        }
        else if (cbSearchVBIOSInitTable_UMA(pcbe, ZSR, 0x1E, &data)&&(data & BIT3)) {
            /* in order to be compatible with old vbios, we need to search the init table
                      * here we should move ssc info from init table to ChipCaps */
            pcbe->ChipCaps.SSC_Enable=TRUE;
        
            if(cbSearchVBIOSInitTable_UMA(pcbe,ZSR,  0x2A, &data)&&(data & BIT6)) {
                pcbe->ChipCaps.SSC_Using_Fifo_Mode=TRUE;
            }
        }
        /* if SSC was enable in sr1e,then set the enable flag and default is original mode */
        else if (cbReadRegByte(pcbe, SR_1E) & BIT3) {
            pcbe->ChipCaps.SSC_Enable=TRUE;
            if(cbReadRegByte(pcbe, SR_2A) & BIT6) {
                pcbe->ChipCaps.SSC_Using_Fifo_Mode=TRUE;
            }
        }
    }
    /* get PAD_ON_OFF_IN_SW_PS misc control from VBIOS */
    if (pcbe->pVCPInfo->miscConfigure2 & BIT8) {
        pcbe->ChipCaps.PAD_on_off_in_SW_PS = TRUE;
    }
    
    pcbe->ChipCaps.PLL_USE_409_FORMULA = FALSE;
    if (pcbe->pVCPInfo->miscConfigure2 & PLL_USE_409_FORMULA_BIT) {
        pcbe->ChipCaps.PLL_USE_409_FORMULA = TRUE;
    }

    if (pcbe->pVCPInfo->miscConfigure3 & SW_PS_CTRL_EDP_BY_PS1) {	
		pcbe->ChipCaps.UseEDPOnDP2 = TRUE;
	}
    
	pcbe->ChipCaps.Force_HDMI_to_DVI_Mode = FALSE;	
}
/*****************************************************************************************/
//
//Function:cbCbiosChipCapsInit
//Discription:
//      This function will init CBIOS chip Caps for some chip related feature or limitation
//Return:
//      None
//
/*****************************************************************************************/
void cbCbiosInterruptInit(PCBIOS_EXTENSION pcbe)
{
    // Now this function will only init DI port HPD and EDID buffer related bits
    // If add more interrupt handle later, we can add its init here
    BYTE i;
    
    for(i=0; i<DigitalPortNUM; i++)
    {
        pcbe->DIPort[i].bHPDInterrpted = FALSE;
        pcbe->DIPort[i].bIsEDIDUpdated = FALSE;
    }
}
