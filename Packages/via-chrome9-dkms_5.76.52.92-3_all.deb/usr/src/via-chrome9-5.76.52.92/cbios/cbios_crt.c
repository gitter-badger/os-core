/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "cbios_uma.h"
#include "cbios_sub_func.h"
#include "cbios_vesa_vpit.h"
#include "cbios_cea_timing.h"

//=============================================================================
// below is new sub functions
//=============================================================================

//*****************************************************************************
// cbTransVESAVPITToTimingTbl
//   This function transfers the VESA vpit timing table to GFX timing table which
// CBIOS uses to load on both IGAs.
//  IN :
//      pVESA_Info : VESA Info pointer
//      pVESA_VPIT : VESA VPIT pointer
//  OUT :
//      pGFXTimingTbl : GFX timing table
//*****************************************************************************
void cbTransVESAVPITToTimingTbl(
    IN PVESA_INFO pVESA_Info,
    IN PVESA_VPIT pVESA_VPIT,
    OUT PGFXTimingTable pTimingTbl
)
{
    if (!pVESA_Info || !pVESA_VPIT || !pTimingTbl)
    {
        ASSERT(FALSE);
        return;
    }

    pTimingTbl->rRateX100   = pVESA_VPIT->RRate * 100;
    pTimingTbl->vPLL        = pVESA_VPIT->PLL;

    pTimingTbl->HPolarity = (pVESA_VPIT->Attribute & ATT_PHS) ? CBIOS_POSITIVE : CBIOS_NEGATIVE;
    pTimingTbl->VPolarity = (pVESA_VPIT->Attribute & ATT_PVS) ? CBIOS_POSITIVE : CBIOS_NEGATIVE;
    
    // horizontal
    pTimingTbl->HTotal     = pVESA_VPIT->HTotal;
    pTimingTbl->HDisEnd    = pVESA_Info->HSize;
    pTimingTbl->HSyncStart = pVESA_VPIT->HSyncSt;
    pTimingTbl->HSyncEnd   = pVESA_VPIT->HSyncEd;
    // has border?
    if (pVESA_VPIT->Attribute & ATT_HB)
    {
        pTimingTbl->HBlankStart = pTimingTbl->HDisEnd + 8;
        pTimingTbl->HBlankEnd   = pTimingTbl->HTotal - 8;
    }
    else
    {
        pTimingTbl->HBlankStart = pTimingTbl->HDisEnd;
        pTimingTbl->HBlankEnd   = pTimingTbl->HTotal;
    }
    
    // vertical
    pTimingTbl->VTotal     = pVESA_VPIT->VTotal;
    // is interlace mode?
    if (pVESA_VPIT->Attribute & ATT_I)
    {
        pTimingTbl->Interlaced = INTERLACE;
        pTimingTbl->VDisEnd    = pVESA_Info->VSize / 2;
    }
    else
    {
        pTimingTbl->Interlaced = PROGRESSIVE;
        pTimingTbl->VDisEnd    = pVESA_Info->VSize;
    }
    pTimingTbl->VSyncStart = pVESA_VPIT->VSyncSt;
    pTimingTbl->VSyncEnd   = pVESA_VPIT->VSyncEd;
    // has border?
    if (pVESA_VPIT->Attribute & ATT_VB)
    {
        pTimingTbl->VBlankStart = pTimingTbl->VDisEnd + 8;
        pTimingTbl->VBlankEnd   = pTimingTbl->VTotal - 8;
    }
    else
    {
        pTimingTbl->VBlankStart = pTimingTbl->VDisEnd;
        pTimingTbl->VBlankEnd   = pTimingTbl->VTotal;
    }

    // set timing aspect ratio to zero
    pTimingTbl->AspectRatio = CBIOS_NONE;
    // set VESA timing V_Sync offset to zero
    pTimingTbl->VSyncOffset = 0;
}

//*****************************************************************************
//
//  cbGetVESAVPITResolutionsBuffer
//
//      This function fills the memory buffer for resolutions in VESAVPIT 
//  which is less than given max H, V resolution size, and returns the memory buffer
//  length be filled by CBIOS
//
//  Parameters:
//      Max_H_Res:      Max Horizontal Resolution (pixel)
//      Max_V_Res:      Max Vertical Resolution (pixel)
//      pResBuf : total buffer used to fill resolutions 
//      bufSize : buffer size of pResBuf passed to this function
//      pBufSize :  real buffer size of whole VESA VPIT resolutions
//  Return Value:
//      function status
//****************************************************************************
BOOL cbGetVESAVPITResolutionsBuffer(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD Max_H_Res,
    IN DWORD Max_V_Res,
    OUT DWORD *pResBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize)
{
    PVESA_INFO pVESA_Info = NULL;
    DWORD xyNum = 0;

    if (NULL == pResBuf)
    {
        // not need fill buffer, set size = 0 for later logic
        bufSize = 0;
    }

    if (pcbe->pVCPInfo != NULL)
    {
        pVESA_Info = (PVESA_INFO)(pcbe->RomData + pcbe->pVCPInfo->VESAVPITPtr);
        // search VESAVPIT table
        while (pVESA_Info->HSize != INVALID_H_SIZE)
        {
            // check for VESAVPIT availabe & less than EDID panel size 
            if( cbIsModeAvailable(pcbe, 0, pVESA_Info)
                && ((Max_H_Res >= pVESA_Info->HSize) && (Max_V_Res >= pVESA_Info->VSize)))
            {
                //Is buffer size enough for saving next mode?
                if ( ((xyNum+2) * sizeof(DWORD)) <= bufSize )
                {
                    // if enough space in the buffer, fill res in
                    pResBuf[xyNum]   = pVESA_Info->HSize; // XResolution
                    pResBuf[xyNum+1] = pVESA_Info->VSize; // YResolution
                }
                xyNum += 2;
            }
            pVESA_Info = (PVESA_INFO)((PBYTE)pVESA_Info + sizeof(VESA_INFO) + pVESA_Info->RRateCount * sizeof(VESA_VPIT));
        } //while (pVESA_Info->HSize != INVALID_H_SIZE)
    }

    // if now resolution supported return FALSE
    if (xyNum == 0)
    {
        return FALSE;
    }
    else
    {
        if (pBufSize != NULL)
        {
            *pBufSize = xyNum * sizeof(DWORD);
        }
        return TRUE;
    }       
}

//*****************************************************************************
//
//  cbGetCEAResolutionsBuffer
//
//      This function fills the memory buffer for resolutions in CBIOS CEA resolution  
//  table, and returns the memory buffer length which has been filled by CBIOS.
//
//  Parameters:
//      pResBuf : total buffer used to fill resolutions 
//      pBufSize :  IN  : buffer size passed to this function
//                  OUT : buffer size used to fill resolution
//  Return Value:
//      function status
//****************************************************************************
BOOL cbGetCEAResolutionsBuffer(
    PCBIOS_EXTENSION pcbe, 
    OUT DWORD *pResBuf,
    IN OUT DWORD *pBufSize)
{
    DWORD xyNum;
    
    if (!pResBuf || !pBufSize)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    for (xyNum = 0; xyNum < CEA861_FORMAT_RES_NUM;   xyNum += 2)
    {
        //Is buffer size enough for saving next mode?
        if ( ((xyNum+2) * sizeof(DWORD)) > (*pBufSize) )
        {
            // if no enough space in the buffer, jump out
            break;
        }
        pResBuf[xyNum]   = CEA861_FormatResTbl[xyNum];  // XResolution
        pResBuf[xyNum+1] = CEA861_FormatResTbl[xyNum+1]; // YResolution
    }

    *pBufSize = xyNum * sizeof(DWORD);

    return TRUE;
}

//*****************************************************************************
//
//  cbGetVESAVPITRefreshRatesForResolution
//
//      This function fills refresh rate information memory buffer for  EDID timing
//  type type resolution.
//
//  Parameters:
//      H_Res:          Horizontal Resolution (pixel)
//      V_Res:          Vertical Resolution (pixel)
//      pRRatesInfoBuf: refresh rate buffer for CBIOS to fill in
//      bufSize:        buffer size of pRRatesInfoBuf
//      pBufSize:       returns the buffer size of whole VESA VPIT Refresh Rates required in bytes
//                      for the specified device and resolution
//
//  Return Value:
//      function status
//****************************************************************************
BOOL cbGetVESAVPITRefreshRatesForResolution(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN DWORD bufSize,
    OUT DWORD *pBufSize)
{   
    PVESA_INFO pVESA_Info = NULL;
    PVESA_VPIT pVESA_VPIT = NULL;
    DWORD rrNum = 0, i;

    if (NULL == pRRatesInfoBuf)
    {
        // not need fill buffer, set size = 0 for later logic
        bufSize = 0;
    }

    // we just report all vbios VESAVPIT support refresh rate
    if (cbGetVBIOSVesaInfo(pcbe, H_Res, V_Res, &pVESA_Info))
    {
        pVESA_VPIT = (PVESA_VPIT)(pVESA_Info + 1);
        // fill all refresh rate in buf
        for (i = 0; i < pVESA_Info->RRateCount; i++)
        {
            // if refresh rate exists in EDID using EDID refreshrate
            if(!(pVESA_VPIT[i].Attribute & ATT_DISABLE))
            {
                // Is buffer size enough for saving next refresh rate?
                if ( ((rrNum+1) * sizeof(RefreshRateInfo)) <= bufSize )
                {
                    // if enough space in the buffer, fill in
                    pRRatesInfoBuf[rrNum].rRateX100= pVESA_VPIT[i].RRate * 100;
                    pRRatesInfoBuf[rrNum].interlaced = pVESA_VPIT[i].Attribute & ATT_I;
                }
                rrNum++;
            }
        } // for RRateCount
    }

    if (rrNum == 0)
    {
        return FALSE;
    }
    else
    {
        if (pBufSize != NULL)
        {
            *pBufSize = rrNum * sizeof(RefreshRateInfo);
        }
        return TRUE;
    }
}

//*****************************************************************************
//
//  cbGetCEARefreshRatesForResolution
//
//      This function fills refresh rate information memory buffer from CEA timing
//  table.
//
//  Parameters:
//      H_Res:          Horizontal Resolution (pixel)
//      V_Res:          Vertical Resolution (pixel)
//      pRRatesInfoBuf  refresh rate buffer for CBIOS to fill in 
//      bufSize:        buffer size of pRRatesInfoBuf
//      pBufSize:       returns buffer size of whole CEA Refresh Rates
//                      for the specified device and resolution
//
//  Return Value:
//      function status
//****************************************************************************
BOOL cbGetCEARefreshRatesForResolution(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize)
{   
    DWORD rrNum = 0, i;

    if (NULL == pRRatesInfoBuf)
    {
        // not need fill buffer, set size = 0 for later logic
        bufSize = 0;
    }

    for (i = 0; i < CEA861_FORMAT_NUM; i++)
    {
        if ( ( CEA861_FormatTbl[i].Interlaced == PROGRESSIVE ||
                (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
            && CEA861_FormatTbl[i].XRes == H_Res 
            && CEA861_FormatTbl[i].YRes == V_Res)
        {
            if(((rrNum+1) * sizeof(RefreshRateInfo)) <= bufSize )
            {
                // if enough space in the buffer, fill in
                pRRatesInfoBuf[rrNum].rRateX100 = CEA861_FormatTbl[i].rRateX100;
                pRRatesInfoBuf[rrNum].interlaced = CEA861_FormatTbl[i].Interlaced;
            }
            rrNum++;
        }
    }

    if (rrNum == 0)
    {
        return FALSE;
    }
    else
    {
        if (pBufSize != NULL)
        {
            *pBufSize = rrNum * sizeof(RefreshRateInfo);
        }
        return TRUE;
    }
}

// Get Vesa Info from VBIOS by resolution
BOOL cbGetVBIOSVesaInfo(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT PVESA_INFO *ppVESA_Info
)
{
    WORD OffsetVPIT;
    PVESA_INFO pVESA_Info;
    BYTE VesaVPITLen = sizeof(VESA_VPIT);
    BYTE VesaInfoLen = sizeof(VESA_INFO);

    if (NULL == pcbe->pVCPInfo)
    {
        return FALSE;
    }

    OffsetVPIT = pcbe->pVCPInfo->VESAVPITPtr;
    pVESA_Info = (PVESA_INFO)(pcbe->RomData + OffsetVPIT);
    
    while(pVESA_Info->HSize != INVALID_H_SIZE)
    {
        if((H_Res == pVESA_Info->HSize) && (V_Res == pVESA_Info->VSize))
        {
            // found VESA mode info
            *ppVESA_Info = pVESA_Info;
            return TRUE;
        } // if HV equal
        // search next mode
        pVESA_Info = (PVESA_INFO)((PBYTE)pVESA_Info + VesaInfoLen + pVESA_Info->RRateCount * VesaVPITLen);
    }
    return FALSE;
}

//-------------------------------------------------------------------------
//cbGetVBIOSVesaTimingTable
//     This function get closest timing which stored in VESAVPIT timing. Timing includes
//  X / Y resolution & refreshrate( interlace / non interlace)
//  IN : 
//     XRes  : X resolution 
//     YRes  : Y resolution
//     rRateInfo : refresh rate number x 100
//              whether interlaced
//  OUT :
//     pTimingTbl  : Timing table
//     function return status
//------------------------------------------------------------------------
BOOL cbGetVBIOSVesaTimingTable(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo,
    IN BOOL bReduceBlk,
    OUT PGFXTimingTable pTimingTbl
)
{
    PVESA_INFO pVESA_Info = NULL;
    BYTE VesaVPITLen = sizeof(VESA_VPIT);
    BYTE VesaInfoLen = sizeof(VESA_INFO);

    WORD curH = 0xffff, curV = 0xffff;
    PVESA_INFO pCurVesaInfo = NULL;
    PVESA_VPIT pCurVesaVpit = NULL;

    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    if (NULL == pcbe->pVCPInfo)
    {
        return FALSE;
    }

    if (bReduceBlk)
    {
        if (pcbe->pVCPInfo->version >= VCP1_6 && 
            0 != pcbe->pVCPInfo->RBKVESAVPITStart)
        {
            pVESA_Info = (PVESA_INFO)(pcbe->RomData + pcbe->pVCPInfo->RBKVESAVPITStart);
        }    
    }
    else
    {
        pVESA_Info = (PVESA_INFO)(pcbe->RomData + pcbe->pVCPInfo->VESAVPITPtr);
    }
    if (pVESA_Info == NULL)
    {
        return FALSE;
    }

    while(pVESA_Info->HSize != INVALID_H_SIZE)
    {
        if((H_Res <= pVESA_Info->HSize) && (V_Res <= pVESA_Info->VSize))
        {
            // found bigger VESA mode info
            // resolution match, search refresh rate
            BYTE i;
            PVESA_VPIT pVESA_VPIT = (PVESA_VPIT)((BYTE*)pVESA_Info + sizeof(VESA_INFO));

            for (i=0; i<pVESA_Info->RRateCount; i++)
            {
                if (!(pVESA_VPIT->Attribute & ATT_DISABLE)
                    && rRateInfo.rRateX100 == pVESA_VPIT->RRate * 100
                    && rRateInfo.interlaced == (pVESA_VPIT->Attribute & ATT_I))
                {
                    // same rrate, available timing
                    // is this timing closer? for VESA VPIT not sort by resolution, we must get smaller one
                    if (pVESA_Info->HSize <= curH && pVESA_Info->VSize <= curV)
                    {
                        curH = pVESA_Info->HSize;
                        curV = pVESA_Info->VSize;
                        pCurVesaInfo = pVESA_Info;
                        pCurVesaVpit = pVESA_VPIT;
                    }
                }
                pVESA_VPIT++; // += sizeof(VESA_VPIT);
            } // for RRateCount
        } // if HV bigger
        // search next mode
        pVESA_Info = (PVESA_INFO)((PBYTE)pVESA_Info + VesaInfoLen + pVESA_Info->RRateCount * VesaVPITLen);
    }

    if (NULL != pCurVesaInfo)
    {
        cbTransVESAVPITToTimingTbl(pCurVesaInfo, pCurVesaVpit, pTimingTbl);
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

//-------------------------------------------------------------------------
//cbIsVBIOSVesaTimingTableExsist
//     This function query if timing is valid in VESAVPIT timing. Timing includes
//  X / Y resolution & refreshrate( interlace / non interlace)
//  IN : 
//     XRes  : X resolution 
//     YRes  : Y resolution
//     rRateInfo : refresh rate number x 100
//              whether interlaced
//  OUT :
//     function return status
//------------------------------------------------------------------------
BOOL cbIsVBIOSVesaTimingTableExsist(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo)
{
    PVESA_INFO pVESA_Info;

    if (cbGetVBIOSVesaInfo(pcbe, H_Res, V_Res, &pVESA_Info))
    {
        // resolution match, search refresh rate
        BYTE i;
        PVESA_VPIT pVESA_VPIT = (PVESA_VPIT)((BYTE*)pVESA_Info + sizeof(VESA_INFO));

        for (i = 0; i < pVESA_Info->RRateCount; i++)
        {
            if (!(pVESA_VPIT->Attribute & ATT_DISABLE)
              && rRateInfo.rRateX100 == pVESA_VPIT->RRate * 100
              && rRateInfo.interlaced == (pVESA_VPIT->Attribute & ATT_I))
            {
                return TRUE;
            }
            pVESA_VPIT++; // += sizeof(VESA_VPIT);
        } // for RRateCount
    }

    return FALSE;
}

//--------------------------------------------------------------------------
// cbGetCBIOSVesaInfo
//   Get VESA info from CBIOS by resolution
//  IN :
//      H_Res : H resolution size
//      V_Res : V resolution size
//      pVESA_Info_CBIOSTbl : VESA info table address
//      TableNum : entity number of the VESA info table
//  OUT :
//      ppVESA_Info_CBIOS_Entity :
//            pointer to CBIOS VESA VPIT element
//--------------------------------------------------------------------------
BOOL cbGetCBIOSVesaInfo(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN PVESA_INFO_CBIOS pVESA_Info_CBIOSTbl,
    IN DWORD TableNum,
    OUT PVESA_INFO_CBIOS *ppVESA_Info_CBIOS_Entity)
{
    ULONG i;

    if (!pVESA_Info_CBIOSTbl || !ppVESA_Info_CBIOS_Entity)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    for( i = 0; i < TableNum; i++)
    {
        // if H / V all equal
        if((H_Res == pVESA_Info_CBIOSTbl[i].vesainfo.HSize) && (V_Res == pVESA_Info_CBIOSTbl[i].vesainfo.VSize))
        {
            // found VESA mode info from CBIOS
            *ppVESA_Info_CBIOS_Entity = &pVESA_Info_CBIOSTbl[i];
            return TRUE;
        }
    }
    return FALSE;
}


//--------------------------------------------------------------------------
// cbGetCBIOSCEAInfo---This function is obsoleted after adding all ceat timing suppport
//   Get CEA info from CBIOS by resolution
//  IN :
//      H_Res : H resolution size
//      V_Res : V resolution size
//  OUT :
//      PCEA_INFO_CBIOS :
//            pointer to CBIOS CEA VPIT element
//--------------------------------------------------------------------------
BOOL cbGetCBIOSCEAInfo(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT PCEA_INFO_CBIOS *ppCEA_Info_CBIOS
)
{
    PCEA_INFO_CBIOS pCEA_Info_CBIOS = CEA_MODE_TABLE_CBIOS;
	ULONG i;

    if (!ppCEA_Info_CBIOS)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    for( i = 0; i < CBIOS_CEA_MODESUPPORT_NUM; i++)
    {
        // if H / V all equal
        if((H_Res == pCEA_Info_CBIOS[i].ceainfo.HSize) && (V_Res == pCEA_Info_CBIOS[i].ceainfo.VSize))
        {
            // found CEA mode info from CBIOS
            *ppCEA_Info_CBIOS = &pCEA_Info_CBIOS[i];
            return TRUE;
        } 
    }
    return FALSE;
}


//-------------------------------------------------------------------------
//cbGetCBIOSVesaTimingTable
//     This function get closest  timing which stored in CBIOS VESAVPIT timing. Timing
//  includes X / Y resolution & refreshrate( interlace / non interlace)
//  IN : 
//     XRes  : X resolution 
//     YRes  : Y resolution
//     rRateInfo : refresh rate number  x 100
//                 whether interlaced
//     pVESA_Info_CBIOSTbl : CBIOS VESA info table address
//     TableNum : table entity number
//  OUT :
//     pTimingTbl  : Timing table 
//     function return status
//------------------------------------------------------------------------
BOOL cbGetCBIOSVesaTimingTable(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo,
    IN PVESA_INFO_CBIOS pVESA_Info_CBIOSTbl,
    IN DWORD TableNum,
    OUT PGFXTimingTable pTimingTbl)
{
    DWORD i, j;
    PVESA_INFO_CBIOS pVESA_Info_CBIOS_Entity = NULL;

    WORD curH = 0xffff, curV = 0xffff;
    PVESA_INFO pCurVesaInfo = NULL;
    PVESA_VPIT pCurVesaVpit = NULL;

    if (!pVESA_Info_CBIOSTbl || !pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    for (i=0; i<TableNum; i++)
    {
        pVESA_Info_CBIOS_Entity = pVESA_Info_CBIOSTbl + i;

        // if H / V all smaller than timing
        if((H_Res <= pVESA_Info_CBIOS_Entity->vesainfo.HSize) && (V_Res <= pVESA_Info_CBIOS_Entity->vesainfo.VSize))
        {
            // found bigger VESA mode info from CBIOS
            BYTE rRateCount = pVESA_Info_CBIOS_Entity->vesainfo.RRateCount;
            for (j=0; j < rRateCount; j++)
            {
                if (rRateInfo.rRateX100 == pVESA_Info_CBIOS_Entity->pvesavpit[j].RRate * 100
                    && rRateInfo.interlaced == (pVESA_Info_CBIOS_Entity->pvesavpit[j].Attribute & ATT_I))
                {
                    // same rrate, available timing
                    // is this timing closer? for VESA VPIT not sort by resolution, we must get smaller one
                    if (pVESA_Info_CBIOS_Entity->vesainfo.HSize <= curH && pVESA_Info_CBIOS_Entity->vesainfo.VSize <= curV)
                    {
                        curH = pVESA_Info_CBIOS_Entity->vesainfo.HSize;
                        curV = pVESA_Info_CBIOS_Entity->vesainfo.VSize;
                        pCurVesaInfo = &pVESA_Info_CBIOS_Entity->vesainfo;
                        pCurVesaVpit = &pVESA_Info_CBIOS_Entity->pvesavpit[j];
                    }
                }
            } // for j<RRateCount
        } // if H / V all smaller than timing
    } // for i<TableNum

    if (NULL != pCurVesaInfo)
    {
        cbTransVESAVPITToTimingTbl(pCurVesaInfo, pCurVesaVpit, pTimingTbl);
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

//-------------------------------------------------------------------------
//cbGetCBIOSCEATimingTable---This function is obsoleted after adding all ceat timing suppport
//     This function query if timing is stored in CBIOS CEAVPIT timing. Timing
//  includes X / Y resolution & refreshrate( interlace / non interlace)
//  IN : 
//     XRes  : X resolution 
//     YRes  : Y resolution
//     rRateInfo : refresh rate number  x 100
//              whether interlaced
//  OUT :
//     pTimingTbl  : Timing table 
//     function return status
//------------------------------------------------------------------------
BOOL cbGetCBIOSCEATimingTable(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo,
    OUT PGFXTimingTable pTimingTbl)
{
    PCEA_INFO_CBIOS pCEA_Info_CBIOS;
	ULONG i;

    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

	if (cbGetCBIOSCEAInfo(pcbe, H_Res, V_Res, &pCEA_Info_CBIOS))
    {
        for (i=0; i < pCEA_Info_CBIOS->ceainfo.RRateCount; i++)
        {
            if (rRateInfo.rRateX100 == pCEA_Info_CBIOS->pceavpit[i].RRate * 100
              && rRateInfo.interlaced == (pCEA_Info_CBIOS->pceavpit[i].Attribute & ATT_I))
            {
                cbTransVESAVPITToTimingTbl(&pCEA_Info_CBIOS->ceainfo, &pCEA_Info_CBIOS->pceavpit[i], pTimingTbl);
                return TRUE;
            }
        } // for RRateCount
    }
    
    return FALSE;

}



//--------------------------------------------------------------------------
// cbSetCRTPowerState
//  change CRT PowerState & initial digital port associated
//  IN 
//      powerstate : ON /OFF
//--------------------------------------------------------------------------
void cbSetCRTPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate)
{
    if(powerstate == S3PM_ON)
    {
        // initial digital port associate with device
        cbConfigureDigitalPort(pcbe, S3_CRT, ON);
        // CRT DPMS ON
        cbWriteRegBits(pcbe, CR_36, BIT4 + BIT5, 0x00);
    }   
    else if(powerstate == S3PM_OFF)
    {
        // CRT DPMS OFF
        cbWriteRegBits(pcbe, CR_36, BIT4 + BIT5, 0x30);
    }
    else
    {
        cbDbgPrint(1, "Now CRT only support Power state on/off!\n");
        return;
    }

    //update device power statue 
    pcbe->devicepowerstate[CRTbit] = powerstate;
}

//--------------------------------------------------------------------------
// cbSensorCRT2_UMA
//      DAC sensor of CRT2 on VT1625 / CH7301
//  OUT
//      pbAttached : Attached status
//  Return
//      CBIOS_STATUS
//--------------------------------------------------------------------------
CBIOS_STATUS cbSensorCRT2_UMA(PCBIOS_EXTENSION pcbe, OUT BOOL *pbAttached)
{
    CBIOS_STATUS status = CBIOS_OK;
    I2C_CONTROL_UMA i2c;
    BYTE RegE, RegF, Reg1C;
    ULONG encodertype = 0;

    i2c.Flags = 0;
    // get CRT2 associated TxType
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_CRT2) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return FALSE;
    }
               
    *pbAttached = FALSE; //default set to not connected
    
    if(pcbe->SupportDevices & S3_CRT2)
    {
        if (pcbe->pVCPInfo != NULL)
        {
            if(pcbe->pVCPInfo->version >= VCP1_2)
            {
                // CRT2 sense status update to scratchpad feature support
                if(pcbe->pVCPInfo->miscConfigure2 & BIT28)
                {
                    if(pcbe->sPad_9.CRT2SenseStatus)
                    {
                        *pbAttached = TRUE; 
                    }
                    else
                    {
                        *pbAttached = FALSE;
                    }
                    return status;
                }
                    
                // CRT2 force on 
                if (pcbe->pVCPInfo->miscConfigure2 & BIT0)
                {
                    *pbAttached = TRUE; 
                    return status;
                }
            }
        }
        
        cbGetDII2Csetting(pcbe, &i2c, S3_CRT2);

        if(encodertype == CH7301)
        {
            i2c.RegIndex  = 0x49;

            // if I2C work properly then check return value
            // get i2c register index data
            if(I2C_Read_Byte_INV(pcbe, &i2c) != TRUE)
            {
                status = CBIOS_ER_DDCRead;
            }
            if(status == CBIOS_OK)
            {
                //VGA to RGB Bypass On
                //BIT 0: Power Management on
                i2c.IndexData &= 0xF0;
                I2C_Write_Byte_INV(pcbe, &i2c);

                //BIT0 : disable DAC bypass mode
                i2c.RegIndex  = 0x21;
                I2C_Read_Byte_INV(pcbe, &i2c);
                i2c.IndexData &= 0xFE;
                I2C_Write_Byte_INV(pcbe, &i2c);

                //enable SENSE bit
                i2c.RegIndex  = 0x20;
                I2C_Read_Byte_INV(pcbe, &i2c);
                i2c.IndexData |= BIT0;
                I2C_Write_Byte_INV(pcbe, &i2c);

                i2c.IndexData &= 0xFE;
                I2C_Write_Byte_INV(pcbe, &i2c);
                
                I2C_Read_Byte_INV(pcbe, &i2c);

                //detect DAC status
                if((i2c.IndexData & 0x0E) == 0x0E)
                {
                    // it is CRT connected
                    *pbAttached = TRUE;
                }
                
                //BIT0 : enable DAC bypass mode
                i2c.RegIndex  = 0x21;
                I2C_Read_Byte_INV(pcbe, &i2c);
                i2c.IndexData |= BIT0;
                I2C_Write_Byte_INV(pcbe, &i2c);
            }
        }
        else // VT1625
        {
            i2c.RegIndex  = 0x0E;
            if(I2C_Read_Byte_INV(pcbe, &i2c) != TRUE)
            {
                status = CBIOS_ER_DDCRead;
            }
            if(status == CBIOS_OK)
            {
                //save tv encoder reg.0e for dac sense
                RegE = i2c.IndexData;
                i2c.IndexData = 0x00;
                I2C_Write_Byte_INV(pcbe, &i2c);
                
                // Normal DAC Sense,save tv encoder reg.1c
                i2c.RegIndex = 0x1C;
                I2C_Read_Byte_INV(pcbe, &i2c);
                Reg1C = i2c.IndexData;

                i2c.IndexData &= 0x1F;
                I2C_Write_Byte_INV(pcbe, &i2c);

                //Enable sense in Normal TV function mode
                //or the sense result will be wrong
                i2c.IndexData |= BIT7;
                I2C_Write_Byte_INV(pcbe, &i2c);

                //delay 5ms for register bit change
                cbDelayMicroSeconds(5000);

                //Before read the sense result, we must disable sense, and set to Normal TV function mode
                //Must do this, or the sense result will be wrong
                i2c.IndexData &= 0x1F;
                I2C_Write_Byte_INV(pcbe, &i2c);
               
                //read the sense result
                i2c.RegIndex = 0x0F;
                I2C_Read_Byte_INV(pcbe, &i2c);
                RegF = i2c.IndexData;

                //restore tv encoder reg.1c
                i2c.RegIndex = 0x1C;
                i2c.IndexData = Reg1C;
                I2C_Write_Byte_INV(pcbe, &i2c);

                //restore tv encoder reg.0e
                i2c.RegIndex = 0x0E;
                i2c.IndexData = RegE;
                I2C_Write_Byte_INV(pcbe, &i2c);

                if((RegF & 0x07) != 0x07)
                {
                    //Does DAC D/E/F connected ?
                    //CRT2 use DAC D/E/F
                    *pbAttached = TRUE;
                }
                else
                {
                    *pbAttached = FALSE; //no dac connected
                }
            }//if(status == CBIOS_OK)
        }
    }
    
    return status;
}

//--------------------------------------------------------------------------
// cbSetCRT2PowerState
//  change CRT2 PowerState & initial digital port associated
// but we should not turn off CRT2 for some special device
//  IN 
//      powerstate : ON /OFF
//--------------------------------------------------------------------------
void cbsetcrt2powerstate(PCBIOS_EXTENSION pcbe, IN PowerState powerstate)
{
    CBIOS_STATUS status = CBIOS_OK;
    I2C_CONTROL_UMA i2c;

    i2c.Flags = 0;
    cbGetDII2Csetting(pcbe, &i2c, S3_CRT2);
    
    if(powerstate == S3PM_ON)
    {
        ULONG encodertype = 0;

        // get CRT2 associated TxType
        if (cbGetDIEncodertype(pcbe, &encodertype, S3_CRT2) == FALSE)
        {
            cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
            return;
        }

        // initial digital port associate with device
        if(!cbConfigureDigitalPort(pcbe, S3_CRT2, ON))
        {
            return;
        }

        if(encodertype == CH7301)
        {
            //Disable YCrCb to RGB conversion
            i2c.RegIndex  = 0x56;
            I2C_Read_Byte_INV(pcbe, &i2c);
            i2c.IndexData &= 0xFE;
            I2C_Write_Byte_INV(pcbe, &i2c);

            //BIT0 : DAC bypass mode
            //BIT2 : DAC gain, low -RGB, high -YCrCb
            //BIT3 : enable the HSYNC and VSYNC outputs
            i2c.RegIndex  = 0x21;
            i2c.IndexData = 0x09;
            I2C_Write_Byte_INV(pcbe, &i2c);

            //VGA to RGB Bypass On
            //BIT 0: Power Management on
            //disable DVI also
            i2c.RegIndex  = 0x49;
            I2C_Read_Byte_INV(pcbe, &i2c);
            i2c.IndexData &= 0x30;
            I2C_Write_Byte_INV(pcbe, &i2c);
        }
        else //TV encoder
        {
            //TV encoder input selection
            i2c.RegIndex  = 0x00;
            i2c.IndexData = 0x03;
            status = I2C_Write_Byte_INV(pcbe, &i2c);

            //set TV encoder DAC type and enable autosense
            i2c.RegIndex  = 0x1C;
            i2c.IndexData = 0x60;
            status = I2C_Write_Bit_INV(pcbe, &i2c, BIT5+BIT6);

            //Enable GFX Hsync
            i2c.RegIndex  = 0x02;
            i2c.IndexData = 0x80;
            status = I2C_Write_Bit_INV(pcbe, &i2c, BIT7);

            //Enable GFX Vsync
            i2c.RegIndex  = 0x1E;
            i2c.IndexData = 0x40;
            status = I2C_Write_Bit_INV(pcbe, &i2c, BIT6);

            //set TV encoder DAC D~F on
            i2c.RegIndex  = 0x0E;
            i2c.IndexData = 0x00;
            status = I2C_Write_Bit_INV(pcbe, &i2c, BIT0+BIT1+BIT2);

            // reset CRT2 encoder(VT1625)
            cbTV1625Reset_UMA(pcbe, &i2c);
        }
    }
    //For some special device, we should not turn off CRT2
    else if(powerstate == S3PM_OFF && !(pcbe->pVCPInfo->miscConfigure2 & FORCE_CRT2_LIGHTON))
    {
        ULONG encodertype = 0;

        // get CRT2 associated TxType
        if (cbGetDIEncodertype(pcbe, &encodertype, S3_CRT2) == FALSE)
        {
            cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
            return;
        }

        if(encodertype == CH7301)
        {
            //BIT0 : DAC bypass mode
            //BIT2 : DAC gain, low -RGB, high -YCrCb
            //BIT3 : enable the HSYNC and VSYNC outputs
            i2c.RegIndex  = 0x21;
            i2c.IndexData = 0x0;
            I2C_Write_Byte_INV(pcbe, &i2c);
        }
        else //TV encoder
        {
            //set TV encoder DAC D~F on
            i2c.RegIndex  = 0x0E;
            i2c.IndexData = 0x07;
            status = I2C_Write_Bit_INV(pcbe, &i2c, BIT0+BIT1+BIT2);  
        }
        
        // initial digital port associate with device
        if(!cbConfigureDigitalPort(pcbe, S3_CRT2, OFF))
        {
            return;
        }
    }
    else
    {
        cbDbgPrint(1, "Now CRT2 only support Power state on/off!\n");
        return;
    }
    //update device power statue 
    pcbe->devicepowerstate[CRT2bit] = powerstate;
}

/*****************************************************************************************/
//
//Function:IsSkipMode
//Discription:
//      Check if the specified mode will be skipped when report mode support list to driver
//Return:
//      TRUE---  this mode group(8/16/32bpp) need skip(will be filtered out),when report to driver
//      FALSE--- this mode is valid,and do not need skip(will not be filtered out)
//
/*****************************************************************************************/
BOOL cbIsCRT2SkipMode(PCBIOS_EXTENSION pcbe, IN PVESA_INFO pVesaInfo)
{
    //for CRT2 on VT1625, filt out too big modes
    if(pcbe->SupportDevices & S3_CRT2)
    {
        DWORD PixelClk;
        DWORD CrtDACFreq;
        BYTE i = 0;
        PVESA_VPIT pVesaVPIT = (PVESA_VPIT)((PBYTE)pVesaInfo + sizeof(VESA_INFO));
        ULONG encodertype = 0;
        
        // get CRT2 associated TxType
        if (cbGetDIEncodertype(pcbe, &encodertype, S3_CRT2) == FALSE)
        {
            cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
            return FALSE;
        }

        if(encodertype == CH7301)
        {
            CrtDACFreq = CH7301_CRTDAC_MAX_FREQ;
        }
        else // VT1625
        {
            CrtDACFreq = VT1625_CRTDAC_MAX_FREQ;
        }

        while(i < pVesaInfo->RRateCount)
        {
            if( !(pVesaVPIT->Attribute & ATT_DISABLE) )
            {
                //Calculate the pixel clock value of the first Refresh rate
                PixelClk = (pVesaVPIT->HTotal) * (pVesaVPIT->VTotal) * (pVesaVPIT->RRate);
            
                //By now,CRT2 use VT1625 DAC and this DAC's Max frequency is 85Mhz
                if(PixelClk <= CrtDACFreq)
                {
                    return FALSE; //found one valid refresh rate,then this mode will not be skipped
                }
            }
            i++;
            pVesaVPIT++;
        }
        //no valid refresh rate found in this mode,so filter out this mode(will be skipped)
        return TRUE;
    } // if(pcbe->SupportDevices & CRT2)
    else
    {
        cbDbgPrint(0,"Function:cbIsCRT2SkipMode,Invalid Function call,CRT2 Unsupported !");
        return FALSE; //Other case,default not filter out the mode
    }
}

/*****************************************************************************************/
//
//Function:IsSkipRRate
//Discription:Check if the specified refresh rate of the mode need skip 
//            when report supported refresh rate list to driver
//Parameters:
//      RRValue:  The refresh rate value(in hz) for check
//                eg. if specified 60hz then RRValue is 60
//
//Return:
//      TRUE---  this refresh rate need skip(will be filtered out),when report to driver
//      FALSE--- this refresh rate is valid,and do not need skip(will not be filtered out)
//
/*****************************************************************************************/
BOOL cbIsCRT2SkipRRate(PCBIOS_EXTENSION pcbe, IN PVESA_INFO pVesaInfo,IN BYTE RRValue)
{
    //For CRT2, filt out the too big refresh rate according to the CRT2 Encoder DAC frequency
    //By now, only take care of CRT2 on VT1625 case
    if(pcbe->SupportDevices & S3_CRT2)
    {
        DWORD PixelClk;
        DWORD CrtDACFreq;
        BYTE i;
        PVESA_VPIT pVesaVPIT = (PVESA_VPIT)((PBYTE)pVesaInfo + sizeof(VESA_INFO));
        ULONG encodertype = 0;

        // get CRT2 associated TxType
        if (cbGetDIEncodertype(pcbe, &encodertype, S3_CRT2) == FALSE)
        {
            cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
            return FALSE;
        }

        if(encodertype == CH7301)
        {
            CrtDACFreq = CH7301_CRTDAC_MAX_FREQ;
        }
        else // VT1625
        {
            CrtDACFreq = VT1625_CRTDAC_MAX_FREQ;
        }
        
        for(i = 0; i < pVesaInfo->RRateCount; i++)
        {
            if( (pVesaVPIT->RRate == RRValue) && (!(pVesaVPIT->Attribute & ATT_DISABLE)) )
            {
                //Calculate the pixel clock value of the specified refresh rate 
                PixelClk = (pVesaVPIT->HTotal) * (pVesaVPIT->VTotal) * (pVesaVPIT->RRate);
                
                //By now,CRT2 use VT1625 DAC and this DAC's Max frequency is 85Mhz
                if(PixelClk <= CrtDACFreq)
                    return FALSE;  //do not filter out this refresh rate
                else
                    return TRUE; //filter out this refresh rate
            }
            pVesaVPIT++;
        }
        cbDbgPrint(0,"Function:cbIsCRT2SkipRRate,Unsupported or Disabled refresh rate !");
        //invalid refresh rate ,default return TRUE to skip it
        return TRUE;        
    } // if(pcbe->SupportDevices & CRT2)
    else
    {
        cbDbgPrint(0,"Function:cbIsCRT2SkipRRate,invalid Function call,CRT2 Unsupported !");
        return FALSE; //Other case,default return FALSE
    }
}

BOOL cbGetRefreshRatesForCRT (
    IN PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN OUT RefreshRateInfo *pRRatesInfoBuf,
    IN OUT DWORD *pBufSize
)
{
    BYTE rrNum = 0;
	ULONG i = 0;

    if (!pRRatesInfoBuf || !pBufSize)
    {
        cbDbgPrint(0, "cbGetRefreshRatesForCRT: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    if(dispDev == S3_CRT)
    {
        if (pcbe->devicetimingtype[CRTbit] == VESAVPIT_TIMING_TYPE)
        {
            // CRT refresh rate
            // 1. timing(Resolution & refresh rate) based on VBIOS VESAVPIT
            // 2. timing(Resolution & refresh rate) based on EDID detailed timing
            // if VESAVPIT has conflict with EDID we use EDID detailed timing
            //     if VCP is null we will use CBIOS VESAVPIT timing while do not use EDID
            // detailed timing 
            if (!cbGetCRTTypeRefreshRatesForResolution(pcbe, 
                                                       S3_CRT,
                                                       H_Res,
                                                       V_Res,
                                                       pRRatesInfoBuf,
                                                       *pBufSize,
                                                       NULL))
            {
                return FALSE;
            }
        }
        else if (pcbe->devicetimingtype[CRTbit] == EDID_ENABLEDEVSCALING_TIMING_TYPE)
        {
            // LCD monitor Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT 
            //    if Est / STD resolution == EDID detailed resolution
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target timing
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_CRT,
                                                    H_Res,
                                                    V_Res,
                                                    pRRatesInfoBuf,
                                                    *pBufSize,
                                                    NULL))
            { 
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe, 
                                                            H_Res,
                                                            V_Res,
                                                            pRRatesInfoBuf,
                                                            *pBufSize,
                                                            NULL))
                {
                    return FALSE;
                }
            }                                                        
        }
        else if (pcbe->devicetimingtype[CRTbit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_CRT,
                                                                  pRRatesInfoBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe, 
                                                            H_Res,
                                                            V_Res,
                                                            pRRatesInfoBuf,
                                                            *pBufSize,
                                                            NULL))
                {
                    return FALSE;
                }
            }
        }
        else
        {
            return FALSE;
        }
    }
    else if(dispDev == S3_CRT2)
    {
        if (pcbe->devicetimingtype[CRT2bit] == VESAVPIT_TIMING_TYPE)
        {
            PVESA_INFO pVESA_Info = NULL;
            if (cbGetVBIOSVesaInfo(pcbe, H_Res, V_Res, &pVESA_Info))
            {
                PVESA_VPIT pVesa_VPIT = (PVESA_VPIT)(pVESA_Info + 1);
                // fill all refresh rate in buf
                for (i = 0; i < pVESA_Info->RRateCount; i++)
                {
                    //Is refresh rate skipped ?
                    if( !cbIsCRT2SkipRRate(pcbe, pVESA_Info, pVesa_VPIT->RRate) )
                    {
                        pRRatesInfoBuf[rrNum].rRateX100= pVesa_VPIT->RRate * 100;
                        if (pVesa_VPIT->Attribute & ATT_I)
                        {
                            pRRatesInfoBuf[rrNum].interlaced = INTERLACE;
                        }
                        else
                        {
                            pRRatesInfoBuf[rrNum].interlaced = PROGRESSIVE;
                        }
                        rrNum++;
                        //Is buffer size enough for saving next refresh rate?
                        if ( ((rrNum+1) * sizeof(RefreshRateInfo)) > (*pBufSize) )
                        {
                            // if no enough space in the buffer, jump out
                            break;
                        }
                    }
                    pVesa_VPIT++; // += sizeof(VESA_VPIT);
                } // for RRateCount
                *pBufSize = rrNum * sizeof(RefreshRateInfo);
            }
            else
            {
                return FALSE;
            }
        }    
        else if (pcbe->devicetimingtype[CRT2bit] == EDID_ENABLEDEVSCALING_TIMING_TYPE)
        {
            // LCD monitor Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT 
            //    if Est / STD resolution == EDID detailed resolution
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target timing
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_CRT2,
                                                    H_Res,
                                                    V_Res,
                                                    pRRatesInfoBuf,
                                                    *pBufSize,
                                                    NULL))
            { 
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe, 
                                                            H_Res,
                                                            V_Res,
                                                            pRRatesInfoBuf,
                                                            *pBufSize,
                                                            NULL))
                {
                    return FALSE;
                }
            }                                                        
        }
        else if (pcbe->devicetimingtype[CRT2bit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_CRT2,
                                                                  pRRatesInfoBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe, 
                                                            H_Res,
                                                            V_Res,
                                                            pRRatesInfoBuf,
                                                            *pBufSize,
                                                            NULL))
                {
                    return FALSE;
                }
            }
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        cbDbgPrint(0,"cbGetRefreshRatesForCRT: Error, incorrectly parameter!");
        return FALSE;
    }

    return TRUE;
}
