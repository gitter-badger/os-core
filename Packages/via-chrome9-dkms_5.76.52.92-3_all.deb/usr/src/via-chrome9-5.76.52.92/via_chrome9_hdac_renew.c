/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "via_chrome9_hdac_renew.h"
#include "via_chrome9_display_common.h"

#define HDAC_RENEW_TIME_MS    20

static void via_hdmi_cts_renew(struct hdmi_cts_renew *ops)
{
	u32 cts_now = 0, cts = 0, mm_c294 = 0, mm_c298 = 0, mm_c29c = 0;

	/* renew it 50 times per second. */
	u32 timer_freq = 1000 / HDAC_RENEW_TIME_MS;

	cts_now = (MMIO_RD( 0xC29C) & 0xFF) << 12;
	cts = cts_now |= (MMIO_RD(0xC298) & 0xFFF00000) >> 20;

	if (cts_now != ops->cts
		&& (ops->counter * 1000) / timer_freq >=
		(ops->interval - ops->feedback)) {
		ops->increaser = ((ops->counter * 1000) / timer_freq) -
		ops->interval + ops->feedback;
		cts = ops->cts;
	}

	if (cts_now != ops->cts + 1
		&& ((ops->counter * 1000) / timer_freq <
		(ops->interval - ops->feedback))) {
		cts = ops->cts + 1;
	}

	ops->counter = (ops->counter + 1) % timer_freq;

	if (ops->counter == 0)
		ops->feedback = ops->increaser;

	if (cts != cts_now) {
		mm_c294 = (MMIO_RD(0xC294) & 0x0000000F) | 0x100000C0;
		mm_c294 |= ((cts - 1) << 8);
		MMIO_WR(0xC294, mm_c294);

		mm_c298 = MMIO_RD(0xC298) & 0x000FFFFF;
		mm_c298 |= ((cts & 0xFFF) << 20);
		MMIO_WR(0xC298, mm_c298);

		mm_c29c |= (cts >> 12) & 0xFF;
		MMIO_WR(0xC29C, mm_c29c);
	}
}

static void via_hdmi_cts_renew_timer_taskle(struct hdmi_cts_renew *ops)
{
#define PHY_FUNCTION_SELECT_HDMI    0x01
#define HDMI_MODE_ENBLE                    0x00000002
#define HDMI_MODE_ENBLE_MASK          0x00000042
	/**
	 *  we do not need to bak and restore 3c4 and 3d4, 
	 *  because cts renew do not operate SR/CR now. 
	 *  pixelclock will update when mode set .
	 *  sample rate will update when  HDAC interrupt triggered.
	 */
	u32 hdmi_ctl_flag = MMIO_RD(0xC280);
	u8 reg_crff = via_chrome9_read_vga_io(REG_CRFF);

	/* We run cts renew just when internal HDMI is working. */
	if ((PHY_FUNCTION_SELECT_HDMI & reg_crff) &&
		(HDMI_MODE_ENBLE == (hdmi_ctl_flag & HDMI_MODE_ENBLE_MASK))) {;
		via_hdmi_cts_renew(ops);
	}
}


static void via_chrome9_hdac_cts_renew_timer_func(unsigned long arg)
{
	struct hdmi_cts_renew * ops = (struct hdmi_cts_renew *)arg;
	u32 *pdata = &(ops->debug_counter);

	struct timer_list *cts_renew_t = &(ops->cts_renew_timer);

	if ((*pdata)%500 == 0)
		KMS_DEBUG("cts renew runs %d seconds past.\n", (*pdata)/50);

	(*pdata)++;
	via_hdmi_cts_renew_timer_taskle(ops);
	cts_renew_t->expires = get_jiffies_64()+msecs_to_jiffies(
		HDAC_RENEW_TIME_MS);
	/* register timer continue. */
	add_timer(cts_renew_t);
}

static void via_chrome9_hdac_cts_renew_timer_init(struct hdmi_cts_renew *ops)
{
	struct timer_list *cts_renew_t = &(ops->cts_renew_timer);
	init_timer(cts_renew_t);
	cts_renew_t->expires = get_jiffies_64()+msecs_to_jiffies(
		HDAC_RENEW_TIME_MS);
	cts_renew_t->data = (unsigned long)ops;
	cts_renew_t->function = (void *)
		via_chrome9_hdac_cts_renew_timer_func;
	add_timer(cts_renew_t);
	KMS_DEBUG("hdac cts renew run!\n");
}

static void via_chrome9_hdac_cts_renew_timer_exit(struct hdmi_cts_renew *ops)
{
	struct timer_list *cts_renew_t = &(ops->cts_renew_timer);

	del_timer_sync(cts_renew_t);

	/* Clear the cts renew variables, ready for re-enable cts renew timer. */
	ops->cts = 0;
	ops->interval = 0;
	ops->feedback = 0;
	ops->counter = 0;
	ops->increaser = 0;

	KMS_DEBUG("hdac cts renew unload!\n");
}

void via_chrome9_hdac_cts_renew_open(struct hdmi_cts_renew *ops)
{
	KMS_DEBUG("try to open\n");
	if (false == ops->is_hdmi_cts_timer_on) {
		ops->is_hdmi_cts_timer_on = true;
		via_chrome9_hdac_cts_renew_timer_init(ops);
	}
}

void via_chrome9_hdac_cts_renew_close(struct hdmi_cts_renew *ops)
{
	KMS_DEBUG("try to close\n");
	if (true ==ops->is_hdmi_cts_timer_on) {
		ops->is_hdmi_cts_timer_on = false;
		ops->debug_counter = 0;
		via_chrome9_hdac_cts_renew_timer_exit(ops);
	}
}

