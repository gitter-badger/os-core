/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _VIA_CHROME9_DMA_H_
#define _VIA_CHROME9_DMA_H_

/*via engine type*/
#define VIA_CHROME9_CMD_2D 0x10
#define VIA_CHROME9_CMD_3D 0x20
#define VIA_CHROME9_CMD_VD 0x40
#define VIA_CHROME9_CMD_HQV0 0x80
#define VIA_CHROME9_CMD_HQV1 0x100
#define VIA_CHROME9_CMD_VIDEO 0x200
#define VIA_CHROME9_CMD_DMA0 0x1000
#define VIA_CHROME9_CMD_DMA1 0x2000
#define VIA_CHROME9_CMD_DMA2 0x4000
#define VIA_CHROME9_CMD_DMA3 0x8000

#define VIA_CHROME9_CMD_GFX  (VIA_CHROME9_CMD_2D | VIA_CHROME9_CMD_3D)
#define VIA_CHROME9_CMD_MASK 0xFFF0

/* for multi-level branch buffer control */
#define VIA_CHROME9_MULTILEVEL_BRANCH_BUFFER_ENABLE 1

struct drm_via_chrome9_dma_manager {
	/* the ring buffer virtual address that we can visit */
	unsigned int *addr_linear;
	/* he ring buffer size */
	unsigned int dmasize;
	/* the ring buffer start virtual address */
	unsigned int *pstart;
	/* the pointer we have used */
	unsigned int *pinusebysw;
	/* the free pointer that we can write command */
	unsigned int *pfree;
	/* the ring buffer end virtual address */
	unsigned int *pend;
	/* the max command we can kick off */
	unsigned int maxkickoffsize;
	/* the offset of this ring buffer in gpu space */
	unsigned int physical_start;
	/* lock for command flush */
	struct mutex command_flush_lock;
};

enum cmd_request_type {
	CM_REQUEST_BCI,
	CM_REQUEST_DMA,
	CM_REQUEST_RB,
	CM_REQUEST_RB_FORCED_DMA,
	CM_REQUEST_NOTAVAILABLE
};

struct cmd_get_space {
	unsigned int            dwrequestsize; /* the command size we request */
	enum cmd_request_type      hint;
	__volatile__ unsigned long *pcmddata;
};

struct cmd_release_space {
	unsigned int  dwreleasesize;
};

struct drm_via_chrome9_flush {
	int    cmd_size; /* command dword size */
	unsigned int *dma_buf; /* command buffer pointer */
};
extern void via_chrome9_init_dma(struct drm_device *dev);
extern void via_chrome9_dma_fini(struct drm_device *dev);
extern void via_chrome9_resume_dma(struct drm_device *dev);
extern void via_chrome9_suspend_dma(struct drm_device *dev);
extern void via_chrome9_init_gart_table(struct drm_device *dev);
extern void via_chrome9_gart_table_fini(struct drm_device *dev);
extern void via_chrome9_suspend_gart_table(struct drm_device *dev);
extern int via_chrome9_ringbuffer_flush(struct drm_device *dev,
			unsigned int *dma_buf, int command_size, bool from_user,
			void *parse_ptr);
extern int via_chrome9_branchbuffer_flush(struct drm_device *dev,
	struct via_chrome9_object *cmd_obj, int command_size, void *parse_ptr);
extern void via_chrome9_kickoff_dma_ring(struct drm_device *dev);
extern int execute_branch_buffer_h6(struct drm_device *dev,
	struct via_chrome9_object *vbo, uint32_t cmd_size);
extern int execute_branch_buffer_h5s2vp1(struct drm_device *dev,
	struct via_chrome9_object *vbo, uint32_t cmd_size);
#if VIA_CHROME9_MULTILEVEL_BRANCH_BUFFER_ENABLE
extern void via_chrome9_instert_sync_cmd_h5s2vp1(struct drm_device *dev,
	unsigned int wait_engines, unsigned int cmd_type);
extern void via_chrome9_instert_sync_cmd_h6(struct drm_device *dev,
	unsigned int wait_engines, unsigned int cmd_type);
#endif
#endif
