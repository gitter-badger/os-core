/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "via_chrome9_drv.h"
#include "via_chrome9_display_common.h"
#include "via_chrome9_object.h"
#include "cbios_uma.h"

extern void via_chrome9_load_fixed_crtc_regs(struct drm_device *dev);
extern int via_chrome9_init_cbios(struct drm_device *dev);
extern void via_chrome9_cbios_init_device_info(
		struct drm_via_chrome9_private *p_priv);
extern void via_chrome9_bios_query_vbe_info(struct drm_device *dev);
extern void* via_chrome9_create_thread(thread_func_t func, void *data);

extern PVOID pcbe;

bool have_device_connected = false; 

static const struct drm_mode_config_funcs via_chrome9_mode_funcs = {
	.fb_create = via_chrome9_user_framebuffer_create,
	.output_poll_changed = via_chrome9_fb_output_poll_changed
};

struct drm_prop_enum_list via_tv_scan_type_enum_list[] =
{
	{TV_SCAN_NORMAL, "Normal"},
	{TV_SCAN_FIT, "Fit"},
	{TV_SCAN_OVER, "Over"}
};

static struct drm_prop_enum_list via_tv_signal_ntsc_pal_enum_list[] =
{
	{TV_SIGNAL_COMPOSITE, "Composite"},
	{TV_SIGNAL_SVIDEO, "Svideo"},
	{TV_SIGNAL_RGB, "RGB"},
	{TV_SIGNAL_YCBCR, "YCbCr"}
};

struct drm_prop_enum_list via_tv_signal_480p_720p_576p_1080i_enum_list[] =
{
	{TV_SIGNAL_RGB, "RGB"},
	{TV_SIGNAL_YCBCR, "YCbCr"}
};

struct via_prop_enum_combine_list via_tv_signal_combine_list[] =
{
	{TV_SIGNAL_ALL, 4, via_tv_signal_ntsc_pal_enum_list},
	{TV_SIGNAL_RGB | TV_SIGNAL_YCBCR, 2, 
		via_tv_signal_480p_720p_576p_1080i_enum_list},
	{-1, -1, NULL}
};
static struct drm_prop_enum_list via_tv_type_6x4_8x5_10x7[] = {
	{TV_STANDARD_NTSC, "NTSC"}, {TV_STANDARD_PAL, "PAL"},
	{TV_STANDARD_480P, "480P"}, {TV_STANDARD_576P, "576P"},
	{TV_STANDARD_720P, "720P"}, {TV_STANDARD_1080I, "1080I"},
	{-1, ""}
};

static struct drm_prop_enum_list via_tv_type_720x480[] = {
	{TV_STANDARD_NTSC, "NTSC"},	{TV_STANDARD_480P, "480P"},
	{TV_STANDARD_720P, "720P"}, {TV_STANDARD_1080I, "1080I"},
	{-1, ""}
};

static struct drm_prop_enum_list via_tv_type_720x576[] = {
	{TV_STANDARD_PAL, "PAL"},	{TV_STANDARD_576P, "576P"},
	{TV_STANDARD_720P, "720P"}, {TV_STANDARD_1080I, "1080I"},
	{-1, ""}
};

static struct drm_prop_enum_list via_tv_type_1280x720[] = {
	{TV_STANDARD_720P, "720P"},
	{-1, ""}
};

static struct drm_prop_enum_list via_tv_type_1920x1080[] = {
	{TV_STANDARD_1080I, "1080I"},
	{-1, ""}
};

struct via_prop_enum_combine_list via_tv_type_combine_list[] =
{
	{TV_STANDARD_ALL, 6, via_tv_type_6x4_8x5_10x7},
	{(TV_STANDARD_NTSC | TV_STANDARD_480P | TV_STANDARD_720P |
		TV_STANDARD_1080I), 4, via_tv_type_720x480},
	{(TV_STANDARD_PAL | TV_STANDARD_576P | TV_STANDARD_720P |
		TV_STANDARD_1080I), 4, via_tv_type_720x576},
	{TV_STANDARD_720P, 1, via_tv_type_1280x720},
	{TV_STANDARD_1080I, 1, via_tv_type_1920x1080},
	{-1, -1, NULL}
};
struct drm_prop_enum_list via_tv_dotcrawl_enum_list[] =
{
	{TV_DOTCRAWL_OFF, "off"},
	{TV_DOTCRAWL_ON, "on"}
};
static struct drm_prop_enum_list via_tv_deflicker_filter_name_enum_list[] =
{
	{TV_DEFLICKER_FILTER_ON, "ffon"},
	{TV_ADAPTIVE_DEFLICKER_ON, "affon"},
	{TV_FLICKER_OFF, "alloff"}
};

struct drm_prop_enum_list via_signal_format_enum_list[] =
{
	{SIGNAL_FORMAT_UNKNOWN, "unknown"},
	{SIGNAL_FORMAT_VGA, "VGA"},
	{SIGNAL_FORMAT_TMDS, "TMDS"},
	{SIGNAL_FORMAT_LVDS, "LVDS"},
	{SIGNAL_FORMAT_DISPLAYPORT, "DisplayPort"},
	{SIGNAL_FORMAT_COMPOSITE, "Composite"},
	{SIGNAL_FORMAT_COMPOSITE_PAL, "Composite-PAL"},
	{SIGNAL_FORMAT_COMPOSITE_NTSC, "Composite-NTSC"},
	{SIGNAL_FORMAT_COMPOSITE_SECAM, "Composite-SECAM"},
	{SIGNAL_FORMAT_SVIDEO, "SVideo"},
	{SIGNAL_FORMAT_COMPONENT, "Component"}
};

struct drm_prop_enum_list via_connector_type_enum_list[] =
{
	{CONNECTOR_TYPE_UNKNOWN, "unknown"},
	{CONNECTOR_TYPE_VGA, "VGA"},
	{CONNECTOR_TYPE_DVI_I, "DVI-I"},
	{CONNECTOR_TYPE_DVI_D, "DVI-D"},
	{CONNECTOR_TYPE_DISPLAYPORT, "DisplayPort"},
	{CONNECTOR_TYPE_HDMI, "HDMI"},
	{CONNECTOR_TYPE_PANEL, "Panel"},
	{CONNECTOR_TYPE_DVI, "DVI"},
	{CONNECTOR_TYPE_DVI_A, "DVI-A"},
	{CONNECTOR_TYPE_TV, "TV"},
	{CONNECTOR_TYPE_TV_COMPOSITE, "TV-Composite"},
	{CONNECTOR_TYPE_TV_SVIDEO, "TV-SVideo"},
	{CONNECTOR_TYPE_TV_COMPONENT, "TV-Component"},
	{CONNECTOR_TYPE_TV_SCART, "TV-SCART"},
	{CONNECTOR_TYPE_TV_C4, "TV-C4"}	
	
};



static int via_chrome9_mode_set_create_properties(struct drm_device *dev)
{
	int i = 0;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	/* left border */
	p_priv->mode_info.left_border_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_RANGE,
		HDMI_LEFT_BORDER_NAME, 2);
	if (!p_priv->mode_info.left_border_property) {
		KMS_DEBUG("create border property failed !\n");
		return -ENOMEM;
	}
	p_priv->mode_info.left_border_property->values[0] = 0;
	p_priv->mode_info.left_border_property->values[1] =
		MAX_SUPPORTED_HOR_BORDER;


	/* right border */
	p_priv->mode_info.right_border_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_RANGE,
		HDMI_RIGHT_BORDER_NAME, 2);
	if (!p_priv->mode_info.right_border_property) {
		KMS_DEBUG("create border property failed !\n");
		return -ENOMEM;
	}
	p_priv->mode_info.right_border_property->values[0] = 0;
	p_priv->mode_info.right_border_property->values[1] =
		MAX_SUPPORTED_HOR_BORDER;


	/* top border */
	p_priv->mode_info.top_border_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_RANGE,
		HDMI_TOP_BORDER_NAME, 2);
	if (!p_priv->mode_info.top_border_property) {
		KMS_DEBUG("create border property failed !\n");
		return -ENOMEM;
	}
	p_priv->mode_info.top_border_property->values[0] = 0;
	p_priv->mode_info.top_border_property->values[1] =
		MAX_SUPPORTED_VER_BORDER;


	/* bottom border */
	p_priv->mode_info.bottom_border_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_RANGE,
		HDMI_BOTTOM_BORDER_NAME, 2);
	if (!p_priv->mode_info.bottom_border_property) {
		KMS_DEBUG("create border property failed !\n");
		return -ENOMEM;
	}
	p_priv->mode_info.bottom_border_property->values[0] = 0;
	p_priv->mode_info.bottom_border_property->values[1] =
		MAX_SUPPORTED_VER_BORDER;


	/* Create connectorType Properties */
	p_priv->mode_info.connector_type= drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_PENDING | DRM_MODE_PROP_ENUM,
		CONNECTOR_TYPE_NAME, CONNECTOR_TYPE_NUM);
	if (!p_priv->mode_info.connector_type) {
		KMS_DEBUG("create connector type failed !\n");
		return -ENOMEM;
	} else {
		for (i = 0; i < CONNECTOR_TYPE_NUM; i++) {
			drm_property_add_enum(p_priv->mode_info.connector_type,
				i, via_connector_type_enum_list[i].type,
				via_connector_type_enum_list[i].name);
		}
	}	

	/* Create signalformat Properties */
	p_priv->mode_info.signal_format = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_PENDING | DRM_MODE_PROP_ENUM,
		SIGNAL_FORMAT_NAME, SIGNAL_FORMAT_NUM);
	if (!p_priv->mode_info.signal_format) {
		KMS_DEBUG("create signal format failed !\n");
		return -ENOMEM;
	} else {
		for (i = 0; i < SIGNAL_FORMAT_NUM; i++) {
			drm_property_add_enum(p_priv->mode_info.signal_format,
				i, via_signal_format_enum_list[i].type,
				via_signal_format_enum_list[i].name);
		}
	}	

	/* Create TV Scan Properties */
	p_priv->mode_info.tv_scan_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_PENDING | DRM_MODE_PROP_ENUM,
		TV_SCAN_TYPE_NAME, TV_SCAN_TYPE_NUM);
	if (!p_priv->mode_info.tv_scan_property) {
		KMS_DEBUG("create tv scan property failed !\n");
		return -ENOMEM;
	} else {
		for (i = 0; i < TV_SCAN_TYPE_NUM; i++) {
			drm_property_add_enum(p_priv->mode_info.tv_scan_property,
				i, via_tv_scan_type_enum_list[i].type,
				via_tv_scan_type_enum_list[i].name);
		}
	}
	/* Create TV DotClaw Properties */
	p_priv->mode_info.tv_dotcrawl_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_PENDING | DRM_MODE_PROP_ENUM,
		TV_DOTCRAWL_NAME, TV_DOTCRAWL_NUM);
	if (!p_priv->mode_info.tv_dotcrawl_property) {
		KMS_DEBUG("create tv dotcrawl property failed !\n");
		return -ENOMEM;
	} else {
		for (i = 0; i < TV_DOTCRAWL_NUM; i++) {
			drm_property_add_enum(p_priv->mode_info.tv_dotcrawl_property,
				i, via_tv_dotcrawl_enum_list[i].type,
				via_tv_dotcrawl_enum_list[i].name);
		}
	}
	/* Create TV brightness Properties */
	p_priv->mode_info.tv_brightness_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_RANGE,
		TV_BRIGHTNESS_NAME, 2);
	if (!p_priv->mode_info.tv_brightness_property) {
		KMS_DEBUG("create tv brightness property failed !\n");
		return -ENOMEM;
	} else {
		p_priv->mode_info.tv_brightness_property->values[0] = 0;
		p_priv->mode_info.tv_brightness_property->values[1] = 100;
	}
	/* Create TV Contrast Properties */
	p_priv->mode_info.tv_contrast_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_RANGE,
		TV_CONTRAST_NAME, 2);
	if (!p_priv->mode_info.tv_contrast_property) {
		KMS_DEBUG("create tv contrast property failed !\n");
		return -ENOMEM;
	} else {
		p_priv->mode_info.tv_contrast_property->values[0] = 0;
		p_priv->mode_info.tv_contrast_property->values[1] = 100;
	}	
	/* Create TV saturation Properties */
	p_priv->mode_info.tv_saturation_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_RANGE,
		TV_SATURATION_NAME, 2);
	if (!p_priv->mode_info.tv_saturation_property) {
		KMS_DEBUG("create tv saturation property failed !\n");
		return -ENOMEM;
	} else {
		p_priv->mode_info.tv_saturation_property->values[0] = 0;
		p_priv->mode_info.tv_saturation_property->values[1] = 100;
	}
	/* Create TV Hue Properties */
	p_priv->mode_info.tv_hue_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_RANGE,
		TV_HUE_NAME, 2);
	if (!p_priv->mode_info.tv_hue_property) {
		KMS_DEBUG("create tv hue property failed !\n");
		return -ENOMEM;
	} else {
		p_priv->mode_info.tv_hue_property->values[0] = 0;
		p_priv->mode_info.tv_hue_property->values[1] = 100;
	}	
	/* Create TV AFFliterValue Properties */
	p_priv->mode_info.tv_adaptive_deflicker_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_RANGE,
		TV_AFFLITER_VALUE, 2);
	if (!p_priv->mode_info.tv_adaptive_deflicker_property) {
		KMS_DEBUG("create tv adaptive deflicker property failed !\n");
		return -ENOMEM;
	} else {
		p_priv->mode_info.tv_adaptive_deflicker_property->values[0] = 0;
		p_priv->mode_info.tv_adaptive_deflicker_property->values[1] = 100;
	}
	/* Create TV FFliterName Properties */
	p_priv->mode_info.tv_deflicker_filter_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_PENDING | DRM_MODE_PROP_ENUM,
		TV_FFLITER_NAME, TV_FFLITER_NAME_NUM);
	if (!p_priv->mode_info.tv_deflicker_filter_property) {
		KMS_DEBUG("create tv FFliterName property failed !\n");
		return -ENOMEM;
	} else {
		for (i = 0; i < TV_FFLITER_NAME_NUM; i++) {
			drm_property_add_enum(
				p_priv->mode_info.tv_deflicker_filter_property,
				i, via_tv_deflicker_filter_name_enum_list[i].type,
				via_tv_deflicker_filter_name_enum_list[i].name);
		}
	}
	/* Create TV FFliterValue Properties */
	p_priv->mode_info.tv_deflicker_filter_val_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_RANGE,
		TV_FFLITER_VALUE, 2);
	if (!p_priv->mode_info.tv_deflicker_filter_val_property) {
		KMS_DEBUG("create tv FFliterValue property failed !\n");
		return -ENOMEM;
	} else {
		p_priv->mode_info.tv_deflicker_filter_val_property->values[0] = 0;
		p_priv->mode_info.tv_deflicker_filter_val_property->values[1] = 100;
	}
	/* Create TV PosH Properties */
	p_priv->mode_info.tv_pos_h_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_RANGE,
		TV_POSH_NAME, 2);
	if (!p_priv->mode_info.tv_pos_h_property) {
		KMS_DEBUG("create tv PosH property failed !\n");
		return -ENOMEM;
	} else {
		p_priv->mode_info.tv_pos_h_property->values[0] = 0;
		p_priv->mode_info.tv_pos_h_property->values[1] = 100;
	}	
	/* Create TV PosV Properties */
	p_priv->mode_info.tv_pos_v_property = drm_property_create(
		p_priv->ddev, DRM_MODE_PROP_RANGE,
		TV_POSV_NAME, 2);
	if (!p_priv->mode_info.tv_pos_v_property) {
		KMS_DEBUG("create tv PosV property failed !\n");
		return -ENOMEM;
	} else {
		p_priv->mode_info.tv_pos_v_property->values[0] = 0;
		p_priv->mode_info.tv_pos_v_property->values[1] = 100;
	}
	return 0;
}

static void  via_chrome9_get_chipset_revision(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	u32 chipset = 0;
	u32 chipset_revision = 0;

	switch (dev->pdev->device) {
	case VX800_DEVICE:
		chipset = 0x000353;
		p_priv->mode_info.chip_index = VX800_INDEX;
		break;

	case VX855_DEVICE:
		chipset = 0x000409;
		p_priv->mode_info.chip_index = VX855_INDEX;
		break;

	case VX900_DEVICE:
		chipset = 0x000410;
		p_priv->mode_info.chip_index = VX900_INDEX;
		break;

	default:
		KMS_DEBUG("An invalid chipset!!!\n");
		break;
	}

	chipset_revision = via_chrome9_read_vga_io(REG_SR3B);
	p_priv->pseudo_chip_revision = (chipset << 8) | chipset_revision;
	KMS_DEBUG("The chipset revision is %x", p_priv->pseudo_chip_revision);
}

/* Function Name: SetChipCaps.
* Purpose: Set chip capabilities according to chip's device ID.
* Parameters: Global variable pBIOSInfo.
* Return value: None.
*/
static void via_chrome9_set_chip_caps(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	switch (dev->pdev->device) {
	case VX800_DEVICE:
		p_priv->via_chrome9_pll_type = VIA_PLL_TYPE_PLL_3_NEW;
		break;
	case VX855_DEVICE:
		p_priv->via_chrome9_pll_type = VIA_PLL_TYPE_PLL_3_ADV;
		break;
	case VX900_DEVICE:
		p_priv->chip_caps = CAPS_IGA1_DOWNSCALING |
			CAPS_IGA1_EXPAND | CAPS_IGA2_DOWNSCALING;
		p_priv->via_chrome9_pll_type = VIA_PLL_TYPE_PLL_3_ADV;
		break;
	default:
		KMS_DEBUG("An invalid chipset!!!\n");
		break;
	}
}

#if CRT_POLL_HOT_PLUG
static int via_chrome9_CrtHpd(void *data)
{
	bool is_connected = FALSE;
	bool is_connected_bak = FALSE;
	/* follow cbios variable type. */
	BOOL is_attached = FALSE;
	CBIOS_STATUS status     = CBIOS_OK;
	struct drm_device *dev = data;

	do {
		status = 
			CBiosNonDestructiveDeviceDetect(pcbe, ACTIVE_TYPE_CRT, &is_attached);
		if(status == CBIOS_OK)
			is_connected = is_attached ? TRUE:FALSE;
		else
			is_connected = FALSE;

		if (is_connected != is_connected_bak) {
			/* drm_helper_hpd_irq_event(dev); */
			drm_sysfs_hotplug_event(dev);
			is_connected_bak = is_connected;
		} 
		msleep(1000);
	}while(1);

	return 0;
}
#endif

int via_chrome9_mode_set_init(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
			(struct drm_via_chrome9_private *)dev->dev_private;
	int i, ret;
	bool connector_status = false;  
	unsigned int cur_dev = 0;
	drm_mode_config_init(dev);

	dev->mode_config.funcs = (void *)&via_chrome9_mode_funcs;
	dev->mode_config.max_width = 4096;
	dev->mode_config.max_height = 4096;
	dev->mode_config.fb_base = p_priv->vram_start;
	p_priv->num_crtc = 2;

	via_chrome9_cbios_init_device_info(p_priv);
	ret = via_chrome9_mode_set_create_properties(dev);
	if (ret) {
		KMS_DEBUG("create properties failed!!\n");
		return ret;
	}

	via_chrome9_set_chip_caps(dev);
	via_chrome9_get_chipset_revision(dev);
	via_chrome9_hw_cursor_init(dev);
	for (i = 0; i < p_priv->num_crtc; i++)
		via_chrome9_crtc_init(dev, i);

	if (ENABLE_CBIOS_CODE) {
		if(0 == via_chrome9_init_cbios(dev)) {
			KMS_DEBUG("CBIOS supported\n");
			via_chrome9_bios_query_vbe_info(dev);

			//after init cbios, power off all device, to avoid garbage.
			for(cur_dev = 1; cur_dev < ACTIVE_TYPE_DP2; cur_dev *=2) {
				if(cur_dev & p_priv->supported_devices) {
					via_chrome9_set_disp_dev_power_state(cur_dev, false);
					KMS_DEBUG("CBIOS init, device 0x%x init as power off.\n", 
						cur_dev);
				}
			}
		} else {
			KMS_DEBUG("CBIOS unsupported\n");
		}
	}

	/* For no device connect case */
	for (i = 0; i < 13; i++)
	{
		connector_status = via_chrome9_cbios_help_device_detect(dev, ACTIVE_TYPE_CRT<< i);
		if (true == connector_status) {
			have_device_connected = true;
			break;
		}
	}
	if(have_device_connected == false)
		KMS_DEBUG("There is no device connected.\n");
	
	ret = via_chrome9_detect_enc_conn(dev);
	if (ret) {
		KMS_DEBUG("detect the encoder and connector error\n");
		return ret;
	}

	/* initialize hpd */
	via_chrome9_hpd_init(dev);

	via_chrome9_fbdev_init(dev);

	drm_kms_helper_poll_init(dev);

#if CRT_POLL_HOT_PLUG
	struct task_struct* ts;
	ts = via_chrome9_create_thread(via_chrome9_CrtHpd, dev);
	if (!IS_ERR(ts)) {   
		KMS_DEBUG("create kthread s3g_kthread ok!\n");   
	} else  {   
		KMS_DEBUG("create ktrhead s3g_kthread failed!\n");   
	}
#endif

	return 0;
}

int via_chrome9_resume_mode_set(struct drm_device *dev)
{
	struct drm_connector *connector;
	struct drm_crtc *crtc;
	struct drm_framebuffer *fb;
	struct via_chrome9_framebuffer *via_fb;
	struct drm_gem_object *obj;
	struct via_chrome9_object *vobj;
	int i, ret;

	via_chrome9_hw_cursor_init(dev);
	via_chrome9_hpd_init(dev);

	/* enable vsync interrupt for vblank count */
	for (i = 0; i < dev->num_crtcs; i++) {
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,13,0))
		if (dev->vblank_enabled[i])
#else
		if (dev->vblank[i].enabled)
#endif
			ret = dev->driver->enable_vblank(dev, i);
	}

	list_for_each_entry(crtc, &dev->mode_config.crtc_list, head) {
		if (!crtc->enabled)
			continue;
		fb = crtc->fb;
		via_fb = to_via_chrome9_framebuffer(fb);
		obj = via_fb->obj;
		vobj = gobj_to_vobj(obj);
		/* if this bo is allocated by fb. the ptr is valid */
		if (vobj->ptr != NULL)
			memset(vobj->ptr, '\0', vobj->bo.num_pages * PAGE_SIZE);
	}

	list_for_each_entry(connector, &dev->mode_config.connector_list, head) {
		drm_helper_connector_dpms(connector, DRM_MODE_DPMS_ON);
	}

	drm_helper_resume_force_mode(dev);

	return 0;
}

void via_chrome9_mode_set_fini(struct drm_device *dev)
{
	drm_kms_helper_poll_fini(dev);
	via_chrome9_hpd_fini(dev);
	via_chrome9_fbdev_fini(dev);
	drm_mode_config_cleanup(dev);
}

void via_chrome9_suspend_mode_set(struct drm_device *dev)
{
	struct drm_connector *connector;

	list_for_each_entry(connector, &dev->mode_config.connector_list, head) {
		drm_helper_connector_dpms(connector, DRM_MODE_DPMS_OFF);
	}
	via_chrome9_hpd_fini(dev);
}
