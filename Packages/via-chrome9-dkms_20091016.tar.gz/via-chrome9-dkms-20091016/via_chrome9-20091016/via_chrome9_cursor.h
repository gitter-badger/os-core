/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef __VIA_CHROME9_CURSOR_H_
#define __VIA_CHROME9_CURSOR_H_

#include "via_chrome9_drv.h"

#define HI_POSSTART             0x208
#define HI_CENTEROFFSET         0x20C
#define HI_FBOFFSET             0x224
#define HI_CONTROL              0x260
#define HI_TRANSPARENT_COLOR    0x270
#define HI_INVTCOLOR            0x274
#define PRIM_HI_POSEND          0x290
#define V327_HI_INVTCOLOR       0x2E4
#define PRIM_HI_FIFO            0x2E8
#define PRIM_HI_TRANSCOLOR      0x2EC
#define PRIM_HI_CTRL            0x2F0
#define PRIM_HI_FBOFFSET        0x2F4
#define PRIM_HI_POSSTART        0x2F8
#define PRIM_HI_CENTEROFFSET    0x2FC
#define PRIM_HI_INVTCOLOR       0x120C
#define ALPHA_V3_PREFIFO_CONTROL   0x268
#define ALPHA_V3_FIFO_CONTROL   0x278

#define CURSOR_WIDTH 64
#define CURSOR_HEIGHT 64

struct via_chrome9_cursor;
extern int via_chrome9_crtc_cursor_set(struct drm_crtc *crtc,
		struct drm_file *file_priv, uint32_t handle,
		uint32_t width, uint32_t height);
extern int via_chrome9_crtc_cursor_move(struct drm_crtc *crtc, int x, int y);
extern void via_chrome9_hw_cursor_init(struct drm_device *dev);
#endif
