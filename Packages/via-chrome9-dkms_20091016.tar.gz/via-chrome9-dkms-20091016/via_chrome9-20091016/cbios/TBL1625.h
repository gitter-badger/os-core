/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "cbios_sub_func.h"

//-----------------------------------------------------------------------------
//                              Normal scan level 
//-----------------------------------------------------------------------------
extern TVTBLDATA_UMA csTVModeTbl_1625[];


//-----------------------Normal scan TV output type Table----------------------------
extern TV_FUNCTION_UMA NTSC_640 [];
extern TV_FUNCTION_UMA NTSC_800 [];
extern TV_FUNCTION_UMA NTSC_1024 [];
extern TV_FUNCTION_UMA NTSC_848 [];
extern TV_FUNCTION_UMA NTSC_720X480 [];
extern TV_FUNCTION_UMA NTSC_720 [];
extern TV_FUNCTION_UMA PAL_640 [];
extern TV_FUNCTION_UMA PAL_800 [];
extern TV_FUNCTION_UMA PAL_1024 [];
extern TV_FUNCTION_UMA PAL_848 [];
extern TV_FUNCTION_UMA PAL_720X576 [];
extern TV_FUNCTION_UMA PAL_720 [];


//-------------------------Normal scan level-------------------------------
extern BYTE N640_TV_VN  [];
extern WORD NTSC_CRTC_640 [];
extern BYTE  N800_TV_VN [];
extern WORD NTSC_CRTC_800 [];
extern BYTE N1024_TV_VN [];
extern WORD NTSC_CRTC_1024 [];
extern BYTE N848_TV_VN [];
extern BYTE NTSC_CRTC_848 [];
extern BYTE N720X480_TV_VN [];
extern WORD NTSC_CRTC_720X480 [];
extern BYTE N720_TV_VN [];
extern WORD NTSC_CRTC_720 [];
extern BYTE P640_TV_VN [];
extern WORD PAL_CRTC_640 [];
extern BYTE P800_TV_VN [];
extern WORD PAL_CRTC_800 [];
extern BYTE P1024_TV_VN [];
extern WORD PAL_CRTC_1024 [];
extern BYTE P848_TV_VN [];
extern BYTE PAL_CRTC_848  [];
extern BYTE P720X576_TV_VN [];
extern WORD PAL_CRTC_720X576 [];
extern BYTE P720_TV_VN [];
extern WORD PAL_CRTC_720 [];
extern BYTE N640_SDTV_VN [];
extern BYTE N800_SDTV_VN [];
extern BYTE N1024_SDTV_VN [];
extern BYTE N848_SDTV_VN [];
extern BYTE N720X480_SDTV_VN [];
extern BYTE N720_SDTV_VN [];
extern BYTE P640_SDTV_VN [];
extern BYTE P800_SDTV_VN [];
extern BYTE P1024_SDTV_VN [];
extern BYTE P848_SDTV_VN [];
extern BYTE P720X576_SDTV_VN [];
extern BYTE P720_SDTV_VN [];
extern BYTE N640_DotCrawl_VN [];
extern BYTE N800_DotCrawl_VN [];
extern BYTE N1024_DotCrawl_VN [];
extern BYTE N848_DotCrawl_VN [];
extern BYTE N720x480_DotCrawl_VN [];
extern BYTE N720_DotCrawl_VN [];
extern BYTE N720x480_DotCrawl_VN [];
extern BYTE N720X480_YCbCr_IN_VN [];



//--------------------------------------------------------------------------
//                           Fit scan level  
//--------------------------------------------------------------------------
extern TVTBLDATA_UMA   csTVModeFitTbl_1625[];
extern TV_FUNCTION_UMA Fit_NTSC_640[];
extern TV_FUNCTION_UMA Fit_NTSC_800 [];
extern TV_FUNCTION_UMA Fit_NTSC_1024 [];
extern TV_FUNCTION_UMA Fit_NTSC_848  [];
extern TV_FUNCTION_UMA Fit_NTSC_720X480 [];
extern TV_FUNCTION_UMA Fit_PAL_640 [];
extern TV_FUNCTION_UMA Fit_PAL_800  [];
extern TV_FUNCTION_UMA Fit_PAL_1024 [];
extern TV_FUNCTION_UMA Fit_PAL_1024 [];
extern TV_FUNCTION_UMA Fit_PAL_720X576 [];


//---------------------------Fit scan TV output type table----------------------
extern BYTE N640_TV_VF [];
extern WORD Fit_NTSC_CRTC_640   [];
extern BYTE N800_TV_VF [] ;
extern WORD Fit_NTSC_CRTC_800 [];
extern BYTE N1024_TV_VF [];
extern WORD Fit_NTSC_CRTC_1024 [];
extern BYTE N848_TV_VF [];
extern BYTE Fit_NTSC_CRTC_848 [];
extern BYTE N720X480_TV_VF [];
extern WORD Fit_NTSC_CRTC_720X480 [];
extern BYTE P640_TV_VF [];
extern WORD  Fit_PAL_CRTC_640 [];
extern BYTE P800_TV_VF [];
extern WORD Fit_PAL_CRTC_800 [];
extern BYTE P1024_TV_VF [];
extern WORD Fit_PAL_CRTC_1024 [];
extern BYTE P848_TV_VF [];
extern BYTE Fit_PAL_CRTC_848 [];
extern BYTE P720X576_TV_VF [];
extern WORD Fit_PAL_CRTC_720X576 [];

//-------------------------Fit scan level-------------------------------------
extern BYTE N640_SDTV_VF [];
extern BYTE N800_SDTV_VF [];
extern BYTE N1024_SDTV_VF [];
extern BYTE N848_SDTV_VF [];
extern BYTE N720X480_SDTV_VF [];
extern BYTE N640_DotCrawl_VF [];
extern BYTE N800_Dotcrawl_VF  [];
extern BYTE N1024_DotCrawl_VF  [];
extern BYTE N1024_DotCrawl_VF  [];
extern BYTE N848_DotCrawl_VF [];
extern BYTE N720x480_DotCrawl_VF [];
extern BYTE P640_SDTV_VF  [];
extern BYTE P800_SDTV_VF [];
extern BYTE P1024_SDTV_VF  [];
extern BYTE P848_SDTV_VF  [];
extern BYTE P720X576_SDTV_VF [];


//---------------------------------------------------------------------------
//                              Over Scanning
//---------------------------------------------------------------------------
extern TVTBLDATA_UMA csTVModeOverTbl_1625 [];

//-----------------------Normal scan TV output type Table----------------------
extern TV_FUNCTION_UMA Over_NTSC_640 [];
extern TV_FUNCTION_UMA Over_NTSC_800 [];
extern TV_FUNCTION_UMA Over_NTSC_1024 [];
extern TV_FUNCTION_UMA Over_NTSC_848 [];
extern TV_FUNCTION_UMA Over_NTSC_720X480 [];
extern TV_FUNCTION_UMA Over_PAL_640 [];
extern TV_FUNCTION_UMA Over_PAL_800 [];
extern TV_FUNCTION_UMA Over_PAL_1024 [];
extern TV_FUNCTION_UMA Over_PAL_848 [];
extern TV_FUNCTION_UMA Over_PAL_720X576 [];

//-------------------------Over scan level-------------------------------------
extern BYTE N640_TV_VO [];
extern WORD Over_NTSC_CRTC_640  [];
extern BYTE N640_TV_VO [];
extern WORD Over_NTSC_CRTC_640 [];
extern BYTE N800_TV_VO  [];
extern WORD Over_NTSC_CRTC_800 [];
extern BYTE N1024_TV_VO [];
extern WORD Over_NTSC_CRTC_1024  [];
extern BYTE N848_TV_VO [];
extern BYTE N720X480_TV_VO [];
extern WORD Over_NTSC_CRTC_720X480 [];
extern BYTE N720X480_TV_VO [];
extern BYTE P640_TV_VO  [];
extern WORD Over_PAL_CRTC_640 [];
extern BYTE P800_TV_VO [];
extern WORD Over_PAL_CRTC_800 [];
extern BYTE P1024_TV_VO [];
extern WORD Over_PAL_CRTC_1024 [];
extern BYTE P848_TV_VO [];
extern BYTE P720X576_TV_VO  [];
extern WORD Over_PAL_CRTC_720X576 [];
extern BYTE N640_SDTV_VO [];
extern BYTE N800_SDTV_VO [];
extern BYTE N1024_SDTV_VO [];
extern BYTE N848_SDTV_VO [];
extern BYTE N720X480_SDTV_VO [];
extern BYTE P640_SDTV_VO [];
extern BYTE P800_SDTV_VO [];
extern BYTE P1024_SDTV_VO [];
extern BYTE P848_SDTV_VO [];
extern BYTE P720X576_SDTV_VO [];
extern BYTE N640_DotCrawl_VO [];
extern BYTE N800_DotCrawl_VO [];
extern BYTE N1024_DotCrawl_VO [];
extern BYTE N848_DotCrawl_VO [];
extern BYTE N720x480_DotCrawl_VO [];
extern BYTE P720X576_YCbCr_IN_VN [];


//-------------------------shared TV table-------------------------
extern BYTE TV_OUT_RGB  [];
extern BYTE TV_OUT_YCbCr [];

#define  TV_Clock_D 0x87
#define  TV_Clock_N 0x1C
















































































































































