/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "cbios_uma.h"
#include "cbios_sub_func.h"

// Color Depth type
#define _8BPP        8
#define _16BPP       16
#define _32BPP       32

// IGA1 pixel timing Registers
#define     IGA1_PXL_H_TOTAL_REG       0x8400  //[15:0]
#define     IGA1_PXL_H_DIS_END_REG     0x8400  //[31:16]
#define     IGA1_PXL_H_BNK_ST_REG      0x8404  //[15:0]
#define     IGA1_PXL_H_BNK_END_REG     0x8404  //[31:16]
#define     IGA1_PXL_H_SYNC_ST_REG     0x8408  //[15:0]
#define     IGA1_PXL_H_SYNC_END_REG    0x8408  //[31:16]
#define     IGA1_PXL_V_TOTAL_REG       0x8424  //[10:0]
#define     IGA1_PXL_V_DIS_END_REG     0x8424  //[26:16]
#define     IGA1_PXL_V_BNK_ST_REG      0x8428  //[10:0]
#define     IGA1_PXL_V_BNK_END_REG     0x8428  //[26:16]
#define     IGA1_PXL_V_SYNC_ST_REG     0x842C  //[10:0]
#define     IGA1_PXL_V_SYNC_END_REG    0x842C  //[15:12]
#define     IGA1_PXL_HALF_LINE_REG     0x8434  //[15:0]

#define     IGA1_PXL_H_TOTAL_MASK      0x0000FFFF  //[15:0]
#define     IGA1_PXL_H_DIS_END_MASK    0xFFFF0000  //[31:16]
#define     IGA1_PXL_H_BNK_ST_MASK     0x0000FFFF  //[15:0]
#define     IGA1_PXL_H_BNK_END_MASK    0xFFFF0000  //[31:16]
#define     IGA1_PXL_H_SYNC_ST_MASK    0x0000FFFF  //[15:0]
#define     IGA1_PXL_H_SYNC_END_MASK   0xFFFF0000  //[31:16]
#define     IGA1_PXL_V_TOTAL_MASK      0x000007FF  //[10:0]
#define     IGA1_PXL_V_DIS_END_MASK    0x07FF0000  //[26:16]
#define     IGA1_PXL_V_BNK_ST_MASK     0x000007FF  //[10:0]
#define     IGA1_PXL_V_BNK_END_MASK    0x07FF0000  //[26:16]
#define     IGA1_PXL_V_SYNC_ST_MASK    0x000007FF  //[10:0]
#define     IGA1_PXL_V_SYNC_END_MASK   0x0000F000  //[15:12]
#define     IGA1_PXL_HALF_LINE_MASK    0x0000FFFF  //[15:0]

void cbLoadTimingOnIGA1_UMA(PCBIOS_EXTENSION pcbe, TIMING_REG_TYPE RegType, WORD Data)
{
    WORD    buf;

    // UnLock STD CRTC write protect    // CR11[7]=0
    cbWriteRegBits(pcbe, CR_11, BIT7, 0x00);

    if(pcbe->ChipCaps.NEW_EXTERN_TIMING_LOCK)
    {
    // UnLock STD CRTC write protect    // CR47[4]=0 and CR47[0]=0
        cbWriteRegBits(pcbe, CR_47, BIT4+BIT0, 0);
    }
    else
    {
    // UnLock STD CRTC write protect    // CR47[0]=0
        cbWriteRegBits(pcbe, CR_47, BIT0, 0x00);
    }

    switch (RegType)
    {
    case H_TOTAL:
        buf = Data / 8;                                 // pixel to character
        buf = buf -5;                                   // fix for H_TOTAL(-5) on IGA1

        // CR00[7:0]
        cbWriteRegByte(pcbe, CR_00, (BYTE)(buf%0x100));

        // CR36[3]
        cbWriteRegBits(pcbe, CR_36, BIT3, (BYTE)((buf/0x100)<<3));

        switch (Data % 8)
        {
        case 0:
        case 1:
            buf = 0;
            break;

        case 2:
        case 3:
            buf = BIT7;         // +2
            break;

        case 4:
        case 5:
            buf = BIT6;         // +4
            break;

        case 6:
        case 7:
            buf = BIT3;         // +6
            break;
        }

        // CR47[7:6:3]
        cbWriteRegBits(pcbe, CR_47, BIT7+BIT6+BIT3, (BYTE)buf);
        break;

    case H_DIS_END:
        // pixel to character, 8 pixel align. fix for H_DIS_END(-1) on IGA1
        buf = (Data + 7) / 8 - 1;

        // CR01[7:0]
        cbWriteRegByte(pcbe, CR_01, (BYTE)(buf%0x100));
        // CR45[1]
        cbWriteRegBits(pcbe, CR_45, BIT1, (BYTE)(buf/0x100)<<1);
        break;

    case H_BNK_ST:
        // pixel to character, 8 pixel align. fix for H_BNK_ST(-1) on IGA1
        buf = (Data + 7) / 8 - 1;

        // CR02[7:0]
        cbWriteRegByte(pcbe, CR_02, (BYTE)(buf%0x100));
        // CR45[2]
        cbWriteRegBits(pcbe, CR_45, BIT2, (BYTE)(buf/0x100)<<2);
        break;

    case H_BNK_END:
        // pixel to character, 8 pixel align. fix for H_BNK_END(-1) on IGA1
        //originary compute method is: H_BNK_END = (Data + 7) / 8 - 1
        //but we use H_TOTAL= Data / 8 to compute H total
        //It will cause H_TOTAL + 1=H_BNK_END when data is not multiplity of 8
        buf = Data / 8 - 1;

        // CR03[4:0]
        cbWriteRegBits(pcbe, CR_03, BIT4+BIT3+BIT2+BIT1+BIT0, (BYTE)(buf%0x100));
        // CR05[7]
        cbWriteRegBits(pcbe, CR_05, BIT7, (BYTE)((buf%0x100)<<2));
        // CR33[5]
        cbWriteRegBits(pcbe, CR_33, BIT5, (BYTE)((buf%0x100)>>1));
        break;

    case H_SYNC_ST:
        // pixel to character, 8 pixel align
        buf = (Data + 7) / 8;

        // CR04[7:0]
        cbWriteRegByte(pcbe, CR_04, (BYTE)(buf%0x100));
        // CR33[4]
        cbWriteRegBits(pcbe, CR_33, BIT4, (buf / 0x100) << 4);
        break;

    case H_SYNC_END:
        // pixel to character, 8 pixel align
        buf = (Data + 7)  / 8;

        // CR05[4:0]
        cbWriteRegBits(pcbe, CR_05, BIT4+BIT3+BIT2+BIT1+BIT0, (BYTE)(buf%0x100));
        break;

    case V_TOTAL:
        buf = Data -2;                                  // fix for V_TOTAL(-2) on IGA1

        // CR06[7:0]
        cbWriteRegByte(pcbe, CR_06, (BYTE)(buf%0x100));
        // CR07[0]
        cbWriteRegBits(pcbe, CR_07, BIT0, (BYTE)(buf/0x100));
        // CR07[5]
        cbWriteRegBits(pcbe, CR_07, BIT5, (BYTE)((buf/0x100)<<4));
        // CR35[0]
        cbWriteRegBits(pcbe, CR_35, BIT0, (BYTE)((buf/0x100)>>2));
        break;

    case V_DIS_END:
        buf = Data - 1;                                  // fix for V_DIS_END(-1) on IGA1

        // CR12[7:0]
        cbWriteRegByte(pcbe, CR_12, (BYTE)(buf%0x100));
        // CR07[1]
        cbWriteRegBits(pcbe, CR_07, BIT1, (BYTE)((buf/0x100)<<1));
        // CR07[6]
        cbWriteRegBits(pcbe, CR_07, BIT6, (BYTE)((buf/0x100)<<5));
        // CR35[2]
        cbWriteRegBits(pcbe, CR_35, BIT2, (BYTE)(buf/0x100));
        break;

    case V_BNK_ST:
        buf = Data -1;                                  // fix for V_BNK_ST(-1) on IGA1

        // CR15[7:0]
        cbWriteRegByte(pcbe, CR_15, (BYTE)(buf%0x100));
        // CR07[3]
        cbWriteRegBits(pcbe, CR_07, BIT3, (BYTE)((buf/0x100)<<3));
        // CR09[5]
        cbWriteRegBits(pcbe, CR_09, BIT5, (BYTE)((buf/0x100)<<4));
        // CR35[3]
        cbWriteRegBits(pcbe, CR_35, BIT3, (BYTE)((buf/0x100)<<1));
        break;

    case V_BNK_END:
        buf = Data - 1;

        // CR16[7:0]
        cbWriteRegByte(pcbe, CR_16, (BYTE)(buf%0x100));
        break;

    case V_SYNC_ST:
        buf = Data - 1;

        // CR10[7:0]
        cbWriteRegByte(pcbe, CR_10, (BYTE)(buf%0x100));
        // CR07[2]
        cbWriteRegBits(pcbe, CR_07, BIT2, (BYTE)((buf/0x100)<<2));
        // CR07[7]
        cbWriteRegBits(pcbe, CR_07, BIT7, (BYTE)((buf/0x100)<<6));
        // CR35[1]
        cbWriteRegBits(pcbe, CR_35, BIT1,(BYTE)((buf/0x100)>>1));
        break;

    case V_SYNC_END:
        buf = Data - 1;

        // CR11[3:0]
        cbWriteRegBits(pcbe, CR_11, BIT3+BIT2+BIT1+BIT0, (BYTE)(buf%0x100));
        break;

    case FETCH_COUNT:
        buf = Data;

        // SR1C[7:0]
        cbWriteRegByte(pcbe, SR_1C,(BYTE)(buf%0x100));
        // SR1D[1:0]
        cbWriteRegBits(pcbe, SR_1D, BIT1+BIT0, (BYTE)(buf/0x100));
        break;

    case OFFSET:
        buf = Data;

        // CR13[7:0]
        cbWriteRegByte(pcbe, CR_13, (BYTE)(buf%0x100));
        // CR35[7:5]
        cbWriteRegBits(pcbe, CR_35, BIT7+BIT6+BIT5, (BYTE)((buf/0x100)<<5));
        break;

    case COLOR_DEPTH:
        switch (Data)
        {
        case _8BPP:
            // SR15[3:2]=00=8bpp
            // SR15[7]=0=6bit LUT
            cbWriteRegBits(pcbe, SR_15, BIT7+BIT3+BIT2, 0x00);
            break;

        case _16BPP:
            // SR15[3:2]=01=16bpp
            // SR15[7]=1=8bit LUT
            cbWriteRegBits(pcbe, SR_15, BIT7+BIT3+BIT2, BIT7+BIT2);
            break;

        case _32BPP:
        default:
            // SR15[3:2]=11=32bpp
            // SR15[7]=1=8bit LUT
            cbWriteRegBits(pcbe, SR_15, BIT7+BIT3+BIT2, BIT7+BIT3+BIT2);
            break;
        }
        break;

    case LINE_COMPARE:
        buf = Data -1;  // fix for LINE_COMPARE(-1)

        // CR18[7:0]
        cbWriteRegByte(pcbe, CR_18, (BYTE)(buf%0x100));
        // CR07[4]
        cbWriteRegBits(pcbe, CR_07, BIT4, (BYTE)((buf/0x100)<<4));
        // CR09[6]
        cbWriteRegBits(pcbe, CR_09, BIT6, (BYTE)((buf/0x100)<<5));
        // CR35[4]
        cbWriteRegBits(pcbe, CR_35, BIT4, (BYTE)((buf/0x100)<<2));
        break;

    case POWER_NOW_END_POS:
        buf = Data - 1;

        // CR41[7]
        cbWriteRegBits(pcbe, CR_41, BIT7, BIT7);
        // CR41[6:0]
        cbWriteRegBits(pcbe, CR_41, BIT6+BIT5+BIT4+BIT3+BIT2+BIT1+BIT0, (BYTE)(buf & 0x7F));
        break;

    default:
        break;

    }

    if(pcbe->ChipCaps.NEW_EXTERN_TIMING_LOCK)
    {
    // Lock STD CRTC write protect    // CR47[4]=1 and CR47[0]=1
        cbWriteRegBits(pcbe, CR_47, BIT4+BIT0, BIT4+BIT0);
    }
    else
    {
    // Lock STD CRTC write protect    // CR47[0]=1
        cbWriteRegBits(pcbe, CR_47, BIT0, BIT0);
    }
    // Lock STD CRTC write protect    // CR11[7]=1
    cbWriteRegBits(pcbe, CR_11, BIT7, BIT7);
}

void cbLoadPixelTimingOnIGA1_UMA(PCBIOS_EXTENSION pcbe, TIMING_REG_TYPE RegType, WORD Data)
{
    DWORD    buf;

    buf = Data;

    switch (RegType)
    {
    case H_TOTAL:
        buf = buf -1;                                   // for H_TOTAL(-1) on IGA1
        cbWriteMMIOUlongBits(pcbe, IGA1_PXL_H_TOTAL_REG, IGA1_PXL_H_TOTAL_MASK, buf);
        break;

    case H_DIS_END:
        buf = buf -1;                                   // for H_DIS_END(-1) on IGA1
        cbWriteMMIOUlongBits(pcbe, IGA1_PXL_H_DIS_END_REG, IGA1_PXL_H_DIS_END_MASK, buf<<16);
        break;

    case H_BNK_ST:
        buf = buf -1;                                   // for H_BNK_ST(-1) on IGA1
        cbWriteMMIOUlongBits(pcbe, IGA1_PXL_H_BNK_ST_REG, IGA1_PXL_H_BNK_ST_MASK, buf);
        break;

    case H_BNK_END:
        buf = buf -1;                                   // for H_BNK_END(-1) on IGA1
        cbWriteMMIOUlongBits(pcbe, IGA1_PXL_H_BNK_END_REG, IGA1_PXL_H_BNK_END_MASK, buf<<16);
        break;

    case H_SYNC_ST:
        buf = buf -1;                                   // for H_SYNC_ST(-1) on IGA1
        cbWriteMMIOUlongBits(pcbe, IGA1_PXL_H_SYNC_ST_REG, IGA1_PXL_H_SYNC_ST_MASK, buf);
        break;

    case H_SYNC_END:
        buf = buf -1;                                   // for H_SYNC_END(-1) on IGA1
        cbWriteMMIOUlongBits(pcbe, IGA1_PXL_H_SYNC_END_REG, IGA1_PXL_H_SYNC_END_MASK, buf<<16);
        break;

    case V_TOTAL:
        buf = buf -2;                                   // for V_TOTAL(-2) on IGA1
        cbWriteMMIOUlongBits(pcbe, IGA1_PXL_V_TOTAL_REG, IGA1_PXL_V_TOTAL_MASK, buf);
        break;

    case V_DIS_END:
        buf = buf -1;                                   // for V_DIS_END(-1) on IGA1
        cbWriteMMIOUlongBits(pcbe, IGA1_PXL_V_DIS_END_REG, IGA1_PXL_V_DIS_END_MASK, buf<<16);
        break;

    case V_BNK_ST:
        buf = buf -1;                                   // for V_BNK_ST(-1) on IGA1
        cbWriteMMIOUlongBits(pcbe, IGA1_PXL_V_BNK_ST_REG, IGA1_PXL_V_BNK_ST_MASK, buf);
        break;

    case V_BNK_END:
        buf = buf -1;                                   // for V_BNK_END(-1) on IGA1
        cbWriteMMIOUlongBits(pcbe, IGA1_PXL_V_BNK_END_REG, IGA1_PXL_V_BNK_END_MASK, buf<<16);
        break;

    case V_SYNC_ST:
        buf = buf -1;                                   // for V_SYNC_ST(-1) on IGA1
        cbWriteMMIOUlongBits(pcbe, IGA1_PXL_V_SYNC_ST_REG, IGA1_PXL_V_SYNC_ST_MASK, buf);
        break;

    case V_SYNC_END:
        buf = buf -1;                                   // for V_SYNC_END(-1) on IGA1
        cbWriteMMIOUlongBits(pcbe, IGA1_PXL_V_SYNC_END_REG, IGA1_PXL_V_SYNC_END_MASK, buf<<12);
        break;

    case HVSYNC_Offset2:                                // for HALF_LINE on IGA1
        cbWriteMMIOUlongBits(pcbe, IGA1_PXL_HALF_LINE_REG, IGA1_PXL_HALF_LINE_MASK, buf);
        break;

    default:
        break;

    }
}

void cbLoadTimingOnIGA2_UMA(PCBIOS_EXTENSION pcbe, TIMING_REG_TYPE RegType, WORD Data)
{
    WORD    buf;
    WORD    current_blank_end=0;
    BYTE      chkCR8A;
    chkCR8A = cbReadRegByte(pcbe, CR_8A);


    switch (RegType)
    {
    case H_TOTAL:
        buf = Data -1;                                  // fix for H_TOTAL(-1) on IGA2

        // a simple func to prevent total smaller than blank end
        // it will cause some LCD display short time garbage
        current_blank_end = cbReadRegByte(pcbe, CR_53);
        current_blank_end |= ((((cbReadRegByte(pcbe, CR_54) & (BIT5 | BIT4 | BIT3))>>3))<<8);
        current_blank_end |= (((cbReadRegByte(pcbe, CR_5D) & (BIT6))>>3)<<8);
        if(buf < current_blank_end)
        {
            // update blank_end first
            cbLoadTimingOnIGA2_UMA(pcbe, H_BNK_END, Data);
        }
        // CR50[7:0]
        cbWriteRegByte(pcbe, CR_50, (BYTE)(buf%0x100));
        // CR55[3:0]
        cbWriteRegBits(pcbe, CR_55, BIT3 | BIT2 | BIT1 | BIT0, (BYTE)(buf/0x100));
        break;

    case H_DIS_END:
        buf = Data -1;                                  // fix for H_DIS_END(-1) on IGA2

        // CR51[7:0]
        cbWriteRegByte(pcbe, CR_51, (BYTE)(buf%0x100));
        // CR55[7:4]
        cbWriteRegBits(pcbe, CR_55, BIT7 | BIT6 | BIT5 | BIT4, (BYTE)((buf/0x100)<<4));
        break;

    case H_BNK_ST:
        buf = Data -1;

        // CR52[7:0]
        cbWriteRegByte(pcbe, CR_52, (BYTE)(buf%0x100));
        // CR54[2:0]
        cbWriteRegBits(pcbe, CR_54, BIT2 | BIT1 | BIT0, (BYTE)(buf/0x100));
        // CR6B[0]
        cbWriteRegBits(pcbe, CR_6B, BIT0, (BYTE)(buf/0x100)>>3);
        break;

    case H_BNK_END:
        buf = Data -1;

        // CR53[7:0]
        cbWriteRegByte(pcbe, CR_53, (BYTE)(buf%0x100));
        // CR54[5:3]
        cbWriteRegBits(pcbe, CR_54, BIT5 | BIT4 | BIT3, (BYTE)((buf/0x100)<<3));
        // CR5D[6]
        cbWriteRegBits(pcbe, CR_5D, BIT6, (BYTE)((buf/0x100)<<3));
        break;

    case H_SYNC_ST:
        if( chkCR8A & 0x1 )
        	buf = Data -2;     // -(1+1) because we set CR_8A=01 to adjust HVsync  
        else 
        	buf = Data -1;
        // CR56[7:0]
        cbWriteRegByte(pcbe, CR_56, (BYTE)(buf%0x100));
        // CR54[7:6]
        cbWriteRegBits(pcbe, CR_54, BIT7+BIT6, (BYTE)((buf/0x100)<<6));
        // CR5C[7]
        cbWriteRegBits(pcbe, CR_5C, BIT7, (BYTE)((buf/0x100)<<5));
        // CR5D[7]
        cbWriteRegBits(pcbe, CR_5D, BIT7, (BYTE)((buf / 0x100) << 4));
        break;

    case H_SYNC_END:
        if( chkCR8A & 0x1 )
        	buf = Data -2;     // -(1+1) because we set CR_8A=01 to adjust HVsync  
        else 
        	buf = Data -1;

        // CR57[7:0]
        cbWriteRegByte(pcbe, CR_57, (BYTE)(buf%0x100));
        // CR5C[6]
        cbWriteRegBits(pcbe, CR_5C, BIT6, (BYTE)((buf/0x100)<<6));
        break;

    case V_TOTAL:
        buf = Data -1;                                  // fix for V_TOTAL(-1) on IGA2

        // CR58[7:0]
        cbWriteRegByte(pcbe, CR_58, (BYTE)(buf%0x100));
        // CR5D[2:0]
        cbWriteRegBits(pcbe, CR_5D, BIT2 | BIT1 | BIT0, (BYTE)(buf/0x100));
        break;

    case V_DIS_END:
        buf = Data -1;                                  // fix for V_DIS_END(-1) on IGA2

        // CR59[7:0]
        cbWriteRegByte(pcbe, CR_59, (BYTE)(buf%0x100));
        // CR5D[5:3]
        cbWriteRegBits(pcbe, CR_5D, BIT5 | BIT4 | BIT3, (BYTE)((buf/0x100)<<3));
        break;

    case V_BNK_ST:
        buf = Data -1;                                  // fix for V_BNK_ST(-1) on IGA2

        // CR5A[7:0]
        cbWriteRegByte(pcbe, CR_5A, (BYTE)(buf%0x100));
        // CR5C[2:0]
        cbWriteRegBits(pcbe, CR_5C, BIT2 | BIT1 | BIT0, (BYTE)(buf/0x100));
        break;

    case V_BNK_END:
        buf = Data -1;

        // CR5B[7:0]
        cbWriteRegByte(pcbe, CR_5B, (BYTE)(buf%0x100));
        // CR5C[5:3]
        cbWriteRegBits(pcbe, CR_5C, BIT5 | BIT4 | BIT3, (BYTE)((buf/0x100)<<3));
        break;

    case V_SYNC_ST:
        buf = Data -1;

        // CR5E[7:0]
        cbWriteRegByte(pcbe, CR_5E, (BYTE)(buf%0x100));
        // CR5F[7:5]
        cbWriteRegBits(pcbe, CR_5F, BIT7 | BIT6 | BIT5, (BYTE)((buf/0x100)<<5));
        break;

    case V_SYNC_END:
        buf = Data -1;

        // CR5F[4:0]
        cbWriteRegBits(pcbe, CR_5F, BIT4 | BIT3 | BIT2 | BIT1 | BIT0, (BYTE)(buf%0x100));
        break;

    case FETCH_COUNT:
        buf = Data;

        // CR65[7:0]
        cbWriteRegByte(pcbe, CR_65, (BYTE)(buf%0x100));
        // CR67[3:2]
        cbWriteRegBits(pcbe, CR_67, BIT3 | BIT2, (BYTE)((buf/0x100)<<2));
        break;

    case OFFSET:
        buf = Data;

        // CR66[7:0]
        cbWriteRegByte(pcbe, CR_66, (BYTE)(buf%0x100));
        // CR67[1:0]
        cbWriteRegBits(pcbe, CR_67, BIT1 | BIT0, (BYTE)(buf/0x100));
        // CR71[7]
        cbWriteRegBits(pcbe, CR_71, BIT7, (BYTE)((buf/0x100)<<5));
        break;

    case H_SCALING_FACTOR:
        buf = Data;

        // CR9F[1:0]
        cbWriteRegBits(pcbe, CR_9F, BIT1 | BIT0, (BYTE)(buf%0x100));
        // CR77[7:0]
        cbWriteRegByte(pcbe, CR_77, (BYTE)(buf>>2));
        // CR79[5:4]
        cbWriteRegBits(pcbe, CR_79, BIT5 | BIT4, (BYTE)((buf/0x100)<<2));

        if (Data != 0)
        {
            // CRA2[7]=1, H Scaling Enable
            cbWriteRegBits(pcbe, CR_A2, BIT6 | BIT7, BIT6 | BIT7);
        }
        else
        {
            // CRA2[7]=0, H Scaling Disable
            cbWriteRegBits(pcbe, CR_A2, BIT6 | BIT7, 0x00);
        }
        break;

    case V_SCALING_FACTOR:
        buf = Data;

        // CR78[7:0]
        cbWriteRegByte(pcbe, CR_78, (BYTE)(buf >> 1));
        // CR79[3]
        cbWriteRegBits(pcbe, CR_79, BIT3, (BYTE)(buf << 3));
        // CR79[7:6]
        cbWriteRegBits(pcbe, CR_79, BIT7 | BIT6, (BYTE)((buf / 0x100) << 5));

        if (Data != 0)
        {
            // CRA2[3]=1, V Scaling Enable
            cbWriteRegBits(pcbe, CR_A2, BIT3, BIT3);
        }
        else
        {
            // CRA2[3]=0, V Scaling Disable
            cbWriteRegBits(pcbe, CR_A2, BIT3, 0x00);
        }
        break;

    case COLOR_DEPTH:
        switch (Data)
        {
        case _8BPP:
            cbWriteRegBits(pcbe, CR_67, BIT7 | BIT6, 0x00); // CR67[7:6]=00
            cbWriteRegBits(pcbe, CR_6A, BIT5, 0x00);    // CR6A[5]=0=6bit LUT
            break;

        case _16BPP:
            cbWriteRegBits(pcbe, CR_67, BIT7 | BIT6, BIT6); // CR67[7:6]=01
            cbWriteRegBits(pcbe, CR_6A, BIT5, BIT5);    // CR6A[5]=1=8bit LUT
            break;

        case _32BPP:
        default:
            cbWriteRegBits(pcbe, CR_67, BIT7 | BIT6, BIT7 | BIT6);    // CR67[7:6]=11
            cbWriteRegBits(pcbe, CR_6A, BIT5, BIT5);            // CR6A[5]=1=8bit LUT
            break;
        }
        break;

    case POWER_NOW_END_POS:
        buf = Data - 1;

        // CR9D[7]
        cbWriteRegBits(pcbe, CR_9D, BIT7, BIT7);
        // CR9D[6:0]
        cbWriteRegBits(pcbe, CR_9D, BIT6|BIT5|BIT4|BIT3|BIT2|BIT1|BIT0, (BYTE)(buf & 0x7F));
        break;

    case HVSYNC_Offset2:
        buf = Data;
        // clear CR FB[7:0] CR FC[2:0] CR AB[7:0] CR AC[2:0]
        cbWriteRegBits(pcbe, CR_FB, BIT7|BIT6|BIT5|BIT4|BIT3|BIT2|BIT1|BIT0, (BYTE)(0 & 0xFF));
        cbWriteRegBits(pcbe, CR_FC, BIT2 | BIT1 | BIT0, (BYTE)((0 >> 8) & 0x07));
        cbWriteRegBits(pcbe, CR_AB, BIT7|BIT6|BIT5|BIT4|BIT3|BIT2|BIT1|BIT0, (BYTE)(0 & 0xFF));
        cbWriteRegBits(pcbe, CR_AC, BIT2 | BIT1 | BIT0, (BYTE)((0 >> 8) & 0x07));
        if(cbReadRegByte(pcbe, CR_9B) & BIT4)    // DVPPort Half Line register
        {
            //CR FB[7:0]
            cbWriteRegBits(pcbe, CR_FB, BIT7|BIT6|BIT5|BIT4|BIT3|BIT2|BIT1|BIT0, (BYTE)(buf & 0xFF));
            //CR FC[2:0]
            cbWriteRegBits(pcbe, CR_FC, BIT2 | BIT1 | BIT0, (BYTE)((buf >> 8) & 0x07));
        }
        else                                    // IGA2 Half Line registers
        {
            //CR AB[7:0]
            cbWriteRegBits(pcbe, CR_AB, BIT7|BIT6|BIT5|BIT4|BIT3|BIT2|BIT1|BIT0, (BYTE)((buf-1) & 0xFF));
            //CR AC[2:0]
            cbWriteRegBits(pcbe, CR_AC, BIT2 | BIT1 | BIT0, (BYTE)((buf >> 8) & 0x07));
        }
        break;

    default:
        break;
    }

}

VOID cbIGA1_FIFO_Setting_UMA(PCBIOS_EXTENSION pcbe, WORD Offset)
{
    BYTE SR15_Value = cbReadRegByte(pcbe, SR_15);
    
    if(SR15_Value & BIT1) // Is extended display mode?
    {
        // set display FIFO depth: {3c4.57.bit[3], 3c4.17.bit[7:0]} x 2
        cbWriteRegBits(pcbe, SR_57, BIT3, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA1_Depth >> 5));
        cbWriteRegByte(pcbe, SR_17, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA1_Depth));

        // set display fetch datum threshold value: {3c4.16.bit[7], bit[5:0]} x 4
        cbWriteRegBits(pcbe, SR_16, BIT7, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA1_Normal_TH << 1));
        cbWriteRegBits(pcbe, SR_16, 0x3F, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA1_Normal_TH));

        // set Low FIFO Threshhold to fixed 08h for 409
        cbWriteRegByte(pcbe, SR_58, 0x08);
        
        // set switch to the highest agent threshold value: {3c4.18.bit[7], bit[5:0]} x 4
        cbWriteRegBits(pcbe, SR_18, BIT7, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA1_Urgent_TH << 1));
        cbWriteRegBits(pcbe, SR_18, 0x3F, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA1_Urgent_TH));

        // set maximum length for a request: 3c4.22.bit[4:0] x 4
        if ( ((1400 == pcbe->IGA1Info.HRes) && (1050 == pcbe->IGA1Info.VRes) && (32 == pcbe->IGA1Info.ColorDepth))
            || ((1600 == pcbe->IGA1Info.HRes) && (1200 == pcbe->IGA1Info.VRes) && (32 == pcbe->IGA1Info.ColorDepth)) )
        {
            // Is 1400x1050 32bpp or 1600x1200 32bpp?
            cbWriteRegBits(pcbe, SR_22, 0x1F, 16);
        }
        else
        {
            cbWriteRegBits(pcbe, SR_22, 0x1F, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA1_Expire_N));
        }
    }

    // Display FIFO threshold for power now indicater (the value must be divided by 4) 
    cbWriteRegBits(pcbe, CR_42, 0x7F, (BYTE)((pcbe->FIFO_Info.ExtGFX_IGA1_Depth+1)>>1));
}

VOID cbIGA2_FIFO_Setting_UMA(PCBIOS_EXTENSION pcbe, WORD Offset)
{
    // set display FIFO depth: (3d4.95.bit[7], 3d4.94.bit[7], 3d4.68.bit[7:4]) x 8
    cbWriteRegBits(pcbe, CR_68, 0xF0, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA2_Depth << 4));
    cbWriteRegBits(pcbe, CR_AA, BIT7, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA2_Depth << 1));
    cbWriteRegBits(pcbe, CR_95, BIT7, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA2_Depth << 2));
    cbWriteRegBits(pcbe, CR_94, BIT7, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA2_Depth << 3));

    // set display fetch datum threshold value: {3d4.95.bit[6:4], 3d4.68.bit[3:0]} x 4
    cbWriteRegBits(pcbe, CR_68, 0x0F, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA2_Normal_TH));
    cbWriteRegBits(pcbe, CR_95, BIT6 + BIT5 + BIT4, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA2_Normal_TH));

    // set Low FIFO Threshhold to fixed 08h for 409
    cbWriteRegByte(pcbe, SR_58, 0x08);

    // set switch to the highest agent threshold value: {3d4.95.bit[2:0], 3d4.92.bit[3:0]} x 4
    cbWriteRegBits(pcbe, CR_92, 0x0F, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA2_Urgent_TH));
    cbWriteRegBits(pcbe, CR_95, BIT2 + BIT1 + BIT0, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA2_Urgent_TH >> 4));

    // set fetch Number for a scan line (unit:8 bytes): {3d4.67.bit[3:2], 3d4.65.bit[7:0]}
    Offset >>= 1;
    if ( (1400 == pcbe->IGA1Info.HRes) && (1050 == pcbe->IGA1Info.VRes)
        && ((8 == pcbe->IGA1Info.ColorDepth) || (16 == pcbe->IGA1Info.ColorDepth)) )
    {
        // Is 1400x1050 8bpp or 1400x1050 16bpp?
        Offset += 3;
        cbWriteRegBits(pcbe, CR_67, BIT3 + BIT2, (BYTE)(Offset >> 6));
        cbWriteRegByte(pcbe, CR_65, (BYTE)(Offset));
    }

    // set maimum length for a request: 3d4.94.bit[6:0] x 4
    if ( ((1400 == pcbe->IGA1Info.HRes) && (1050 == pcbe->IGA1Info.VRes) && (32 == pcbe->IGA1Info.ColorDepth))
        || ((1600 == pcbe->IGA1Info.HRes) && (1200 == pcbe->IGA1Info.VRes) && (32 == pcbe->IGA1Info.ColorDepth)) )
    {
        // Is 1400x1050 32bpp or 1600x1200 32bpp?
        cbWriteRegBits(pcbe, CR_94, 0x7F, 16);
    }
    else
    {
        cbWriteRegBits(pcbe, CR_94, 0x7F, (BYTE)(pcbe->FIFO_Info.ExtGFX_IGA2_Expire_N));
    }

    // Display FIFO threshold for power now indicater (the value must be divided by 4) 
    cbWriteRegBits(pcbe, CR_9E, 0x7F, (BYTE)((pcbe->FIFO_Info.ExtGFX_IGA2_Depth+1)<<1));
}

//=============================================================================
// below is new sub functions
//=============================================================================

//----------------------------------------------------------------------------
//  cbenableDevice_UMA
//      This function enable device. It only enable one Device each time
//  during enable device, digital port will also be set
//     IN : Device type bit 
//     OUT : function status
//---------------------------------------------------------------------------
CBIOS_STATUS cbenableDevice_UMA(PCBIOS_EXTENSION pcbe, IN DWORD Device)
{
    CBIOS_STATUS status = CBIOS_OK;
    if (MORE_THAN_1BIT(Device))
    {
        cbDbgPrint(1, "More than one device to enable!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }

    switch(Device)
    {
    case S3_CRT:
        cbSetCRTPowerState(pcbe, S3PM_ON);
        break;
    case S3_CRT2:
        cbsetcrt2powerstate(pcbe, S3PM_ON);
        break;
    case S3_LCD:
        cbSetLCDPowerState(pcbe, S3PM_ON);
        break;
    case S3_LCD2:
        cbSetLCD2PowerState(pcbe, S3PM_ON);
        break;
    case S3_DVI:
        cbSetDVIPowerState(pcbe, S3PM_ON);
        break;
    case S3_DVI2:
        cbSetDVI2PowerState(pcbe, S3PM_ON);
        break;    
    case S3_HDTV:
        cbSetHDTVPowerState(pcbe, S3PM_ON);
        break;
    case S3_TV:
        cbSetTVPowerState(pcbe, S3PM_ON);
        break;
    case S3_HDMI:
        cbSetHDMIPowerState(pcbe, S3PM_ON);
        break;
    case S3_HDMI2:
        cbSetHDMI2PowerState(pcbe, S3PM_ON);
        break;
    case S3_DP:
        cbSetDPPowerState(pcbe, S3PM_ON);
        break;
    case S3_DP2:
        cbSetDP2PowerState(pcbe, S3PM_ON);
        break;
    default:
        cbDbgPrint(1, "Error device type!\n");
        status = CBIOS_ER_INVALID_PARAMETER;
    }
    return status;
}

//----------------------------------------------------------------------------
//  cbdisableDevice_UMA
//      This function disbale device. It will only disable one Device each time
//     IN : Device type bit 
//     OUT : function status
//---------------------------------------------------------------------------
CBIOS_STATUS cbdisableDevice_UMA(PCBIOS_EXTENSION pcbe, IN DWORD Device)
{
    CBIOS_STATUS status = CBIOS_OK;
    if (MORE_THAN_1BIT(Device))
    {
        cbDbgPrint(1, "More than one device to enable!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }
   
    switch(Device)
    {
    case S3_CRT:
        cbSetCRTPowerState(pcbe, S3PM_OFF);
        break;
    case S3_CRT2:
        cbsetcrt2powerstate(pcbe, S3PM_OFF);
        break;
    case S3_LCD:
        cbSetLCDPowerState(pcbe, S3PM_OFF);
        break;
    case S3_LCD2:
        cbSetLCD2PowerState(pcbe, S3PM_OFF);
        break;
    case S3_DVI:
        cbSetDVIPowerState(pcbe, S3PM_OFF);
        break;
    case S3_DVI2:
        cbSetDVI2PowerState(pcbe, S3PM_OFF);
        break;
    case S3_HDTV:
        cbSetHDTVPowerState(pcbe, S3PM_OFF);
        break;
    case S3_TV:
        cbSetTVPowerState(pcbe, S3PM_OFF);
        break;
    case S3_HDMI:
        cbSetHDMIPowerState(pcbe, S3PM_OFF);
        break;
    case S3_HDMI2:
        cbSetHDMI2PowerState(pcbe, S3PM_OFF);
        break;
    case S3_DP:
        cbSetDPPowerState(pcbe, S3PM_OFF);
        break;
    case S3_DP2:
        cbSetDP2PowerState(pcbe, S3PM_OFF);
        break;
    default:
        cbDbgPrint(1, "Error device type!\n");
        status = CBIOS_ER_INVALID_PARAMETER;
    }    
    return status;
}

//---------------------------------------------------------------------------
//  device power management function
//  on / off device power state & initial digital port associate
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//  cbConfigureIGApath
//      This function initialize IGA data path according to device
//  since CBIOS do not support simultaneous mode 
//        CR6B[3]    0
//    OUT
//---------------------------------------------------------------------------
void cbConfigureIGApath(PCBIOS_EXTENSION pcbe)
{
    // CBIOS do not support IGA1 + IGA2 simultaneous
    // so always disable simultaneous
    cbWriteRegBits(pcbe, CR_6B, BIT3, 0x00); 
}


//---------------------------------------------------------------------------
//  cbSetIGAPower
//      Except for D0 / D1 / D2 / D3 power state, in order to reduce power 
//  consume. we still need to modify chip state according to device on / off
//  state, Now 
//          pixel clock VCK & LCK( we need to keep VCK always on since HW limitation)
//          power now (for VT3336 only)
//          IGA2 Second Display Channel enable / disable
//      is under consideration
//      
//      IGA data sequence control is handled by driver since there is API for
//  driver to control this.
//
//     IN :
//      IGANum     : IGA1 / IGA2
//      powerState : ON / OFF
//---------------------------------------------------------------------------
void cbSetIGAPower(PCBIOS_EXTENSION pcbe, IN  DWORD IGA_Num, IN DWORD IGAPower)
{

    if(IGA_Num == IGA1)

    {
        // IGA1 power control
        if (S3PM_ON == IGAPower)
        {
            // disable power save
            // turn on VCK
            cbWriteRegBits(pcbe, SR_1B, BIT4+BIT5, BIT4+BIT5);

            // IGA1 PLL Power Control
            // VCK (Primary Display Clock) PLL Power Control
            cbWriteRegBits(pcbe, SR_2D, BIT4+BIT5, BIT4+BIT5);
            // special for VT3336
            // Enable Power Now Indicator : CR30[2]
            // Ending position of power now indicator(CR41) was loaded when Load timing
            cbWriteRegBits(pcbe, CR_30, BIT2, BIT2);
            pcbe->IGA1Info.PowerNowState = POWER_NOW_ON;
        }
        else
        {
            // enable power save
            if(pcbe->pVCPInfo->miscConfigure2 & CBIOS_PLL_Control_Enable)
            {
                // turn off VCK
                cbWriteRegBits(pcbe, SR_1B, BIT4+BIT5, 0);

                // IGA1 PLL Power Control
                // VCK (Primary Display Clock) PLL Power Control
                cbWriteRegBits(pcbe, SR_2D, BIT4+BIT5, 0);
            }
            // Disable Power Now Indicator
            cbWriteRegBits(pcbe, CR_30, BIT2, 0);    // CR30[2]
            pcbe->IGA1Info.PowerNowState = POWER_NOW_OFF;
        }
    }


    if(IGA_Num == IGA2)

    {
        // IGA2 power control
        if (S3PM_ON == IGAPower)
        {
            // Disable power save
            // turn on LCK
            cbWriteRegBits(pcbe, SR_1B, BIT6+BIT7, BIT6+BIT7);

            // IGA2 PLL Power Control
            cbWriteRegBits(pcbe, SR_2D, BIT2+BIT3, BIT2+BIT3);
            // special for VT3336
            // Enable Power Now Indicator : CR9F[7]
            // Ending position of power now indicator(CR9D) was loaded when Load timing
            cbWriteRegBits(pcbe, CR_9F, BIT7, BIT7);
            pcbe->IGA2Info.PowerNowState = POWER_NOW_ON;

            //Advanced GFX power control(NB Snapshop function enable on IGA2)
            //SR59[7]=0 , IGA2 Enable
            cbWriteRegBits(pcbe, SR_59, BIT7, 0); 

            // reset IGA2 before enable second display channel  
            // if we want to turn on IGA2, it must be reset IGA2 firstly to avoid unstable state
            if(!(cbReadRegByte(pcbe, CR_6A) & BIT7))
                cbIGA2HWResetEnable_UMA(pcbe);
            // enable IGA2 display channel
            cbWriteRegBits(pcbe, CR_6A, BIT6+BIT7, BIT6+BIT7);

            // Set IGA2 screen on/off independent
            // so that IGA1 screen on / off will not influence IGA2 state
            // CR6B[1]: IGA2 screen off selection 0: IGA2 SCR OFF
            cbWriteRegBits(pcbe, CR_6B, BIT1, 0x00); 

        }
        else  //other power state 
        {
            // enable powersave
            if(pcbe->pVCPInfo->miscConfigure2 & CBIOS_PLL_Control_Enable)
            {
                // turn off LCK           
                cbWriteRegBits(pcbe, SR_1B, BIT6+BIT7, 0);            
                // IGA2 PLL Power Control
                cbWriteRegBits(pcbe, SR_2D, BIT2+BIT3, 0);
            }

            // Disable Power Now Indicator
            cbWriteRegBits(pcbe, CR_9F, BIT7, 0);    // CR9F[7]
            pcbe->IGA2Info.PowerNowState = POWER_NOW_OFF;

            //Advanced GFX power control(NB Snapshop function back to IGA1)
            //SR59[7]=1 , IGA1 Enable
            cbWriteRegBits(pcbe, SR_59, BIT7, BIT7);  

            // disable second display channel 
            // this will stop IGA2 request signal
            cbWriteRegBits(pcbe, CR_6A, BIT6+BIT7, 0); 
         
        }
    }

    //
    // 353 hardware only support IGA2 with snapshot, if snapshot enable IGA1 request
    // trigger will cause system hang.
    //
    if((pcbe->IGA1Info.PowerNowState == POWER_NOW_OFF) &&
       (pcbe->IGA2Info.PowerNowState == POWER_NOW_ON))
    {
        // enable snapshot support
        cbWriteRegBits(pcbe, CR_F3, 0x04, 0x04); // CRF3[2] = 1
    }
    else
    {
        // disable snapshot support
        cbWriteRegBits(pcbe, CR_F3, 0x04, 0x00); // CRF3[2] = 0
    }
    
    // 
    // Can't enable two IGA power now it will cause CPU FID/VID change fail
    // special handle this case, disable IGA1 power now
    // keep in touch with system team to find the root cause
    //
    if (pcbe->PCIDeviceID == PCI_ID_VT3336)
    {
    if((pcbe->IGA1Info.PowerNowState == POWER_NOW_ON) && 
       (pcbe->IGA2Info.PowerNowState == POWER_NOW_ON))
    {
        // disable IGA1 power now
        cbWriteRegBits(pcbe, CR_30, 0x04, 0x00); // CR30[2] = 0
        pcbe->IGA1Info.PowerNowState = POWER_NOW_OFF;
    }
    }
}


/*---------------------------------------------------------------------------
*  cbInitPad
*      This function initialize Pad according to DI portType
*    IN 
*      PortType :   CRT_PORT / DVP0/ DVP1/ DFPH/ DFPL/ DFP/
*      Operate  :   ON /OFF
*    OUT
*      Function status
*---------------------------------------------------------------------------*/
CBIOS_STATUS cbInitPad(PCBIOS_EXTENSION pcbe, IN DI_TYPE PortType, IN DWORD Operate)
{
    CBIOS_STATUS status = CBIOS_OK;
    
    switch(PortType)
    {
    case CRT_PORT:
        cbDbgPrint(1, "Not error, CRT no Pad just return\n");
        break;
    case DVP0:
        /* DVP0 Pad SR1E[7:6]  */
        if (Operate == ON) {
            cbWriteRegBits(pcbe, SR_1E, BIT7+BIT6, BIT7+BIT6);
        } else {
            cbWriteRegBits(pcbe, SR_1E, BIT7+BIT6, 0);
        }
        break;
    case DVP1:
    {
        BYTE  TXtype = TX_NONE;
        /* for 409 TTL_PANEL, use LVDS2 & DFPH to do data dithering */
        if (pcbe->ChipCaps.FOR_409_TTL_PANEL ) {
            BYTE i;
            for (i=0; i< DigitalPortNUM; i++) {
                if (pcbe->DIPort[i].DIType == DVP1) {
                    TXtype = pcbe->DIPort[i].PortInfo.TXType;
                    break;
                }
            }
        }
        /* DVP1 Pad SR1E[5:4] */
        if (Operate == ON) {
            /* 324 DVP1 pad on/off will cause LVDS interrupt, so we disable it temporarily */
            if (pcbe->ChipCaps.DISABLE_INTERRUPT_IN_PAD_ONOFF) {
                DWORD MMIO200 = ReadMMIOUlong(CB_MMIO_OFFSET(InterruptControlReg));
                if (pcbe->DIPort[1].PortInfo.DIPORTMISC & USING_LVDS_HPD_INTERRUPT) {
                    /* disable LVDS interrupt, MMIO200[30],and clear interrupt status BIT27 meanwhile */
                    cbWriteMMIOUlongBits(pcbe, InterruptControlReg, BIT30+BIT27, BIT27);
                    /* pad on */
                    cbWriteRegBits(pcbe, SR_1E, BIT5+BIT4, BIT5+BIT4);
                    /* restore MMIO200 and clear LVDS interrupt status, mmio200[27] */
                    WriteMMIOUlong(CB_MMIO_OFFSET(InterruptControlReg), MMIO200|BIT27); 
                } else if (pcbe->DIPort[1].PortInfo.DIPORTMISC & USING_TMDS_HPD_INTERRUPT) {
                    /* disable TMDS interrupt, MMIO200[16],and clear interrupt status BIT0 meanwhile */
                    cbWriteMMIOUlongBits(pcbe, InterruptControlReg, BIT16+BIT0, BIT0);
                    /* pad on */
                    cbWriteRegBits(pcbe, SR_1E, BIT5+BIT4, BIT5+BIT4);
                    /* restore MMIO200 and clear TMDS interrupt status, mmio200[0] */
                    WriteMMIOUlong(CB_MMIO_OFFSET(InterruptControlReg), MMIO200|BIT0); 
                } else {
                    cbDbgPrint(1, "No interrupt layout!\n");
                }
            } else {
                cbWriteRegBits(pcbe, SR_1E, BIT5+BIT4, BIT5+BIT4);
            }
            /* 409 TTL panel should enable DFPH PAD meanwhile */
            if (TXtype == TTL_PANEL) {
	            cbWriteRegBits(pcbe, SR_2A, BIT3+BIT2, BIT3+BIT2);
	        }
        } else {
            /* 324 DVP1 pad on/off will cause LVDS interrupt, so we disable it temporarily */
            if (pcbe->ChipCaps.DISABLE_INTERRUPT_IN_PAD_ONOFF) {
                DWORD MMIO200 = ReadMMIOUlong(CB_MMIO_OFFSET(InterruptControlReg));
                if (pcbe->DIPort[1].PortInfo.DIPORTMISC & USING_LVDS_HPD_INTERRUPT) {
                    /*disable LVDS interrupt, MMIO200[30],and clear interrupt status BIT27 meanwhile */
                    cbWriteMMIOUlongBits(pcbe, InterruptControlReg, BIT30+BIT27, BIT27);
                    /* pad off */
                    cbWriteRegBits(pcbe, SR_1E, BIT5+BIT4, 0);
                    /* restore MMIO200 and clear LVDS interrupt status, mmio200[27] */
                    WriteMMIOUlong(CB_MMIO_OFFSET(InterruptControlReg), MMIO200|BIT27); 
                } else if (pcbe->DIPort[1].PortInfo.DIPORTMISC & USING_TMDS_HPD_INTERRUPT) {
                    /* disable TMDS interrupt, MMIO200[16],and clear interrupt status BIT0 meanwhile */
                    cbWriteMMIOUlongBits(pcbe, InterruptControlReg, BIT16+BIT0, BIT0);
                    /* pad off */
                    cbWriteRegBits(pcbe, SR_1E, BIT5+BIT4, 0);
                    /* restore MMIO200 and clear TMDS interrupt status, mmio200[0] */
                    WriteMMIOUlong(CB_MMIO_OFFSET(InterruptControlReg), MMIO200|BIT0); 
                } else {
                    cbDbgPrint(1, "No interrupt layout!\n");
                }
            } else {
                cbWriteRegBits(pcbe, SR_1E, BIT5+BIT4, 0);
            }
            /* 409 TTL panel should disalbe DFPH PAD meanwhile */
            if (TXtype == TTL_PANEL) {
	            cbWriteRegBits(pcbe, SR_2A, BIT3+BIT2, 0);
	        }
        }
        break;
    }    
    case DFP_HIGH:
        /* DFP_H Pad SR2A[3:2] */
        if (Operate == ON) {
            cbWriteRegBits(pcbe, SR_2A, BIT3+BIT2, BIT3+BIT2);
        } else {
            cbWriteRegBits(pcbe, SR_2A, BIT3+BIT2, 0);
        }
        break;
    case DFP_LOW:        
        /* DFP_L Pad SR2A[1:0] */
        if (Operate == ON) {
            cbWriteRegBits(pcbe, SR_2A, BIT1+BIT0, BIT1+BIT0);
        } else {
            cbWriteRegBits(pcbe, SR_2A, BIT1+BIT0, 0);
        }
        break;
    case DFP_FULL:
        /* DFP Pad SR2A[3:0] */
        if (Operate == ON) {
            cbWriteRegBits(pcbe, SR_2A, 0x0F, 0x0F);
        } else {
            cbWriteRegBits(pcbe, SR_2A, 0x0F, 0);
        }
        break;
    default:
        cbDbgPrint(1, "error digital port type!\n");
        status = CBIOS_ER_INVALID_PARAMETER;
    }
    return status;
}


CBIOS_STATUS  CBiosSetActiveDisplayDeviceConfiguration_share (
    PVOID pvcbe, 
    IN DWORD dispDevIGA1,
    IN DWORD dispDevIGA2,
    IN DWORD AffectIGAs
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    PDigitalPortInfo PDIPort = NULL;
    DWORD dev;
    DWORD IGA1Power = S3PM_OFF, IGA2Power = S3PM_OFF;
    CBIOS_STATUS status = CBIOS_OK;

    dispDevIGA1 &= ALL_SUPPORT_DEV;
    dispDevIGA2 &= ALL_SUPPORT_DEV;

    if (0 == (dispDevIGA1 | dispDevIGA2))
    {
        // no device connect to both IGAs
        cbDbgPrint(1, "No device connect to one IGA");
        return CBIOS_ER_INVALID_PARAMETER;
    }

    
    // Valid device paramater, save to CBIOS info
    if((AffectIGAs == IGA1) ||(AffectIGAs == IGA1_IGA2))
    {
        pcbe->IGA1Info.dispDev = dispDevIGA1;
    }

    
    if((AffectIGAs == IGA2) ||(AffectIGAs == IGA1_IGA2))
    {
        pcbe->IGA2Info.dispDev = dispDevIGA2;
    }

    //*******************************************************************
    // for new set mode logic, when device is configured to 
    // one IGA , then IGA data path & DI port data source associated with 
    // device should also be configured
    // since we changed DI port source and IGA data path we need 
    // to do screen on / off or device on / off to get rid of garbage
    //*******************************************************************

    // 1. configure IGA data path
    cbConfigureIGApath(pcbe);

    // ----------------  IGA1 device configure  -----------------------

    if((AffectIGAs == IGA1) ||(AffectIGAs == IGA1_IGA2))
    {
        // put device on IGA1
        if (dispDevIGA1 != 0)
        {
            // 2. set device associate DI port data source
            // assume CRT also connect to a pseudo digital port without TX on it

            //in simultaneous, there will be more than one device in a IGA, so we should configure all DI ports of devices
            for (dev = pcbe->IGA1Info.dispDev; GET_LOWEST_BIT1(dev) != 0; dev = CLEAR_LOWEST_BIT1(dev))
            {
                 if (cbGetDIPortInfo(pcbe, &PDIPort, GET_LOWEST_BIT1(dev)) == TRUE)
                 {
                     // Set DI port Data Source 
                     cbSetDIPortSource(pcbe, PDIPort->DIType, IGA1);   // Data Source
                 }
                 else
                 {
                     status = CBIOS_ER_LACKOFINFO;
                     goto SetActiveDisplayDeviceConfigurationEnd;
                 }
            }
            // 3. turn IGA1 power on
            IGA1Power = S3PM_ON;
        }
        else 
        {
            // if device has been moved from IGA1
            // turn IGA1 power off
            IGA1Power = S3PM_OFF;
        }
    }

    // ----------------  IGA2 device configure  ------------------------
    
    if((AffectIGAs == IGA2) ||(AffectIGAs == IGA1_IGA2))
    {
        // put device on IGA2
        if (dispDevIGA2 != 0)
        {
            // 2. set device associate DI port data source
            // assume CRT also connect to a pseudo digital port without TX on it

            //in simultaneous, there will be more than one device in a IGA, so we should configure all DI ports of devices
            for (dev = pcbe->IGA2Info.dispDev; GET_LOWEST_BIT1(dev) != 0; dev = CLEAR_LOWEST_BIT1(dev))
            {
                 if (cbGetDIPortInfo(pcbe, &PDIPort, GET_LOWEST_BIT1(dev)) == TRUE)
                 {
                     // Set DI port Data Source 
                     cbSetDIPortSource(pcbe, PDIPort->DIType, IGA2);   // Data Source
                 }
                 else
                 {
                     status = CBIOS_ER_LACKOFINFO;
                     goto SetActiveDisplayDeviceConfigurationEnd;
                 }
            }

            // 3. turn IGA2 power on
            IGA2Power = S3PM_ON;
        }
        else 
        {   
            // 1. if device has been moved from IGA2
            // turn IGA2 power off
            IGA2Power = S3PM_OFF;
        }
    }

    
    //CONTROL SSC
    if(pcbe->ChipCaps.SSC_Enable) //if ssc needs to control
    {
        //if Lcd is going to light on but not on now, it will have power sequence
        BOOL bLcd1NeedPwrSeq=(dispDevIGA2&S3_LCD)&&!cbIsLcd1OnNow(pcbe);
        BOOL bLcd2NeedPwrSeq=(dispDevIGA2&S3_LCD2)&&!cbIsLcd2OnNow(pcbe);
        //check if any lcd need to be sent power sequence
        if(!bLcd1NeedPwrSeq && !bLcd2NeedPwrSeq)
        {
            if(cbIsSSCAvailable(pcbe))
            {
                //if ssc need to be on, we should turn it on
                cbOnOffSSC(pcbe, ON);
            }
        }
    }

    if((AffectIGAs == IGA1) ||(AffectIGAs == IGA1_IGA2))
    {
        cbSetIGAPower(pcbe, IGA1, IGA1Power);
    }

    if((AffectIGAs == IGA2) ||(AffectIGAs == IGA1_IGA2))
    {
        cbSetIGAPower(pcbe, IGA2, IGA2Power);
    }

SetActiveDisplayDeviceConfigurationEnd:

    return CBIOS_OK;
}



/*---------------------------------------------------------------------------
*  cbSetDIPortSource
*      This function set Digital port data source to IGA1 /IGA2
*    IN 
*      PortType  :   CRT_PORT / DVP0/ DVP1/ DFPH/ DFPL/ DFP/
*      IGA_Num   :   IGA1 / IGA2
*    OUT
*      Function status
*--------------------------------------------------------------------------- */
CBIOS_STATUS cbSetDIPortSource(PCBIOS_EXTENSION pcbe,IN DI_TYPE PortType, IN DWORD IGA_Num)
{
    ULONG datasource;
    CBIOS_STATUS status = CBIOS_OK;
    
    if (IGA1 == IGA_Num) {
        /* IGA1 = 0 */
        datasource = 0;
    } else if (IGA2 == IGA_Num) {
        /* IGA2 = 1 */
        datasource = 1;
    } else {
        cbDbgPrint(1, "Device haven't connected to IGA!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }

    /* 3324 & 3393 internal TX data doesn't come from DVP */
    /* enable DFPH/ DFPL do not need to init DVP0 /DVP1 */
    switch(PortType)
    {
    case CRT_PORT:
        /* CRT data source control Reg SR16[6] */
        cbWriteRegBits(pcbe, SR_16, BIT6, (BYTE)(datasource << 6));
        break;
    case DVP0:
        /* DVP0 data source control Reg CR96[4] */
        cbWriteRegBits(pcbe, CR_96, BIT4, (BYTE)(datasource << 4));
        break;
    case DVP1:
        /* DVP1 data source control Reg CR9B[4] */
        
        cbWriteRegBits(pcbe, CR_9B, BIT4, (BYTE)(datasource << 4));
        /* for TTL_PANEL, use CR99 to control data source */
        /* it's hardware layout problem */
        if(pcbe->pVCPInfo->miscConfigure2 & BIT6) {
	        cbWriteRegBits(pcbe, CR_99, BIT4, (BYTE)(datasource << 4));
        }
        /* for 409 TTL_PANEL, use LVDS2 & DFPH to do data dithering */
        if (pcbe->ChipCaps.FOR_409_TTL_PANEL ) {
            BYTE i, TXtype = TX_NONE;
            for (i=0; i< DigitalPortNUM; i++) {
                if (pcbe->DIPort[i].DIType == DVP1) {
                    TXtype = pcbe->DIPort[i].PortInfo.TXType;
                    break;
                }
            }
            if (TXtype == TTL_PANEL) {
	            cbWriteRegBits(pcbe, CR_97, BIT4, (BYTE)(datasource << 4));
	        }
        }
        
		break;
    case DFP_HIGH:
        /* DFP_H data source control Reg CR97[4]
               * Hardware limitation DFPH data come from DVP0
               * so also need to configure DVP0 
               * for VT3353 DI port source can be configured separately so do not 
               * configure DVP0 */
        if (!(pcbe->ChipCaps.DIPort_data_ctrl)) {
            cbWriteRegBits(pcbe, CR_96, BIT4, (BYTE)(datasource << 4));
        }
        cbWriteRegBits(pcbe, CR_97, BIT4, (BYTE)(datasource << 4));
        break;
    case DFP_LOW:        
        /* DFP_L data source control Reg CR99[4]
               * Hardware limitation DFPL data come from DVP1
               * so also need to configure DVP1
               * for VT3353 DI port source can be configured separately so do not 
               * configure DVP1 */
        if (!(pcbe->ChipCaps.DIPort_data_ctrl)) {
            cbWriteRegBits(pcbe, CR_9B, BIT4, (BYTE)(datasource << 4));
        }
        cbWriteRegBits(pcbe, CR_99, BIT4, (BYTE)(datasource << 4));
        
        break;
    case DFP_FULL:
        /* DFP data source control Reg CR97[4], CR99[4] */
        cbWriteRegBits(pcbe, CR_97, BIT4, (BYTE)(datasource << 4));
        cbWriteRegBits(pcbe, CR_99, BIT4, (BYTE)(datasource << 4));
        break;
    default:
        cbDbgPrint(1, "error digital port type!\n");
        status = CBIOS_ER_INVALID_PARAMETER;
    }

    return status;
}

//---------------------------------------------------------------------------
//  cbSetDVP0DrivingSelect
//      This function initialize DVP0 driving select setting According to Device 
//  associated IGA pixel clock
//    IN 
//      clk   :  Device associated IGA pixel clock
//    OUT
//      TURE or FALSE
//---------------------------------------------------------------------------

BOOL cbSetDVP0DrivingSelect(PCBIOS_EXTENSION pcbe, IN DWORD clk)
{    
    BYTE DrvValue = 0;

    if (NULL != pcbe->pVCPInfo)
    {
        if ((pcbe->pVCPInfo->version >= VCP1_4) &&
            (0 != pcbe->pVCPInfo->DVP0DrvSelectTbl) )
        {
            BYTE  *pDrvSelect;
            DWORD *pClkRange;
            
            pClkRange = (PDWORD)(pcbe->RomData + pcbe->pVCPInfo->DPA_ClockRange);
            pDrvSelect = (PBYTE)(pcbe->RomData + pcbe->pVCPInfo->DVP0DrvSelectTbl);
            if (clk <= pClkRange[0])
            {
                DrvValue = pDrvSelect[0];
            }
            else if (clk <= pClkRange[1])
            {
                DrvValue = pDrvSelect[1];
            }
            else if (clk <= pClkRange[2])
            {
                DrvValue = pDrvSelect[2];
            }
            else if (clk <= pClkRange[3])
            {
                DrvValue = pDrvSelect[3];
            }
            else if (clk <= pClkRange[4])
            {
                DrvValue = pDrvSelect[4];
            }
            else // clock >= clock range [4]
            {
                DrvValue = pDrvSelect[5];
            }        
        }
    }

    cbWriteRegBits(pcbe, SR_1E, BIT2, DrvValue<<2);
    cbWriteRegBits(pcbe, SR_2A, BIT4, DrvValue<<3);
    cbWriteRegBits(pcbe, SR_2A, BIT5, DrvValue);
    cbWriteRegBits(pcbe, SR_1B, BIT1, DrvValue>>3);

    return TRUE;
}

//---------------------------------------------------------------------------
//  cbSetDVP1DrivingSelect
//      This function initialize DVP1 driving select setting According to Device 
//  associated IGA pixel clock
//    IN 
//      clk   :  Device associated IGA pixel clock
//    OUT
//      TURE or FALSE
//---------------------------------------------------------------------------
BOOL cbSetDVP1DrivingSelect(PCBIOS_EXTENSION pcbe, IN DWORD clk)
{    
    BYTE DrvValue = 0;

    if (NULL != pcbe->pVCPInfo)
    {
        if ( (pcbe->pVCPInfo->version >= 0x14) &&
            (0 != pcbe->pVCPInfo->DVP1DrvSelectTbl) )
        {
            BYTE  *pDrvSelect;
            DWORD *pClkRange;
            
            pClkRange = (PDWORD)(pcbe->RomData + pcbe->pVCPInfo->DPA_ClockRange);
            pDrvSelect = (PBYTE)(pcbe->RomData + pcbe->pVCPInfo->DVP1DrvSelectTbl);
            if (clk <= pClkRange[0])
            {
                DrvValue = pDrvSelect[0];
            }
            else if (clk <= pClkRange[1])
            {
                DrvValue = pDrvSelect[1];
            }
            else if (clk <= pClkRange[2])
            {
                DrvValue = pDrvSelect[2];
            }
            else if (clk <= pClkRange[3])
            {
                DrvValue = pDrvSelect[3];
            }
            else if (clk <= pClkRange[4])
            {
                DrvValue = pDrvSelect[4];
            }
            else // clock >= clock range [4]
            {
                DrvValue = pDrvSelect[5];
            }        
        }
    }
    
    cbWriteRegBits(pcbe, SR_65, BIT3+BIT2+BIT1+BIT0, DrvValue);
    
    return TRUE;
}

//---------------------------------------------------------------------------
//  cbSetDeviceDPA
//      This function initialize device associated DPA setting According to Device 
//  and IGA pixel clock
//    IN 
//      device    :   device bit
//      clk       :   pixel clock
//    OUT
//      Function status
//---------------------------------------------------------------------------
BOOL cbSetDeviceDPA(
    PCBIOS_EXTENSION pcbe,
    IN DWORD device,
    IN DWORD clk)
{
    BOOL status = TRUE;
    BYTE DPAValue = 0;
    PDigitalPortInfo pDIPortInfo = NULL;

    if (cbGetDIPortInfo(pcbe, &pDIPortInfo, device) == FALSE)
    {
        return FALSE;
    }
    
    // get DPA value according to pixel clock
    // if VCPInfo == NULL DPAvlaue default 0
    if (NULL != pcbe->pVCPInfo)
    {
        DWORD *pClkRange;
        pClkRange = (PDWORD)(pcbe->RomData + pcbe->pVCPInfo->DPA_ClockRange);
       
        if (clk <= pClkRange[0])
        {
            DPAValue = pDIPortInfo->PortInfo.DPASetting[0];
        }
        else if (clk <= pClkRange[1])
        {
            DPAValue = pDIPortInfo->PortInfo.DPASetting[1];
        }
        else if (clk <= pClkRange[2])
        {
            DPAValue = pDIPortInfo->PortInfo.DPASetting[2];
        }
        else if (clk <= pClkRange[3])
        {
            DPAValue = pDIPortInfo->PortInfo.DPASetting[3];
            //VT3324, TV on DVP1
            if (pcbe->ChipCaps.DVP1_DPA_Value_Adjust &&  
                (pDIPortInfo->PortInfo.TXType == VT1625_6 || 
                 pDIPortInfo->PortInfo.TXType == VT1625A_6A)) 
            {
                //aid for 324 DVP1_3 DPA conflict among TV PAL 1024X768 over scan, 
                //1024X768 on HDTV 1080I & HDTV 720P native mode
                if (device == S3_TV)
                {
                    DPAValue = 0x0F;
                }
                else //HDTV
                {
                    if (pcbe->sPad_11.HDTV_Type == HDTV1080I)
                    {
                        DPAValue = 0x02;
                    }
                    else //720P
                    {
                        DPAValue = 0x01;
                    }
                }
            }
        }
        else if (clk <= pClkRange[4])
        {
            DPAValue = pDIPortInfo->PortInfo.DPASetting[4];
        }
        else // clock >= clock range [4]
        {
            DPAValue = pDIPortInfo->PortInfo.DPASetting[5];
        }
        
    }// if VCP exist

    //set DPA value accordingt to digital port
    switch(pDIPortInfo->DIType)
    {
    case CRT_PORT:
        // CRT port DPA Reg CR33[2:0]
        cbWriteRegBits(pcbe, CR_33, 0x07, DPAValue);
        break;
    case DVP0:
        // DVP0 DPA Reg CR96[3:0]
        cbWriteRegBits(pcbe, CR_96, 0x0F, DPAValue);
        cbSetDVP0DrivingSelect(pcbe,clk);
        break;
    case DVP1:
        // DVP1 DPA Reg CR9B[3:0]
        cbWriteRegBits(pcbe, CR_9B, 0x0F, DPAValue);
        cbSetDVP1DrivingSelect(pcbe,clk);
        break;
    case DFP_HIGH:
        // DFP_H DPA Reg CR97[3:0]
        cbWriteRegBits(pcbe, CR_97, 0x0F, DPAValue);
        break;
    case DFP_LOW:        
        // DFP_L DPA Reg CR99[3:0]
        cbWriteRegBits(pcbe, CR_99, 0x0F, DPAValue);
        break;
    case DFP_FULL:
        // DFP DPA Reg CR97[3:0], CR99[3:0]
        cbWriteRegBits(pcbe, CR_97, 0x0F, DPAValue);
        cbWriteRegBits(pcbe, CR_99, 0x0F, DPAValue);
        break;
    default:
        cbDbgPrint(1, "error digital port type!\n");
        status = FALSE;
    }

    if(((pDIPortInfo->PortInfo.device & (S3_DVI | S3_DVI2)) == device) && (pDIPortInfo->PortInfo.TXType == CH7301))
    {
        I2C_CONTROL_UMA i2c;
        i2c.Flags = 0;

        // get i2c info first
        if (cbGetDII2Csetting(pcbe, &i2c, device))
        {
            UCHAR DVI_PLL_TBL[] = 
            {  0x31, 0x00, 0x32, 0x23, 0x33, 0x08, 0x34, 0x16, 0x35, 0x30, 0x36, 0x60, 0x37, 0x00 
            };
            UCHAR DVI_BIGGER_65M_PLL_TBL[] = 
            {  0x31, 0x00, 0x32, 0x2D, 0x33, 0x06, 0x34, 0x26, 0x35, 0x30, 0x36, 0xA0, 0x37, 0x00 
            };
            PUCHAR pPLL_TBL = DVI_PLL_TBL;
            int i = sizeof(DVI_PLL_TBL) / 2;
            UCHAR ucTemp = 0;

            i2c.RegIndex  = 0x49;
            I2C_Read_Byte_INV(pcbe, &i2c);
            ucTemp = i2c.IndexData;
            i2c.IndexData &= 0x3F;
            I2C_Write_Byte_INV(pcbe, &i2c);

            if(clk > (65 * 1000000))
            {
                pPLL_TBL = DVI_BIGGER_65M_PLL_TBL;
                i = sizeof(DVI_BIGGER_65M_PLL_TBL) / 2;
            }

            for(;i>0;i--)
            {
                i2c.RegIndex  = *pPLL_TBL++;
                i2c.IndexData = *pPLL_TBL++;
                I2C_Write_Byte_INV(pcbe, &i2c);
            }

            i2c.RegIndex  = 0x49;
            i2c.IndexData = ucTemp;
            I2C_Write_Byte_INV(pcbe, &i2c);
        }
    }

    return status;
}

//---------------------------------------------------------------------------
// cbSetPolarity
//    This function init Polarity value for given device, polarity is controled 
//  on Digital Port, so set polarity is associated both with IGA (which mode) and 
//  device (which digital port). Now this function also supports CRT.
//
//  IN 
//      device : device type
//      HPolarity : Horizontal sync polarity
//                  CBIOS_NEGATIVE : CBIOS_POSITIVE
//      VPolarity : Vertical sync polarity
//                  CBIOS_NEGATIVE : CBIOS_POSITIVE
//  OUT 
//      function status
//---------------------------------------------------------------------------
BOOL cbSetPolarity(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD device, 
    IN BYTE HPolarity, 
    IN BYTE VPolarity)
{
    BOOL status = TRUE;
    PDigitalPortInfo pDIportinfo = NULL;
    DI_TYPE  DIType;
    BYTE polarity = 0;
        
    // special aid for VT3353 INLVDS_POLARITY_CONTROL
    if (pcbe->ChipCaps.INLVDS_Polarity_Control)
    {
        // VT3353 IN_LVDS1 IN_LVDS2 polarity control on SR78[6:3]
        if (cbGetDIPortInfo(pcbe, &pDIportinfo, device) == TRUE
            && (pDIportinfo->PortInfo.TXType == IN_LVDS1 || pDIportinfo->PortInfo.TXType == IN_LVDS2))
        {
            if (device & pcbe->IGA1Info.dispDev)
            {
                // IGA1 polarity SR78[4:3] IGA1 Polarity for internal LVDS1 or LVDS2
                if (HPolarity == CBIOS_NEGATIVE)
                {
                    polarity |= BIT4;
                }
                if (VPolarity == CBIOS_NEGATIVE)
                {
                    polarity |= BIT3;
                }
                // IGA1 polarity control 
                cbWriteRegBits(pcbe, SR_78, BIT3 + BIT4, polarity);
            }
            else if(device & pcbe->IGA2Info.dispDev)
            {
                // IGA2 polarity SR78[6:5] IGA2 Polarity for internal LVDS1 or LVDS2
                // IGA2 polarity CR9B[6:5] IGA2 Polarity for DVP1
                if (HPolarity == CBIOS_NEGATIVE)
                {
                    polarity |= BIT6;
                }
                if (VPolarity == CBIOS_NEGATIVE)
                {
                    polarity |= BIT5;
                }
                // IGA2 polarity control 
                cbWriteRegBits(pcbe, SR_78, BIT5 + BIT6, polarity);
                cbWriteRegBits(pcbe, CR_9B, BIT5 + BIT6, polarity);
            }

            return TRUE;
        }
    }


    //---------------init device DIport info------------------------
    if (cbGetDIPortInfo(pcbe, &pDIportinfo, device))
    {
        DIType = pDIportinfo->DIType;
        if (DIType == CRT_PORT)
        {
            // CRT MISC[6:7]
            if (HPolarity == CBIOS_NEGATIVE)
            {
                polarity |= 0x40;
            }
            if (VPolarity == CBIOS_NEGATIVE)
            {
                polarity |= 0x80;
            }
        }
        else
        {
            //device on DIPORT CRXX[6:5] 
            if (HPolarity == CBIOS_NEGATIVE)
            {
                polarity |= 0x20;
            }
            if (VPolarity == CBIOS_NEGATIVE)
            {
                polarity |= 0x40;
            }
        }
    }
    else
    {
         return FALSE;
    }


    //------------------set DIport Polarity---------------------
    switch(DIType)
    {
    case CRT_PORT:
        // CRT port polarity 
        // MISC[6] : HSYNC | MISC[7] : VSYNC
        WriteUchar(CB_MISC_OUTPUT_WRITE_REG, (ReadUchar(CB_MISC_OUTPUT_READ_REG) & 0x3F) | polarity);
        break;
    case DVP0:
        // DVP0 port polarity
        // CR96[5] : HSYNC | CR96[6] : VSYNC
        cbWriteRegBits(pcbe, CR_96, 0x60, polarity);
        break;
    case DVP1:
        // DVP1 port polarity
        // CR9B[5] : HSYNC | CR9B[6] : VSYNC
        cbWriteRegBits(pcbe, CR_9B, 0x60, polarity);
        break;
    case DFP_LOW:        
        // DFP_L port polarity
        // CR99[5] : HSYNC | CR99[6] : VSYNC
        cbWriteRegBits(pcbe, CR_99, 0x60, polarity);
        break;
    case DFP_HIGH:
    case DFP_FULL:
        // DFP_H / DFP port polarity all depending on CR97
        // CR97[5] : HSYNC | CR97[6] : VSYNC
        cbWriteRegBits(pcbe, CR_97, 0x60, polarity);
        break;
    default:
        cbDbgPrint(1, "DI port type error!\n");
        status = FALSE;
    }

    return status; 
}


//---------------------------------------------------------------------------
// cbConfigureDigitalPort
//   This function initialize / close digital port associate with device 
//  Three part of the digital port will be initialized 
//   1. Pad(clock)
//   2. DIPortDataCTRL
//  IN 
//      device : device type
//      Operate : ON / OFF
//  OUT 
//      TRUE or FALSE;
//---------------------------------------------------------------------------
BOOL cbConfigureDigitalPort(PCBIOS_EXTENSION pcbe, IN DWORD device, IN DWORD Operate)
{
    BOOL status = TRUE;
    PDigitalPortInfo PDIPort = NULL;
    RegGroupIndex RGIndex = CR_91; // default check PS1

    //--------------------------------------
    // get digital port info 
    //--------------------------------------
    // find which digital port of the 6 supported DI port for this DIPortDev
    // assume CRT also connect to a pseudo digital port without TX on it
    if (cbGetDIPortInfo(pcbe, &PDIPort, device) == FALSE)
    {
        cbDbgPrint(1, "No Digital port assigned to current device\n");
        return FALSE;
    }

    if((pcbe->pVCPInfo->miscConfigure3 & SW_PS2_BLT_VDD_BY_GPIO23) && 
        (PDIPort->PortInfo.TXType == TTL_PANEL))
    {
        RGIndex = CR_D3; // change to check PS2
    }

    //--------------------------------------------
    // set the Digital port info
    //   1. Pad(clock)
    //--------------------------------------------
    if (Operate == ON)
    {
        // aid for PAD_ON_OFF_IN_SW_PS:
        // PCIE NBs(336/364) data enable bit do not work, So turn on/off PAD to pull up/down data&clock
        // if PAD_ON_OFF_IN_SW_PS and LCD use Software Power squence and TX is HARDWIRED_LVDS
        // Then we control PAD when loading Software PowerSquence
        if( !( device & (S3_LCD | S3_LCD2) )           ||
            !(pcbe->ChipCaps.PAD_on_off_in_SW_PS) ||
            !(cbReadRegByte(pcbe, RGIndex) & BIT0)        ||
             ((PDIPort->PortInfo.TXType != HARDWIRED_LVDS) && (PDIPort->PortInfo.TXType != TTL_PANEL)))
        {
            cbInitPad(pcbe, PDIPort->DIType, ON);           // Pad (clock)
        }
    }
    else if (Operate == OFF)
    {
        // aid for PAD_ON_OFF_IN_SW_PS:
        // PCIE NBs(336/364) data enable bit do not work, So turn on/off PAD to pull up/down data&clock
        // if PAD_ON_OFF_IN_SW_PS and LCD use Software Power squence and TX is HARDWIRED_LVDS
        // Then we control PAD when loading Software PowerSquence
        if( !( device & (S3_LCD | S3_LCD2) )           ||
            !(pcbe->ChipCaps.PAD_on_off_in_SW_PS) ||
            !(cbReadRegByte(pcbe, RGIndex) & BIT0)        ||
             ((PDIPort->PortInfo.TXType != HARDWIRED_LVDS) && (PDIPort->PortInfo.TXType != TTL_PANEL)))
        {
            cbInitPad(pcbe, PDIPort->DIType, OFF);          // Pad (clock)
        }
    }
    else
    {
        cbDbgPrint(1, "Error Operation input!\n");
        status = FALSE;
    }
    
    return status;
}

//---------------------------------------------------------------------------
// cbDIPortDataCTRL
//    This function is DI port Data Control for Device
//
//  IN 
//      PortType :   DVP0/ DVP1/ DFPH/ DFPL/ DFP/
//      Operate  :   ON /OFF
//  OUT 
//      
//---------------------------------------------------------------------------
void cbDIPortDataCTRL(PCBIOS_EXTENSION pcbe, IN DWORD Operate,IN DI_TYPE PortType)
{   

    //------------------set DIport Data---------------------
    if (Operate == ON)
    {
        switch(PortType)
        {
            case DVP0:                
                cbWriteRegBits(pcbe, CR_91, BIT5, 0);
                break;
            case DVP1:
                cbWriteRegBits(pcbe, CR_D3, BIT5, 0);
                break;
            case DFP_LOW:        
                cbWriteRegBits(pcbe, CR_91, BIT7, 0);
                break;
            case DFP_HIGH:
                cbWriteRegBits(pcbe, CR_D3, BIT7, 0);
                break;
            default:
                break;
        }
     }   
    else
    {
        switch(PortType)
          {
             case DVP0:          
                 cbWriteRegBits(pcbe, CR_91, BIT5, BIT5);
                 break;
             case DVP1:
                 cbWriteRegBits(pcbe, CR_D3, BIT5, BIT5);
                 break;
             case DFP_LOW:        
                 cbWriteRegBits(pcbe, CR_91, BIT7, BIT7);
                 break;
             case DFP_HIGH:
                 cbWriteRegBits(pcbe, CR_D3, BIT7, BIT7);
                 break;
             default:
                 break;
          }
    }

}

//------------------------------------------------------------------
//  IGA Screen on off subfunction 
//  
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// SetIGA1screenOnOff
//      set IGA1 accessing data mode to achieve screen on/off
//   IN :
//       screenState : ON /OFF
//   OUT : 
//       CBIOS_STATUS 
//-----------------------------------------------------------------
CBIOS_STATUS SetIGA1screenOnOff(PCBIOS_EXTENSION pcbe, BOOL screenState)
{
    CBIOS_STATUS status = CBIOS_OK;
    DWORD dev;
    PDigitalPortInfo pDIPortInfo = NULL;
            

    // set SR01 reg to control IGA1 to access memory 
    // then device will screen on/off
    switch (screenState)
    {
    case ON:
        //SR01[5] = 0 On
        cbWriteRegBits(pcbe, SR_01, 0x20, 0x00); // Turn on IGA1
        
        if (pcbe->ChipCaps.IGA2Seq_SeparateDI_control)
        {
            // VT3353 VT3324 open all DI port data control which attached to IGA1
            for (dev = pcbe->IGA1Info.dispDev; GET_LOWEST_BIT1(dev) != 0; dev = CLEAR_LOWEST_BIT1(dev))
            {
                cbGetDIPortInfo(pcbe, &pDIPortInfo, GET_LOWEST_BIT1(dev));
	        if(pDIPortInfo)
        	{
	                cbDIPortDataCTRL(pcbe, ON, pDIPortInfo->DIType);        
        	}
            }
        }
        break;       
    case OFF:
        //SR01[5] = 1 Off
        cbWriteRegBits(pcbe, SR_01, 0x20, 0x20); // Turn off IGA1

        break;
    default:
        cbDbgPrint(1, "IGA1 on/off paramter error\n");
        status = CBIOS_ER_INVALID_PARAMETER;
    }

    // update IGA1 Screen On/Off Info
    if (status == CBIOS_OK)
    {
        pcbe->IGA1Info.ScreenOnOffState = screenState;
    }
    return status;    
}



//-----------------------------------------------------------------
// SetIGA2screenOnOff
//      set IGA2 accessing data mode to achieve screen on/off
//   IN :
//       screenState : ON /OFF
//   OUT : 
//       CBIOS_STATUS 
//-----------------------------------------------------------------
CBIOS_STATUS SetIGA2screenOnOff(PCBIOS_EXTENSION pcbe, BOOL screenState)
{
    CBIOS_STATUS status = CBIOS_OK;
    DWORD dev;
    PDigitalPortInfo pDIPortInfo = NULL;
    // since many chips IGA2 do not support IGA access memory control 
    // ability So for IGA2 we have to use datapath control reg instead
    // 
    switch (screenState)
    {
    case ON:
        // disable second display channel 
        // this will stop IGA2 request signal, or S3 will hang randomly
        // according to spec CR6A[7] to IGA2 is the same as SR01[5] to IGA1
        cbWriteRegBits(pcbe, CR_6A, BIT7, BIT7); 
        if (pcbe->ChipCaps.IGA2Seq_SeparateDI_control)
        {
            // use cr6b to turn on IGA2 screen from off state, it will bring garbage in 353,
            // so if not in vblank now, we should wait to vblank, then do this operation
            if (pcbe->ChipCaps.CR6B_ONOFF_SCRN_NOT_IN_VBLANK && !cbIsInVBlank(pcbe, IGA2))
            {
                cbWaitVBlank(pcbe, IGA2);
            }
            // IGA2 screen off selection 0: IGA2 SCR OFF
            // IGA2 screen off 1: screen off
            cbWriteRegBits(pcbe, CR_6B, BIT1+BIT2, 0x00); 

            // VT3353 VT3324 open data control of all the DI port which attached to IGA2
            for (dev = pcbe->IGA2Info.dispDev; GET_LOWEST_BIT1(dev) != 0; dev = CLEAR_LOWEST_BIT1(dev))
            {
                cbGetDIPortInfo(pcbe, &pDIPortInfo, GET_LOWEST_BIT1(dev));
                cbDIPortDataCTRL(pcbe, ON, pDIPortInfo->DIType);        
            }
        }
        else
        {                
            // VT3364 /3336 no sequence bit
            // CR91[7],[5] = 0 On to control IGA2 data on DI port
            cbWriteRegBits(pcbe, CR_91, 0xA0, 0x00); // Turn on IGA2 data on all DI port
        }
        break;

    case OFF:
        if (pcbe->ChipCaps.IGA2Seq_SeparateDI_control)
        {
            // VT3353 VT3324 close data control of all the DI port which attached to IGA2
            for (dev = pcbe->IGA2Info.dispDev; GET_LOWEST_BIT1(dev) != 0; dev = CLEAR_LOWEST_BIT1(dev))
            {
                cbGetDIPortInfo(pcbe, &pDIPortInfo, GET_LOWEST_BIT1(dev));
                cbDIPortDataCTRL(pcbe, OFF, pDIPortInfo->DIType);        
            }

            // IGA2 screen off selection 0: IGA2 SCR OFF
            // IGA2 screen off 1: screen off
            cbWriteRegBits(pcbe, CR_6B, BIT1+BIT2, BIT2); 
        }
        else
        {
            // VT3364 /3336 no sequence bit
            // CR91[7],[5] = 1 On to control IGA2 data on DI port
            cbWriteRegBits(pcbe, CR_91, 0xA0, 0xA0); // Turn off IGA2 data
        }

        break;

    default:
        cbDbgPrint(1, "IGA2 on/off paramter error\n");
        status = CBIOS_ER_INVALID_PARAMETER;
    }

    // update IGA Screen On/Off Info
    if (status == CBIOS_OK)
    {
        pcbe->IGA2Info.ScreenOnOffState = screenState;
    }

    return status;
}

//--------------------------------------------------------------------------
// cbUpdateHWDispDeviceBits
//      Update VBIOS current active display device registers
//      (CR3B and the related overflow bits)
//      Two active display device can be updated to these registers, at most
//  IN:
//      DispDevComb: Device bits that will be writed to registers
//                   this value should less than two device bit 
//                   (VBIOS getprimary function limitatin)
//  OUT:
//      NO
//  Return:
//      VOID
//--------------------------------------------------------------------------
VOID cbUpdateHWDispDeviceBits(IN PCBIOS_EXTENSION pcbe)
{
    DWORD dispDev;
    BYTE i;
	
    //Update active display device bits to HW registers
    /****************** Scratch pad 1 ******************/
    dispDev = pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev;
    //If CRT attached on, do not update CRT to HW scratch pad
    if (pcbe->pVCPInfo !=NULL)
    {
        if(pcbe->pVCPInfo->version >= VCP1_4)
        {	
	        if(pcbe->pVCPInfo->Always_On_Device & CRT_ATTACHED_ON)
	        {
	            dispDev &= ~S3_CRT;
	        }
        }
    }
	
    // if device has configured to one IGA while havn't been turned on
    // clear it & do not sync it to scrachpad
    for (i = 0; i < (sizeof(dispDev)<<3); i++)
    {
        if((dispDev & (1 << i)) && pcbe->devicepowerstate[i] == S3PM_OFF)
        {
            dispDev &= ~(1 << i);
        }
    }    
    if (!cbIsDeviceCombinationValid(dispDev))
    {
        // since when vbios control we only do simultaneous flow
        // so we need to check if IGA1 / IGA2 device is a valid simultaneous device combination 
        // if not just use IGA2 device
        dispDev = pcbe->IGA2Info.dispDev;
    }
    // since CRT may used as attached device while does not exist in ScrachPad
    // So CRT power state will be got from current HW register setting CR36[5,4] DPMS state,
    // we can make sure it's power status true when back from full screen. So we can force 
    // set CRT to hw register when device = 0
    if (dispDev == 0)
    {
        dispDev = S3_CRT;
    }
    // for VBIOS control case
    // it will never be a duoview case since without driver we only
    // use simultaneous way
    pcbe->sPad_1.bDuoView = 0;
    pcbe->sPad_1.Out_Dev = (BYTE)(dispDev & 0x7F); // scratch pad 1 [6:0] Output Device
    // For 324, we should translate word define device to s3 define here.
    if (pcbe->pVCPInfo != NULL)
    {
        if((pcbe->pVCPInfo->version >= VCP1_5) &&
            (pcbe->ChipCaps.S3_device_define_for_324))
        {
            if(dispDev & S3_HDTV)
            {
                pcbe->sPad_1.Out_Dev &= ~S3_HDTV;
                pcbe->sPad_1.Out_Dev |= WORD_HDTV;
            }
            if(dispDev & S3_CRT2)
            {
                pcbe->sPad_1.Out_Dev &= ~S3_CRT2;
            }
            if (dispDev & S3_LCD2)
            {
                pcbe->sPad_1.Out_Dev |= WORD_LCD2;
            }
        }
    }
    cbWriteRegByte(pcbe, CR_3B, STRUCT_BYTE(pcbe->sPad_1, 0));

    /****************** Scratch pad 11******************/
    // For 324, we should translate word define device to s3 define here.
    if(pcbe->pVCPInfo != NULL)
    {
        if ( (pcbe->pVCPInfo->version >= VCP1_5) &&
             (pcbe->ChipCaps.S3_device_define_for_324) )
        {
            if (dispDev & S3_CRT2)  // scratch pad 11[4] CRT2
            {
                pcbe->sPad_11.LCD2devBit = 1;
            }
            else
            {
                pcbe->sPad_11.LCD2devBit = 0;
            }
        }
    }
    else
    {
        if (dispDev & S3_LCD2)  // scratch pad 11[4] LCD2
        {
            pcbe->sPad_11.LCD2devBit = 1;
        }
        else
        {
            pcbe->sPad_11.LCD2devBit = 0;
        }
    } 
    
    cbWriteRegBits(pcbe, CR_3C, BIT4, STRUCT_BYTE(pcbe->sPad_11, 0));
    
    if(pcbe->pVCPInfo !=NULL)
    {
        if(pcbe->pVCPInfo->version >= VCP1_8)
        {
            /****************** Scratch pad 7 ******************/
            // ****HDMI device bit
            if (dispDev & S3_HDMI)
            {
                pcbe->sPad_7.HDMIdevBit= 1; 
            }
            else
            {
                pcbe->sPad_7.HDMIdevBit = 0;
            }
            cbWriteRegBits(pcbe, CR_4D, BIT7, STRUCT_BYTE(pcbe->sPad_7, 0));


            /****************** Shadow Scratch ******************/
            // transfer to access shadow scratch pad
            cbWriteRegBits(pcbe, SR_5A, BIT0, BIT0);

            /****************** Shadow Scratch pad 3******************/
            // ****HDMI2 device bit
            if (dispDev & S3_HDMI2)
            {
                pcbe->shPad_3.HDMI2devBit = 1; 
            }
            else
            {
                pcbe->shPad_3.HDMI2devBit = 0;
            }

            // ****DP device bit
            if (dispDev & S3_DP)
            {
                pcbe->shPad_3.DPdevBit = 1;
            }
            else
            {
                pcbe->shPad_3.DPdevBit = 0;
            }

            // ****DP2 device bit
            if (dispDev & S3_DP2)
            {
                pcbe->shPad_3.DP2devBit = 1; 
            }
            else
            {
                pcbe->shPad_3.DP2devBit = 0;
            }
            cbWriteRegBits(pcbe, CR_3E, BIT0+BIT1+BIT2, STRUCT_BYTE(pcbe->shPad_3, 0));

            // transfer to access normal scratch pad
            cbWriteRegBits(pcbe, SR_5A, BIT0, 0);
        }
    }
    else
    {
        /****************** Scratch pad 7 ******************/
        //                       &
        /****************** Shadow Scratch pad 3******************/
        // transfer to access shadow scratch pad
        cbWriteRegBits(pcbe, SR_5A, BIT0, BIT0);

        // ****HDMI2 device bit
        if (dispDev & S3_HDMI2)
        {
            pcbe->shPad_3.HDMI2devBit = 1; 
        }
        else
        {
            pcbe->shPad_3.HDMI2devBit = 0;
        }
        cbWriteRegBits(pcbe, CR_3E, BIT0, STRUCT_BYTE(pcbe->shPad_3, 0));

        // ****DP & HDMI device bit
        if (dispDev & S3_DP || dispDev & S3_HDMI)
        {
            pcbe->shPad_3.DPdevBit = 0;     // DP bit
            pcbe->sPad_7.HDMIdevBit = 0;    // HDMI bit
            if(pcbe->ChipCaps.InternalDP_Support)
            {
                if(!(pcbe->pVCPInfo->miscConfigure3 & BIT6)) // old definition: BIT6 is DP_LAYOUT_CONNECTOR. VCP1.8 later, it is removed
                {
                    if(dispDev & S3_DP)
                        pcbe->shPad_3.DPdevBit = 1;     // DP bit
                    else
                        pcbe->sPad_7.HDMIdevBit = 1;    // HDMI bit
                }
                else
                    pcbe->shPad_3.DPdevBit = 1;     // DP bit
            }
            else // HDMI bit
                pcbe->sPad_7.HDMIdevBit = 1;    // HDMI bit
        }
        else
        {
            pcbe->shPad_3.DPdevBit = 0;     // DP bit
            pcbe->sPad_7.HDMIdevBit = 0;    // HDMI bit
        }
        // write DP bit
        cbWriteRegBits(pcbe, CR_3E, BIT1, STRUCT_BYTE(pcbe->shPad_3, 0));

        // transfer to access normal scratch pad
        cbWriteRegBits(pcbe, SR_5A, BIT0, 0);
        // write HDMI bit
        cbWriteRegBits(pcbe, CR_4D, BIT7, STRUCT_BYTE(pcbe->sPad_7, 0));
        // transfer to access shadow scratch pad
        cbWriteRegBits(pcbe, SR_5A, BIT0, BIT0);

        // ****DP2 device bit
        if (dispDev & S3_DP2)
        {
            pcbe->shPad_3.DP2devBit = 1; 
        }
        else
        {
            pcbe->shPad_3.DP2devBit = 0;
        }
        cbWriteRegBits(pcbe, CR_3E, BIT2, STRUCT_BYTE(pcbe->shPad_3, 0));

        // transfer to access normal scratch pad
        cbWriteRegBits(pcbe, SR_5A, BIT0, 0);
    }
}

//-----------------------------------------------------------------
// cbIsAlwaysOnDevice
//      This function is used to judge if a device is always on device
//   IN :
//       device
//   OUT : 
//       TRUE or FALSE 
//-----------------------------------------------------------------
BOOL cbIsAlwaysOnDevice(PCBIOS_EXTENSION pcbe, DWORD device)
{
    if(NULL != pcbe->pVCPInfo)
    {
        if(pcbe->pVCPInfo->version >= VCP1_4)
        {
	        if( (pcbe->pVCPInfo->Always_On_Device & CRT_ATTACHED_ON) && (device & S3_CRT) )
	        {
	            //if CRT attached on, then remove CRT from always on devices
	            return FALSE;
	        }
	        if(device & pcbe->pVCPInfo->Always_On_Device)
	        {
	            return TRUE;
	        }
        }
    }
    return FALSE;
}

/*****************************************************************************************/
//
//Function:cbFilterOneDevice
//Discription:
//      This function will filter one device from input device combination.
//      General device filter sequence is : TV2->CRT2->DVI2->LCD2->HDTV->TV->HDMI->DVI->CRT->LCD,
//      that means we will try to keep display on some more generic devices, such as: LCD/CRT, 
//      then TV2/LCD2/DVI2 will be filter out first in this case .
//Return:
//      device combination after filter
//
/*****************************************************************************************/
DWORD cbFilterOneDevice(PCBIOS_EXTENSION pcbe, IN DWORD dev)
{
    // FILTERARRAY contains the general filter device sequence
    CONST DWORD FILTERARRAY[] = {S3_TV2,S3_CRT2,S3_DVI2,S3_LCD2,S3_HDTV,S3_TV,S3_HDMI,S3_DVI,S3_CRT,S3_LCD};
    BYTE i;
    for(i = 0; i<sizeofarray(FILTERARRAY); i++)
    {
        if(FILTERARRAY[i] & dev)
        {
            //Filter this display device, if input device has this device bit
            dev &= ~FILTERARRAY[i];
            break;
        }
    }
    return dev;
}

//*************************************************
// IGADeviceRuleTbl is the table used to define
// VALID device combination rule on signle IGA
//*************************************************
typedef struct DeviceOneIGACombination{
    DWORD primary;        // primary device (when set timing using its timing type)
    DWORD secondary;      // secondary device
}OneIGADeviceCombination;

static OneIGADeviceCombination IGADeviceRuleTbl[] = {
         { 0         ,      0  },           // no device on IGA
         { S3_CRT    ,      0  },      
         { S3_LCD    ,      0  },     
         { S3_TV     ,      0  },     
         { S3_HDTV   ,      0  },     
         { S3_DVI2   ,      0  },     
         { S3_DVI    ,      0  },     
         { S3_CRT2   ,      0  },     
         { S3_LCD2   ,      0  },     
         { S3_HDMI   ,      0  }, 
         { S3_HDMI2  ,      0  }, 
         { S3_DP     ,      0  }, 
         { S3_DP2    ,      0  }, 
         { S3_DVI3   ,      0  },     
         { S3_DVI4   ,      0  },     
         { S3_HDMI1  ,      0  },    
         { S3_HDMI2  ,      0  },  
         { S3_HDMI4  ,      0  },    
         { S3_TV2    ,      0  },      
         { S3_LCD    ,  S3_CRT },                  
         { S3_LCD    ,  S3_LCD2},
         { S3_DVI    ,  S3_CRT },                  
         { S3_DVI    ,  S3_DVI2},
         { S3_TV     ,  S3_CRT }, 
         { S3_HDTV   ,  S3_CRT },                  
         { S3_DVI2   ,  S3_CRT },
         { S3_CRT2   ,  S3_CRT },
         { S3_LCD2   ,  S3_CRT },
         { S3_HDMI   ,  S3_CRT },
         { S3_HDMI2  ,  S3_CRT },
         { S3_HDMI4  ,  S3_CRT },
         { S3_DP     ,  S3_CRT },
         { S3_DP2    ,  S3_CRT },
         { S3_TV2    ,  S3_CRT } };

//-----------------------------------------------------------------
// cbIsDeviceCombinationValid
//      This function is used to test whether device combination on one IGA
//  is valid, we just check the device IGA rule table.
//   IN :
//       device
//   OUT : 
//      function status TRUE or FALSE 
//-----------------------------------------------------------------
BOOL cbIsDeviceCombinationValid(IN DWORD device)
{
    ULONG i;
    // test device configuration
    // search in in device combination array
    // if found  return success
    for (i = 0; i < (sizeof(IGADeviceRuleTbl)/sizeof(OneIGADeviceCombination)); i++)
    {
       if (device == (IGADeviceRuleTbl[i].primary | IGADeviceRuleTbl[i].secondary))
       {
           return TRUE;
       }
    }

    return FALSE;
}

//-----------------------------------------------------------------
// cbGetPrimaryDevice
//      This function Gets primary device bit by searching IGADeviceRuleTbl
//  table
//   IN OUT:
//       device : device combination to find primary device
//   OUT : 
//       primary device bit (0 if no device combination supported)
//-----------------------------------------------------------------
DWORD cbGetPrimaryDevice(IN DWORD device)
{
    ULONG i;

    // test device configuration
    // search in in device combination array
    // if found  return success
    for (i = 0; i < (sizeof(IGADeviceRuleTbl)/sizeof(OneIGADeviceCombination)); i++)
    {
        if (device == (IGADeviceRuleTbl[i].primary | IGADeviceRuleTbl[i].secondary))
        {
             return IGADeviceRuleTbl[i].primary;
        }
    }

    return 0;
}
 


//-----------------------------------------------------------------
// cbTranslateWordDefineToS3Define
//      This function translate word define device to s3 define device for 324.
//   IN:
//       pDevice : device before translated
//   OUT : 
//       pDevice : device after translated
//-----------------------------------------------------------------
BOOL cbTranslateWordDefineToS3Define(PCBIOS_EXTENSION pcbe, 
                                     IN OUT DWORD *pDevice)
{
    DWORD dispDev;
    if (!pDevice)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    dispDev = *pDevice;
    
    if ( (pcbe->pVCPInfo->version < VCP1_5) ||
        !(pcbe->ChipCaps.S3_device_define_for_324) )
    {
        return FALSE;
    }
    if ( dispDev & WORD_LCD2 )
    {
        *pDevice &= ~WORD_LCD2;
        *pDevice |= S3_LCD2;
    }
    if ( dispDev & WORD_HDTV )
    {
        *pDevice &= ~WORD_HDTV;
        *pDevice |= S3_HDTV;
    }
    if ( dispDev & WORD_CRT2 )
    {
        *pDevice &= ~WORD_CRT2;
        *pDevice |= S3_CRT2;
    }
    return TRUE;
}

//-----------------------------------------------------------------
// cbTranslateS3DefineToWordDefine
//      This function translate s3 define device to word define device for 324.
//   IN:
//       pDevice:  device before translated
//   OUT : 
//       pDevice:  device after translated
//-----------------------------------------------------------------
BOOL cbTranslateS3DefineToWordDefine(PCBIOS_EXTENSION pcbe, 
                                     IN OUT DWORD *pDevice)
{
    DWORD dispDev;
    if (!pDevice)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    dispDev = *pDevice;
    
    if ( (pcbe->pVCPInfo->version < VCP1_5) ||
        !(pcbe->ChipCaps.S3_device_define_for_324) )
    {
        return FALSE;
    }
    if ( dispDev & S3_LCD2 )
    {
        *pDevice &= ~S3_LCD2;
        *pDevice |= WORD_LCD2;
    }
    if ( dispDev & S3_HDTV )
    {
        *pDevice &= ~S3_HDTV;
        *pDevice |= WORD_HDTV;
    }
    if ( dispDev & S3_CRT2 )
    {
        *pDevice &= ~S3_CRT2;
        *pDevice |= WORD_CRT2;
    }
    return TRUE;
}

//--------------------------------------------------------------------------
// cbGetDeviceDDCStatus
//      This function checks device associated DDC connection status. Now we 
//  support DDC2B protocal. so according to DDC2B spec we need to query 0xA0, 
//  0xA2, 0xA6 address
//  
//  IN :
//      Device : device bit
//  OUT :
//      function status
//--------------------------------------------------------------------------
BOOL cbGetDeviceDDCStatus (
    PCBIOS_EXTENSION pcbe, 
    IN DWORD Device)
{
    I2C_CONTROL_UMA i2c;
    ULONG i;

    i2c.Flags = 0;
    if (!cbGetDeviceDDCPort(pcbe, &i2c, Device))
    {
        return FALSE;
    }

    // DDC2B basic capiblity 

    // read EDID1.X I2C subAddr should be 0xA0
    // EDID1.X takes the first priority since our CBIOS can only
    // pareser EDID 1.X datastructure
    if(I2C_SetDDC2_INV(pcbe, &i2c) == FALSE)
        return FALSE;
    
    for (i = 0; i < DDCMAXTRIES; i++)
    {
        // We should start or restart the I2C bus before a data write/read operation. 
        I2C_StartService_INV(pcbe, &i2c);
     
        I2C_ByteWrite_INV(pcbe, &i2c, 0xA0); //Send Device Address + write
        if(I2C_AckRead_INV(pcbe, &i2c) == TRUE)
        {
            I2C_StopService_INV(pcbe, &i2c);
            return TRUE;
        }
    }
    
    I2C_StopService_INV(pcbe, &i2c);
    return FALSE;
}    

//---------------------------------------------------------------------------
//  cbDIPortHPDIntProcess
//      This function handle the interrupt for each Digital port
//    IN 
//      PDIPort  :   Pointer of target Digital Port info
//    OUT
//      NONE
//    RETURN
//      BOOL     : Function status
//---------------------------------------------------------------------------
BOOL cbDIPortHPDIntProcess(PCBIOS_EXTENSION pcbe, IN PDigitalPortInfo PDIPort)
{
    BOOL status = FALSE, bIsIRQ = FALSE;
    I2C_CONTROL_UMA i2c;

    i2c.Flags = 0;
    if (!PDIPort)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    PDIPort->bHPDInterrpted  = TRUE;
    PDIPort->bIsEDIDUpdated = FALSE;
    // aid for AD9389 with HDMI || DVI || DVI2 when HPD
    // AD9389 has its own HPD signal and usually not sync with our TMDS interrupt.
    // So each time we detect TMDS interrupt occurs, we MUST wait for AD9389's HPD siganl to
    // avoid many sense/power on problems caused by non-sync interrupt.
    switch(PDIPort->PortInfo.TXType)
    {
    case AD9389B:
        if(!pcbe->TurnOnAD9389ing)
        {
            BYTE i = 0;
            i2c.I2cPort = PDIPort->PortInfo.I2CPort;
            i2c.SlaveAddr = PDIPort->PortInfo.I2CSubAddr;

            i2c.RegIndex = 0x41;
            i2c.IndexData = 0x50;
            I2C_Write_Byte_INV(pcbe, &i2c);

            // delay 1s for Dell U2410 monitor hot-unplug connected issue.
            for (i=0; i<10; i++)
                cbDelayMicroSeconds(100000);

            i2c.RegIndex = 0x41;
            i2c.IndexData = 0x10;
            I2C_Write_Byte_INV(pcbe, &i2c);
        }
        //cbDelayMicroSeconds(100000);

        break;

    case INTERNAL_DP:
        if((ReadMMIOUlong(CB_MMIO_OFFSET(0xC730)) & 0xC0000000) != 0xC0000000)
        {
            if(pcbe->DPPortLastConnectStatus == FALSE && (ReadMMIOUlong(CB_MMIO_OFFSET(0xC730)) & 0xC0000000) == 0x40000000)
            {
                pcbe->DPPortLastConnectStatus = TRUE;
            }
            if((ReadMMIOUlong(CB_MMIO_OFFSET(0xC730)) & 0xC0000000) == 0x80000000)
            {
                i2c.SlaveAddr = 0xA0;
                i2c.IndexData = 0x00;
                i2c.Flags = 0;
                if(!cbHDMII2CReadByte(pcbe, &i2c))
                    pcbe->DPPortLastConnectStatus = FALSE;
            }
        }
        if((ReadMMIOUlong(CB_MMIO_OFFSET(0xC730)) & 0xC0000000) == 0xC0000000)
            bIsIRQ = TRUE;
        
        break;
        
    default:
        break;
    }

    if(bIsIRQ)
    {
        if(PDIPort->PortInfo.TXType== INTERNAL_DP)
            cbDPIRQHandler(pcbe, DP1);
        if(PDIPort->PortInfo.TXType== INTERNAL_DP2)
            cbDPIRQHandler(pcbe, DP2);
    }
        
    return status;
}

//---------------------------------------------------------------------------
//  cbGetUnsupportedDevCombBuf
//      This function fill unsupport device combination to given buffer
//    and return buffer size for saving all unsupport device combination
//    IN 
//      bufSize  :   pDevBuf size in BYTE
//    OUT
//      pDevBuf  :   buf to fill unsupport device combinations
//      pBufSize :   buffer size for saving all unsupportdevice combination
//    RETURN
//      VOID
//---------------------------------------------------------------------------
static CONST DWORD UNSUPPORT_DEVCOMB[][2] = {
    {S3_TV,     S3_HDTV},
    {S3_CRT2,   S3_TV },
    {S3_CRT2,   S3_HDTV},
    {S3_DVI,    S3_HDMI},
    {S3_LCD,    S3_DVI2},
    {S3_LCD2,   S3_DVI},
    {S3_LCD2,   S3_DVI2},
    {S3_DVI,    S3_CRT2},
	{S3_DVI2,   S3_CRT2}
};

VOID cbGetUnsupportedDevCombBuf(
    PCBIOS_EXTENSION pcbe,
    OUT DWORD *pDevBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize)
{
    DI_TYPE DIType1 = None, DIType2 = None;
    BYTE i, DevNum = 0;

    if (NULL == pDevBuf)
    {
        // set buf size = 0 when buf is NULL for later logic
        bufSize = 0;
    }

    for(i=0; i<sizeofarray(UNSUPPORT_DEVCOMB); i++)
    {
        // if supported these device cmobination both ?
        if (pcbe->SupportDevices & UNSUPPORT_DEVCOMB[i][0] &&
            pcbe->SupportDevices & UNSUPPORT_DEVCOMB[i][1])
        {
            PDigitalPortInfo pDIportinfo;
            if (cbGetDIPortInfo(pcbe, &pDIportinfo, UNSUPPORT_DEVCOMB[i][0]))
            {
                //Get DI type of device1
                DIType1 = pDIportinfo->DIType;
            }
            if (cbGetDIPortInfo(pcbe, &pDIportinfo, UNSUPPORT_DEVCOMB[i][1]))
            {
                //Get DI type of device2
                DIType2 = pDIportinfo->DIType;
            }
            if (DIType1 == DIType2)
            {
                //use same DI port, then can not light on at same time
                if ( (DevNum+1) * sizeof(UNSUPPORT_DEVCOMB[0][0]) <= bufSize)
                {
                    // if buf size enough, fill in
                    *pDevBuf = UNSUPPORT_DEVCOMB[i][0] + UNSUPPORT_DEVCOMB[i][1];
                    pDevBuf++;
                }
                DevNum++;
            }
        }
    }

    if (pcbe->pVCPInfo !=NULL)
    {
        if (pcbe->pVCPInfo->version >= VCP1_6 && !(pcbe->pVCPInfo->miscConfigure3 & LCD_HDMI_DUOVIEW_SUPPORT))
        {
            // Disable LCD1+HDMI or LCD2+HDMI duoview support
            if(pcbe->SupportDevices & (S3_LCD+S3_HDMI))
            {
                if ( (DevNum+1) * sizeof(UNSUPPORT_DEVCOMB[0][0]) <= bufSize)
                {
                    // if buf size enough, fill in
                    *pDevBuf = S3_LCD + S3_HDMI;
                    pDevBuf++;
                }
                DevNum++;
            }

            if (pcbe->SupportDevices & (S3_LCD2+S3_HDMI))
            {
                if ( (DevNum+1) * sizeof(UNSUPPORT_DEVCOMB[0][0]) <= bufSize)
                {
                    // if buf size enough, fill in
                    *pDevBuf = S3_LCD2 + S3_HDMI;
                    pDevBuf++;
                }
                DevNum++;
            }
        }
    }

    if (NULL != pBufSize)
    {
        *pBufSize = DevNum * sizeof(UNSUPPORT_DEVCOMB[0][0]);
    }
}

//---------------------------------------------------------------------------
//  cbGetHotKeySwitchDevCombBuf
//      This function fill hotkey device combination to given buffer
//    and return buffer size for saving all device combination
//    IN 
//      bufSize  :   pDevBuf size in BYTE
//    OUT
//      pDevBuf  :   buf to fill hotkey device combinations
//      pBufSize :   buffer size for saving all device combination
//    RETURN
//      VOID
//---------------------------------------------------------------------------
static CONST DWORD DEFAULT_SEQ[] = {S3_LCD,S3_CRT,S3_LCD+S3_CRT};

VOID cbGetHotKeySwitchDevCombBuf(
    IN PCBIOS_EXTENSION pcbe,
    OUT DWORD *pDevBuf,
    IN DWORD bufSize,
    OUT DWORD *pBufSize)
{
    BYTE DevNum = 0;

    if (NULL == pDevBuf)
    {
        // not need fill buffer, set buf size = 0 for later logic
        bufSize = 0;
    }

    if (pcbe->pVCPInfo != NULL)
    {
        if(pcbe->pVCPInfo->version >= VCP1_5
            && MORE_THAN_1BIT(pcbe->SupportDevices)
            && 0 != pcbe->pVCPInfo->HotKey_Switch_SequenceTbl)
        {    	
            DWORD *pHotKey_Dev = (DWORD *)(pcbe->RomData + pcbe->pVCPInfo->HotKey_Switch_SequenceTbl);
            while(*pHotKey_Dev != 0xFFFFFFFF)
            {
                // filter switch device combination, with supported devices
                DWORD dev = *pHotKey_Dev & pcbe->SupportDevices;
                if (0 != dev)
                {
                    // device sequence not zero, then filter to two devices at most
                    BYTE BitNumbers = cbGetBitNumbers(pcbe, dev);
                    for( ; BitNumbers>2; BitNumbers--)
                    {
                        dev = cbFilterOneDevice(pcbe, dev);
                    }

                    if ( ((DevNum+1) * sizeof(DWORD)) <= bufSize)
                    {
                        // if enough buf, fill in
                        *pDevBuf = dev;
                        pDevBuf++;
                    }
                    DevNum++;
                }
                pHotKey_Dev++;
            }
        }    
    }

    // if can't get VBIOS hotkey dev, use default
    if (0 == DevNum)
    {
        BYTE i;
        for(i=0; i<sizeofarray(DEFAULT_SEQ); i++)
        {
            if(DEFAULT_SEQ[i] & pcbe->SupportDevices)
            {
                if ( ((DevNum+1) * sizeof(DWORD)) <= bufSize)
                {
                    // if enough buf, fill in
                    *pDevBuf = DEFAULT_SEQ[i] & pcbe->SupportDevices;
                    pDevBuf++;
                }
                DevNum++;
            }
        }
    }

    if (NULL != pBufSize)
    {
        // return real buf size
        *pBufSize = DevNum * sizeof(DWORD);
    }
}
