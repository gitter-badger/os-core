/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _UMA_VCP_H_
#define _UMA_VCP_H_

//***************************************************************************
//
//  Module Name:
//  VCP (Video Configuration Parameter) area definition
//  Version: 1.4
//  UMA use only
//
//  This area contain in VBIOS image
//  Provide HW related configurations to CBIOS
//  All info in this area are fixed after VBIOS compile, not dynamic
//
//  This area just following PMID check sum BYTE
//  Use "PMID" as its check tag also
//
//  Current VCP size: A4h (164) Bytes (DWORD align)
//
//***************************************************************************
#define VCP_VERSION     0x16
#define VCP1_1          0x11
#define VCP1_2          0x12
#define VCP1_3          0x13
#define VCP1_4          0x14
#define VCP1_5          0x15
#define VCP1_6          0x16
#define VCP1_7          0x17
#define VCP1_8          0x18
#if !defined (__linux__)
#define VCP1_9          0x19
#endif

#define GET_VCPVERSION(VCPVERSION)    (((VCPVERSION) & 0xF0) >> 4)
#define GET_VCPREVISION(VCPVERSION)   ((VCPVERSION) & 0x0F)

// Digital Interface Port Configuration Info
// Size: 10h (16) Bytes
typedef struct _DIPortInfo
{
    DWORD   device;

    BYTE    TXType;
    BYTE    I2CPort;
    BYTE    I2CSubAddr;
    BYTE    DDCPort;
    BYTE    DPASetting[6];
    BYTE    DIPORTMISC;
    
    BYTE    _reserved;
} DIPortInfo, *PDIPortInfo;

// now supports 5 digital port info in VCP
// we assume CRT aslo connect to a pseudo DI port
#define DigitalPortNUM  (5 + 1 + 2)

// now support 32 type of device
#define DeviceNumber   32

//***************************************************************************
// below structure come from VBIOS
// they must sync with VBIOS structure
//***************************************************************************
#pragma pack(push, 1)

// Video Configuration Parameter
typedef struct _VCPInfo
{
// Mandatory informationg for all VCP revisions
    BYTE    VCPCheckSum;    // if valid VCP, this check sum must right
    BYTE    version;        // bit[7-4] = main version, [3-0] = sub version
    WORD    length;

    DWORD   BIOSSupportDev;

//***************************************************************************
//
//  Offset: 08h
//  digital interface port
//
//***************************************************************************
    DIPortInfo  DI_DVP0;
    DIPortInfo  DI_DVP1;
    DIPortInfo  DI_DFPH;
    DIPortInfo  DI_DFPL;
    DIPortInfo  DI_DFP;
    
//***************************************************************************
//
//  Offset: 58h
//  Memory related infos
//
//***************************************************************************
    BYTE    drvReserveMemoSize; // size of memory need driver reserve
                                // MB, for integrated TV, down scaler, etc.
    BYTE    _reserve0[3];       // for additional memory define, DWORD align

//***************************************************************************
//
//  Offset: 5Ch
//  ecx = vBIOS Misc Information
//      = Bit[31~20]  Reserved
//      = Bit[19]    report a fake 12x10 EDID and don't care panel size		
//      = Bit[18]    LCD shrink should enable
//      = Bit[17]    NEW vBIOS DuoView Caps Interface 
//      = Bit[16]    Block switch on 3D application 
//      = Bit[15]    Block switch on Overlay 
//      = Bit[14]    Block switch on specific platform Full-Screen Mode
//      = Bit[13]    Horizontal/Vertical Scalling Factor control independently  
//      = Bit[12]    report a fake 10x7 EDID and don't care panel size		
//      = Bit[11]    independent IGA2's LUT control support			
//      = Bit[10]    Dual channel support
//      = Bit[9]     LGA2's LUT support 6/8 bits
//      = Bit[8]     Integrated TV support
//      = Bit[7]     Enable Prefetch mode. for k8
//      = Bit[6]     TV always on IGA1
//      = Bit[5]     Capability to report I2C port of TV/DVI
//      = Bit[4]     LCD on IGA2 ONLY
//      = Bit[3]     FastResume support
//      = Bit[2]     Validate modes support control
//         0: Generic case
//         1: Skip ValidateSupportMode control
//            (mode control by vBIOS; driver don't care)
//      = Bit[1]     Device definition length
//         0: BYTE
//         1: WORD
//      = Bit[0]     Device definition
//         0: Old definition
//         1:  S3 definition
//
//***************************************************************************
    DWORD   miscConfigure;     // 4f14 0200 ecx return flags
                               // add busMasterSupport (originally in 4f14 0000)
    DWORD   miscConfigure2;   // for additional Configure define, DWORD align

//***************************************************************************
//
//  Offset: 64h
//  esi = NEW vBIOS DuoView Caps Interface (if ecx[17]=1)
//      = Bit[24]    TV+TV2   DuoView. 1=Support, 0=Not Support
//      = Bit[25]    LCD+DVI  DuoView. 1=Support, 0=Not Support
//      = Bit[26]    LCD+LCD2 DuoView. 1=Support, 0=Not Support
//      = Bit[27]    CRT+HDTV DuoView. 1=Support, 0=Not Support
//      = Bit[28]    CRT+TV   DuoView. 1=Support, 0=Not Support
//      = Bit[29]    CRT+DVI  DuoView. 1=Support, 0=Not Support
//      = Bit[30]    CRT+LCD  DuoView. 1=Support, 0=Not Support
//      = Bit[31]    DVI+DVI2 DuoView. 1=Support, 0=Not Support
//
//***************************************************************************
    DWORD   duoViewCaps;    // 4f14 0200 esi return flags

    BYTE   _reserve2[4];    // for additional Configure define, DWORD align

//***************************************************************************
//
//  Offset: 6Ch
//  Table offset pointer in VBIOS image
//
//***************************************************************************
    WORD    xRInitTbl;
    WORD    dualViewRuleTbl;

    WORD    VESAVPITPtr;        // CRTC timing table
    WORD    LCDInfoHeader;      // LCD timing table
    WORD    DVIResolution;      // DVI resolution index table (necessary?)
    WORD    TVModeTbl;          // TV timing table

    // If TX is auto detection type, use below table to search
    WORD    TX_LCD_DVI2_TBL;
    WORD    TX_DVI_LCD2_TBL;
    WORD    TV_TBL;

    WORD    modesEnabledControl;
    WORD    DPA_ClockRange;     // clock range1, 2, 3, 4, 5 follows

    WORD    LCD_SW_POWER_ON;
    WORD    LCD_SW_POWER_OFF;

// Mandatory informationg for VCP1.1 and above
    WORD    ECLKTbl;            // default engine clock
    WORD    FIFOSetting;        // FIFO specific Value Setting

    WORD    TVModeFitTbl;       // TV fit scan timing table
    WORD    TVModeOverTbl;      // TV over scan timing table
    WORD    HDTVFuncTbl;        // HDTV function table
    WORD    HDTVEntryTbl;       // HDTV timing entry

    WORD    xRBitsInitTbl;      // reg bit init table
    WORD    csVidParams;        // std mode timing
    WORD    FPconfigTbl;        // mainly LCD Scaling Parameter
    WORD    TX_HDMI_TBL;
    
//************** Mandatory informationg for VCP1.4 and above ***************
    WORD    DVP0DrvSelectTbl;   // DVP0 driving select table
    WORD    DVP1DrvSelectTbl;   // DVP1 driving select table
    WORD    VT1636DPATbl;       // 1636 DPA setting table
    DWORD   Always_On_Device;   // always on device

//************** Mandatory informationg for VCP1.5 and above ***************
    WORD    HotKey_Switch_SequenceTbl;   // Hotkey switch sequence table
    
    WORD    InTVIndexMaskTbl;            // Internal TV index mask table
    WORD    InTVinitValueTbl;            // Internal TV initial table
    WORD    csInTVMaskTbl;               // Internal TV encoder regs mask table
    WORD    InTVModeTbl;                 // Internal TV timing table
    WORD    InHDTV720pBPPatchTbl;        // Internal HDTV 720p bypass specific table
    WORD    InHDTV1080iBPPatchTbl;       // Internal HDTV 1080i bypass specific table
    
    BYTE    Orig_SSC_ClockOut_Reg;       // orginal SSC clock output register SRXX
    BYTE    FIFO_SSC_ClockOut_Reg;       // FIFO SSC clock output register SRXX
//************** Mandatory informationg for VCP1.6 and above ***************
    DWORD   _reserve3[4];                // reserved 4 dword
    DWORD   miscConfigure3;              // for additional Configure define, DWORD align
    DWORD   _reserve4;                   // reserve, for additional Configure define, DWORD align
    BYTE    InternalSSCModulation;       // Internal SSC Modulation Selection, modified by BIOSWE
    BYTE    CRT_PORT_MISC;               // for CRT misc info e.g hot plug info.
    WORD    AD9389_HDMI_INIT_TBL;        // HDMI TX init table
    WORD    RBKVESAVPITStart;            // reduce blank table
    WORD    SIL9022_HDMI_INIT_TBL;       // HDMI TX init table
    WORD    ITE6610_HDMI_INIT_TBL;       // HDMI TX init table
    WORD    VDCLKTbl;                    // default Video IP Clock

//***************************************************************************
//
//  digital interface port 2
//
//***************************************************************************
    DIPortInfo  DI_DPPHY;
    DIPortInfo  DI_DPMUX;
    WORD    EDPInfoHeader;               // EDP info table
#if !defined (__linux__)
    WORD 	Chip_SubSysVenderID;	     // Chip Subsystem Vender ID
    WORD	Chip_SubSysemID;             // Chip Subsystem ID
#endif

}VCPInfo, *PVCPInfo;

// PMID
typedef struct _PMID_Info
{
    BYTE        Signature[4];
    WORD        EntryPoint;
    WORD        PMInitialize;
    WORD        BIOSDataSel;
    WORD        A0000Sel;
    WORD        B0000Sel;
    WORD        B8000Sel;
    WORD        CodeSegSel;
    BYTE        InProtectMode;
    BYTE        CheckSum;
}PMID_Info, *PPMID_Info;

typedef struct _VESA_INFO
{
    WORD    HSize;
    WORD    VSize;
    WORD    ModeNo8BPP;
    WORD    ModeNo16BPP;
    WORD    ModeNo32BPP;
    BYTE    RRateCount;
}VESA_INFO, *PVESA_INFO;

// VESA VPIT Attribute
#define ATT_I            BIT0            // 1= Interlace refresh rate
#define ATT_PHS          BIT1            // 1= positive H sync
#define ATT_NHS          0
#define ATT_PVS          BIT2            // 1= positive V sync
#define ATT_NVS          0
#define ATT_HB           BIT3            // 1= 1-character-wide H border
#define ATT_VB           BIT4            // 1= 8-line-wide V border
#define ATT_RB           BIT5            // 1= Reduced Blanking
#define ATT_DISABLE      BIT31           // 1= Refresh rate disabled

typedef struct _VESA_VPIT
{
    DWORD   PLL;
    BYTE    RRate;
    DWORD   Attribute;
    WORD    HTotal;
    WORD    HSyncSt;
    WORD    HSyncEd;
    WORD    VTotal;
    WORD    VSyncSt;
    WORD    VSyncEd;
}VESA_VPIT, *PVESA_VPIT;

typedef struct _VESA_INFO_CBIOS // for CBIOS VESA timing information
{
    VESA_INFO  vesainfo;        // vesa info structure 
    PVESA_VPIT pvesavpit;       // vesa vpit table pointer
}VESA_INFO_CBIOS, *PVESA_INFO_CBIOS;

typedef struct _CEA_INFO_CBIOS // for CBIOS CEA timing information
{
    VESA_INFO  ceainfo;        // cea info structure 
    PVESA_VPIT  pceavpit;       // cea vpit table pointer
}CEA_INFO_CBIOS, *PCEA_INFO_CBIOS;


// LCD VBIOS flat panel header info
typedef struct _PanelTblData
{
        WORD H_Size;    // Horizontal size
        WORD V_Size;    // Vertical Size
        BYTE mode4bpp;  // 4bpp mode number
        BYTE mode8bpp;  // 8bpp mode number
        BYTE mode16bpp; // 16bpp mode number
        BYTE mode32bpp; // 32bpp mode number
} PanelTblData, *PPanelTblData;

// Panel PWM control
typedef struct _LCDPWMCONTROL
{
        BYTE PWMNormalDDutyLevel;
        BYTE PWMInverseDDutyLevel;
        BYTE PWMSourceClockDivider;
        BYTE PWMSourceClockSelection;
}LCDPWMCONTROL, *PLCDPWMCONTROL;

// fpControl caps
enum
{
    EN_DITHERING    = 0x01,
    DUAL_CHANNEL    = 0x04,
    PWM_DUTY_POLARITY  = 0x08, // 0: normal, 1: inverse
    COLOR_DATA_MSB  = 0x10,
    NEG_H_POLARITY  = 0x20,
    NEG_V_POLARITY  = 0x40,
};

// LCD VBIOS flat panel header info
typedef struct _FPHeaderData
{
    WORD TD0;
    WORD TD1;
    WORD TD2;
    WORD TD3;
    BYTE fpControl;
    WORD fpPanelTblData;
    WORD fpEntryPoint;
} FPHeaderData, *PFPHeaderData;

// LCD 1+2 VBIOS flat panel header info
typedef struct _FPHeaderData12
{
    BYTE fpSize;
    WORD TD0;
    WORD TD1;
    WORD TD2;
    WORD TD3;
    BYTE fpControl;
} FPHeaderData12, *PFPHeaderData12;

// LCD VBIOS timing table
typedef struct _LCDInitTbl
{
    DWORD   IGA2_PLL        ; // IGA2 PLL for 24-bits mode
    DWORD   IGA1_PLL        ; // IGA1 PLL for 24-bits mode
    WORD    H_Total         ; // SecH_Total +1
    WORD    H_DisEnd        ; // SecH_DIS_END +1
    WORD    H_BnkSt         ; // SecH_BNK_ST +1
    WORD    H_BnkEnd        ; // SecH_BNK_END +1
    WORD    H_SyncSt        ; // SecH_SYNC_ST
    WORD    H_SyncEnd       ; // SecH_SYNC_END
    WORD    V_Total         ; // SecV_Total +1
    WORD    V_DisEnd        ; // SecV_DIS_END +1
    WORD    V_BnkSt         ; // SecV_BNK_ST +1
    WORD    V_BnkEnd        ; // SecV_BNK_END +1
    WORD    V_SyncSt        ; // SecV_SYNC_ST
    WORD    V_SyncEnd       ; // SecV_SYNC_END
} LCDInitTbl, *PLCDInitTbl;

//DWORD   DCLK_65M                ; IGA2 clk
//DWORD   DCLK_65M                ; IGA1 clk
//BYTE    11111111b,11111111b,11111111b,11111111b,11111110b
//;=============================================================================================
//;+++++++ 50 | 51 | 52 | 53 | 54 | 55 | 56 | 57 - 58 | 59 | 5A | 5B | 5C | 5D | 5E | 5F +++++++
//;=============================================================================================
//;+++++++ 65 | 66 | 67 | 6D | 6E | 6F | 70 | 71 - 72 | 73 | 74 | 75 | 76 | 77 | 78 | 79 +++++++
//;=============================================================================================
//;+++++++ 9F | A1 | A2 | A5 | A6 | A7 | A8 ++++++++++++++++++++++++++++++++++++++++++++++++++++
//;=============================================================================================
// LCD 1+2 VBIOS timing table
typedef struct _LCDInitTbl12
{
    DWORD IGA2_PLL, IGA1_PLL;
    BYTE mask0, mask1, mask2, mask3, mask4;
    BYTE CR50, CR51, CR52, CR53, CR54, CR55, CR56, CR57;
    BYTE CR58, CR59, CR5A, CR5B, CR5C, CR5D, CR5E, CR5F;
    BYTE CR65, CR66, CR67, CR6D, CR6E, CR6F, CR70, CR71;
    BYTE CR72, CR73, CR74, CR75, CR76, CR77, CR78, CR79;
    BYTE CR9F, CRA1, CRA2, CRA5, CRA6, CRA7, CRA8;
} LCDInitTbl12, *PLCDInitTbl12;

// LCD 1+2 VBIOS offset table
typedef struct _FPOffsetData
{
    BYTE fpSize;
    WORD fpEntryPoint;
    WORD fpSupportMode;
    BYTE fpNumOfEntry;
} FPOffsetData, *PFPOffsetData;

// VBIOS LCD & DVI TX I2C info
typedef struct _TXTABLEDATA{
    BYTE TXDI;
    BYTE TXSLVADDR;
    BYTE TXDEVID;
    BYTE TXDIDOFST;
    BYTE TXI2CPORT;
}TXTABLEDATA, *PTXTABLEDATA;

// VBIOS TV I2C table
typedef struct _TVI2CTBLDATA{
        BYTE TVI2CPORT;
        BYTE TVSlaveAddr;
}TVI2CTBLDATA, *PTVI2CTBLDATA;

// TV VBIOS table
typedef struct _TVTBLDATA
{
    BYTE tvModeIndex;
    WORD tvNTSCOffset;
    WORD tvPALOffset;
    WORD tvNTSCTimingOffset;
    WORD tvPALTimingOffset;
}TVTBLDATA, *PTVTBLDATA;

typedef struct _TV_FUNCTION_VCP {
    BYTE    tvFunIndex;                          // TV function index
    WORD    tvFunOffset;                        // TV function table entry
} TV_FUNCTION_VCP, *PTV_FUNCTION_VCP;

typedef struct _HDTVENTRYTBL
{
    WORD HDTV720P;
    WORD HDTV1080I;
    WORD HDTV1080P;
    WORD HDTV720PTimingOffset;
    WORD HDTV1080ITimingOffset;
}HDTVENTRYTBL, *PHDTVENTRYTBL;

typedef struct _HDTVPatchTbl
{
    BYTE HDTVPatchIndex;
    WORD HDTVPatchOffset;
}HDTVPatchTbl, *PHDTVPatchTbl;

typedef struct _FIFOPatchSetting
{
    BYTE    VGA_IGA1_Depth;
    BYTE    VGA_IGA1_Normal_TH;
    BYTE    VGA_IGA1_Fetch_CNT;
    BYTE    VGA_IGA1_Expire_N;

    BYTE    TEXT_IGA1_Depth;
    BYTE    TEXT_IGA1_Normal_TH;
    BYTE    TEXT_IGA1_Urgent_TH;
    BYTE    TEXT_IGA1_Fetch_CNT;
    BYTE    TEXT_IGA1_Expire_N;

    BYTE    ExtVGA_IGA1_Expire_N;

    BYTE    ExtGFX_IGA1_Depth;
    BYTE    ExtGFX_IGA1_Normal_TH;
    BYTE    ExtGFX_IGA1_Urgent_TH;
    BYTE    ExtGFX_IGA1_Expire_N;

    BYTE    ExtGFX_IGA2_Depth;
    BYTE    ExtGFX_IGA2_Normal_TH;
    BYTE    ExtGFX_IGA2_Urgent_TH;
    BYTE    ExtGFX_IGA2_Expire_N;
} FIFOPatchSetting, *PFIFOPatchSetting;

typedef struct _VBBitINITTBL
{
    BYTE    group;
    BYTE    index;
    BYTE    mask;
    BYTE    data;
} VBBitINITTBL, *PVBBitINITTBL;

typedef struct _VBINITTBL
{
    BYTE    group;
    BYTE    index;
    BYTE    data;
}VBINITTBL, *PVBINITTBL;

typedef struct _VBIOSAD9389INITTBL
{
    BYTE    DevAddr;
    BYTE    Index;
    BYTE    Data;
}VBIOSAD9389INITTBL,*PVBIOSAD9389INITTBL;

typedef struct _EDPPOWERDELAYDATA{
    WORD TD3;
    WORD TD8;
    WORD TD12;
}EDPPOWERDELAYDATA, *PEDPPOWERDELAYDATA;

//----------------------------------------------------------------------
// pwm contrl table offset based on fpEntryPoint in VBIOS by byte
//----------------------------------------------------------------------
#define     OFFSET_PANEL_PWM_CONTROL_TABLE      8

//-----------------------------------------------------------------------
// Define VCP misc configure bits info(including misc 1/2/3 etc)
//-----------------------------------------------------------------------
#define FORCE_CRT2_LIGHTON          BIT0
#define CRT2NOPANNING               BIT1
#define IGA2_SEQ_CONTROL_SUPPORT    BIT2
#define HDMI_SHRINK_ENABLE          BIT3
#define INVERSE_LVDS_POWER          BIT4
#define TV_SHRINK_USE_NATIVE_MODE   BIT5
#define VT3353_Patch_TTL_LCD        BIT6
#define INTERNAL_TV_SUPPORT         BIT8
// Considering old vbios's MISC2[12] always equals 0, So if old customer enable SPWG in the old way, CBIOS can not know
// To cover this we use inversed logic here, then for old vbios, we assume always SPWG first
#define SPWG_LCD_NOT_Support        BIT12
#define IGA2_SSC_ENABLE             BIT13
#define SSC_Fifo_Mode               BIT14
#define HDMI_USING_AD9389B          BIT15
#define CBIOS_PLL_Control_Enable    BIT16
#define DIPORT_HPD_INTERRUPT_SETTING_VALID BIT19
#define CRT_HPD_INTERRUPT_SETTING_VALID    BIT20
#define LCDBKLIGHT_USE_INTERPWM_BIT        BIT21
#define HDMI_USING_AD9889           BIT22
#define PLL_USE_409_FORMULA_BIT     BIT23
#define LCD_NOT_VERIFY_CHECKSUM     BIT24
#define DRVWRAPPER_USING_CILDRV_BIT BIT25
#define HDMI_DVI_NOT_VERIFY_CHECKSUM     BIT27
#define HDMI_INTERLACE_MODE_SUPPORT      BIT29

//***MISC3 bit define***//
// 410 and later chip, IGA1 has scaling too, this bit control LCD1(2)/HDMI duoview support
#define LCD_HDMI_DUOVIEW_SUPPORT    BIT1

// 409 has the special bios and board that uses PS2 BLT and VDD by GPIO23 for TTL when support IL and TTL
#define SW_PS2_BLT_VDD_BY_GPIO23    BIT2

// avoid to IGA1 and IGA2 have the same timing and show the ghost image on CRT
#define AVOID_IGA1_IGA2_SAME_CLK    BIT3

// support DVI-I cable for CRT and DVI share connector
#define CRT_DVI_SHARE_CONNECTOR     BIT4

// support DVI-I cable for CRT and DVI2 share connector
#define CRT_DVI2_SHARE_CONNECTOR    BIT5

// 410 and later chip, new definition of scratch pad for DIPort TX of LCD/DVI2 and DVI/LCD2
#define NEW_DIPOPRT_TX_SCRATCHPAD   BIT6

// support software control power sequence of EDP by PS1
#define SW_PS_CTRL_EDP_BY_PS1       BIT7

// SW control DCON with I2C by WORD
#define SW_CTRL_DCON_PANEL          BIT8

// For lcd pwm control cap
#define SUPPORT_RESTORE_PWM_CAP     BIT10

// For VBIOS control int15 write back
#define BIOS_CTL_CMOS_CALLBACK      BIT11

#define HDMI_ONLY_SUPPORT_720P      BIT15
#define RECOGNIZE_AS_EDP_CONNECT    BIT16   // for eDP panel connect

#pragma pack(pop)

#endif // _UMA_VCP_H_
