//*****************************************************************************
//  Copyright (c) 2001-2003, S3 Graphics, Inc.
//  Copyright (c) 2004-200x, S3 Graphics Co., Ltd.
//  Copyright (c) 1998-200x, VIA Technologies, Inc. All Rights Reserved.
//  All Rights Reserved.
//
//  This is UNPUBLISHED PROPRIETARY SOURCE CODE of S3 Graphics, Inc.;
//  the contents of this file may not be disclosed to third parties, copied or
//  duplicated in any form, in whole or in part, without the prior written
//  permission of S3 Graphics, Inc.
//
//  RESTRICTED RIGHTS LEGEND:
//  Use, duplication or disclosure by the Government is subject to restrictions
//  as set forth in subdivision (c)(1)(ii) of the Rights in Technical Data
//  and Computer Software clause at DFARS 252.227-7013, and/or in similar or
//  successor clauses in the FAR, DOD or NASA FAR Supplement. Unpublished -
//  rights reserved under the Copyright Laws of the United States.
//*****************************************************************************

//*****************************************************************************
//
//  Module Name: CBios_UMA_new.c
//
//  Content: CBIOS new meaningful interface.
//
//*****************************************************************************
//#include "cbios_type.h"

#include "cbios_uma.h"
#include "cbios_sub_func.h"
#include "TBL1625.h"

//****************************************************************
//   VESA mode number (16 bits)
//****************************************************************
#define MODE_640x480x8          0x101
#define MODE_640x480x16         0x111
#define MODE_640x480x32         0x112
#define MODE_800x600x8          0x103
#define MODE_800x600x16         0x114
#define MODE_800x600x32         0x115
#define MODE_800x480x8          0x22E
#define MODE_800x480x16         0x22F
#define MODE_800x480x32         0x230
#define MODE_1024x600x8         0x200
#define MODE_1024x600x16        0x201
#define MODE_1024x600x32        0x203
#define MODE_1024x768x8         0x105
#define MODE_1024x768x16        0x117
#define MODE_1024x768x32        0x118
#define MODE_720x480x8          0x171
#define MODE_720x480x16         0x173
#define MODE_720x480x32         0x175
#define MODE_720x576x8          0x17C
#define MODE_720x576x16         0x17E
#define MODE_720x576x32         0x17F
#define MODE_1280x720x8         0x125
#define MODE_1280x720x16        0x126
#define MODE_1280x720x32        0x127
#define MODE_1920x1080x8        0x166
#define MODE_1920x1080x16       0x167
#define MODE_1920x1080x32       0x168
#define MODE_848x480x8          0x15C
#define MODE_848x480x16         0x15D
#define MODE_848x480x32         0x15F

#define HueLevelNum                61

MapTVModeIndex TblMapTVModeIndex[] = 
{
        {{640, 480, MODE_640x480x8, MODE_640x480x16, MODE_640x480x32, 1}, MODE640},
            
        {{800, 600, MODE_800x600x8, MODE_800x600x16, MODE_800x600x32, 1}, MODE800},
        
        {{1024, 768, MODE_1024x768x8, MODE_1024x768x16, MODE_1024x768x32, 1}, MODE1024},
        
        {{848, 480, MODE_848x480x8, MODE_848x480x16, MODE_848x480x32, 1}, MODE848},
        
        {{720, 480, MODE_720x480x8, MODE_720x480x16, MODE_720x480x32, 1}, MODE720X480},
        
        {{720, 576, MODE_720x576x8, MODE_720x576x16, MODE_720x576x32, 1}, MODE720X576},
        
        {{1280, 720, MODE_1280x720x8, MODE_1280x720x16, MODE_1280x720x32, 1}, MODE1280X720},
        
        {{1920, 1080, MODE_1920x1080x8, MODE_1920x1080x16, MODE_1920x1080x32, 1}, HDTV1920x1080},
        
        {{800, 480, MODE_800x480x8, MODE_800x480x16, MODE_800x480x32, 1}, MODE800X480},
        
        {{1024, 600, MODE_1024x600x8, MODE_1024x600x16, MODE_1024x600x32, 1}, MODE1024X600},

        {{0xFFFF},}
};

DWORD const TVResolutionNTSC[] = 
{
     640,  480,
     800,  600,
    1024,  768,
     720,  480,
};
DWORD const TV_NTSC_RESOLUTION_NUM = sizeof(TVResolutionNTSC) / sizeof(DWORD) / 2;

DWORD const TVResolutionPAL[] = 
{
     640,  480,
     800,  600,
    1024,  768,
     720,  576,
};
DWORD const TV_PAL_RESOLUTION_NUM = sizeof(TVResolutionPAL) / sizeof(DWORD) / 2;

//---------------------------------------------------------------
// HDTVResolution720P indicates vbios timing table really support
// resolution on 720P HDTV 
//---------------------------------------------------------------
DWORD const HDTVResolution720P[] = 
{
     640,  480,     //  640 x 480
     720,  480,     //  720 x 480
     720,  576,     //  720 x 576
     800,  600,     //  800 x 600
    1024,  768,     // 1024 x 768
    1280,  720,     // 1280 x 720
};
DWORD const HDTV720P_RESOLUTION_NUM = sizeof(HDTVResolution720P) / sizeof(DWORD) / 2;


//---------------------------------------------------------------
// HDTVResolution1080I indicates vbios timing table really support
// resolution on 1080I HDTV 
//---------------------------------------------------------------
DWORD const HDTVResolution1080I[] = 
{
     640,  480,     //  640 x 480
     720,  480,     //  720 x 480
     720,  576,     //  720 x 576
     800,  600,     //  800 x 600
    1024,  768,     // 1024 x 768
    1920, 1080,     // 1920 x 1080
};
DWORD const HDTV1080I_RESOLUTION_NUM = sizeof(HDTVResolution1080I) / sizeof(DWORD) / 2;

//---------------------------------------------------------------
// HDTVSupportResolution 
//     For DTM test HDTV need more mode than Our VBIOS timing table can 
// offer. So we need to center / pan these mode on HDTV native mode 
//---------------------------------------------------------------
DWORD const HDTVSupportResolution[] =
{
     640,  480,     //  640 x 480
     720,  480,     //  720 x 480
     720,  576,     //  720 x 576
     800,  600,     //  800 x 600
    1024,  768,     // 1024 x 768
    1280,  720,     // 1280 x 720
    1920, 1080,     // 1920 x 1080
};
DWORD const HDTV_RESOLUTION_NUM = sizeof(HDTVSupportResolution) / sizeof(DWORD) / 2;

BYTE TV_LayoutToConType_BitMask[] =
{
    BIT0 ,    //CVBS
    BIT1 ,    //SVideo
    BIT2 ,    //RGB
    BIT3 ,    //YCbCr
    BIT4 ,    //SDTV-RGB
    BIT5 ,    //SDTV-YPbPr
    BIT0+BIT1,    // CVBS+SVideo
    BIT0+BIT2,    // CVBS+RGB
    BIT0+BIT3,    // CVBS+YCbCr
    //BIT0+BIT1+BIT3    // CVBS+SVideo0+YCbCr
};
#define TV_LayoutToConType_BitMask_Len (sizeof(TV_LayoutToConType_BitMask)/sizeof(BYTE))

WORD TV_StandardType_Map[] =
{
    BIT0 , //ntsc
    BIT1 , //pal
    BIT3 , //pal m
    BIT11, //pal n
    BIT12, //pal nc
    BIT8 , //pal i
    BIT5 , //pal d
    BIT2   //ntsc japan
};
#define TV_StandardType_Map_Len (sizeof(TV_StandardType_Map)/sizeof(WORD))
//---------------------------------------------------------------
//HDTVResolutionRefreshRate
//    For DTM test HDTV needs to report all interlace / progressive 
//  timing.
//--------------------------------------------------------------
HDTVResolutionRR const HDTVResolutionRefreshRate[] = 
{
     {640,  480,  60, INTERLACE   },    // 640 x 480 60I
     {720,  480,  59, PROGRESSIVE },    // 720 x 480 59P
     {720,  480,  60, PROGRESSIVE },    // 720 x 480 60P
     {720,  576,  50, PROGRESSIVE },    // 720 x 576 50P
     {720,  576,  60, PROGRESSIVE },    // 720 x 576 60P 
     {800,  600,  60, INTERLACE   },    // 800 x 600 60I
     {1024, 768,  60, INTERLACE   },    //1024 x 768 60I
     {1280, 720,  50, PROGRESSIVE },    //1280 x 720 50P
     {1280, 720,  59, PROGRESSIVE },    //1280 x 720 59P
     {1280, 720,  60, PROGRESSIVE },    //1280 x 720 60P
     {1920, 1080, 50, INTERLACE   },    //1920 x1080 50I
     {1920, 1080, 59, INTERLACE   },    //1920 x1080 59I
     {1920, 1080, 60, INTERLACE   }     //1920 x1080 60I
};

DWORD const HDTV_REFRESHRATE_NUM = sizeof(HDTVResolutionRefreshRate) / sizeof(HDTVResolutionRR);



BOOL cbGetTVI2CInfo(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c)
{
    pi2c->SlaveAddr = pcbe->TVI2CSubAddr;
    pi2c->I2cPort = pcbe->TVI2CPort;
    return TRUE;
}

UCHAR
TV_Read_Byte_UMA(
    PCBIOS_EXTENSION pcbe,
    UCHAR   subAddr
    )
{
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;

    cbGetTVI2CInfo(pcbe, &i2c);
    i2c.RegIndex = subAddr;
    if (I2C_Read_Byte_INV(pcbe, &i2c))
    {
        return (i2c.IndexData);
    }
    else
    {
        return 0;
    }
}

BOOL
TV_Write_Byte_UMA(PCBIOS_EXTENSION pcbe,
    UCHAR   subAddr,
    UCHAR   ucData
    )
{
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;

    cbGetTVI2CInfo(pcbe, &i2c);
    i2c.RegIndex = subAddr;
    i2c.IndexData = ucData;

    return (I2C_Write_Byte_INV(pcbe, &i2c));
}

UCHAR
InTV_Read_Byte_UMA(
    PCBIOS_EXTENSION pcbe,
    IN UCHAR   index
    )
{
    return ReadUchar(IN_TV_SHADOW_REG(index));
}

VOID
InTV_Write_Byte_UMA(
    PCBIOS_EXTENSION pcbe,
    IN UCHAR   index,
    IN UCHAR   data
    )
{
    WriteUchar(IN_TV_SHADOW_REG(index),data);
}

VOID
InTV_Write_Bits_UMA(
    PCBIOS_EXTENSION pcbe,
    IN UCHAR   index,
    IN UCHAR   data,
    IN UCHAR   mask
    )
{
    UCHAR val;
    val = InTV_Read_Byte_UMA(pcbe, index);
    val &= ~mask;
    val |= (data&mask);
    WriteUchar(IN_TV_SHADOW_REG(index), val);
}


//**************************************************************************
// 
// decideTVLayout - get TV connector layout which will be supported     
//   This procedure will decide TV connector layout which will be supported   
//
//      Entry: HWLayout = TV H/W Layout function
//
//      return:     = support TV outputting signals
//                  = BIT0 :   CVBS
//                    BIT1 :   SVideo1                      
//                    BIT2 :   RGB                               
//                    BIT3 :   YCbCr                             
//                    BIT4 :   SDTV_RGB                          
//                    BIT5 :   SDTV_YPbPr                        
//                    BIT6 :   CVBS+SVideo1                
//                    BIT7 :   CVBS+RGB    
//                    BIT8 :   CVBS+YCbCr  
//**************************************************************************
DWORD cbGetTVLayout(PCBIOS_EXTENSION pcbe, WORD HWLayout)
{
    WORD TVLayout = 0;
    switch (HWLayout)
    {
    case TV_LAYOUT_CVBS_SVideo:
        TVLayout = BIT0 + BIT1 + BIT6;
        break;

    case TV_LAYOUT_SVideo_SVideo:
        TVLayout = BIT1;
        break;

    case TV_LAYOUT_CVBS_RGB:
        TVLayout = BIT0 + BIT2;
        break;

    case TV_LAYOUT_CVBS_YCbCr:
        TVLayout = BIT0 + BIT3;
        break;

    case TV_LAYOUT_CVBS_SDTV_RGB:
        TVLayout = BIT0 + BIT4;
        break;

    case TV_LAYOUT_CVBS_SDTV_YPbPr:
        TVLayout = BIT0 + BIT5;
        break;

    case TV_LAYOUT_CVBS:
        TVLayout = BIT0;
        break;

    case TV_LAYOUT_SVideo:
        TVLayout = BIT1;
        break;

    case TV_LAYOUT_RGB:
        TVLayout = BIT2;
        break;

    case TV_LAYOUT_YCbCr:
        TVLayout = BIT3;
        break;

    case TV_LAYOUT_SDTV_RGB:
        TVLayout = BIT4;
        break;

    case TV_LAYOUT_SDTV_YPbPr:
        TVLayout = BIT5;
        break;

    case TV_LAYOUT_SVideo_RGB:
        TVLayout = BIT1 + BIT2;
        break;

    case TV_LAYOUT_SVideo_YCbCr:
        TVLayout = BIT1 + BIT3;
        break;

    case TV_LAYOUT_CVBS_SVideo_RGB:
        TVLayout = BIT0 + BIT1 + BIT2 + BIT6 + BIT7;
        break;

    case TV_LAYOUT_CVBS_SVideo_YCbCr:
        TVLayout = BIT0 + BIT1 + BIT3 + BIT6 + BIT8;
        break;

    case TV_LAYOUT_BIOS_DEFAULT:
    default:
        // get TV Layout
        //if (VT1626)
        //{
        //    biosArguments->Ecx = BIT0 + BIT1;
        //}
        //else
        TVLayout = BIT0 + BIT1 + BIT2 + BIT3 + BIT4 + BIT5 + BIT6;
        break;
    }

    return TVLayout;
}
//**************************************************************************
// 
//  cbLimitTVConTypeInLayout - limit TV connector type combination in TV layout
//  In:
//      *pTVConType : TV connector type combination
//              = Bit[6]      S-VIDEO 1 (Y/C)
//              = Bit[5]      C_SDTVYPbPr
//              = Bit[4]      C_SDTVRGB
//              = Bit[3]      YCbCr
//              = Bit[2]      RGB
//              = Bit[1]      S-VIDEO 0 (Y/C)
//              = Bit[0]      CVBS
//      *pTVLayout : TV layout bit combination
//              = Bit0        CVBS
//              = Bit1        SVideo1
//              = Bit2        RGB
//              = Bit3        YCbCr
//              = Bit4        SDTVRGB
//              = Bit5        SDTVYPbPr
//              = Bit6        CVBS+SVideo1
//              = Bit7        CVBS+RGB
//              = Bit8        CVBS+YCbCr
//  Out:
//      updated *pTVConType
//      if can't match a correct layout, then we will return the Connector type corresponding to 
//    lsb of available layout.
//    For example:
//    TV layout             TV connector type               output TV connector type
//    BIT6+BIT1+BIT0        BIT1+BIT0                           BIT1+BIT0
//    BIT6+BIT1+BIT0        BIT1                                BIT1
//    BIT6+BIT1+BIT0        BIT3                                BIT0
void cbLimitTVConTypeInLayout(BYTE *pTVConType, WORD TVLayout)
{
    BYTE TempConType;
    WORD TempLayOut,LayoutMask;
    int i;
	if(pTVConType == NULL)
		return;
    TempLayOut=TVLayout;
    TempConType=*pTVConType;
    LayoutMask=BIT8;
    TVLayout=0;
    (*pTVConType)=0;
    for(i=TV_LayoutToConType_BitMask_Len-1;i>=0;i--)
    {
        if(TempLayOut & LayoutMask)
        {
            TVLayout = LayoutMask;
            *pTVConType=TV_LayoutToConType_BitMask[i];
            if((TempConType&*pTVConType)== *pTVConType)
            {
                break;
            }
        }
        LayoutMask >>=1;
    }
    return;
}
//**************************************************************************
// 
//  cbLimitTVType - limit TV type in TV type capability
//  In:
//      *pTVType = TV type
//               000 - NTSC
//               001 - PAL / PAL B / PAL G / PAL H
//               010 - PAL M
//               011 - PAL N
//               100 - PAL Nc
//               101 - PAL I
//               110 - PAL D
//               111 - NTSC Japan
//      TVTypeCap = TV type capability
//              Bit[12]     =  PAL Nc
//              Bit[11]     =  PAL N
//              Bit[10]     =  PAL K1
//              Bit[9]      =  PAL K
//              Bit[8]      =  PAL I
//              Bit[7]      =  PAL H
//              Bit[6]      =  PAL G
//              Bit[5]      =  PAL D
//              Bit[4]      =  PAL B
//              Bit[3]      =  PAL M
//              Bit[2]      =  NTSC Japan
//              Bit[1]      =  PAL
//              Bit[0]      =  NTSC U.S / NTSC M
//  Output:
//      *pTVType = updated TV type
VOID cbLimitTVType(BYTE *pTVType, WORD TVTypeCap)
{
    if(pTVType == NULL)
        return;
    *pTVType &= 0x07;
    if( TV_StandardType_Map[*pTVType] & TVTypeCap )
        return;
    //find an available TV type
    for(*pTVType=0; *pTVType<TV_StandardType_Map_Len; (*pTVType)++)
    {
        if( TV_StandardType_Map[*pTVType] & TVTypeCap )
        {
            return;
        }
    }
    *pTVType=0;
}
//**************************************************************************
// 
//  cbLimitHDTVType - limit HDTV type in HDTV type capability
//  In:
//      *pHDTVType = HDTV type
//              = 000         SDTV 525I (SDTV 480I, NTSC)
//              = 001         SDTV 625I (SDTV 576I, PAL)
//              = 010         HDTV 480P (HDTV 525P, NTSC)
//              = 011         HDTV 576P (HDTV 625P, PAL)
//              = 100         HDTV 720P
//              = 101         HDTV 1080I
//              = 110         HDTV 1080P
//      HDTVTypeCap = HDTV type capability
//              Bit[6]     =  HDTV 1080P
//              Bit[5]     =  HDTV 1080I
//              Bit[4]     =  HDTV 720P
//              Bit[3]     =  HDTV 576P
//              Bit[2]     =  HDTV 480P
//              Bit[1]     =  SDTV 625I
//              Bit[0]     =  SDTV 525I
//  Output:
//      *pHDTVType = updated HDTV type
VOID cbLimitHDTVType(BYTE *pHDTVType, BYTE HDTVTypeCap)
{
    BYTE CapBit;
    if(pHDTVType == NULL)
        return;
    HDTVTypeCap &= 0x7F;
    CapBit=(BIT0<<(*pHDTVType));
    if( CapBit & HDTVTypeCap)
        return;
    //find an available HDTV type
    CapBit = BIT0;
    for(*pHDTVType=0; (*pHDTVType)<7; (*pHDTVType)++)
    {
        if( CapBit & HDTVTypeCap)
            return;
        CapBit <<= 1;
    }
    *pHDTVType=0;
}

//**************************************************************************
// cbGetContrastRegIndex
//     This function returns TV contrast register index according toTV
//  encoder output type
//      IN :
//          PCBIOS_EXTENSION
//          TblLen : pTVContrastRegIndexTbl size
//      Out : 
//          pTVContrastRegIndexTbl : TV reg to be set index table for Contrast  
//          length of TvRegIndex MUST >= 3
//**************************************************************************
CBIOS_STATUS cbGetContrastRegIndex(
        PCBIOS_EXTENSION pcbe, 
        OUT PBYTE pTVContrastRegIndexTbl,
        IN ULONG TblLen)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    
    if (!pTVContrastRegIndexTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    if (TblLen < 3)
    {
        cbDbgPrint(0, "Table length is not right, please check!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    switch(encodertype)
    {
    case VT1622A:
    case VT1623_3A:
        cbGetContrastRegIndex_1622A_UMA(pcbe, pTVContrastRegIndexTbl, TblLen);
        break;

    case VT1625_6:
    case VT1625A_6A:
        //for 1625/ 1625A TV encode
        cbGetContrastRegIndex_1625_UMA(pcbe, pTVContrastRegIndexTbl, TblLen);
        break;

    case IN_TV:
        pTVContrastRegIndexTbl[0] = 0x54;
        pTVContrastRegIndexTbl[1] = 0x55; 
        pTVContrastRegIndexTbl[2] = 0x00;
        break;
        
    default:
        cbDbgPrint(0, "Now CBIOS only support VT1625\n");
        status = CBIOS_ER_LACKOFINFO;
    }
    
    return status;
}


//**************************************************************************
// cbGetTvContrastRegIndex_UMA
//     This function sets TV contrast register index according to TV encoder
//  output type
//      IN :
//          PCBIOS_EXTENSION
//          TblLen : TvRegIndexTbl length
//      Out : 
//          TvRegIndexTbl : TV reg to be set index table for contrast  
//          length of TvRegIndex MUST >= 3
//**************************************************************************
VOID cbGetContrastRegIndex_1622A_UMA(
      PCBIOS_EXTENSION pcbe, 
      OUT PBYTE TvRegIndexTbl,
      IN ULONG TblLen)
{
    if (!TvRegIndexTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }
    if (TblLen < 3)
    {
        cbDbgPrint(0, "Table length is not right, please check!\n");
        ASSERT(FALSE); 
        return;
    }
    
    if ((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev) & S3_TV )
    {
        if (pcbe->sPad_7.TVOutType & (TV_RGB | TV_SDTVRGB))
        {
           //when TV output Type RGB
           TvRegIndexTbl[0] = 0x0A;
           TvRegIndexTbl[1] = 0x0C;
           TvRegIndexTbl[2] = 0x0D;
        }
        else if (pcbe->sPad_7.TVOutType & (TV_Ycbcr | TV_SDTVYpbpr)) 
        {
           //when TV output Type Component
           TvRegIndexTbl[0] = 0x0C;
           TvRegIndexTbl[1] = 0x00; 
           TvRegIndexTbl[2] = 0x00;
        }
        else if (pcbe->sPad_7.TVOutType & (TV_SVideo1 | TV_SVideo2))
        {
           //when use SVIDEO1 or SVIDEO2
           TvRegIndexTbl[0] = 0x0C;
           TvRegIndexTbl[1] = 0x00; 
           TvRegIndexTbl[2] = 0x00; 
        }else{
           TvRegIndexTbl[0] = 0x0C;
           TvRegIndexTbl[1] = 0x00; 
           TvRegIndexTbl[2] = 0x00;
        }
    }
}

//**************************************************************************
// cbGetTvContrastRegIndex_UMA
//     This function sets TV contrast register index according to TV encoder
//  output type
//      IN :
//          PCBIOS_EXTENSION
//          TblLen : TvRegIndexTbl length
//      Out : 
//          TvRegIndexTbl : TV reg to be set index table for contrast  
//          length of TvRegIndex MUST >= 3
//**************************************************************************
VOID cbGetContrastRegIndex_1625_UMA(
      PCBIOS_EXTENSION pcbe, 
      OUT PBYTE TvRegIndexTbl,
      IN ULONG TblLen)
{
    if (!TvRegIndexTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }
    if (TblLen < 3)
    {
        cbDbgPrint(0, "Table length is not right, please check!\n");
        ASSERT(FALSE);  
        return;
    }
    
    if ((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev) & S3_TV )
    {
        if (pcbe->sPad_7.TVOutType & (TV_RGB | TV_SDTVRGB))
        {
           //when TV output Type RGB
           TvRegIndexTbl[0] = 0x65;
           TvRegIndexTbl[1] = 0x66;
           TvRegIndexTbl[2] = 0x67;
        }
        else if (pcbe->sPad_7.TVOutType & (TV_Ycbcr | TV_SDTVYpbpr)) 
        {
           //when TV output Type Component
           TvRegIndexTbl[0] = 0x65;
           TvRegIndexTbl[1] = 0x00; 
           TvRegIndexTbl[2] = 0x00;
        }
        else if (pcbe->sPad_7.TVOutType & (TV_SVideo1 | TV_SVideo2))
        {
           //when use SVIDEO1 or SVIDEO2
           TvRegIndexTbl[0] = 0x65;
           if (pcbe->sPad_7.TVOutType & TV_CVBS)
           {
               //when use SVIDEO + CVBS
               TvRegIndexTbl[1] = 0x0C;
           }
           else
           {
               TvRegIndexTbl[1] = 0x00;
           }
           TvRegIndexTbl[2] = 0x00; 
        }
        else
        {
           TvRegIndexTbl[0] = 0x0C;
           TvRegIndexTbl[1] = 0x00; 
           TvRegIndexTbl[2] = 0x00;
        }
    }
    else if ((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev) & S3_HDTV)
    {
        if (pcbe->sPad_11.HDTVOutputType)
        {
            //when HDTV output Type Component
            TvRegIndexTbl[0] = 0x65;
            TvRegIndexTbl[1] = 0x00; 
            TvRegIndexTbl[2] = 0x00;
        }
        else
        {
            //when HDTV output Type RGB
            TvRegIndexTbl[0] = 0x65;
            TvRegIndexTbl[1] = 0x66;
            TvRegIndexTbl[2] = 0x67;
        }
    }
    
}

//**************************************************************************
// cbSetContrastControl_UMA
//     This function sets TV contrast level 
//      IN : PCBIOS_EXTENSION
//           contrastleve : TV contrast level to be set               
//      Out: 
//          Set contrast level status
//           CBIOS_OK  : success
//           Other     : fail
//**************************************************************************
CBIOS_STATUS cbSetContrastControl_UMA(
    PCBIOS_EXTENSION pcbe, 
    IN ULONG contrastlevel)
{
    BYTE TvRegIndexTbl[3];
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    //------------------------------------------------
    //---1. Get TV Saturation adjust register index
    //------------------------------------------------
    cbGetContrastRegIndex(pcbe, TvRegIndexTbl, sizeof(TvRegIndexTbl) / sizeof(BYTE));
    
    //------------------------------------------------
    //---2. Set TV contrast level from TV encoder
    //------------------------------------------------
    if (encodertype != IN_TV)
    {
        status = TV_I2CWRITE_BYTE_UMA(pcbe, TvRegIndexTbl[0], (BYTE)contrastlevel);
        if (status == CBIOS_OK && TvRegIndexTbl[1] != 0)
        {
            status = TV_I2CWRITE_BYTE_UMA(pcbe, TvRegIndexTbl[1], (BYTE)contrastlevel);
        }
        if (status == CBIOS_OK && TvRegIndexTbl[2] != 0)
        {
            status = TV_I2CWRITE_BYTE_UMA(pcbe, TvRegIndexTbl[2], (BYTE)contrastlevel);
        }
    }
    else
    {
        InTV_Write_Byte_UMA(pcbe, TvRegIndexTbl[0], (BYTE)contrastlevel); // 0x54
        if (TvRegIndexTbl[1] != 0)
        {
            // 0x55[0]
            InTV_Write_Bits_UMA(pcbe, TvRegIndexTbl[1], (BYTE)(contrastlevel >> 8), BIT0);
        }
    }
    
    //store current TV contrast level
    if (status == CBIOS_OK)
    {
        pcbe->tvparameter.CurContrast = contrastlevel;
    }
    
    return status;
        
}

//**************************************************************************
// cbGetMaxContrast_UMA
//     This function returns TV MAX contrast level 
//      IN : PCBIOS_EXTENSION              
//      Out: 
//          pMaxCon : Max contrast level
//************************************************************************
CBIOS_STATUS cbGetMaxContrast_UMA(PCBIOS_EXTENSION pcbe, OUT PULONG pMaxCon)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    
    if (!pMaxCon)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    *pMaxCon = 0;

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    switch(encodertype)
    {
    case VT1622:
    case VT1622A:
    case VT1623_3A:
        //Max contrast level for VT1625 0xFF + 1
        *pMaxCon = 0xFF + 1;
        break;
        
    case VT1625_6:
    case VT1625A_6A:
        //Max contrast level for VT1625 0xFF + 1
        *pMaxCon = 0xFF + 1;
        break;

    case IN_TV:
        //Max contrast level for InTV 0x1FF + 1
        *pMaxCon = 0x1FF + 1;
        break;    
        
    default:
        cbDbgPrint(0, "No such TV encoder!\n");
        status = CBIOS_ER_LACKOFINFO;
    }

    return status;
    
}

//**************************************************************************
// cbSetSaturationControl_UMA
//     This function sets TV saturation level 
//      IN : PCBIOS_EXTENSION              
//      Out: Max contrast level
//**************************************************************************
CBIOS_STATUS cbSetSaturationControl_UMA(PCBIOS_EXTENSION pcbe, IN ULONG satlevel)
{
    BYTE TVSatRegIndexTbl[4];
    BYTE  OldU = 0, OldV = 0;          // for U & V factor adjust 
    int   OldU1 = 0, OldV1 = 0;
    int  DeltaUV;
    long NewB, NewR;          // for R & B factor adjust
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }

    //------------------------------------------------
    //---1. Get TV Saturation adjust register index
    //------------------------------------------------
    cbGetSaturationRegIndex(pcbe, TVSatRegIndexTbl, sizeof(TVSatRegIndexTbl) / sizeof(BYTE));

    //-------------------------------------------------
    //---2. Set TV Saturation adjust register
    //------------------------------------------------
    if (encodertype != IN_TV)
    {
        if (((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev) & S3_TV) &&
        (pcbe->sPad_7.TVOutType & (TV_SVideo1 | TV_SVideo2 | TV_CVBS)))
        {
            // TV encoder output is SVIDEO or COMPASITE adjust U & V
            // first get old U & V
            status = TV_I2CRead_BYTE_UMA(pcbe, TVSatRegIndexTbl[0], &OldU);
            if (status == CBIOS_OK && TVSatRegIndexTbl[1] != 0)
            {
                status = TV_I2CRead_BYTE_UMA(pcbe, TVSatRegIndexTbl[1], &OldV);
            }
        
            // get the Delta modified value of current & set U ,V
            DeltaUV = satlevel - (int)OldU;

            // Update new U & V
            if (status == CBIOS_OK && TVSatRegIndexTbl[0] != 0)
            {
                status = TV_I2CWRITE_BYTE_UMA(pcbe, TVSatRegIndexTbl[0], (BYTE)((int)OldU + DeltaUV));
            }

            if (status == CBIOS_OK && TVSatRegIndexTbl[1] != 0)
            {
                status = TV_I2CWRITE_BYTE_UMA(pcbe, TVSatRegIndexTbl[1], (BYTE)((int)OldV + DeltaUV));
            }
        }
        else
        {
            // other case output for RGB / YPrPb / YCrCb 
            // adjust R & B factor
            // Cb' = Cb cos a + Cr sin a
            // Cr' = Cr cos a - Cb sin a 
            NewB = (LONG)satlevel * CosHueLevel_UMA(pcbe->tvparameter.CurHueAngle) / 100000 + 
                    (LONG)satlevel * SinHueLevel_UMA(pcbe->tvparameter.CurHueAngle) / 100000;
            NewR = (LONG)satlevel * CosHueLevel_UMA(pcbe->tvparameter.CurHueAngle) / 100000 - 
                    (LONG)satlevel * SinHueLevel_UMA(pcbe->tvparameter.CurHueAngle) / 100000;

            // Update new B & R
            status = TV_I2CWRITE_BYTE_UMA(pcbe, TVSatRegIndexTbl[0], (BYTE)NewB);
            if (status == CBIOS_OK && TVSatRegIndexTbl[1] != 0)
            {
                status = TV_I2CWRITE_BYTE_UMA(pcbe, TVSatRegIndexTbl[1], (BYTE)NewR);
            }
        }
    }
    else //InTV
    {
        OldU1 = InTV_Read_Byte_UMA(pcbe, TVSatRegIndexTbl[0]);
        if (TVSatRegIndexTbl[1] != 0)
        {
            OldU1 |= (InTV_Read_Byte_UMA(pcbe, TVSatRegIndexTbl[1]) & BIT0) << 8;
        }
        if (TVSatRegIndexTbl[2] != 0)
        {
            OldV1 = InTV_Read_Byte_UMA(pcbe, TVSatRegIndexTbl[2]);
        }
        if (TVSatRegIndexTbl[3] != 0)
        {
            OldV1 |= (InTV_Read_Byte_UMA(pcbe, TVSatRegIndexTbl[3]) & BIT0) << 8;
        }
        
        DeltaUV = OldV1 - OldU1;
        
        InTV_Write_Byte_UMA(pcbe, TVSatRegIndexTbl[0], (BYTE)satlevel);
        if (TVSatRegIndexTbl[1] != 0)
        {
            InTV_Write_Bits_UMA(pcbe, TVSatRegIndexTbl[1], (BYTE)(satlevel>>8), BIT0);
        }
        if (TVSatRegIndexTbl[2] != 0)
        {
            InTV_Write_Byte_UMA(pcbe, TVSatRegIndexTbl[2], (BYTE)(satlevel + DeltaUV));
        }
        if (TVSatRegIndexTbl[3] != 0)
        {
            InTV_Write_Bits_UMA(pcbe, TVSatRegIndexTbl[3], (BYTE)((satlevel + DeltaUV)>>8), BIT0);
        }
    }
    
    // if function success store current saturation value
    if (status == CBIOS_OK)
    {
        pcbe->tvparameter.CurSaturation = satlevel;
    }
    
    return status;
   
}

//**************************************************************************
// cbGetSaturationRegIndex
//     This function returns TV sturation register index according toTV
//  encoder output type
//      IN :
//          PCBIOS_EXTENSION
//          TblLen : TvRegIndexTbl size
//      Out : 
//          TvRegIndexTbl : TV reg to be set index table for saturation  
//          length of TvRegIndex MUST >= 3
//**************************************************************************
CBIOS_STATUS cbGetSaturationRegIndex(
        PCBIOS_EXTENSION pcbe, 
        OUT PBYTE pTVSatRegIndexTbl,
        IN ULONG TblLen)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    
    if (!pTVSatRegIndexTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    if (TblLen < 3)
    {
        cbDbgPrint(0, "Table length is not right, please check!\n");
        ASSERT(FALSE);    
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }

    switch(encodertype)
    {
    case VT1622A:
    case VT1623_3A:
        cbGetSaturationRegIndex_1622A_UMA(pcbe, pTVSatRegIndexTbl, TblLen);
        break;
    
    case VT1625_6:
    case VT1625A_6A:
        //for 1625/ 1625A TV encode
        cbGetSaturationRegIndex_1625_UMA(pcbe, pTVSatRegIndexTbl, TblLen);
        break;

    case IN_TV:
        cbGetSaturationRegIndex_InTV_UMA(pcbe, pTVSatRegIndexTbl, TblLen);
        break;
        
    default:
        cbDbgPrint(0, "Now CBIOS only support VT1625\n");
        status = CBIOS_ER_LACKOFINFO;
    }

    return status;
}

//**************************************************************************
// cbGetSaturationRegIndex_1622A_UMA
//     This function returns TV sturation register index according to 1622A TV
//  encoder output type
//      IN :
//          PCBIOS_EXTENSION
//          TblLen : TvRegIndexTbl size
//      Out : 
//          TvRegIndexTbl : TV reg to be set index table for saturation  
//          length of TvRegIndex MUST >= 3
//**************************************************************************
VOID cbGetSaturationRegIndex_1622A_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen)
{
    if (!TvRegIndexTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }
    if (TblLen < 3)
    {
        cbDbgPrint(0, "Table length is not right, please check!\n");
        ASSERT(FALSE);
        return;
    }
    
    if ((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev) & S3_TV)
    {
        // if TV is set to one IGA
        if (pcbe->sPad_7.TVOutType & (TV_SVideo1 | TV_SVideo2 | TV_CVBS))
        {
           // when use SVIDEO1 or SVIDEO2 or TV_CVBS
           // adjust U & V factor
           TvRegIndexTbl[0] = 0x0D;
           TvRegIndexTbl[1] = 0x0A; 
           TvRegIndexTbl[2] = 0x00; 
        }
        else
        {
           // when TV output Type Component or RGB
           // adjust (R / Pr / Cr) & (B / Pb / Cb) factor
           TvRegIndexTbl[0] = 0x66;
           TvRegIndexTbl[1] = 0x67; 
           TvRegIndexTbl[2] = 0x00;
        }
    }
}

//**************************************************************************
// cbGetSaturationRegIndex_1625_UMA
//     This function returns TV sturation register index according to 1625 TV
//  encoder output type
//      IN :
//          PCBIOS_EXTENSION
//          TblLen : TvRegIndexTbl size
//      Out : 
//          TvRegIndexTbl : TV reg to be set index table for saturation  
//          length of TvRegIndex MUST >= 3
//**************************************************************************
VOID cbGetSaturationRegIndex_1625_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen)
{
    if (!TvRegIndexTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }
    if (TblLen < 3)
    {
        cbDbgPrint(0, "Table length is not right, please check!\n");
        ASSERT(FALSE); 
        return;
    }
    
    if ((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev) & S3_TV)
    {
        // if TV is set to one IGA
        if (pcbe->sPad_7.TVOutType & (TV_SVideo1 | TV_SVideo2 | TV_CVBS))
        {
           // when use SVIDEO1 or SVIDEO2 or TV_CVBS
           // adjust U & V factor
           TvRegIndexTbl[0] = 0x0D;
           TvRegIndexTbl[1] = 0x0A; 
           TvRegIndexTbl[2] = 0x00; 
        }
        else
        {
           // when TV output Type Component or RGB
           // adjust (R / Pr / Cr) & (B / Pb / Cb) factor
           TvRegIndexTbl[0] = 0x66;
           TvRegIndexTbl[1] = 0x67; 
           TvRegIndexTbl[2] = 0x00;
        }
    }
    else if ((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev ) & S3_HDTV) 
    {
        // if HDTV is set to one IGA
        // adjust (R / Pr / Cr) & (B / Pb / Cb) factor
        TvRegIndexTbl[0] = 0x66;
        TvRegIndexTbl[1] = 0x67; 
        TvRegIndexTbl[2] = 0x00;
    }
    
}

//**************************************************************************
// cbGetSaturationRegIndex_InTV_UMA
//     This function returns TV sturation register index according to internal TV
//  encoder output type
//      IN :
//          PCBIOS_EXTENSION
//          TblLen : TvRegIndexTbl size
//      Out : 
//          TvRegIndexTbl : TV reg to be set index table for saturation  
//          length of TvRegIndex MUST >= 3
//**************************************************************************
VOID cbGetSaturationRegIndex_InTV_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen)
{
    if (!TvRegIndexTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }
    if (TblLen < 3)
    {
        cbDbgPrint(0, "Table length is not right, please check!\n");
        ASSERT(FALSE);
        return;
    }
    
    TvRegIndexTbl[0] = 0x50;
    TvRegIndexTbl[1] = 0x51; //only BIT0
    TvRegIndexTbl[2] = 0x52;
    if (TblLen > 3)
    {
        TvRegIndexTbl[3] = 0x53; //only BIT0
    }    
}

//**************************************************************************
// cbGetMaxSaturation_UMA
//     This function returns TV MAX saturation level 
//      IN : PCBIOS_EXTENSION              
//      Out: 
//         pMaxSat : Max Saturation level
//************************************************************************
CBIOS_STATUS cbGetMaxSaturation_UMA(PCBIOS_EXTENSION pcbe, OUT PULONG pMaxSat)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    
    if (!pMaxSat)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    *pMaxSat = 0;

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }

    switch(encodertype)
    {
    case VT1622:
    case VT1622A:
    case VT1623_3A:
        //Max saturation level for VT1622A 0xdb + 1
        *pMaxSat = 0xdb + 1;
        break;
    
    case VT1625_6:
    case VT1625A_6A:
        //Max saturation level for VT1625 0xdb + 1
        *pMaxSat = 0xdb + 1;
        break;
    
    case IN_TV:
        *pMaxSat = 0x1ff + 1;
        break;
        
    default:
        cbDbgPrint(0, "Now CBIOS only support VT1625\n");
        status = CBIOS_ER_LACKOFINFO;
    }

    return status;
}    


//**************************************************************************
// cbSetHueControl_UMA
//     This function sets TV Hue level 
//      IN : PCBIOS_EXTENSION              
//           Max Hue level
//      OUT :
//          CBIOS_STATUS
//**************************************************************************
CBIOS_STATUS cbSetHueControl_UMA(PCBIOS_EXTENSION pcbe, IN ULONG hueangle)
{
    BYTE TVHueRegIndexTbl[3];
    long NewB, NewR;          // for R & B factor adjust
    BYTE bhueanglehigh;       
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
        
    if ( cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
        
    //------------------------------------------------
    //---1. Get TV Hue adjust register index
    //------------------------------------------------
    cbGetHueRegIndex(pcbe, TVHueRegIndexTbl, sizeof(TVHueRegIndexTbl) / sizeof(BYTE));
        

    //-------------------------------------------------
    //---2. Set TV Hue adjust register
    //------------------------------------------------
    if (encodertype != IN_TV)
    {
        if (((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev) & S3_TV) &&
            (pcbe->sPad_7.TVOutType & (TV_SVideo1 | TV_SVideo2 | TV_CVBS)))
        {
            // TV encoder output is SVIDEO or COMPASITE adjust Hue value directly
            // Update new Hue 
            // 0x10 Hue [7:0]
            status = TV_I2CWRITE_BYTE_UMA(pcbe, TVHueRegIndexTbl[0], (BYTE)(hueangle & 0xFF));

            // 0x11 Hue [10:8]
            if (status == CBIOS_OK && TVHueRegIndexTbl[1] != 0)
            {
                status = TV_I2CRead_BYTE_UMA(pcbe, TVHueRegIndexTbl[1], &bhueanglehigh);
            }
            
            if (status == CBIOS_OK && TVHueRegIndexTbl[1] != 0)
            {
                // clear Hue [10 : 8] stored in bits [2 : 0]
                bhueanglehigh &= 0xF8;   
                bhueanglehigh |= (hueangle & 0x700) >> 8; 
                status = TV_I2CWRITE_BYTE_UMA(pcbe, TVHueRegIndexTbl[1], (BYTE)(bhueanglehigh));
            }
        }
        else
        {
            // other case output for RGB / YPrPb / YCrCb 
            // adjust R & B factor
            // Cb' = Cb cos a + Cr sin a
            // Cr' = Cr cos a - Cb sin a 
            NewB = pcbe->tvparameter.CurSaturation * CosHueLevel_UMA(hueangle) / 100000 + 
                    pcbe->tvparameter.CurSaturation * SinHueLevel_UMA(hueangle) / 100000;
            NewR = pcbe->tvparameter.CurSaturation * CosHueLevel_UMA(hueangle) / 100000 - 
                    pcbe->tvparameter.CurSaturation * SinHueLevel_UMA(hueangle) / 100000;

            // Update new B & R
            status = TV_I2CWRITE_BYTE_UMA(pcbe, TVHueRegIndexTbl[0], (BYTE)NewB);
            if (status == CBIOS_OK && TVHueRegIndexTbl[1] != 0)
            {
                status = TV_I2CWRITE_BYTE_UMA(pcbe, TVHueRegIndexTbl[1], (BYTE)NewR);
            }
        }
    }
    else  // InTV
    {
        InTV_Write_Byte_UMA(pcbe, TVHueRegIndexTbl[0], (BYTE)(hueangle & 0xFF));
 
        // 0x61[2:0] <-> Hue [10:8]
        if (TVHueRegIndexTbl[1] != 0)
        {
            bhueanglehigh = InTV_Read_Byte_UMA(pcbe, TVHueRegIndexTbl[1]);
        }
        
        if (TVHueRegIndexTbl[1] != 0)
        {
            // clear Hue [10 : 8] stored in bits [2 : 0]
            bhueanglehigh &= 0xF8;   
            bhueanglehigh |= (hueangle & 0x700) >> 8; 
            InTV_Write_Byte_UMA(pcbe, TVHueRegIndexTbl[1], (BYTE)(bhueanglehigh));
        }
    }
    
    // if function success store current hue value
    if (status == CBIOS_OK)
    {
        pcbe->tvparameter.CurHueAngle = hueangle;
    }
    
    return status;
   
}


//**************************************************************************
// cbGetHueRegIndex
//     This function returns TV hue register index according to TV
//  encoder output type
//      IN :
//          PCBIOS_EXTENSION
//          TblLen : TvRegIndexTbl length
//      Out : 
//          pTVHueRegIndexTbl : TV reg to be set index table for Hue  
//          length of TvRegIndex MUST >= 3
//**************************************************************************
CBIOS_STATUS cbGetHueRegIndex(
        PCBIOS_EXTENSION pcbe, 
        OUT PBYTE pTVHueRegIndexTbl,
        IN ULONG TblLen)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    
    if (!pTVHueRegIndexTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    if (TblLen < 3)
    {
        cbDbgPrint(0, "Table length is not right, please check!\n");
        ASSERT(FALSE);    
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    switch(encodertype)
    {
    case VT1622A:
    case VT1623_3A:
        //for 1625/ 1625A TV encode
        cbGetHueRegIndex_1622A_UMA(pcbe, pTVHueRegIndexTbl, TblLen);
        break;

    case VT1625_6:
    case VT1625A_6A:
        //for 1625/ 1625A TV encode
        cbGetHueRegIndex_1625_UMA(pcbe, pTVHueRegIndexTbl, TblLen);
        break;

    case IN_TV:
        pTVHueRegIndexTbl[0] = 0x60;
        pTVHueRegIndexTbl[1] = 0x61;
        pTVHueRegIndexTbl[2] = 0x00;
        break;
        
    default:
        cbDbgPrint(0, "Now CBIOS only support VT1625\n");
        status = CBIOS_ER_LACKOFINFO;
    }
    
    return status;
}

//**************************************************************************
// cbGetHueRegIndex_1625_UMA
//     This function returns TV Hue register index according to 1625 TV
//  encoder output type
//      IN :
//          PCBIOS_EXTENSION
//      Out : 
//          TvRegIndexTbl : TV reg to be set index table for saturation  
//          length of TvRegIndex MUST >= 3
//**************************************************************************
VOID cbGetHueRegIndex_1622A_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen)
{
    if (!TvRegIndexTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }
    if (TblLen < 3)
    {
        cbDbgPrint(0, "Table length is not right, please check!\n");
        ASSERT(FALSE); 
        return;
    }
    
    if ((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev) & S3_TV)
    {
        // if TV is set to one IGA
        if (pcbe->sPad_7.TVOutType & (TV_SVideo1 | TV_SVideo2 | TV_CVBS))
        {
           // when use SVIDEO1 or SVIDEO2 or TV_CVBS
           // adjust Hue factor
           TvRegIndexTbl[0] = 0x10;
           TvRegIndexTbl[1] = 0x11; 
           TvRegIndexTbl[2] = 0x00; 
        }
        else
        {
           // when TV output Type Component or RGB
           // adjust (R / Pr / Cr) & (B / Pb / Cb) factor
           TvRegIndexTbl[0] = 0x66;
           TvRegIndexTbl[1] = 0x67; 
           TvRegIndexTbl[2] = 0x00;
        }
    }
}

//**************************************************************************
// cbGetHueRegIndex_1625_UMA
//     This function returns TV Hue register index according to 1625 TV
//  encoder output type
//      IN :
//          PCBIOS_EXTENSION
//      Out : 
//          TvRegIndexTbl : TV reg to be set index table for saturation  
//          length of TvRegIndex MUST >= 3
//**************************************************************************
VOID cbGetHueRegIndex_1625_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen)
{
    if (!TvRegIndexTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }
    if (TblLen < 3)
    {
        cbDbgPrint(0, "Table length is not right, please check!\n");
        ASSERT(FALSE); 
        return;
    }
    
    if ((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev) & S3_TV)
    {
        // if TV is set to one IGA
        if (pcbe->sPad_7.TVOutType & (TV_SVideo1 | TV_SVideo2 | TV_CVBS))
        {
           // when use SVIDEO1 or SVIDEO2 or TV_CVBS
           // adjust Hue factor
           TvRegIndexTbl[0] = 0x10;
           TvRegIndexTbl[1] = 0x11; 
           TvRegIndexTbl[2] = 0x00; 
        }
        else
        {
           // when TV output Type Component or RGB
           // adjust (R / Pr / Cr) & (B / Pb / Cb) factor
           TvRegIndexTbl[0] = 0x66;
           TvRegIndexTbl[1] = 0x67; 
           TvRegIndexTbl[2] = 0x00;
        }
    }
    else if ((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev ) & S3_HDTV) 
    {
        // if HDTV is set to one IGA
        // adjust (R / Pr / Cr) & (B / Pb / Cb) factor
        TvRegIndexTbl[0] = 0x66;
        TvRegIndexTbl[1] = 0x67; 
        TvRegIndexTbl[2] = 0x00;
    }
    
}


//**************************************************************************
// cbGetMaxHue_UMA
//     This function returns TV MAX hue level 
//      IN : PCBIOS_EXTENSION              
//      Out:
//         pMaxHue : Max hue level
//************************************************************************
CBIOS_STATUS cbGetMaxHue_UMA(PCBIOS_EXTENSION pcbe, OUT PULONG pMaxHue)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    
    if (!pMaxHue)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    *pMaxHue = 0;

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    switch(encodertype)
    {
    case VT1622:
    case VT1622A:
    case VT1623_3A:
        if ((!(((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev) & S3_TV) &&
            (pcbe->sPad_7.TVOutType & (TV_SVideo1 | TV_SVideo2 | TV_CVBS)))))
        {
            //Max Hue level for VT1622A should be 61, because the SinLut_UMA[] and CosLut_UMA[] has only 61 entries
            *pMaxHue = HueLevelNum;
        }
        else
        {
            //Max Hue level for VT1622A 0x7FF [10:0]
            *pMaxHue = 0x7FF + 1;        
        }
        break;
    
    case VT1625_6:
    case VT1625A_6A:
        if ((encodertype != IN_TV) &&
            (!(((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev) & S3_TV) &&
            (pcbe->sPad_7.TVOutType & (TV_SVideo1 | TV_SVideo2 | TV_CVBS)))))
        {
            //Max Hue level for VT1625 should be 61, because the SinLut_UMA[] and CosLut_UMA[] has only 61 entries
            *pMaxHue = HueLevelNum;
        }
        else
        {
            //Max Hue level for VT1625 0x7FF [10:0]
            *pMaxHue = 0x7FF + 1;        
        }
        
        break;

    case IN_TV:
        *pMaxHue = 0x7FF + 1;        
        break;
        
    default:
        cbDbgPrint(0, "Now CBIOS only support VT1625\n");
        status = CBIOS_ER_LACKOFINFO;
    }

    return status;
}


//**************************************************************************
// cbSetBrightnessControl_UMA
//     This function sets TV Brightness level 
//      IN : PCBIOS_EXTENSION              
//      Out: Max Brightness level
//**************************************************************************
CBIOS_STATUS cbSetBrightnessControl_UMA(PCBIOS_EXTENSION pcbe, IN ULONG BrightLevel)
{
    BYTE TVBrightnessRegIndexTbl[3];
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
        
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }

    //------------------------------------------------
    //---1. Get TV Brightness adjust register index
    //------------------------------------------------
    cbGetBrightnessRegIndex(pcbe, TVBrightnessRegIndexTbl, sizeof(TVBrightnessRegIndexTbl) / sizeof(BYTE));
        

    //-------------------------------------------------
    //---2. Set TV Brightness adjust register
    //------------------------------------------------
    // for 16XX register we just adjust 0x0b
    if (encodertype != IN_TV)
    {
        status = TV_I2CWRITE_BYTE_UMA(pcbe, TVBrightnessRegIndexTbl[0], (BYTE)(BrightLevel & 0xFF));
    }
    else
    {
        // 0x56[7] & 0x57[6:0]
        InTV_Write_Bits_UMA(pcbe, TVBrightnessRegIndexTbl[0], (BYTE)((BrightLevel & 0x01)<<7), BIT7);
        if (TVBrightnessRegIndexTbl[1] != 0)
        {
            InTV_Write_Bits_UMA(pcbe, TVBrightnessRegIndexTbl[1], (BYTE)((BrightLevel & 0xfe)>>1), 0x7F);
        }
    }
    
    // if function success store current brightness value
    if (status == CBIOS_OK)
    {
        pcbe->tvparameter.CurBrightness = BrightLevel;
    }
    
    return status;
   
}

//**************************************************************************
// cbGetBrightnessRegIndex
//     This function returns TV Brightness register index according to TV
//  encoder output type
//      IN :
//          PCBIOS_EXTENSION
//          TblLen : pTVBrightnessRegIndexTbl length
//      Out : 
//          pTVBrightnessRegIndexTbl : TV reg to be set index table for Brightness  
//          length of TvRegIndex MUST >= 3
//**************************************************************************
CBIOS_STATUS cbGetBrightnessRegIndex(
        PCBIOS_EXTENSION pcbe, 
        OUT PBYTE pTVBrightnessRegIndexTbl,
        IN ULONG TblLen)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    
    if (!pTVBrightnessRegIndexTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    if (TblLen < 3)
    {
        cbDbgPrint(0, "Table length is not right, please check!\n");
        ASSERT(FALSE);    
        return CBIOS_ER_INVALID_PARAMETER;
    }
        
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    switch(encodertype)
    {
    case VT1622A:
    case VT1623_3A:
        //for 1622A/ 1623 TV encode
        cbGetBrightnessRegIndex_1622A_UMA(pcbe, pTVBrightnessRegIndexTbl, TblLen);
        break;

    case VT1625_6:
    case VT1625A_6A:
        //for 1625/ 1625A TV encode
        cbGetBrightnessRegIndex_1625_UMA(pcbe, pTVBrightnessRegIndexTbl, TblLen);
        break;

    case IN_TV:
        pTVBrightnessRegIndexTbl[0] = 0x56;
        pTVBrightnessRegIndexTbl[1] = 0x57;
        pTVBrightnessRegIndexTbl[2] = 0x00;
        break;
        
    default:
        cbDbgPrint(0, "Now CBIOS only support VT1625\n");
        status = CBIOS_ER_LACKOFINFO;
    }
    
    return status;
}

//**************************************************************************
// cbGetBrightnessRegIndex_1622A_UMA
//     This function returns TV Brightness register index according to 1622A TV
//  encoder output type
//      IN :
//          PCBIOS_EXTENSION
//      Out : 
//          TvRegIndexTbl : TV reg to be set index table for Brightness  
//          length of TvRegIndex MUST >= 3
//**************************************************************************
VOID cbGetBrightnessRegIndex_1622A_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen)
{
    if (!TvRegIndexTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }
    if (TblLen < 3)
    {
        cbDbgPrint(0, "Table length is not right, please check!\n");
        ASSERT(FALSE); 
        return;
    }
    
    // for 16xx register just set 0x0b black level register 
    TvRegIndexTbl[0] = 0x0b;
    TvRegIndexTbl[1] = 0x00; 
    TvRegIndexTbl[2] = 0x00; 
    
}

//**************************************************************************
// cbGetBrightnessRegIndex_1625_UMA
//     This function returns TV Brightness register index according to 1625 TV
//  encoder output type
//      IN :
//          PCBIOS_EXTENSION
//      Out : 
//          TvRegIndexTbl : TV reg to be set index table for Brightness  
//          length of TvRegIndex MUST >= 3
//**************************************************************************
VOID cbGetBrightnessRegIndex_1625_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen)
{
    if (!TvRegIndexTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }
    if (TblLen < 3)
    {
        cbDbgPrint(0, "Table length is not right, please check!\n");
        ASSERT(FALSE); 
        return;
    }
    
    // for 16xx register just set 0x0b black level register 
    TvRegIndexTbl[0] = 0x0b;
    TvRegIndexTbl[1] = 0x00; 
    TvRegIndexTbl[2] = 0x00; 
    
}


//**************************************************************************
// cbGetMaxBrightness_UMA
//     This function returns TV MAX Brightnes level 
//      IN : PCBIOS_EXTENSION              
//      Out:
//         pMaxHue : Max Brightnes level
//************************************************************************
CBIOS_STATUS cbGetMaxBrightness_UMA(PCBIOS_EXTENSION pcbe, OUT PULONG pMaxBrightness)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    
    if (!pMaxBrightness)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    *pMaxBrightness = 0;

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    switch(encodertype)
    {
    case VT1622:
    case VT1622A:
    case VT1623_3A:
        //Max Brightness level for VT1622A 0xFF
        *pMaxBrightness = 0xFF + 1;
        break;
    
    case VT1625_6:
    case VT1625A_6A:
        //Max Brightness level for VT1625 0xFF
        *pMaxBrightness = 0xFF + 1;
        break;

    case IN_TV:
        *pMaxBrightness = 0xFF + 1;
        break;
        
    default:
        cbDbgPrint(0, "Now CBIOS only support VT1625\n");
        status = CBIOS_ER_LACKOFINFO;
    }

    return status;
}


//**************************************************************************
// cbEnableNormFlickerFilter_UMA
//     This function enables normal flicker filter and disables adaptive flicker 
//  filter since we can only use one kind of flicker filter 
//      IN : PCBIOS_EXTENSION              
//      OUT: CBIOS_STATUS
//************************************************************************
CBIOS_STATUS cbEnableNormFlickerFilter_UMA(PCBIOS_EXTENSION pcbe)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    BYTE bReg03, bReg62;
    
    if ( cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    switch(encodertype)
    {
    case VT1622:
    case VT1622A:
    case VT1623_3A:
        if(0)
        {
        // enable Luma filter & set deflicker filter to 1:1:1
        TV_I2CRead_BYTE_UMA(pcbe, 0x03, &bReg03);
        bReg03 &= 0xE0;
        bReg03 |= 0x0F;
        TV_I2CWRITE_BYTE_UMA(pcbe, 0x03, bReg03);
        
        // switch deflicker filter to normal flicker type
        bReg62 = 0x00;
        TV_I2CWRITE_BYTE_UMA(pcbe, 0x62, bReg62);
        }
        break;
    
    case VT1625_6:
    case VT1625A_6A:
        // enable Luma filter & set deflicker filter to 1:1:1
        TV_I2CRead_BYTE_UMA(pcbe, 0x03, &bReg03);
        bReg03 &= 0xE0;
        bReg03 |= 0x0F;
        TV_I2CWRITE_BYTE_UMA(pcbe, 0x03, bReg03);
        
        // switch deflicker filter to normal flicker type
        TV_I2CRead_BYTE_UMA(pcbe, 0x62, &bReg62);
        bReg62 &= 0xFC;
        TV_I2CWRITE_BYTE_UMA(pcbe, 0x62, bReg62);
        break;
    
    case IN_TV:
        cbDbgPrint(1, "Internal TV not support it!\n");
        status = CBIOS_ER_NOT_YET_IMPLEMENTED;
        break;
        
    default:
        cbDbgPrint(0, "Now CBIOS only support VT1625\n");
        status = CBIOS_ER_LACKOFINFO;
    }

    if (status == CBIOS_OK)
    {
       pcbe->tvparameter.CurDeflickerFliterStatus = ENABLE_NORM_FLICKERFILTER;
    }
    return status;

}


//**************************************************************************
// cbEnableAdaptiveFlickerFilter_UMA
//     This function disables normal flicker filter and enables adaptive flicker 
//  filter since we can only use one kind of flicker filter 
//      IN : PCBIOS_EXTENSION              
//      Out: CBIOS_STATUS
//************************************************************************
CBIOS_STATUS cbEnableAdaptiveFlickerFilter_UMA(PCBIOS_EXTENSION pcbe)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    BYTE bReg03, bReg62;
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    switch(encodertype)
    {
    case VT1622:
    case VT1622A:
    case VT1623_3A:
        if(0)
        {
        // disable Luma filter & set deflicker filter none
        TV_I2CRead_BYTE_UMA(pcbe, 0x03, &bReg03);
        bReg03 &= 0xE0;
        TV_I2CWRITE_BYTE_UMA(pcbe, 0x03, bReg03);
        
        // switch deflicker filter to adaptive flicker type
        bReg62 = 0x03;
        TV_I2CWRITE_BYTE_UMA(pcbe, 0x62, bReg62);
        }
        break;
    
    case VT1625_6:
    case VT1625A_6A:
        // disable Luma filter & set deflicker filter none
        TV_I2CRead_BYTE_UMA(pcbe, 0x03, &bReg03);
        bReg03 &= 0xE0;
        TV_I2CWRITE_BYTE_UMA(pcbe, 0x03, bReg03);
        
        // switch deflicker filter to adaptive flicker type
        TV_I2CRead_BYTE_UMA(pcbe, 0x62, &bReg62);
        bReg62 &= 0xFC;
        bReg62 |= 0x01;
        TV_I2CWRITE_BYTE_UMA(pcbe, 0x62, bReg62);
        break;
    
    case IN_TV:
        cbDbgPrint(1, "Internal TV not support AdaptiveFlickerFilter!\n");
        status = CBIOS_ER_NOT_YET_IMPLEMENTED;
        break;
        
    default:
        cbDbgPrint(0, "Now CBIOS only support VT1625\n");
        status = CBIOS_ER_LACKOFINFO;
    }

    if (status == CBIOS_OK)
    {
       pcbe->tvparameter.CurDeflickerFliterStatus = ENABLE_ADAPTIVE_FLICKERFILTER;
    }

    return status;

}

//**************************************************************************
// cbSetPositionControl_UMA
//     This function sets TV position  according to given H/V Postion Adjustment 
//  level 
//      Horizontal Position adjustment value range [0, X] 
//        0 : leftmost position , X : rightmost position
//      Vertical Position adjustment value range [0, X]
//        0 : downmost position ,   X : upmost position
//           |upmost
//           |
//           |
//           | middle
//           |
//           |
//           |
//           |____________middle______________rightmost
//      IN :
//          PCBIOS_EXTENSION              
//          HPositionAdj
//          VPositionAdj
//      Out:
//**************************************************************************
CBIOS_STATUS cbSetPositionControl_UMA(
    PCBIOS_EXTENSION pcbe,
    IN ULONG HPositionAdj, 
    IN ULONG VPositionAdj)
{
    ULONG encodertype;
    CBIOS_STATUS status = CBIOS_OK;
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }

    //
    switch(encodertype)
    {
    case VT1622A:
    case VT1623_3A:
        //for 1622A/ 1623 TV encode
        cbSetTVPosition_1622A_UMA(pcbe, HPositionAdj, VPositionAdj);   
        break;

    case VT1625_6:
    case VT1625A_6A:
        //for 1625/ 1625A TV encode
        cbSetTVPosition_1625_UMA(pcbe, HPositionAdj, VPositionAdj);   
        break;

    case IN_TV:
        cbSetTVPosition_InTV_UMA(pcbe, HPositionAdj, VPositionAdj);   
        break;
        
    default:
        cbDbgPrint(0, "Now CBIOS only support VT1625\n");
        status = CBIOS_ER_LACKOFINFO;
    }

    return status;
}

//**************************************************************************
// cbGetPositionControl_UMA
//     This function get TV position adjustment level 
//      Horizontal Position adjustment value range [0, X] 
//        0 : leftmost position , X : rightmost position
//      Vertical Position adjustment value range [0, X]
//        0 : downmost position ,   X : upmost position
//           |upmost
//           |
//           |
//           | middle
//           |
//           |
//           |
//           |____________middle______________rightmost
//      IN :
//          PCBIOS_EXTENSION              
//      Out:
//          pHPositionAdj : H position adjustment level
//          pVPositionAdj : V position adjustment level
//**************************************************************************
CBIOS_STATUS cbGetPositionControl_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPositionAdj, 
    OUT PULONG pVPositionAdj)
{
    ULONG HPositionMax, VPositionMax;
    ULONG encodertype;
    CBIOS_STATUS status = CBIOS_OK;
    
    if (!pHPositionAdj || !pVPositionAdj)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    // Caution! Now we just handle H right side limit & V downwards limit
    // for H left side limit & V upwards limit do not handle since we haven't 
    // see such limitation case
    status = cbGetTVPositionMaxRange_UMA(pcbe, &HPositionMax, &VPositionMax);
    switch (encodertype)
    {
    case VT1625_6:
    case VT1625A_6A:
        if ((LONG)pcbe->tvparameter.DefaultHPosition >= ((LONG)(HPositionMax >> 1) - 1))
        {
            // if there is enough room for us to adjust H position
            // then keep default H position as middle value
            // rightmost =< 0_________________defualt______________MAX <= leftmost
            *pHPositionAdj = pcbe->tvparameter.DefaultHPosition - 
                             pcbe->tvparameter.CurHPosition + 
                             (HPositionMax >> 1);
            
        }
        else
        {
            // else keep RegValue == 0 as H position adjust level Max
            // rightmost =< 0___________________________defualt____MAX = leftmost
            *pHPositionAdj = HPositionMax - pcbe->tvparameter.CurHPosition;
        }
    
        if ((LONG)pcbe->tvparameter.DefaultVPosition >= ((LONG)(VPositionMax >> 1) - 1))
        {
            // if there is enough room for us to adjust V position
            // then keep default V position as middle value
            *pVPositionAdj = pcbe->tvparameter.CurVPosition- 
                             pcbe->tvparameter.DefaultVPosition + 
                             (VPositionMax >> 1);
        }
        else
        {
            // else keep RegValue == 0 as H position adjust level 0
            *pVPositionAdj = pcbe->tvparameter.CurVPosition;
        }
        break;
    case IN_TV:
        *pHPositionAdj = pcbe->tvparameter.CurHPosition;
        *pVPositionAdj = pcbe->tvparameter.CurVPosition;
        break;
    default:
        break;
    }
    return status;                 
                     
}

//**************************************************************************
// cbGetTVPositionRange_UMA
//     This function returns Max TV position adjustment range according to the
//  TV encoder type.
//      Horizontal Position adjustment value range [0, X] 
//        0 : leftmost position adjustment, X : rightmost position adjustment
//      Vertical Position adjustment value range [0, X]
//        0 : upmost position adjustment,   X : downmost position adjustment
//           |upmost
//           |
//           |
//           | middle
//           |
//           |
//           |
//           |____________middle______________rightmost
//      IN :
//          PCBIOS_EXTENSION              
//      Out:
//          pHPositionMax  : H position adjustment range
//          pVPositionMax  : V position adjustment range
//**************************************************************************
CBIOS_STATUS cbGetTVPositionMaxRange_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPositionMax,
    OUT PULONG pVPositionMax)
{
    ULONG encodertype;
    CBIOS_STATUS status = CBIOS_OK;

    if (!pHPositionMax || !pVPositionMax)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    switch(encodertype)
    {
    case VT1622A:
    case VT1623_3A:
        //for 1622A/ 1623 TV encode
        cbGetTVPositionMaxRange_1622A_UMA(pcbe, pHPositionMax, pVPositionMax);   
        break;

    case VT1625_6:
    case VT1625A_6A:
        //for 1625/ 1625A TV encode
        cbGetTVPositionMaxRange_1625_UMA(pcbe, pHPositionMax, pVPositionMax);   
        break;

    case IN_TV:
        *pHPositionMax = 0x13;
        *pVPositionMax = 0x0F;
        break;
        
    default:
        cbDbgPrint(0, "Now CBIOS only support VT1625 & InTV\n");
        status = CBIOS_ER_LACKOFINFO;
    }
    
    return status;
     
}

//**************************************************************************
//  cbGetTVPositionMaxRange_1622A_UMA
//     This function returns VT1622A TV Max position adjustment range 
//      Horizontal Position adjustment value range [0, X] 
//        0 : leftmost position adjustment, X : rightmost position adjustment
//      Vertical Position adjustment value range [0, X]
//        0 : upmost position adjustment,   X : downmost position adjustment
//           |upmost
//           |
//           |
//           | middle
//           |
//           |
//           |
//           |____________middle______________rightmost
//      IN :
//          PCBIOS_EXTENSION              
//      Out:
//          pHPositionMax  : H position adjustment range
//          pVPositionMax  : V position adjustment range
//**************************************************************************
VOID cbGetTVPositionMaxRange_1622A_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPositionMax, 
    OUT PULONG pVPositionMax)
{
    if (!pHPositionMax || !pVPositionMax)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }

    // According to TVShare.c file 
    // VT1625 H position ranging from 0 to 0x40 [0x00, 0x40]
    //        V position ranging from 0 to 0x0A [0x00, 0x0A]
    //           |upmost
    //           |
    //           |
    //           | middle
    //           |
    //           |
    //           |
    //           |____________middle______________rightmost
    *pHPositionMax = 0x40 + 1;
    *pVPositionMax = 0x0A + 1;
}

//**************************************************************************
//  cbGetTVPositionMaxRange_1625_UMA
//     This function returns VT1625A TV Max position adjustment range 
//      Horizontal Position adjustment value range [0, X] 
//        0 : leftmost position adjustment, X : rightmost position adjustment
//      Vertical Position adjustment value range [0, X]
//        0 : upmost position adjustment,   X : downmost position adjustment
//           |upmost
//           |
//           |
//           | middle
//           |
//           |
//           |
//           |____________middle______________rightmost
//      IN :
//          PCBIOS_EXTENSION              
//      Out:
//          pHPositionMax  : H position adjustment range
//          pVPositionMax  : V position adjustment range
//**************************************************************************
VOID cbGetTVPositionMaxRange_1625_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPositionMax, 
    OUT PULONG pVPositionMax)
{
    if (!pHPositionMax || !pVPositionMax)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }

    // According to TVShare.c file 
    // VT1625 H position ranging from 0 to 0x40 [0x00, 0x40]
    //        V position ranging from 0 to 0x0A [0x00, 0x0A]
    //           |upmost
    //           |
    //           |
    //           | middle
    //           |
    //           |
    //           |
    //           |____________middle______________rightmost
    *pHPositionMax = 0x40 + 1;
    *pVPositionMax = 0x0A + 1;
}

//**************************************************************************
// cbGetTVCurPosition_UMA
//     This function returns current TV register setting value for H / V value
//      IN :
//          PCBIOS_EXTENSION              
//      Out:
//          pHPosition  : H position value
//          pVPosition  : V position value
//**************************************************************************
CBIOS_STATUS cbGetTVCurPosition_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPosition,
    OUT PULONG pVPosition)
{
    ULONG encodertype;
    CBIOS_STATUS status = CBIOS_OK;

    if (!pHPosition || !pVPosition)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    switch(encodertype)
    {
    case VT1622A:
    case VT1623_3A:
        //for 1622A/ 1623 TV encode
        cbGetTVCurPosition_1622A_UMA(pcbe, pHPosition, pVPosition);   
        break;

    case VT1625_6:
    case VT1625A_6A:
        //for 1625/ 1625A TV encode
        cbGetTVCurPosition_1625_UMA(pcbe, pHPosition, pVPosition);   
        break;

    case IN_TV:
        cbGetTVCurPosition_InTV_UMA(pcbe, pHPosition, pVPosition);   
        break;
        
    default:
        cbDbgPrint(0, "Now CBIOS only support VT1625\n");
        status = CBIOS_ER_LACKOFINFO;
    }
    
    return status;
     
}

//**************************************************************************
//  cbGetTVCurPosition_1622A_UMA
//     This function returns VT1622A current TV position register value 
//      IN :
//          PCBIOS_EXTENSION              
//      Out:
//          pHPosition  : Current H position reg value
//          pVPosition  : Current V position reg value
//**************************************************************************
VOID cbGetTVCurPosition_1622A_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPosition, 
    OUT PULONG pVPosition)
{
    BYTE TVRegVal;
    
    if (!pHPosition || !pVPosition)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }

    // 1. update H position offset Tx 08
    TV_I2CRead_BYTE_UMA(pcbe, 0x08, &TVRegVal);
    *pHPosition = TVRegVal;
    
    // 3. update V position offset Tx 09
    TV_I2CRead_BYTE_UMA(pcbe, 0x09, &TVRegVal);
    *pVPosition = TVRegVal;
    
    // Tx 1C [1] : Start Vertical Position [8]
    TV_I2CRead_BYTE_UMA(pcbe, 0x1C, &TVRegVal);
    TVRegVal &= 0x02;
    *pVPosition |= TVRegVal << 7;

    // Tx 1C [2] : Start Horiziontal Position [8]
    TV_I2CRead_BYTE_UMA(pcbe, 0x1C, &TVRegVal);
    TVRegVal &= 0x04;
    *pHPosition |= TVRegVal << 6;
}

//**************************************************************************
//  cbGetTVCurPosition_1625_UMA
//     This function returns VT1625A current TV position register value 
//      IN :
//          PCBIOS_EXTENSION              
//      Out:
//          pHPosition  : Current H position reg value
//          pVPosition  : Current V position reg value
//**************************************************************************
VOID cbGetTVCurPosition_1625_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPosition, 
    OUT PULONG pVPosition)
{
    BYTE TVRegVal;
    
    if (!pHPosition || !pVPosition)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }

    // 1. update H position offset Tx 08
    TV_I2CRead_BYTE_UMA(pcbe, 0x08, &TVRegVal);
    *pHPosition = TVRegVal;
    
    // 3. update V position offset Tx 09
    TV_I2CRead_BYTE_UMA(pcbe, 0x09, &TVRegVal);
    *pVPosition = TVRegVal;
    
    // Tx 1C [3:1] : Start Vertical Position [10:8]
    TV_I2CRead_BYTE_UMA(pcbe, 0x1C, &TVRegVal);
    TVRegVal &= 0x0E;
    *pVPosition |= TVRegVal << 7;
}

//**************************************************************************
//  cbGetTVCurPosition_InTV_UMA
//     This function returns internal TV current TV position register value 
//        0 : leftmost position adjustment, X : rightmost position adjustment
//           |upmost      
//           |              
//           |              
//           |-- vposition 0x40~0x70 <-> Reg.4f=0x80~0xB0
//           |
//           |-- vposition 0x3f <-> Reg.4f=0
//           | 
//           |---vmiddle(vposition=0x38, Reg.4f=0x07)
//           |
//           |-- vposition 0~0x38 <-> Reg.4f = 0x3f~0x07
//           |
//           |
//           |____________middle______________rightmost
//        Hposition 0~0x0c <-> Reg.4b = 0x40~4c
//        Hposition default=0x0d <-> Reg.4b=0x01
//        Hposition 0x0d~0x38 <-> Reg.4b = 0x01~0x2a
//           
//      Vertical Position adjustment value range [0, X]
//        0 : downmost position adjustment,   X : upmost position adjustment
//      IN :
//          PCBIOS_EXTENSION              
//      Out:
//          pHPosition  : Current H position reg value
//          pVPosition  : Current V position reg value
//**************************************************************************
VOID cbGetTVCurPosition_InTV_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPosition, 
    OUT PULONG pVPosition)
{
    BYTE TVRegVal;
    
    if (!pHPosition || !pVPosition)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }

    // 1. update H position offset 0x4a,0x4b, now we only cover 0x4b adjust
    TVRegVal = InTV_Read_Byte_UMA(pcbe, 0x4b) & 0x7f;
    if (TVRegVal == 0)
    {
        TVRegVal = 0x40; //when adjusted leftward,0x0 has the same position as 0x40
    }
    // Rightward adjust, 0x4b value varies from 0x01~0x2a, but we cover 0x01~0x0E
    if (TVRegVal > 0x01 && TVRegVal <= 0x0e)
    {
        *pHPosition = TVRegVal + 0x6 - 0x01; //0xd is default h position
    }
    // Leftward adjust, 0x4b value varies from 0x40~0x4c, now we cover 0x40~0x45;
    else if (TVRegVal <= 0x45 && TVRegVal >= 0x40)
    {
        *pHPosition = 0x45 - TVRegVal;
    }
    else
    {
        *pHPosition = 0x6; //default position value.
    }
    // 2. update V position offset 0x4e, 0x4f,now we only cover 0x4f adjust
    TVRegVal = InTV_Read_Byte_UMA(pcbe, 0x4f);
    *pVPosition = 0x0F - TVRegVal; //0x0F is the max v position

}

//**************************************************************************
//  cbSetTVPosition_1622A_UMA
//     This function updates VT1622A TV position   
//      Horizontal Position adjustment value range [0, X] 
//        0 : leftmost position adjustment, X : rightmost position adjustment
//           |upmost
//           |
//           |
//           | middle
//           |
//           |
//           |
//           |____________middle______________rightmost
//      Vertical Position adjustment value range [0, X]
//        0 : downmost position adjustment,   X : upmost position adjustment
//      IN :
//          PCBIOS_EXTENSION              
//          HPositionAdj  : H position adjustment level
//          VPositionAdj  : V position adjustment level
//**************************************************************************
#define MAX_1622A_H_POSITION 0x200

CBIOS_STATUS cbSetTVPosition_1622A_UMA(
    PCBIOS_EXTENSION pcbe, 
    IN ULONG HPositionAdj, 
    IN ULONG VPositionAdj)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG  HPositionMax, VPositionMax;
    BYTE   TVRegVal;
    
    status = cbGetTVPositionMaxRange_UMA(pcbe, &HPositionMax, &VPositionMax);
    
    if (HPositionAdj > HPositionMax || VPositionAdj > VPositionMax)
    {
        return CBIOS_ER_INVALID_PARAMETER;
    }
    //                  Position adjust range
    //           |upmost
    //           |
    //           |
    //           | middle
    //           |
    //           |
    //           |
    //           |____________middle______________rightmost
    //                     default position
    // 1. Calculate new H/V Position according to H / V position adjustment

    // Caution! Now we just handle H right side limit & V downwards limit
    // for H left side limit & V upwards limit do not handle since we haven't 
    // see such limitation case
    if ( (LONG)pcbe->tvparameter.DefaultHPosition <= (MAX_1622A_H_POSITION - (LONG)(HPositionMax >> 1)) )
    {
        // if there is enough room for us to adjust H position
        // then keep default H position as middle value
        // rightmost =< -MAX_________________defualt______________leftmost
        pcbe->tvparameter.CurHPosition = pcbe->tvparameter.DefaultHPosition -(LONG)(HPositionMax >> 1) + HPositionAdj;
    }
    else
    {
        // rightmost =< -MAX___________________________defualt____leftmost
        pcbe->tvparameter.CurHPosition = MAX_1622A_H_POSITION - HPositionMax + HPositionAdj;
    }

    if ((LONG)pcbe->tvparameter.DefaultVPosition >= ((LONG)(VPositionMax >> 1) - 1))
    {
        // if there is enough room for us to adjust V position
        // then keep default V position as middle value
        // Bottommost =< 0_________________defualt______________MAX <= upmost
        pcbe->tvparameter.CurVPosition = pcbe->tvparameter.DefaultVPosition - (LONG)(VPositionMax>>1) + VPositionAdj;
    }
    else
    {
         // else keep RegValue == 0 as H position adjust level 0
         // Bottommost =< 0___________________________defualt____MAX = upmost
         pcbe->tvparameter.CurVPosition = VPositionAdj;
    }

    if (pcbe->tvparameter.CurHPosition < 0)
    {
        pcbe->tvparameter.CurHPosition = 0;
    }
    if (pcbe->tvparameter.CurVPosition < 0)
    {
        pcbe->tvparameter.CurVPosition = 0;
    }

    // 2. update H position offset Tx 08
    TV_I2CWRITE_BYTE_UMA(pcbe, 0x08, (BYTE)(pcbe->tvparameter.CurHPosition & 0xFF));

    // 3. update V position offset Tx 09
    TV_I2CWRITE_BYTE_UMA(pcbe, 0x09, (BYTE)(pcbe->tvparameter.CurVPosition & 0xFF));

    // Tx 1C [2] : Start Horizontal Position [8]
    // Tx 1C [1] : Start Vertical Position [8]
	TV_I2CRead_BYTE_UMA(pcbe, 0x1C, &TVRegVal);
    TVRegVal &= 0xF9;
    TVRegVal |= (pcbe->tvparameter.CurHPosition & 0x100) >> 6;
    TVRegVal |= (pcbe->tvparameter.CurVPosition & 0x100) >> 7;
    TV_I2CWRITE_BYTE_UMA(pcbe, 0x1C, TVRegVal);

    return CBIOS_OK;
}

//**************************************************************************
//  cbSetTVPosition_1625_UMA
//     This function updates VT1625A TV position   
//      Horizontal Position adjustment value range [0, X] 
//        0 : leftmost position adjustment, X : rightmost position adjustment
//           |upmost
//           |
//           |
//           | middle
//           |
//           |
//           |
//           |____________middle______________rightmost
//      Vertical Position adjustment value range [0, X]
//        0 : downmost position adjustment,   X : upmost position adjustment
//      IN :
//          PCBIOS_EXTENSION              
//          HPositionAdj  : H position adjustment level
//          VPositionAdj  : V position adjustment level
//**************************************************************************
CBIOS_STATUS cbSetTVPosition_1625_UMA(
    PCBIOS_EXTENSION pcbe, 
    IN ULONG HPositionAdj, 
    IN ULONG VPositionAdj)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG  HPositionMax, VPositionMax;
    BYTE   TVRegVal;
    
    status = cbGetTVPositionMaxRange_UMA(pcbe, &HPositionMax, &VPositionMax);
    
    if (HPositionAdj > HPositionMax || VPositionAdj > VPositionMax)
    {
        return CBIOS_ER_INVALID_PARAMETER;
    }
    //                  Position adjust range
    //           |upmost
    //           |
    //           |
    //           | middle
    //           |
    //           |
    //           |
    //           |____________middle______________rightmost
    //                     default position
    // 1. Calculate new H/V Position according to H / V position adjustment

    // Caution! Now we just handle H right side limit & V downwards limit
    // for H left side limit & V upwards limit do not handle since we haven't 
    // see such limitation case
    if ((LONG)pcbe->tvparameter.DefaultHPosition >= ((LONG)(HPositionMax >> 1) - 1))
    {
        // if there is enough room for us to adjust H position
        // then keep default H position as middle value
        // rightmost =< 0_________________defualt______________MAX <= leftmost
        pcbe->tvparameter.CurHPosition = pcbe->tvparameter.DefaultHPosition + (LONG)(HPositionMax>>1) - HPositionAdj;
    }
    else
    {
        // rightmost =< 0___________________________defualt____MAX = leftmost
        pcbe->tvparameter.CurHPosition = HPositionMax - HPositionAdj;
    }

    if ((LONG)pcbe->tvparameter.DefaultVPosition >= ((LONG)(VPositionMax >> 1) - 1))
    {
        // if there is enough room for us to adjust V position
        // then keep default V position as middle value
        // Bottommost =< 0_________________defualt______________MAX <= upmost
        pcbe->tvparameter.CurVPosition = pcbe->tvparameter.DefaultVPosition - (LONG)(VPositionMax>>1) + VPositionAdj;
    }
    else
    {
         // else keep RegValue == 0 as H position adjust level 0
         // Bottommost =< 0___________________________defualt____MAX = upmost
         pcbe->tvparameter.CurVPosition = VPositionAdj;
    }

    if (pcbe->tvparameter.CurHPosition < 0)
    {
        pcbe->tvparameter.CurHPosition = 0;
    }
    if (pcbe->tvparameter.CurVPosition < 0)
    {
        pcbe->tvparameter.CurVPosition = 0;
    }

    // 2. update H position offset Tx 08
    TV_I2CWRITE_BYTE_UMA(pcbe, 0x08, (BYTE)(pcbe->tvparameter.CurHPosition & 0xFF));

    // 3. update V position offset Tx 09
    TV_I2CWRITE_BYTE_UMA(pcbe, 0x09, (BYTE)(pcbe->tvparameter.CurVPosition & 0xFF));

    // Tx 1C [3:1] : Start Vertical Position [10:8]
    TV_I2CRead_BYTE_UMA(pcbe, 0x1C, &TVRegVal);
    TVRegVal &= 0xF1;
    TVRegVal |= (pcbe->tvparameter.CurVPosition & 0x700) >> 7;    
    TV_I2CWRITE_BYTE_UMA(pcbe, 0x1C, TVRegVal);  

    return CBIOS_OK;
}

//**************************************************************************
//  cbSetTVPosition_InTV_UMA
//     This function updates internal TV position   
//      Horizontal Position adjustment value range [0, X] 
//        0 : leftmost position adjustment, X : rightmost position adjustment
//           |upmost      
//           |              
//           |              
//           |-- vposition 0x40~0x70 <-> Reg.4f=0x80~0xB0
//           |
//           |-- vposition 0x3f <-> Reg.4f=0
//           | 
//           |---vmiddle(vposition=0x38, Reg.4f=0x07)
//           |
//           |-- vposition 0~0x38 <-> Reg.4f = 0x3f~0x07
//           |
//           |
//           |____________middle______________rightmost
//        Hposition 0~0x0c <-> Reg.4b = 0x40~4c
//        Hposition default=0x0d <-> Reg.4b=0x01
//        Hposition 0x0d~0x38 <-> Reg.4b = 0x01~0x2a
//           
//      Vertical Position adjustment value range [0, X]
//        0 : downmost position adjustment,   X : upmost position adjustment
//      IN :
//          PCBIOS_EXTENSION              
//          HPositionAdj  : H position adjustment level
//          VPositionAdj  : V position adjustment level
//**************************************************************************
CBIOS_STATUS cbSetTVPosition_InTV_UMA(
    PCBIOS_EXTENSION pcbe, 
    IN ULONG HPositionAdj, 
    IN ULONG VPositionAdj)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG  HPositionMax, VPositionMax;
    
    status = cbGetTVPositionMaxRange_UMA(pcbe, &HPositionMax, &VPositionMax);
    
    if (HPositionAdj > HPositionMax || VPositionAdj > VPositionMax)
    {
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    pcbe->tvparameter.CurHPosition = HPositionAdj;
    pcbe->tvparameter.CurVPosition = VPositionAdj;
    if (pcbe->tvparameter.CurHPosition < 0)
    {
        pcbe->tvparameter.CurHPosition = 0;
    }
    if (pcbe->tvparameter.CurVPosition < 0)
    {
        pcbe->tvparameter.CurVPosition = 0;
    }
    
    // 1. set horizontal position adjustment
    if (pcbe->tvparameter.CurHPosition < pcbe->tvparameter.DefaultHPosition)
    {
        InTV_Write_Bits_UMA(pcbe, 0x4b, TV_HPOSITION_LEFT_BOUNDARY_REG_VALUE - (BYTE)pcbe->tvparameter.CurHPosition, 0x7f);
    }
    else if (pcbe->tvparameter.CurHPosition == pcbe->tvparameter.DefaultHPosition)
    {
        InTV_Write_Bits_UMA(pcbe, 0x4b, TV_HPOSITION_DEFAULT_REG_VALUE, 0x7f);
    }
    else
    {
        InTV_Write_Bits_UMA(pcbe, 0x4b, (BYTE)(pcbe->tvparameter.CurHPosition - pcbe->tvparameter.DefaultHPosition + TV_HPOSITION_DEFAULT_REG_VALUE), 0x7f);
    }
    // 2. set vertical position adjustment
    // Downward

    InTV_Write_Byte_UMA(pcbe, 0x4f, (BYTE)(VPositionMax - pcbe->tvparameter.CurVPosition));
    
    return status;
}

//**************************************************************************
// cbUpdateTVparameter
//     This function updates TV parameter structure to init Current & Defult
//  Saturation &  Hue value. This function is called when TV register reaload
//      1. TV / HDTV setmode
//      2. TV contraction reset
//   IN : 
//      NONE
//   Out: 
//      NONE
//**************************************************************************
CBIOS_STATUS cbUpdateTVparameter(PCBIOS_EXTENSION pcbe)
{
    CBIOS_STATUS status = CBIOS_OK;
    BYTE TVRegData;
    BYTE TVRegIndexTbl[3];
    ULONG encodertype;
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    //------------------------------------------------
    //---1. Update TV Contrast adjust parameter
    //------------------------------------------------
    status = cbGetContrastRegIndex(pcbe, TVRegIndexTbl, sizeof(TVRegIndexTbl) / sizeof(BYTE));
    
    if (status == CBIOS_OK && encodertype != IN_TV)
    {
        status = TV_I2CRead_BYTE_UMA(pcbe, TVRegIndexTbl[0], &TVRegData); 
        pcbe->tvparameter.CurContrast = TVRegData;
        pcbe->tvparameter.DefaultContrast = TVRegData;
    }
    else
    {
        // 0x54 & 0x55[0]
        TVRegData = InTV_Read_Byte_UMA(pcbe, TVRegIndexTbl[1]) & BIT0;
        pcbe->tvparameter.CurContrast = InTV_Read_Byte_UMA(pcbe, TVRegIndexTbl[0]) | (TVRegData<<8);
        pcbe->tvparameter.DefaultContrast = InTV_Read_Byte_UMA(pcbe, TVRegIndexTbl[0]) | (TVRegData<<8);
    }
    
    
    //------------------------------------------------
    //---2. Update TV Saturation adjust parameter
    //------------------------------------------------
    // set default saturation level as 1st TV enc register value
    status = cbGetSaturationRegIndex(pcbe, TVRegIndexTbl, sizeof(TVRegIndexTbl) / sizeof(BYTE));

    if (status == CBIOS_OK && encodertype != IN_TV)
    {
        status = TV_I2CRead_BYTE_UMA(pcbe, TVRegIndexTbl[0], &TVRegData); 
        pcbe->tvparameter.CurSaturation = TVRegData;
        pcbe->tvparameter.DefaultSaturation = TVRegData;
    }
    else
    {
        // 0x50 & 0x51[0]
        TVRegData = InTV_Read_Byte_UMA(pcbe, TVRegIndexTbl[1]) & BIT0;
        pcbe->tvparameter.CurSaturation = InTV_Read_Byte_UMA(pcbe, TVRegIndexTbl[0]) | (TVRegData<<8);
        pcbe->tvparameter.DefaultSaturation = InTV_Read_Byte_UMA(pcbe, TVRegIndexTbl[0]) | (TVRegData<<8);
    }

    //------------------------------------------------
    //---3. Update TV Hue adjust  parameter
    //---   For YUV case we read directly from Reg
    //---   For other case we set Hue to zero level
    //------------------------------------------------
    if (((pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev) & S3_TV) &&
        (pcbe->sPad_7.TVOutType & (TV_SVideo1 | TV_SVideo2 | TV_CVBS)))
    {
        if (encodertype == VT1625_6 || encodertype == VT1625A_6A)
        {
            // TV encoder output is SVIDEO or COMPASITE adjust Hue value directly (YUV)
            // Update new Hue 
            // 0x10 Hue [7:0]
            BYTE Reg10, Reg11;
            cbGetHueRegIndex_1625_UMA(pcbe,  TVRegIndexTbl, sizeof(TVRegIndexTbl) / sizeof(BYTE));
            status = TV_I2CRead_BYTE_UMA(pcbe, TVRegIndexTbl[0], &Reg10);
    
            // 0x11 Hue [10:8]
            if (status == CBIOS_OK && TVRegIndexTbl[1] != 0)
            {
                status = TV_I2CRead_BYTE_UMA(pcbe, TVRegIndexTbl[1], &Reg11);
                if (status == CBIOS_OK)
                {
                    // Reg11 [2:0] : HueAngle [10:8]
                    // Reg10 [7:0] : HueAngle [7:0]
                    Reg11 &= 0x07;
                    pcbe->tvparameter.CurHueAngle = ((ULONG)Reg11 << 8 )| (ULONG)Reg10 ; 
                    pcbe->tvparameter.DefaultHueAngle = pcbe->tvparameter.CurHueAngle;
                }            
            }
        }
        else if (encodertype == IN_TV)
        {
            BYTE hueLow, hueHigh;
            cbGetHueRegIndex(pcbe,  TVRegIndexTbl, sizeof(TVRegIndexTbl) / sizeof(BYTE));
            hueLow = InTV_Read_Byte_UMA(pcbe, TVRegIndexTbl[0]);
    
            // 0x61 Hue [10:8]
            if (status == CBIOS_OK && TVRegIndexTbl[1] != 0)
            {
                hueHigh = InTV_Read_Byte_UMA(pcbe, TVRegIndexTbl[1]);
                if (status == CBIOS_OK)
                {
                    // hueHigh [2:0] : HueAngle [10:8]
                    // hueLow [7:0] : HueAngle [7:0]
                    hueHigh &= 0x07;
                    pcbe->tvparameter.CurHueAngle = ((ULONG)hueHigh << 8 )| (ULONG)hueLow ; 
                    pcbe->tvparameter.DefaultHueAngle = pcbe->tvparameter.CurHueAngle;
                }            
            }
        }
    }
    else
    {
        // for TV / HDTV YPrPb / RGB case we set Hue angle to 0
        // (middle of the CosLut_UMA SinLut_UMA table)
        // according to angle index means HueLevelNum / 2 
        pcbe->tvparameter.CurHueAngle = HueLevelNum / 2;
        pcbe->tvparameter.DefaultHueAngle = HueLevelNum / 2;
    
    }
    
    //-----------------------------------------------
    //---4. Update TV Brightness adjust parameter
    //-----------------------------------------------
    status = cbGetBrightnessRegIndex(pcbe, TVRegIndexTbl, sizeof(TVRegIndexTbl) / sizeof(BYTE));

    if (status == CBIOS_OK && encodertype != IN_TV)
    {
        status = TV_I2CRead_BYTE_UMA(pcbe, TVRegIndexTbl[0], &TVRegData); 
        pcbe->tvparameter.CurBrightness = TVRegData;
        pcbe->tvparameter.DefaultBrightness = TVRegData;
    }
    else
    {
        // 0x56[7] & 0x57[6:0]
        TVRegData = InTV_Read_Byte_UMA(pcbe, TVRegIndexTbl[0]) & BIT7;
        pcbe->tvparameter.CurBrightness = ((InTV_Read_Byte_UMA(pcbe, TVRegIndexTbl[1]) & 0x7f)<<1) | (TVRegData>>7);
        pcbe->tvparameter.DefaultBrightness = ((InTV_Read_Byte_UMA(pcbe, TVRegIndexTbl[1]) & 0x7f)<<1) | (TVRegData>>7);
    }

    //-----------------------------------------------
    //---5. Update TV position adjustment parameter 
    //----------------------------------------------
    if (status == CBIOS_OK)
    {
        status =cbGetTVCurPosition_UMA(pcbe, 
                                   &pcbe->tvparameter.CurHPosition, 
                                   &pcbe->tvparameter.CurVPosition);
        pcbe->tvparameter.DefaultHPosition = pcbe->tvparameter.CurHPosition;
        pcbe->tvparameter.DefaultVPosition = pcbe->tvparameter.CurVPosition;
    }    

    //--------------------------------------------------
    //---6. Update TV H/V contraction level adjustment parameter
    //---   when reload three levels of contraction table
    //---   set Cur H contraction level as 0x02
    //---   set Cur V contraction level as contraction level in scratchpad
    //--------------------------------------------------

    if (status == CBIOS_OK)
    {
        if (encodertype != IN_TV)
        {
            pcbe->tvparameter.DefaultHContraction = 0x02;
            pcbe->tvparameter.DefaultVContraction = TV_V_NORMAL;
            pcbe->tvparameter.CurHContraction = 0x02;
            pcbe->tvparameter.CurVContraction = pcbe->sPad_5.TV_Contraction;
        }
        else // Internal TV
        {
            pcbe->tvparameter.DefaultHContraction = 0x0;
            pcbe->tvparameter.DefaultVContraction = TV_V_NORMAL;
            pcbe->tvparameter.CurHContraction = 0x0;
            pcbe->tvparameter.CurVContraction = TV_V_NORMAL;
        }
    }

    //---------------------------------------------------
    //---7. Update TV flicker filter / adaptive flicker filter status
    //---   Now only support VT1625  
    //---------------------------------------------------
    if (status == CBIOS_OK)
    {  
        if (encodertype == VT1625A_6A || encodertype == VT1625_6)
        {
            BYTE bReg03;
            TV_I2CRead_BYTE_UMA(pcbe, 0x03, &bReg03);
            // VT1625 Reg03[4] Indicates flicker filter on off status
            // this is a wrong value just to be consistent with Old TV share
            // behavior 
            // when bypass Luma filter Reg03[4] == 1 adaptive flicker filter
            // when disable bypass luma filter       normal   flicker filter
            if (bReg03 & BIT4)
            {
                pcbe->tvparameter.CurDeflickerFliterStatus = ENABLE_ADAPTIVE_FLICKERFILTER;
                pcbe->tvparameter.DefaultDeflickerFliterStatus = ENABLE_ADAPTIVE_FLICKERFILTER;
            }
            else
            {
                pcbe->tvparameter.CurDeflickerFliterStatus = ENABLE_NORM_FLICKERFILTER;
                pcbe->tvparameter.DefaultDeflickerFliterStatus = ENABLE_NORM_FLICKERFILTER;
            }
        }
        else if (encodertype == IN_TV)
        {
            cbDbgPrint(1, "Internal TV has no such feature,need to add return value!\n");
            pcbe->tvparameter.CurDeflickerFliterStatus = 0x2;
            pcbe->tvparameter.DefaultDeflickerFliterStatus = 0x2;
            status = CBIOS_ER_NOT_YET_IMPLEMENTED;
        }
    }
    return status;
}


//=============================================================================
// below is new sub functions
//=============================================================================
//----------------------------------------------------------------------------
// cbHDTVIsVBIOSSupportMode 
//      This function check if vbios offers HDTV timing table for the given 
// resolution.
//  For 720P now vbios supports  640 x 480, 800 x 600, 1024 x 768, 1280 x 720
//  For 1080I now vbios supports 640 x 480, 800 x 600, 1024 x 768, 1920 x 1080
//  IN :
//      H_Res :
//      V_Res : 
//  OUT :
//      function status 
//      TRUE : H / V in VBIOS support Mode
//     FALSE : H / V not in VBIOS support Mode
//----------------------------------------------------------------------------
BOOL cbHDTVIsVBIOSSupportMode(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res, 
    IN DWORD V_Res)
{
    DWORD const*VBIOSHDTVSupportModeTbl;
    DWORD ModeTblNum, i;
    
    switch (pcbe->sPad_11.HDTV_Type)
    {
    case HDTV720P:         
        VBIOSHDTVSupportModeTbl = HDTVResolution720P;
        ModeTblNum = HDTV720P_RESOLUTION_NUM;
        break;

    case HDTV1080I:  
        VBIOSHDTVSupportModeTbl = HDTVResolution1080I;
        ModeTblNum = HDTV1080I_RESOLUTION_NUM;
        break;

    default:
        return FALSE;
    }

    for (i = 0; i < ModeTblNum; i++)
    {
        if (H_Res == VBIOSHDTVSupportModeTbl[i<<1]
          && V_Res == VBIOSHDTVSupportModeTbl[(i<<1) + 1])
        {
            return TRUE;
        }
    }
      
    return FALSE;
}

//----------------------------------------------------------------------------
//  cbTransTVandHDTVTimingTbl
//     This function transfer TV / HDTV timing table on GFX side to generic timing table
//  which CBIOS can recognize. TVT1625 TV / HDTV GFX table are of the same data structure
//  since VT1625 and VT1622 differs in their timing table structure. so we need to handle them separately
//  IN :
//      pTvTimingTbl : tv timing table pointer
//      rRateX100    : refresh rate info
//  OUT :
//      pTimingTbl   : timing table pointer to be returned
//----------------------------------------------------------------------------
BOOL cbTransTVandHDTVTimingTbl(
    PCBIOS_EXTENSION pcbe,
    IN PWORD pTvTimingTbl,
    IN DWORD rRateX100,
    OUT PGFXTimingTable pTimingTbl
)
{
    ULONG   encodertype;
    PBYTE p1622ATvTimingTbl = (PBYTE) pTvTimingTbl;
    WORD dwRetV=0, i;
    
    if (!pTvTimingTbl || !pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return FALSE;
    }

    // TV / HDTV timing not interlace on GFX side
    pTimingTbl->Interlaced = PROGRESSIVE;

    switch (encodertype)
    {
    case VT1625_6:
    case VT1625A_6A:
    case IN_TV:
        // horizontal
        pTimingTbl->HTotal       = pTvTimingTbl[0];
        pTimingTbl->HDisEnd      = pTvTimingTbl[1];
        pTimingTbl->HBlankStart  = pTvTimingTbl[2];
        pTimingTbl->HBlankEnd    = pTvTimingTbl[3];
        pTimingTbl->HSyncStart   = pTvTimingTbl[4];
        pTimingTbl->HSyncEnd     = pTvTimingTbl[5];

        // vertical
        pTimingTbl->VTotal       = pTvTimingTbl[6];
        pTimingTbl->VDisEnd      = pTvTimingTbl[7];
        pTimingTbl->VBlankStart  = pTvTimingTbl[8];
        pTimingTbl->VBlankEnd    = pTvTimingTbl[9];
        pTimingTbl->VSyncStart   = pTvTimingTbl[10];
        pTimingTbl->VSyncEnd     = pTvTimingTbl[11];

        pTimingTbl->rRateX100 = rRateX100;

        // VT1625 TV / HDTV use TV encoder clock as IGA pixel clock
        // so IGA PLL clock setting is useless
        pTimingTbl->vPLL = pTimingTbl->HTotal * pTimingTbl->HTotal * 60;
        break;

    case VT1622A:
    case VT1623_3A:
        // horizontal
        dwRetV = p1622ATvTimingTbl[1] + 5;  // CR00
        pTimingTbl->HTotal       = dwRetV * 8;
        
        dwRetV = p1622ATvTimingTbl[2] + 1;  // CR01
        pTimingTbl->HDisEnd      = dwRetV * 8;
        
        dwRetV = p1622ATvTimingTbl[3] + 1;  // CR02
        pTimingTbl->HBlankStart  = dwRetV * 8;
        
        dwRetV = (p1622ATvTimingTbl[3]);    
        i = (p1622ATvTimingTbl[14] & 0x20) << 1;    // CR33[5], CR05[7], CR03[4:0]
        i += (p1622ATvTimingTbl[6] & 0x80) >> 2;
        i += (p1622ATvTimingTbl[4] & 0x1F);
        while((dwRetV&0x7f)!=i) dwRetV++;
        dwRetV++;
        pTimingTbl->HBlankEnd = dwRetV * 8;
        
        dwRetV = (p1622ATvTimingTbl[14] & 0x10) >> 4;   // CR33[4], CR04
        dwRetV = dwRetV*0x100 + p1622ATvTimingTbl[5];
        pTimingTbl->HSyncStart   = dwRetV * 8;

        dwRetV = p1622ATvTimingTbl[5];  // CR04, CR05[4:0]
        i = p1622ATvTimingTbl[6]&0x1F;
        while((dwRetV&0x1F)!=i) dwRetV++;
        pTimingTbl->HSyncEnd = dwRetV * 8;

        // vertical
        dwRetV = 0; // CR35[0], CR07[5], CR07[0], CR06
        dwRetV = dwRetV*2 + ((p1622ATvTimingTbl[8]&0x20) >> 5);
        dwRetV = dwRetV*2 + (p1622ATvTimingTbl[8]&0x01);
        dwRetV = dwRetV*0x100 + p1622ATvTimingTbl[7];
        dwRetV += 2;
        pTimingTbl->VTotal = dwRetV;

        dwRetV = 0; // CR35[2], CR07[6], CR07[1], CR[12]
        dwRetV = dwRetV*2 + ((p1622ATvTimingTbl[8]&0x40) >> 6);
        dwRetV = dwRetV*2 + ((p1622ATvTimingTbl[8]&0x02) >> 1);
        dwRetV = dwRetV*0x100 + p1622ATvTimingTbl[11];
        dwRetV += 1;
        pTimingTbl->VDisEnd = dwRetV;

        
        dwRetV = 0; // CR35[3], CR09[5], CR07[3], CR15
        dwRetV = dwRetV*2 + ((p1622ATvTimingTbl[9]&0x20) >> 5);
        dwRetV = dwRetV*2 + ((p1622ATvTimingTbl[8]&0x08) >> 3);
        dwRetV = dwRetV*0x100 + p1622ATvTimingTbl[12];
        dwRetV += 1;
        pTimingTbl->VBlankStart = dwRetV;
        
        dwRetV = 0; // CR35[3], CR09[5], CR07[3], CR15
        dwRetV = dwRetV*2 + ((p1622ATvTimingTbl[9]&0x20) >> 5);
        dwRetV = dwRetV*2 + ((p1622ATvTimingTbl[8]&0x08) >> 3);
        dwRetV = dwRetV*0x100 + p1622ATvTimingTbl[12];
        dwRetV += 1;
        i = p1622ATvTimingTbl[13];  // CR16
        while((dwRetV&0xFF)!=i) dwRetV++;
        dwRetV++;
        pTimingTbl->VBlankEnd = dwRetV;
        
        dwRetV = 0; // CR35[1], CR07[7], CR07[2], CR10
        dwRetV = dwRetV*2 + ((p1622ATvTimingTbl[8]&0x80) >> 7);
        dwRetV = dwRetV*2 + ((p1622ATvTimingTbl[8]&0x04) >> 2);
        dwRetV = dwRetV*0x100 + p1622ATvTimingTbl[10];
        dwRetV++;
        pTimingTbl->VSyncStart = dwRetV;

        dwRetV = 0; // CR35[1], CR07[7], CR07[2], CR10
        dwRetV = dwRetV*2 + ((p1622ATvTimingTbl[8]&0x80) >> 7);
        dwRetV = dwRetV*2 + ((p1622ATvTimingTbl[8]&0x04) >> 2);
        dwRetV = dwRetV*0x100 + p1622ATvTimingTbl[10];
        i = 0; // CR11
        while((dwRetV&0x0F)!=i) dwRetV++;
        dwRetV++;
        pTimingTbl->VSyncEnd = dwRetV;
        
        pTimingTbl->rRateX100 = rRateX100;

        // VT1622A TV use TV encoder clock as IGA pixel clock
        // so IGA PLL clock setting is useless
        pTimingTbl->vPLL = pTimingTbl->HTotal * pTimingTbl->HTotal * 60;
        break;
        
    default:
        return FALSE;
    }

    // TV / HDTV H V polarity default all positive 
    pTimingTbl->HPolarity = CBIOS_POSITIVE;
    pTimingTbl->VPolarity = CBIOS_POSITIVE;

    // set aspect ratio to NONE
    pTimingTbl->AspectRatio = CBIOS_NONE;
    // TV / HDTV timing set VSyncOffset to zero
    pTimingTbl->VSyncOffset = 0;
    
    return TRUE;
}


//--------------------------------------------------------------------------
//cbGetVBIOSTVGFXTimingTable
//   Get TV timing table for GFX side according to H_Res & V_Res parameters
//  IN :
//      H_Res   : H resolution
//      V_Res   : V resolution
//  OUT:
//      pTimingTbl   : GFX side timing table to be filled
//      Function Status
//--------------------------------------------------------------------------
BOOL cbGetVBIOSTVGFXTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN WORD  H_Res,
    IN WORD  V_Res,
    OUT PGFXTimingTable pTimingTbl)
{
    PTVTBLDATA pTvTbl = NULL;               // get TV timing and func
    ULONG encodertype;
    PMapTVModeIndex pTvModeIndexTbl = TblMapTVModeIndex;
    WORD H_cur = 0xffff, V_cur = 0xffff;    // current H, V size, default set as max to record available TV mode

    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    // check if VCP info is NULL
    if (pcbe->pVCPInfo == NULL)
    {
        return FALSE;
    }
    // only VCP 1.1 and above have valid TV table
    if (pcbe->pVCPInfo->version < VCP1_1)
    {
        return FALSE;
    }

    // to judge if internal tv, we get tv encoder type here
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return FALSE;
    }
    // get TV mode table ptr
    if ( encodertype == IN_TV )
    {    
        if( (pcbe->pVCPInfo->version >= VCP1_5) &&
            (pcbe->pVCPInfo->InTVModeTbl != 0) )
        {
            pTvTbl = (PTVTBLDATA)(pcbe->RomData + pcbe->pVCPInfo->InTVModeTbl);
        }
        else //we must return here, otherwise, pTvTbl will be null pointer for later use
        {
            return FALSE;
        }
    }
    else
    {
        //select different table according to TV contraction level
        switch (pcbe->sPad_5.TV_Contraction)
        {
        case TV_V_NORMAL:
            if (pcbe->pVCPInfo->TVModeTbl != 0)
            {
                pTvTbl = (PTVTBLDATA)(pcbe->RomData + pcbe->pVCPInfo->TVModeTbl);
            }
            else
            {
                return FALSE;
            }
            break;
        case TV_V_FIT:
            if (pcbe->pVCPInfo->TVModeFitTbl != 0)
            {
                pTvTbl = (PTVTBLDATA)(pcbe->RomData + pcbe->pVCPInfo->TVModeFitTbl);
            }
            else
            {
                return FALSE;
            }
            break;
        case TV_V_OVER:
            if (pcbe->pVCPInfo->TVModeOverTbl != 0)
            {
                pTvTbl = (PTVTBLDATA)(pcbe->RomData + pcbe->pVCPInfo->TVModeOverTbl);
            }
            else
            {
                return FALSE;
            }
            break;

        default:
            cbDbgPrint(0, "TV contraction level wrong! Can not find TV timing table\n");
            ASSERT(0);
            return FALSE;
        }
    }

    // get TV mode index according to resolution
    // Search closest TV Mode Index
    for (; pTvModeIndexTbl->VesaInfo.HSize != 0xFFFF; pTvModeIndexTbl++)
    {
        if ( (H_Res <= pTvModeIndexTbl->VesaInfo.HSize) && (pTvModeIndexTbl->VesaInfo.HSize <= H_cur) &&
            (V_Res <= pTvModeIndexTbl->VesaInfo.VSize) && (pTvModeIndexTbl->VesaInfo.VSize <= V_cur) )
        {

            PTVTBLDATA pTmpTvTbl;
            // find TV func offset(TV encode) according to TV type (NTSC, PALM\ PAL)
            // get TV CRTC timing table value
            for (pTmpTvTbl=pTvTbl; pTmpTvTbl->tvModeIndex != 0xFF; pTmpTvTbl++)
            {
                if (pTmpTvTbl->tvModeIndex == pTvModeIndexTbl->TvModeIndex)
                {
                    if ( (NTSC == pcbe->sPad_8.TV_Type)
                        || (NTSCJP == pcbe->sPad_8.TV_Type)
                        || (PALM == pcbe->sPad_8.TV_Type) ) // PALM is base on NTSC to adjust
                    {
                        if (0 != pTmpTvTbl->tvNTSCTimingOffset)
                        {
                            // found closer TV mode, record it
                            H_cur = pTvModeIndexTbl->VesaInfo.HSize;
                            V_cur = pTvModeIndexTbl->VesaInfo.VSize;
                            cbTransTVandHDTVTimingTbl(pcbe, (PWORD)(pcbe->RomData + pTmpTvTbl->tvNTSCTimingOffset), 6000, pTimingTbl);
                        }
                    }
                    else
                    {
                        if (0 != pTmpTvTbl->tvPALTimingOffset)
                        {
                            // found closer TV mode, record it
                            H_cur = pTvModeIndexTbl->VesaInfo.HSize;
                            V_cur = pTvModeIndexTbl->VesaInfo.VSize;
                            cbTransTVandHDTVTimingTbl(pcbe, (PWORD)(pcbe->RomData + pTmpTvTbl->tvPALTimingOffset), 5000, pTimingTbl);
                        }
                    }
                }
            } // for tv mode table

        }
    } // for tv mode index table

    if (0xffff == H_cur)
    {
        // If there is no available mode, return FALSE
        cbDbgPrint(0, "Not support this TV mode now!!!");
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

//--------------------------------------------------------------------------
// cbGetVBIOSTVEncoderTimingTable
//   Get TV timing table for TV encoder side according to H_Res & V_Res parameters
//  IN :
//      H_Res   : H resolution
//      V_Res   : V resolution
//  OUT:
//   ppTVFunc   : TV encoder timing table
//      Function Status
//--------------------------------------------------------------------------
BOOL cbGetVBIOSTVEncoderTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN WORD  H_Res,
    IN WORD  V_Res,
    OUT PTV_FUNCTION_VCP *ppTVFunc)
{
    BYTE modeIndex = 0;
    PTVTBLDATA pTvTbl = NULL;              // get TV timing and func
    ULONG encodertype;
    if (!ppTVFunc)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    // check if VCP info is NULL
    if (pcbe->pVCPInfo == NULL)
    {
        return FALSE;
    }
    // only VCP 1.1 and above have valid TV table
    if (pcbe->pVCPInfo->version < VCP1_1)
    {
        return FALSE;
    }

    //get TV mode index according to resolution
    {
        PMapTVModeIndex pTvModeIndexTbl = TblMapTVModeIndex;
        // Search TV Mode Index
        for (; pTvModeIndexTbl->VesaInfo.HSize != 0xFFFF; pTvModeIndexTbl++)
        {
            if ( (H_Res == pTvModeIndexTbl->VesaInfo.HSize)
                && (V_Res == pTvModeIndexTbl->VesaInfo.VSize) )
            {
                modeIndex = pTvModeIndexTbl->TvModeIndex;
                break;
            }
        }
        if (0 == modeIndex)
        {
            // If there is no match mode index, return FALSE
            cbDbgPrint(0, "Not support this TV mode index now!!!");
            return FALSE;
        }
    }
    // to judge if internal tv, we get tv encoder type here
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return FALSE;
    }

    if ( encodertype == IN_TV )
    {    
         if( (pcbe->pVCPInfo->version >= VCP1_5) &&
         (pcbe->pVCPInfo->InTVModeTbl != 0) )
         {
             pTvTbl = (PTVTBLDATA)(pcbe->RomData + pcbe->pVCPInfo->InTVModeTbl);
         }
         else //we must return here, otherwise, pTvTbl will be null pointer for later use
         {
             return FALSE;
         }
    }
    else
    {
    //select different table according to TV contraction level
        switch (pcbe->sPad_5.TV_Contraction)
        {
        case TV_V_NORMAL:
            if (pcbe->pVCPInfo->TVModeTbl != 0)
            {
                pTvTbl = (PTVTBLDATA)(pcbe->RomData + pcbe->pVCPInfo->TVModeTbl);
            }
            else
            {
                return FALSE;
            }
            break;
        case TV_V_FIT:
            if (pcbe->pVCPInfo->TVModeFitTbl != 0)
            {
                pTvTbl = (PTVTBLDATA)(pcbe->RomData + pcbe->pVCPInfo->TVModeFitTbl);
            }
            else
            {
                return FALSE;
            }
            break;
        case TV_V_OVER:
            if (pcbe->pVCPInfo->TVModeOverTbl != 0)
            {
                pTvTbl = (PTVTBLDATA)(pcbe->RomData + pcbe->pVCPInfo->TVModeOverTbl);
            }
            else
            {
                return FALSE;
            }
            break;
    
        default:
            cbDbgPrint(0, "TV contraction level wrong! Can not find TV timing table\n");
            ASSERT(0);
            return FALSE;
        }
    }

    // find TV func offset(TV encode) according to TV type (NTSC, PALM\ PAL)
    // get TV CRTC timing table value
    for (; pTvTbl->tvModeIndex != 0xFF; pTvTbl++)
    {
        if (pTvTbl->tvModeIndex == modeIndex)
        {
            if ( (NTSC == pcbe->sPad_8.TV_Type)
                || (NTSCJP == pcbe->sPad_8.TV_Type)
                || (PALM == pcbe->sPad_8.TV_Type) ) // PALM is base on NTSC to adjust
            {
                *ppTVFunc = (PTV_FUNCTION_VCP)(pcbe->RomData + pTvTbl->tvNTSCOffset);
            }
            else
            {
                *ppTVFunc = (PTV_FUNCTION_VCP)(pcbe->RomData + pTvTbl->tvPALOffset);
            }
            return TRUE;
        }
    }

    return FALSE;
}

//--------------------------------------------------------------------------
//cbGetVBIOSHDTVGFXTimingTable
//   Get HDTV timing table for GFX side according to H_Res & V_Res parameters
//  IN :
//      H_Res   : H resolution
//      V_Res   : V resolution
//  OUT:
//      pTimingTbl   : GFX side timing table to be filled
//      Function Status
//--------------------------------------------------------------------------
BOOL cbGetVBIOSHDTVGFXTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN WORD  H_Res,
    IN WORD  V_Res,
    OUT PGFXTimingTable pTimingTbl)
{
    BYTE modeIndex = 0;
    PHDTVENTRYTBL pHdtvTbl = NULL, pHdtvPatchEntry = NULL;
    PHDTVPatchTbl pHDTVPatchTbl = NULL;
    PBYTE pHDTVPatch = NULL;
    DWORD DES_H_Res = H_Res, DES_V_Res = V_Res;     // Taget H / V resolution ( disp timing)
    ULONG encodertype;
    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // check if VCP info is NULL
    if (pcbe->pVCPInfo == NULL)
    {
        return FALSE;
    }
    // only VCP 1.1 and above have valid TV table
    if (pcbe->pVCPInfo->version < VCP1_1)
    {
        return FALSE;
    }

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return FALSE;
    }
    // get HDTV timing and func
    if(pcbe->pVCPInfo->HDTVEntryTbl != 0)
    {
        pHdtvTbl = (PHDTVENTRYTBL)(pcbe->RomData + pcbe->pVCPInfo->HDTVEntryTbl);
        pHdtvPatchEntry = pHdtvTbl + 1;
    }
    else
    {
        //Invalid function call happened, this vbios may not support HDTV
        return FALSE;
    }
    // HDTV support all mode solution
    //  see if the mode exists in VBIOS support mode list 
    //  if yes then using VBIOS timing, if not 
    //  then use centering / panning on native mode timing
    if (!cbHDTVIsVBIOSSupportMode(pcbe, DES_H_Res, DES_V_Res))
    {
        switch (pcbe->sPad_11.HDTV_Type)
        {
        case HDTV720P:      
            DES_H_Res = 1280;                      
            DES_V_Res = 720;            
            break;

        case HDTV1080I:
            DES_H_Res = 1920;                      
            DES_V_Res = 1080;            
            break;

        default:
            return FALSE;
        }
    }
    
    //get TV mode index according to resolution
    {
        PMapTVModeIndex pTvModeIndexTbl = TblMapTVModeIndex;
        // Search TV Mode Index
        for (; pTvModeIndexTbl->VesaInfo.HSize != 0xFFFF; pTvModeIndexTbl++)
        {
            if ( (DES_H_Res == pTvModeIndexTbl->VesaInfo.HSize)
                && (DES_V_Res == pTvModeIndexTbl->VesaInfo.VSize) )
            {
                modeIndex = pTvModeIndexTbl->TvModeIndex;
                break;
            }
        }
        if (0 == modeIndex)
        {
            // If there is no match mode index, return FALSE
            cbDbgPrint(0, "Not support this TV mode index now!!!");
            return FALSE;
        }
    }
    
    switch (pcbe->sPad_11.HDTV_Type)
    {
    case HDTV720P:
        pHDTVPatchTbl = (PHDTVPatchTbl)(pcbe->RomData + pHdtvPatchEntry->HDTV720P);
        cbTransTVandHDTVTimingTbl(pcbe, (PWORD)(pcbe->RomData + pHdtvTbl->HDTV720PTimingOffset), 6000, pTimingTbl);
        break;

    case HDTV1080I:
        pHDTVPatchTbl = (PHDTVPatchTbl)(pcbe->RomData + pHdtvPatchEntry->HDTV1080I);
        cbTransTVandHDTVTimingTbl(pcbe, (PWORD)(pcbe->RomData + pHdtvTbl->HDTV1080ITimingOffset), 6000, pTimingTbl);
        break;

    default:
        return FALSE;
    }

    // find HDTV specific timing table according to mode
    for (; pHDTVPatchTbl->HDTVPatchIndex != 0xFF; pHDTVPatchTbl++)
    {
        if (pHDTVPatchTbl->HDTVPatchIndex == modeIndex)
        {
            pHDTVPatch = (pcbe->RomData + pHDTVPatchTbl->HDTVPatchOffset);
            pHDTVPatch += (*pHDTVPatch * 2) + 1;   // skip reg num & WORD define reg 
            // 1625 has following byte define tables in specific timing table, 
            //  while internal HDTV has not.
            if ( (encodertype == VT1625_6) ||
                 (encodertype == VT1625A_6A) )
            {     
                pHDTVPatch += 0x04;                    // skip 12h - 15h
                pHDTVPatch += 0x12;                    // skip 50h - 61h
                pHDTVPatch += 0x02;                    // skip 63h - 64h
            }
            return cbTransTVandHDTVTimingTbl(pcbe, (PWORD)pHDTVPatch, 6000, pTimingTbl);
        }
    }

    //if the mode HDTV no support, do centering
    if (!cbHDTVIsVBIOSSupportMode(pcbe, H_Res, V_Res))
    {
        cbGetCenterTiming(H_Res, V_Res, pTimingTbl);		
    }

    // HDTV native mode 1080I, 720P no specific timing table just return TRUE
    return TRUE;
}

//--------------------------------------------------------------------------
// cbGetVBIOSHDTVEncoderTimingTable
//   Get HDTV timing table for encoder side according to H_Res & V_Res parameters
//  IN :
//      H_Res   : H resolution
//      V_Res   : V resolution
//  OUT:
//   ppHDTVFunc : HDTV encoder timing table
//   ppHDTVPatch: HDTV encoder specific table
//      Function Status
//--------------------------------------------------------------------------
BOOL cbGetVBIOSHDTVEncoderTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN WORD  H_Res,
    IN WORD  V_Res,
    OUT PTV_FUNCTION_VCP *ppHDTVFunc,
    OUT BYTE **ppHDTVPatch)
{
    BYTE modeIndex = 0;
    PHDTVENTRYTBL pHdtvTbl = NULL, pHdtvPatchEntry = NULL;
    PHDTVPatchTbl pHDTVPatchTbl = NULL;
    DWORD DES_H_Res = H_Res, DES_V_Res = V_Res;     // Taget H / V resolution ( disp timing)
    
    if (!ppHDTVFunc|| !ppHDTVPatch)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // check if VCP info is NULL
    if (pcbe->pVCPInfo == NULL)
    {
        return FALSE;
    }
    // only VCP 1.1 and above have valid TV table
    if (pcbe->pVCPInfo->version < VCP1_1)
    {
        return FALSE;
    }
    // get HDTV timing and func
    if(pcbe->pVCPInfo->HDTVEntryTbl != 0)
    {
        pHdtvTbl = (PHDTVENTRYTBL)(pcbe->RomData + pcbe->pVCPInfo->HDTVEntryTbl);
        pHdtvPatchEntry = pHdtvTbl + 1;
    }
    else
    {
        //Invalid function call happened, this vbios may not support HDTV
        return FALSE;
    }
    // HDTV support all mode solution
    //  see if the mode exists in VBIOS support mode list 
    //  if yes then using VBIOS timing, if not 
    //  then use centering / panning on native mode timing
    if (!cbHDTVIsVBIOSSupportMode(pcbe, DES_H_Res, DES_V_Res))
    {
        switch (pcbe->sPad_11.HDTV_Type)
        {
        case HDTV720P:      
            DES_H_Res = 1280;                      
            DES_V_Res = 720;            
            break;

        case HDTV1080I:
            DES_H_Res = 1920;                      
            DES_V_Res = 1080;            
            break;

        default:
            return FALSE;
        }
    }
    
    //get TV mode index according to resolution
    {
        PMapTVModeIndex pTvModeIndexTbl = TblMapTVModeIndex;
        // Search TV Mode Index
        for (; pTvModeIndexTbl->VesaInfo.HSize != 0xFFFF; pTvModeIndexTbl++)
        {
            if ( (DES_H_Res == pTvModeIndexTbl->VesaInfo.HSize)
                && (DES_V_Res == pTvModeIndexTbl->VesaInfo.VSize) )
            {
                modeIndex = pTvModeIndexTbl->TvModeIndex;
                break;
            }
        }
        if (0 == modeIndex)
        {
            // If there is no match mode index, return FALSE
            cbDbgPrint(0, "Not support this TV mode index now!!!");
            return FALSE;
        }
    }
    
    switch (pcbe->sPad_11.HDTV_Type)
    {
    case HDTV720P:
        pHDTVPatchTbl = (PHDTVPatchTbl)(pcbe->RomData + pHdtvPatchEntry->HDTV720P);
        *ppHDTVFunc = (PTV_FUNCTION_VCP)(pcbe->RomData + pHdtvTbl->HDTV720P);
        break;

    case HDTV1080I:
        pHDTVPatchTbl = (PHDTVPatchTbl)(pcbe->RomData + pHdtvPatchEntry->HDTV1080I);
        *ppHDTVFunc = (PTV_FUNCTION_VCP)(pcbe->RomData + pHdtvTbl->HDTV1080I);
        break;

    default:
        return FALSE;
    }

    // find HDTV specific table according to mode
    for (; pHDTVPatchTbl->HDTVPatchIndex != 0xFF; pHDTVPatchTbl++)
    {
        if (pHDTVPatchTbl->HDTVPatchIndex == modeIndex)
        {
            *ppHDTVPatch = (pcbe->RomData + pHDTVPatchTbl->HDTVPatchOffset);
            return TRUE;
        }
    }

    // HDTV native mode 1080I, 720P no specific table, HDTV specific pointer 
    // need to be set to NULL just return TRUE
    *ppHDTVPatch = NULL;
    return TRUE;
}

//----------------------------------------------------------------------------
//  cbGetCBIOSTVGFXTimingTable
//      This function gets TV timing from CBIOS own table, since in VBIOS
//  all the table is configured as offset(16 bits), while in CBIOS, all the table is 
//  configured as a address (32bit). So we need to write a new function to handle 
//  new CBIOS TV data structure.(Now this function only supports TV, since we only 
//  port TV timing table in CBIOS).
//    IN :
//      dispDev :
//        H_Res :
//        V_Res :
//    OUT :
//      pTimingTbl   :       TV timing table on GFX side
//----------------------------------------------------------------------------
BOOL cbGetCBIOSTVGFXTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN WORD  H_Res,
    IN WORD  V_Res,
    OUT PGFXTimingTable pTimingTbl)
{
    PMapTVModeIndex pTvModeIndexTbl = TblMapTVModeIndex;
    PTVTBLDATA_UMA pCBIOSTvTbl;
    WORD H_cur = 0xffff, V_cur = 0xffff;     // current H, V size, default set as max to record available TV mode

    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    // 1. find  the TV table stored in CBIOS
    // get TV timing and func from CBIOS
    //select different table according to TV contraction level 
    switch (pcbe->sPad_5.TV_Contraction)
    {
    case TV_V_NORMAL:
        pCBIOSTvTbl = csTVModeTbl_1625;
        break;
    case TV_V_FIT:
        pCBIOSTvTbl = csTVModeFitTbl_1625;
        break;
    case TV_V_OVER:
        pCBIOSTvTbl = csTVModeOverTbl_1625;
        break;
    default:
        cbDbgPrint(0, "TV contraction level wrong! Can not find TV timing table\n");
        ASSERT(0);
        return FALSE;
    }

    // 2.  get TV mode index according to resolution
    // Search closest TV Mode Index
    for (; pTvModeIndexTbl->VesaInfo.HSize != 0xFFFF; pTvModeIndexTbl++)
    {
        if ( (H_Res <= pTvModeIndexTbl->VesaInfo.HSize) && (pTvModeIndexTbl->VesaInfo.HSize <= H_cur) &&
            (V_Res <= pTvModeIndexTbl->VesaInfo.VSize) && (pTvModeIndexTbl->VesaInfo.VSize <= V_cur))
        {
    
            PTVTBLDATA_UMA pTmpTvTbl;
            // find TV func offset(TV encode) according to TV type (NTSC, PALM\ PAL)
            // get TV CRTC timing table value
            for (pTmpTvTbl=pCBIOSTvTbl; pTmpTvTbl->tvModeIndex != 0xFF; pTmpTvTbl++)
            {
                if (pTmpTvTbl->tvModeIndex == pTvModeIndexTbl->TvModeIndex)
                {
                    if ( (NTSC == pcbe->sPad_8.TV_Type)
                        || (NTSCJP == pcbe->sPad_8.TV_Type)
                        || (PALM == pcbe->sPad_8.TV_Type) ) // PALM is base on NTSC to adjust
                    {
                        if (NULL != pTmpTvTbl->ptvNTSCTiming)
                        {
                            // found closer TV mode, record it
                            if(TRUE == cbTransTVandHDTVTimingTbl(pcbe, pTmpTvTbl->ptvNTSCTiming, 6000, pTimingTbl))
                            {
                                H_cur = pTvModeIndexTbl->VesaInfo.HSize;
                                V_cur = pTvModeIndexTbl->VesaInfo.VSize;
                            }
                        }
                    }
                    else
                    {
                        if (NULL != pTmpTvTbl->ptvPALTiming)
                        {
                            // found closer TV mode, record it
                            if(TRUE == cbTransTVandHDTVTimingTbl(pcbe, pTmpTvTbl->ptvPALTiming, 5000, pTimingTbl))
                            {
                                H_cur = pTvModeIndexTbl->VesaInfo.HSize;
                                V_cur = pTvModeIndexTbl->VesaInfo.VSize;
                            }
                        }
                    }
                }
            } // for tv mode table

        }
    }

    if (0xffff == H_cur)
    {
        // If there is no available mode, return FALSE
        cbDbgPrint(0, "Not support this TV mode now!!!");
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

//----------------------------------------------------------------------------
//  cbGetCBIOSTVEncoderTimingTable
//      This function gets TV encoder timing from CBIOS own table, since in VBIOS
//  all the table is configured as offset(16 bits), while in CBIOS, all the table is 
//  configured as a address (32bit). So we need to write a new function to handle 
//  new CBIOS TV data structure.(Now this function only supports TV, since we only 
//  port TV timing table in CBIOS).
//    IN :
//      dispDev :
//        H_Res :
//        V_Res :
//    OUT :
//      ppCBIOSTVFunc : TV encoder contraction level table addr
//----------------------------------------------------------------------------
BOOL cbGetCBIOSTVEncoderTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN WORD  H_Res,
    IN WORD  V_Res,
    OUT PTV_FUNCTION_UMA *ppCBIOSTVFunc)
{
    BYTE modeIndex = 0;
    PMapTVModeIndex pTvModeIndexTbl ;
	PTVTBLDATA_UMA pCBIOSTvTbl;

    if (!ppCBIOSTVFunc)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    // 1.  get TV mode index according to resolution
    pTvModeIndexTbl = TblMapTVModeIndex;
    // Search TV Mode Index
    for (; pTvModeIndexTbl->VesaInfo.HSize != 0xFFFF; pTvModeIndexTbl++)
    {
        if ( (H_Res == pTvModeIndexTbl->VesaInfo.HSize)
            && (V_Res == pTvModeIndexTbl->VesaInfo.VSize) )
        {
            modeIndex = pTvModeIndexTbl->TvModeIndex;
            break;
        }
    }
    
    if (0 == modeIndex)
    {
        // If there is no match mode index, return FALSE
        cbDbgPrint(0, "Not support this TV mode index now!!!");
        return FALSE;
    }
    
    // 2. find  the TV table stored in CBIOS
    // get TV timing and func from CBIOS
   
    //select different table according to TV contraction level 
    switch (pcbe->sPad_5.TV_Contraction)
    {
    case TV_V_NORMAL:
        pCBIOSTvTbl = csTVModeTbl_1625;
        break;
    case TV_V_FIT:
        pCBIOSTvTbl = csTVModeFitTbl_1625;
        break;
    case TV_V_OVER:
        pCBIOSTvTbl = csTVModeOverTbl_1625;
        break;
    default:
        cbDbgPrint(0, "TV contraction level wrong! Can not find TV timing table\n");
        ASSERT(0);
        return FALSE;
    }

    // find TV func offset(TV encode) according to TV type (NTSC, PALM\ PAL)
    // get TV CRTC timing table value
    for (; pCBIOSTvTbl->tvModeIndex != 0xFF; pCBIOSTvTbl++)
    {
        if (pCBIOSTvTbl->tvModeIndex == modeIndex)
        {
            if ( (NTSC == pcbe->sPad_8.TV_Type)
                || (NTSCJP == pcbe->sPad_8.TV_Type)
                || (PALM == pcbe->sPad_8.TV_Type) ) // PALM is base on NTSC to adjust
            {
                *ppCBIOSTVFunc = pCBIOSTvTbl->ptvNTSC;
            }
            else
            {
                *ppCBIOSTVFunc = pCBIOSTvTbl->ptvPAL;
            }
            return TRUE;
        }
    }

    return FALSE;
  
}

//--------------------------------------------------------------------------
//  cbFillInTVEncoderRegs
//  fill internal TV regs
//     IN
//        pTVTable, offset of internal TV table in VBIOS rom image  
//--------------------------------------------------------------------------

BOOL cbFillInTVEncoderRegs(PCBIOS_EXTENSION pcbe,PBYTE pTVTable)
{
    PBYTE pInTVModeTblMask;
    BYTE i, j;
    BYTE counter = 0;
    if( pcbe->pVCPInfo->version < VCP1_5 )
    {
        return FALSE;
    }
    if(pcbe->pVCPInfo->csInTVMaskTbl != 0)
    {
        pInTVModeTblMask = (PBYTE)(pcbe->RomData + pcbe->pVCPInfo->csInTVMaskTbl);
    }
    else
    {
        return FALSE;
    }
    // select Intv pll
    if ( (pcbe->IGA1Info.dispDev | pcbe->IGA1Info.dispDev) & S3_TV )
    {
        InTV_Write_Byte_UMA(pcbe, 0xE1, 0x58);
    }
    else //HDTV
    {
        InTV_Write_Byte_UMA(pcbe, 0xE1, 0x30);
    }
    for ( i=0; i<30; i++ )      //30 bytes mask
    {
        for( j=0; j<8; j++ )
        {
            if( ( ( pInTVModeTblMask[i] << j ) & BIT7 ) != 0 )
            {
                InTV_Write_Byte_UMA( pcbe, i*8+j , pTVTable[counter]);
                counter++;
            }
        }
    }
    // specific for disable reserved register case
    if( (cbReadRegByte(pcbe, SR_43) & BIT1) == 0 )  //if SR43[1]==0, reserved register disabled
    {
        BYTE TVtypemask = pcbe->sPad_8.TV_Type;
    
        switch(TVtypemask)
        {
        case NTSC:
        case NTSCJP:
            InTV_Write_Byte_UMA(pcbe, 0xE8, 0x6D);
            break;
        case PAL:
        case PALM:
        case PALN:
        case PALNc:
            InTV_Write_Byte_UMA(pcbe, 0xE8, 0x71);
            break;
        default:
            break;
        }
        
    }
    return TRUE;

}

void cbFillTVFunctionRegs (
    PCBIOS_EXTENSION pcbe,
    IN PTV_FUNCTION_VCP pTVFunc,
    IN TV_FUNCTION_TYPE TVFuncType
)
{
    BOOL bGetTVFuncOffset = FALSE;
    WORD TVFunOffset = 0x00;
    ULONG  encodertype= 0x00;
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return ;
    }
    
    // Select TV Function Offset
    for (; pTVFunc->tvFunIndex != 0xFF; pTVFunc++)
    {
        if (pTVFunc->tvFunIndex == TVFuncType)
        {
            TVFunOffset = pTVFunc->tvFunOffset;
            bGetTVFuncOffset = TRUE;
        }
    }
    if (!bGetTVFuncOffset)
    {
        return;
    }

    if (TV_FUNC == TVFuncType)
    {
        // BYTE definition TV encoder regs table
        BYTE  Counter = 0, TVIndex;
        PBYTE pTVTable = (PBYTE)(pcbe->RomData + TVFunOffset);

        switch (encodertype)
        {
        case VT1625_6:
        case VT1625A_6A:  
            {
                // TV. 0 ~ 2Fh
                for (TVIndex = 0; TVIndex <= 0x2F; Counter++, TVIndex++)
                {
                    TV_Write_Byte_UMA(pcbe, TVIndex, pTVTable[Counter]);
                }
                // TV. 4Ah ~ 64h
                for (TVIndex = 0x4A; TVIndex <= 0x64 ; TVIndex++, Counter++)
                {
                    TV_Write_Byte_UMA(pcbe, TVIndex, pTVTable[Counter]);
                }

                // Is output device HDTV?
                if (pcbe->sPad_7.TVOutType & (BIT4 + BIT5)) // Is SDTVRGB + SDTVYPbPr ?
                {
                    for (TVIndex = 0x6B; TVIndex <= 0x73 ; TVIndex++)
                        TV_Write_Byte_UMA(pcbe, TVIndex, 0x00);
                }
                else
                {
                    for (TVIndex = 0x6B; TVIndex <= 0x73 ; TVIndex++, Counter++)
                        TV_Write_Byte_UMA(pcbe, TVIndex, pTVTable[Counter]);
                }

            }
            break;
            
        case VT1622A:
        case VT1623_3A:
            {
                // TV. 0 ~ 2Fh
                for (TVIndex = 0; TVIndex <= 0x2F; Counter++, TVIndex++)
                {
                    TV_Write_Byte_UMA(pcbe, TVIndex, pTVTable[Counter]);
                }
                // TV. 4Ah ~ 64h
                for (TVIndex = 0x4A; TVIndex <= 0x64 ; TVIndex++, Counter++)
                {
                    TV_Write_Byte_UMA(pcbe, TVIndex, pTVTable[Counter]);
                }
            }
            break;
            
        case IN_TV:
            {
                cbFillInTVEncoderRegs( pcbe, pTVTable );
            }
            break;
            
        default:
            return;
        }
    }
    else
    {
        // WORD definition TV encoder regs table
        BYTE *pTvFunRegTbl = (PBYTE)(pcbe->RomData + TVFunOffset);
        BYTE RegIndex, RegData;

        BYTE NumOfRegs = *pTvFunRegTbl;
        pTvFunRegTbl++;
        if (0 == NumOfRegs)
        {
            return;
        }

        if (DOTCRAWL_FUNC == TVFuncType)
        {
            // Dot crawl function must write first reg in bit
            RegIndex = pTvFunRegTbl[0];
            RegData  = pTvFunRegTbl[1];
            if ( encodertype == IN_TV )
            {
                InTV_Write_Byte_UMA(pcbe, RegIndex, RegData | InTV_Read_Byte_UMA(pcbe, RegIndex));                
            }
            else
            {
                TV_Write_Byte_UMA(pcbe, RegIndex, RegData | TV_Read_Byte_UMA(pcbe, RegIndex));
            }
            NumOfRegs--;
            pTvFunRegTbl += 2;
        }

        while (NumOfRegs--)
        {
            RegIndex = pTvFunRegTbl[0];
            RegData  = pTvFunRegTbl[1];
            if ( encodertype == IN_TV )
            {
                InTV_Write_Byte_UMA(pcbe, RegIndex, RegData);
            }
            else
            {
                TV_Write_Byte_UMA(pcbe, RegIndex, RegData);
            }
            pTvFunRegTbl += 2;
        }
    } // if TV_FUNC
}


//---------------------------------------------------------------------------
// cbFillTVFunctionRegs_CBIOS
//      This function init TV encoder register according to TV func. TV timing 
//  table retrieving from CBIOS.
//   IN :
//      pTVFunc_CBIOS : TV function table 
//      TVFuncType : TV func type
//   OUT :
//      None
//--------------------------------------------------------------------------
void cbFillTVFunctionRegs_CBIOS (
    PCBIOS_EXTENSION pcbe,
    IN PTV_FUNCTION_UMA pTVFunc_CBIOS,
    IN TV_FUNCTION_TYPE TVFuncType
)
{
    void *pTVFun = NULL;
    ULONG  encodertype;

    if (!pTVFunc_CBIOS)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }
   
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return ;
    }
      
        
    // Select TV Function Offset
    for (; pTVFunc_CBIOS->tvFunIndex != 0xFF; pTVFunc_CBIOS++)
    {
        if (pTVFunc_CBIOS->tvFunIndex == TVFuncType)
        {
            pTVFun = pTVFunc_CBIOS->pTvFun;
        }
    }
    if (pTVFun == NULL)
    {
        return;
    }

    if (TV_FUNC == TVFuncType)
    {
        // BYTE definition TV encoder regs table
        BYTE  Counter = 0, TVIndex;
        PBYTE pTVTable = (PBYTE)pTVFun;

        switch (encodertype)
        {
        case VT1625_6:
        case VT1625A_6A:
            {
                // TV. 0 ~ 2Fh
                for (TVIndex = 0; TVIndex <= 0x2F; Counter++, TVIndex++)
                {
                    TV_Write_Byte_UMA(pcbe, TVIndex, pTVTable[Counter]);
                }
                // TV. 4Ah ~ 64h
                for (TVIndex = 0x4A; TVIndex <= 0x64 ; TVIndex++, Counter++)
                {
                    TV_Write_Byte_UMA(pcbe, TVIndex, pTVTable[Counter]);
                }

                // Is output device HDTV?
                if (pcbe->sPad_7.TVOutType & (BIT4 + BIT5)) // Is SDTVRGB + SDTVYPbPr ?
                {
                    for (TVIndex = 0x6B; TVIndex <= 0x73 ; TVIndex++)
                        TV_Write_Byte_UMA(pcbe, TVIndex, 0x00);
                }
                else
                {
                    for (TVIndex = 0x6B; TVIndex <= 0x73 ; TVIndex++, Counter++)
                        TV_Write_Byte_UMA(pcbe, TVIndex, pTVTable[Counter]);
                }
            }
            break;
            
        case VT1622A:
        case VT1623_3A:
            {
                // TV. 0 ~ 2Fh
                for (TVIndex = 0; TVIndex <= 0x2F; Counter++, TVIndex++)
                {
                    TV_Write_Byte_UMA(pcbe, TVIndex, pTVTable[Counter]);
                }
                // TV. 4Ah ~ 64h
                for (TVIndex = 0x4A; TVIndex <= 0x64 ; TVIndex++, Counter++)
                {
                    TV_Write_Byte_UMA(pcbe, TVIndex, pTVTable[Counter]);
                }
            }
            break;
            
        default:
            return;
        }
    }
    else
    {
        // WORD definition TV encoder regs table
        BYTE *pTvFunRegTbl = (PBYTE)pTVFun;
        BYTE RegIndex, RegData;

        BYTE NumOfRegs = *pTvFunRegTbl;
        pTvFunRegTbl++;
        if (0 == NumOfRegs)
        {
            return;
        }

        if (DOTCRAWL_FUNC == TVFuncType)
        {
            // Dot crawl function must write first reg in bit
            RegIndex = pTvFunRegTbl[0];
            RegData  = pTvFunRegTbl[1];
            TV_Write_Byte_UMA(pcbe, RegIndex, RegData | TV_Read_Byte_UMA(pcbe, RegIndex));
            NumOfRegs--;
            pTvFunRegTbl += 2;
        }

        while (NumOfRegs--)
        {
            RegIndex = pTvFunRegTbl[0];
            RegData  = pTvFunRegTbl[1];
            TV_Write_Byte_UMA(pcbe, RegIndex, RegData);
            pTvFunRegTbl += 2;
        }
    } // if TV_FUNC
}

//---------------------------------------------------------------------------
// cbPatchTVFunctions
//      This function patches TV encoder register according to TV func. TV timing 
//  table retrieving from VBIOS.
//   IN :
//      pTVFunc : TV function table 
//   OUT :
//      None
//--------------------------------------------------------------------------
void cbPatchTVFunctions(
    PCBIOS_EXTENSION pcbe,
    IN PTV_FUNCTION_VCP pTVFunc)
{
    
    BYTE TV_Type = pcbe->sPad_8.TV_Type;
    BYTE TVOutType = pcbe->sPad_7.TVOutType;

    // TV check function
    // if VT1625
    if (1 == pcbe->sPad_5.TVInputMode) // TV Input Format: Ycbcr
    {
        cbFillTVFunctionRegs(pcbe, pTVFunc, YCBCR_IN_FUNC);
    }

    // DotCrawl ?
    if ( (TVOutType & TV_CVBS) &&
        ((TV_Type ==  NTSC) || (TV_Type ==  PALM) || (TV_Type ==  NTSCJP)) &&
        (pcbe->sPad_5.enableDotCrawl) )
    {
        // fill DotCrawl registers
        cbFillTVFunctionRegs(pcbe, pTVFunc, DOTCRAWL_FUNC);
    }

    // if VT1622 or VT1622A or VT1625 or IntegratedTV or VT1626
    // if VT1625
    if(TVOutType & (TV_SVideo1 | TV_SVideo2)) // If It is SVideo1 or SVideo2
    {
        TV_Write_Byte_UMA(pcbe, 0x65, 0x51);
    }

    if(TVOutType & TV_RGB)
    {
        cbFillTVFunctionRegs(pcbe, pTVFunc, RGB_FUNC);
    }
    else if(TVOutType & TV_Ycbcr)
    {
        cbFillTVFunctionRegs(pcbe, pTVFunc, YCBCR_FUNC);
    }
    else if(TVOutType & TV_SDTVRGB)
    {
        // if VT1625
        cbFillTVFunctionRegs(pcbe, pTVFunc, RGB_FUNC);

        cbFillTVFunctionRegs(pcbe, pTVFunc, SDTV_RGB_FUNC);
    }
    else if(TVOutType & TV_SDTVYpbpr)
    {
        // if VT1625
        cbFillTVFunctionRegs(pcbe, pTVFunc, YCBCR_FUNC);

        cbFillTVFunctionRegs(pcbe, pTVFunc, SDTV_YPBPR_FUNC);
    }

    
}


//-------------------------------------------------------------------------
//cbPatchHDTVFunctions
//  This function patches HDTV function table sepcially 
//  IN : 
//       pHDTVPatch : HDTV different mode specific table
//-------------------------------------------------------------------------
void cbPatchHDTVFunctions(
    PCBIOS_EXTENSION pcbe,
    IN BYTE *pHDTVPatch
)
{
    PTV_FUNCTION_VCP pHDTVFunc = NULL;
    ULONG encodertype;

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) ==FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return;
    }
    // specific HDTV table
    if (pHDTVPatch != NULL)
    {
        BYTE TVIndex = 0;

        // first is WORD definition HDTV encoder regs table
        BYTE NumOfRegs = *pHDTVPatch;
        pHDTVPatch++;   // skip reg num byte
        if ( encodertype == IN_TV )
        {
            while (NumOfRegs--)
            {
                InTV_Write_Byte_UMA(pcbe, pHDTVPatch[0], pHDTVPatch[1]);
                pHDTVPatch += 2;
            }
        }
        else if ( (encodertype == VT1625_6) ||
                  (encodertype == VT1625A_6A) )
        {          
            while (NumOfRegs--)
            {
                TV_Write_Byte_UMA(pcbe, pHDTVPatch[0], pHDTVPatch[1]);
                pHDTVPatch += 2;
            }
    
            // secondary is BYTE definition TV encoder regs table
            // TV. 12h ~ 15h
            for (TVIndex = 0x12; TVIndex <= 0x15; TVIndex++, pHDTVPatch++)
            {
                TV_Write_Byte_UMA(pcbe, TVIndex, *pHDTVPatch);
            }
            // TV. 50h ~ 61h
            for (TVIndex = 0x50; TVIndex <= 0x61; TVIndex++, pHDTVPatch++)
            {
                TV_Write_Byte_UMA(pcbe, TVIndex, *pHDTVPatch);
            }
            // TV. 63h ~ 64h
            for (TVIndex = 0x63; TVIndex <= 0x64; TVIndex++, pHDTVPatch++)
            {
                TV_Write_Byte_UMA(pcbe, TVIndex, *pHDTVPatch);
            }
            // if not HDTV native mode
            for (TVIndex = 0x6B; TVIndex <= 0x73 ; TVIndex++)
            {
                TV_Write_Byte_UMA(pcbe, TVIndex, 0x00);
            }
        }
        else
        {
            cbDbgPrint(1, "Unsupported TV encoder!\n");
            ASSERT(0);
        }
    }

    // HDTV check function in different place, get again
    if(pcbe->pVCPInfo->HDTVFuncTbl != 0)
    {
        pHDTVFunc = (PTV_FUNCTION_VCP)(pcbe->RomData + pcbe->pVCPInfo->HDTVFuncTbl);
        // if VT1625
        if (1 == pcbe->sPad_5.TVInputMode) // TV Input Format: Ycbcr
        {
            cbFillTVFunctionRegs(pcbe, pHDTVFunc, YCBCR_IN_FUNC);
        }

        if (1 == pcbe->sPad_11.HDTVOutputType)
        {
            cbFillTVFunctionRegs(pcbe, pHDTVFunc, YCBCR_FUNC);
        }
        else
        {
            cbFillTVFunctionRegs(pcbe, pHDTVFunc, RGB_FUNC);
        }
    }
   
}


//--------------------------------------------------------------------------
// cbPatchTVFunctions_CBIOS
//    This function load TV table according to TV property, all the tables come
//  from CBIOS
//  IN :
//      pTVFunc_CBIOS :
//  OUT :
//      NONE
//-------------------------------------------------------------------------
void cbPatchTVFunctions_CBIOS(
    PCBIOS_EXTENSION pcbe,
    IN PTV_FUNCTION_UMA pTVFunc_CBIOS
)
{
    BYTE TV_Type = pcbe->sPad_8.TV_Type;
    BYTE TVOutType = pcbe->sPad_7.TVOutType;
    
    if (!pTVFunc_CBIOS)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }
 

    // TV check function
    // if VT1625
    if (1 == pcbe->sPad_5.TVInputMode) // TV Input Format: Ycbcr
    {
        cbFillTVFunctionRegs_CBIOS(pcbe, pTVFunc_CBIOS, YCBCR_IN_FUNC);
    }

    // DotCrawl ?
    if ( (TVOutType & TV_CVBS) &&
        ((TV_Type ==  NTSC) || (TV_Type ==  PALM) || (TV_Type ==  NTSCJP)) &&
        (pcbe->sPad_5.enableDotCrawl) )
    {
        // fill DotCrawl registers
        cbFillTVFunctionRegs_CBIOS(pcbe, pTVFunc_CBIOS, DOTCRAWL_FUNC);
    }

    // if VT1622 or VT1622A or VT1625 or IntegratedTV or VT1626
    // if VT1625
    if(TVOutType & (TV_SVideo1 | TV_SVideo2)) // If It is SVideo1 or SVideo2
    {
        TV_Write_Byte_UMA(pcbe, 0x65, 0x51);
    }

    if(TVOutType & TV_RGB)
    {
        cbFillTVFunctionRegs_CBIOS(pcbe, pTVFunc_CBIOS, RGB_FUNC);
    }
    else if(TVOutType & TV_Ycbcr)
    {
        cbFillTVFunctionRegs_CBIOS(pcbe, pTVFunc_CBIOS, YCBCR_FUNC);
    }
    else if(TVOutType & TV_SDTVRGB)
    {
        // if VT1625
        cbFillTVFunctionRegs_CBIOS(pcbe, pTVFunc_CBIOS, RGB_FUNC);

        cbFillTVFunctionRegs_CBIOS(pcbe, pTVFunc_CBIOS, SDTV_RGB_FUNC);
    }
    else if(TVOutType & TV_SDTVYpbpr)
    {
        // if VT1625
        cbFillTVFunctionRegs_CBIOS(pcbe, pTVFunc_CBIOS, YCBCR_FUNC);

        cbFillTVFunctionRegs_CBIOS(pcbe, pTVFunc_CBIOS, SDTV_YPBPR_FUNC);
    }

}


//----------------------------------------------------------------------
//  cbSetTVCLK_PATH_UMA
//      this function configs TV clock path according to which IGA TV is on
//   set TVCIE 6C[0] 1 ,VCKIS 6B[0] 0 for 336 or 364 case, while for VT3353 &
//   VT3324 it has new control logic for CR6C. In fact internal TV , external TV encoder
//   also involves different ways to control.Now both internal & external TV encoder
//   use master feature which means GFX clock need to bypass its own PLL.
//
//   IN
//      IGAInfo : which IGA TV is configured on 
//----------------------------------------------------------------------
void cbSetTVCLK_PATH_UMA(PCBIOS_EXTENSION pcbe, IN DWORD IGAInfo, IN DWORD Operate)
{
    ULONG encodertype;
    
    if ( cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE )
    {
        return;
    }

    // TV clock input enable TVCIE CR6C[0]
    // TV path selection     CR6C[7]
    switch(Operate)
    {
    case ON:
        // TV master mode behavior, TV PLL clock will be introduced instead of 
        // GFX own PLL (master mode)
        if(IGAInfo == IGA1)
        {
            if(pcbe->ChipCaps.tv_two_clk_ctrl_sup)
            {
                // VCK PLL reference clock source selection: 101 = DVP1TVCLKR
                // VCK source selection: 1 = use VCK PLL reference clock
                // This is for external TV encoder setting,  there will be other 
                // configuration for CR6C If using internal TV encoder(VT3324)
                if( encodertype == IN_TV )
                {
                    InTV_Write_Bits_UMA( pcbe, 0x02, 0, BIT2); //TV source from IGA1
                    cbWriteRegBits(pcbe, CR_6C, 0x0F0, 0x050);
                }
                else
                {
                    cbWriteRegBits(pcbe, CR_6C, 0x0F0, 0x0B0);
                }
            }
            else
            {
                // VCK Input Selection: 0 = External clock. (Ex: TV clock)
                // IGA1 and TV Clock Input Enable
                cbWriteRegBits(pcbe, CR_6B, BIT0, 0x0);
                cbWriteRegBits(pcbe, CR_6C, BIT7 + BIT0, BIT0);
            }
        }
        else
        {
            if(pcbe->ChipCaps.tv_two_clk_ctrl_sup)
            {
                // LCK PLL reference clock source selection: 101 = DVP1TVCLKR
                // LCK source selection: 1 = use LCK PLL reference clock    
                // This is for external TV encoder setting,  there will be other 
                // configuration for CR6C If using internal TV encoder(VT3324)
                if( encodertype == IN_TV )
                {
                    InTV_Write_Bits_UMA( pcbe, 0x2, BIT2, BIT2); //TV source from IGA1
                    cbWriteRegBits(pcbe, CR_6C, 0x00F, 0x005);
                }
                else
                {
                    cbWriteRegBits(pcbe, CR_6C, 0x00F, 0x00B);
                }
            }
            else
            {
                // LCK Input Selection: 0 = External clock. (Ex: TV clock)
                // IGA2 and TV Clock Input Enable
                cbWriteRegBits(pcbe, CR_6B, BIT0, 0x0);
                cbWriteRegBits(pcbe, CR_6C, BIT7 + BIT0, BIT7 + BIT0);
            }
        }
        break;
    case OFF:
        if(IGAInfo == IGA1)
        {
            if(pcbe->ChipCaps.tv_two_clk_ctrl_sup)
            {
                // VCK source selection: 0 = VCK PLL output clock
                if( encodertype == IN_TV )
                {
                    InTV_Write_Bits_UMA( pcbe, 0x2, 0, BIT2);
                    cbWriteRegBits(pcbe, CR_6C, 0x0F0, 0x0);
                }
                else
                {
                    cbWriteRegBits(pcbe, CR_6C, 0x0F0, 0x0);
                }
            }
            else
            {
                // VCK Input Selection: 1 = Internal clock = PLL output clock.
                // IGA1 and TV Clock Input Disable
                cbWriteRegBits(pcbe, CR_6B, BIT0, BIT0);
                cbWriteRegBits(pcbe, CR_6C, BIT0, 0x0);
            }
        }
        else
        {
            if(pcbe->ChipCaps.tv_two_clk_ctrl_sup)
            {
                // LCK source selection: 0 = LCK PLL output clock
                if( encodertype == IN_TV )
                {
                    InTV_Write_Bits_UMA( pcbe, 0x2, BIT2, BIT2);
                    cbWriteRegBits(pcbe, CR_6C, 0x00F, 0x0);
                }
                else
                {
                    cbWriteRegBits(pcbe, CR_6C, 0x00F, 0x0);
                }
            }
            else
            {
                // LCK Input Selection: 1 = Internal clock = PLL output clock.
                // IGA2 and TV Clock Input Disable
                cbWriteRegBits(pcbe, CR_6B, BIT0, BIT0);
                cbWriteRegBits(pcbe, CR_6C, BIT0, 0x0);
            }
        }
        break;
    default:
        cbDbgPrint(1, "cbSetTVCLK_PATH_UMA: Error Operation input!\n");
        ASSERT(0);
        break;
    }
}

//--------------------------------------------------------------------------
//  cbSetTVPowerState
//  change TV PowerState & initial digital port associated
//     IN
//        powerstate : ON /OFF  
//--------------------------------------------------------------------------
void cbSetTVPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate)
{
    BYTE TV_DAC;
    BYTE TVOutType;
    ULONG encodertype;
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return;
    }
    cbGetDII2Csetting(pcbe, &i2c, S3_TV);
    
    if(powerstate == S3PM_ON) // turn on TV
    {
        // configure TV /HDTV clock 
        if (cbGetPrimaryDevice(pcbe->IGA1Info.dispDev) == S3_TV)
        {
            cbSetTVCLK_PATH_UMA(pcbe, IGA1, ON);
        }
        else if (cbGetPrimaryDevice(pcbe->IGA2Info.dispDev) == S3_TV)
        {
            cbSetTVCLK_PATH_UMA(pcbe, IGA2, ON);
        }
            
        // initial digital port 
        // since for TV /HDTV will share same digital port cfg 
        // as TV. So here just set parameter as TV 
        cbConfigureDigitalPort(pcbe, S3_TV, ON);
        
        // if VT1625, Reset TV
        // enable TV DAC according to TV  output setting
        TVOutType = pcbe->sPad_7.TVOutType;
        
        switch(encodertype)
        {
        case VT1625_6:
        case VT1625A_6A:
            // default no TV DACs opened
            TV_DAC = 0x3F;
            if (TVOutType & TV_CVBS)
            {
                TV_DAC &= (~BIT3);                          // open DAC C
            }
            if (TVOutType & (TV_SVideo1 | TV_SVideo2))
            {
                TV_DAC &= (~(BIT4 + BIT5));                 // open DAC A & B
            } 
            if (TVOutType & (TV_RGB | TV_SDTVRGB))
            {
                TV_DAC &= (~(BIT0 + BIT1 + BIT2 + BIT3));   // open DAC: C D E F
            }
            if (TVOutType & (TV_Ycbcr | TV_SDTVYpbpr))
            {
                TV_DAC &= (~(BIT0 + BIT1 + BIT2));          // open DAC: D E F
            }
            TV_I2CWRITE_BYTE_UMA(pcbe, 0x0E, TV_DAC);
            cbTV1625Reset_UMA(pcbe, &i2c);
            break;
         case VT1622:
         case VT1622A:
         case VT1623_3A:
            // default no TV DACs opened
            TV_DAC = 0xF;
            if (TVOutType & TV_CVBS)
            {
                TV_DAC &= (~BIT3);                          // open DAC A
            }
            if (TVOutType & (TV_SVideo1 | TV_SVideo2))
            {
                TV_DAC &= (~(BIT2 + BIT1));                 // open DAC B & C
            } 
            if (TVOutType & (TV_RGB | TV_SDTVRGB))
            {
                TV_DAC &= (~(BIT0 + BIT1 + BIT2 + BIT3));   // open DAC: A B C D
            }
            if (TVOutType & (TV_Ycbcr | TV_SDTVYpbpr))
            {
                TV_DAC &= (~(BIT0 + BIT1 + BIT2));          // open DAC: B C D
            }
            TV_I2CWRITE_BYTE_UMA(pcbe, 0x0E, TV_DAC);
            break;
         case IN_TV:
            cbEnableInTV( pcbe, S3_TV );
            break;
         default:
             cbDbgPrint(0, "Not Support TV Type\n");
             break;
         }
         
    }
    else // turn off TV
    {
        switch(encodertype)
        {
            case VT1625_6:
            case VT1625A_6A:
                {
                    // only for VT1625 TV encoder now
                    // turn off DAC A~F
                    TV_I2CWRITE_BYTE_UMA(pcbe, 0x0E, 0x3F);
                    // reset TV
                    TV_I2CWRITE_BYTE_UMA(pcbe, 0x1D, 0x00);
                    // disable reset TV
                    TV_I2CWRITE_BYTE_UMA(pcbe, 0x1D, 0x80);
                }
                break;
            case VT1622:
            case VT1622A:
            case VT1623_3A:
                {
                    // turn off DAC A~D
                    TV_I2CWRITE_BYTE_UMA(pcbe, 0x0E, 0x4F);
                    // reset TV
                    TV_I2CWRITE_BYTE_UMA(pcbe, 0x1D, 0x00);
                    // disable reset TV
                    TV_I2CWRITE_BYTE_UMA(pcbe, 0x1D, 0x80);
                }
                break;
            case IN_TV:
                cbDisableInTV( pcbe );
                break;
            default:
                cbDbgPrint(0, "Not Support TV Type\n");
                break;
        }
        // TV on DVP0, disable digital port
        cbConfigureDigitalPort(pcbe, S3_TV, OFF);
        // configure TV /HDTV clock 
        if (cbGetPrimaryDevice(pcbe->IGA1Info.dispDev) == S3_TV)
        {
            cbSetTVCLK_PATH_UMA(pcbe, IGA1, OFF);
        }
        else if (cbGetPrimaryDevice(pcbe->IGA2Info.dispDev) == S3_TV)
        {
            cbSetTVCLK_PATH_UMA(pcbe, IGA2, OFF);
        }
    }
    // update device power statue 
    pcbe->devicepowerstate[TVbit] = powerstate;
}


//--------------------------------------------------------------------------
//  cbSetHDTVPowerState
//  change HDTV PowerState & initial digital port associated
//     IN
//        powerstate : ON /OFF  
//--------------------------------------------------------------------------
void cbSetHDTVPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate)
{
    BYTE HDTV_DAC;
    BYTE HDTVOutType;
    ULONG encodertype;
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_HDTV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return;
    }
    cbGetDII2Csetting(pcbe, &i2c, S3_HDTV);
    
    if (powerstate == S3PM_ON) // turn on HDTV
    {
        // configure HDTV clock 
        if (cbGetPrimaryDevice(pcbe->IGA1Info.dispDev) == S3_HDTV)
        {
            cbSetTVCLK_PATH_UMA(pcbe, IGA1, ON);
        }
        else if (cbGetPrimaryDevice(pcbe->IGA2Info.dispDev) == S3_HDTV)
        {
            cbSetTVCLK_PATH_UMA(pcbe, IGA2, ON);
        }
            
        // initial digital port 
        // since for HDTV will share same digital port cfg 
        // as TV. So here just set parameter as TV 
        cbConfigureDigitalPort(pcbe, S3_HDTV, ON);
        
        // enable HDTV DAC according to HDTV  output setting
        HDTVOutType = pcbe->sPad_11.HDTVOutputType;
        
        switch(encodertype)
        {
        case VT1625_6:
        case VT1625A_6A:
            // default no HDTV DACs opened
            HDTV_DAC = 0x3F;
            if (HDTV_RGB == HDTVOutType) // HDTV RGB output 
            {
                // some TV may need to use one separate DAC as SYNC output
                // so we need to open one more DAC when RGB output
                HDTV_DAC &= (~(BIT0 + BIT1 + BIT2 + BIT3)); // open DAC C D E F  
            }
            else // HDTV Y/Pr/Pb output 
            {
                HDTV_DAC &= (~(BIT0 + BIT1 + BIT2));        // open DAC D E F
            } 
            TV_I2CWRITE_BYTE_UMA(pcbe, 0x0E, HDTV_DAC);
            cbTV1625Reset_UMA(pcbe, &i2c);
            break;
         case IN_TV:
            cbEnableInTV(pcbe, S3_HDTV);
            break;
         default:
             cbDbgPrint(0, "Only VT1625 & Internal TV support HDTV\n");
             break;
         }
         
    }
    else // turn off HDTV
    {
        if (((pcbe->sPad_8.bTVAttached) && 
            (encodertype == VT1625_6)) || 
            (encodertype == VT1625A_6A) )
        {
            // only for VT1625 TV encoder now
            // turn off DAC A~F
            TV_I2CWRITE_BYTE_UMA(pcbe, 0x0E, 0x3F);
            // reset HDTV
            TV_I2CWRITE_BYTE_UMA(pcbe, 0x1D, 0x00);
            // disable reset HDTV
            TV_I2CWRITE_BYTE_UMA(pcbe, 0x1D, 0x80);
        }
        else if (pcbe->sPad_8.bTVAttached && 
            encodertype == IN_TV )
        {
            cbDisableInTV(pcbe);
        } 
        // HDTV on DVP0, disable digital port
        cbConfigureDigitalPort(pcbe, S3_HDTV, OFF);
        // configure HDTV clock 
        if (cbGetPrimaryDevice(pcbe->IGA1Info.dispDev) == S3_HDTV)
        {
            cbSetTVCLK_PATH_UMA(pcbe, IGA1, OFF);
        }
        else if (cbGetPrimaryDevice(pcbe->IGA2Info.dispDev) == S3_HDTV)
        {
            cbSetTVCLK_PATH_UMA(pcbe, IGA2, OFF);
        }
    }
    // update device power statue 
    pcbe->devicepowerstate[HDTVbit] = powerstate;
}


//------------------------------------------------------------------
//cbTV1625Reset_UMA
//  This function reset VT1625 TV encoder
//      IN pi2c : pointer to I2C port where VT1625 exists
//                (VT1625/ VT1625A / CRT2ENCODER)
//------------------------------------------------------------------
void cbTV1625Reset_UMA(
    PCBIOS_EXTENSION pcbe,
    IN PI2C_CONTROL_UMA pi2c)
{
    if (!pi2c)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }
    
    // TV.1Dh = 00h, Software Reset
    pi2c->RegIndex  = 0x1D;
    pi2c->IndexData = 0x00;
    I2C_Write_Byte_INV(pcbe, pi2c);

    // delay 30 ms for vt1625 reset
    cbDelayMicroSeconds(30000);

    // TV.1Dh = 80h, retrun to normal state
    pi2c->IndexData = 0x80;
    I2C_Write_Byte_INV(pcbe, pi2c);
}


//----------------------------------------------------------------
//cbInitTVencoder1625
//      This function inits VT1625 TV encoder according to the input 
//  device bit. Since different device request different TV encoder
//  configuration.
//  IN :
//      device bit : S3_TV | S3_HDTV | S3_TV2 | S3_CRT2
//----------------------------------------------------------------
CBIOS_STATUS cbInitTVencoder1625(
        PCBIOS_EXTENSION pcbe, 
        IN ULONG device)
{
    I2C_CONTROL_UMA i2c;
    CBIOS_STATUS status = CBIOS_OK;
    i2c.Flags = 0;
    
    // DAC sensor voltage init
    // the sensor data be changed from 290h to 230h to get a 
    // acceptalbe output voltage  for both TV / HDTV and CRT2.        
    if (cbGetDII2Csetting(pcbe, &i2c, device))
    {
        //TV reg 0x69 0x6A Auto sense data[9:0]
        i2c.RegIndex = 0x69;
        i2c.IndexData = 0x30;
        if (I2C_Write_Byte_INV(pcbe, &i2c) == TRUE)
        {
            i2c.RegIndex = 0x6A;
            i2c.IndexData = 0x02;
            I2C_Write_Byte_INV(pcbe, &i2c);
        }
        else
        {
            status = CBIOS_ER_DDCRead;
        }
    }
    else
    {
        status = CBIOS_ER_DDCRead;
    }

    // DAC default selection only for VT1625 TV / HDTV 
    // DAC A : S-Video 1 Y
    // DAC B : S-Video 1 C
    // DAC C : CVBS 1 
    // DAC D : Component 2 Y
    // DAC E : Component 2 CR (PR)
    // DAC F : Component 2 CB (PB)
    if (status == CBIOS_OK &&
        (device == S3_TV || device == S3_HDTV || device == S3_TV2))
    {
        i2c.RegIndex = 0x4A;
        i2c.IndexData = 0xC5;
        if (I2C_Write_Byte_INV(pcbe, &i2c) == TRUE)
        {
            i2c.RegIndex = 0x4B;
            i2c.IndexData = 0x0F;
            I2C_Write_Byte_INV(pcbe, &i2c);
        }
        else
        {
            status = CBIOS_ER_DDCRead;
        }
    }

    return status;
}

//----------------------------------------------------------------
//cbInitTVencoder1623
//      This function inits VT1623 TV encoder according to the input 
//  device bit. Since different device request different TV encoder
//  configuration.
//  IN :
//      device bit : S3_TV
//----------------------------------------------------------------
CBIOS_STATUS cbInitTVencoder1623(
        PCBIOS_EXTENSION pcbe, 
        IN ULONG device)
{
    I2C_CONTROL_UMA i2c;
    CBIOS_STATUS status = CBIOS_OK;
    i2c.Flags = 0;
    
    if (cbGetDII2Csetting(pcbe, &i2c, device))
    {
        i2c.RegIndex  = 0x1D;
        i2c.IndexData = 0x00;
        I2C_Write_Byte_INV(pcbe, &i2c);
        
        i2c.RegIndex  = 0x1D;
        i2c.IndexData = 0x80;
        I2C_Write_Byte_INV(pcbe, &i2c);
        
        i2c.RegIndex  = 0x55;
        i2c.IndexData = 0xA7;
        I2C_Write_Byte_INV(pcbe, &i2c);
        
        i2c.RegIndex  = 0x56;
        i2c.IndexData = 0x97;
        I2C_Write_Byte_INV(pcbe, &i2c);
        
        i2c.RegIndex  = 0x57;
        i2c.IndexData = 0x8A;
        I2C_Write_Byte_INV(pcbe, &i2c);
    }
    else
    {
        status = CBIOS_ER_DDCRead;
    }

    return status;
}

static BYTE SyncBufferBaseAddr[] = {0x06, 0x0a, 0x0e, 0x2e, 0x32};

//--------------------------------------------------------------------------
//  cbInitInTVEncoder
//  fill internal TV initial regs
//--------------------------------------------------------------------------
CBIOS_STATUS cbInitInTVEncoder(PCBIOS_EXTENSION pcbe)
{
    PBYTE pInTVInitTblMask;
    PBYTE pInTVInitTbl;
    PBYTE pBufferBaseTbl;
    BYTE i, j;
    BYTE counter = 0;
    CBIOS_STATUS status = CBIOS_OK;

    if( pcbe->pVCPInfo->version < VCP1_5 )
    {
        return CBIOS_ER_NOT_YET_IMPLEMENTED;
    }
    // load initial reg table
    if(pcbe->pVCPInfo->InTVIndexMaskTbl ==0 || pcbe->pVCPInfo->InTVinitValueTbl == 0)
    {
        return CBIOS_ER_LACKOFVCPDATA;
    }
    else
    {
        pInTVInitTblMask = (PBYTE)(pcbe->RomData + pcbe->pVCPInfo->InTVIndexMaskTbl);
        pInTVInitTbl     = (PBYTE)(pcbe->RomData + pcbe->pVCPInfo->InTVinitValueTbl);
    }
    for ( i=0; i<32; i++ )  //32 bytes mask
    {
        for( j=0; j<8; j++ )
        {
            if( ( ( pInTVInitTblMask[i]<<j) & BIT7 ) != 0 )
            {
                InTV_Write_Byte_UMA( pcbe, i*8+j , pInTVInitTbl[counter]);
                counter++;
            }
        }
    }
    // load buffer base address table, now we support only async buffer mode
    pBufferBaseTbl = SyncBufferBaseAddr;
    {
        DWORD baseaddr;
        baseaddr = ( pcbe->sPad_C.Mem_Size << 22 ) - ( 1 << 21 ); //sPad_C - 2M
        baseaddr >>= 16; // 64kb align
        for( i=0; i<NELEMS(SyncBufferBaseAddr); i++ )
        {
            InTV_Write_Byte_UMA( pcbe, pBufferBaseTbl[i], (BYTE)baseaddr );
            InTV_Write_Byte_UMA( pcbe, pBufferBaseTbl[i]+1, (BYTE)( baseaddr>>8 ) );
            baseaddr = baseaddr - (BUFFER_2M); // -2M, 64k alignment
        }
    }
    return status;
    
}

//--------------------------------------------------------------------------
//  cbDisableInTV
//  Disable internal TV, must follow the following order, from 1~7 
//--------------------------------------------------------------------------
 void cbDisableInTV( PCBIOS_EXTENSION pcbe )
 {

     // 1. Dac off, sr5e[1:3] = 111
     cbWriteRegBits( pcbe, SR_5E, BIT3+BIT2+BIT1, BIT3+BIT2+BIT1 );
     // 2. start reset internal TV
     // if sync buffer mode, we should set InTV_Write_Bits_UMA( pcbe, 0x02, BIT4+BIT6, BIT4 );
     // here, we don't handle sync buffer case
     cbStartResetInTV(pcbe);
     // 3. #38[0] = disable TV
     InTV_Write_Bits_UMA( pcbe, 0x038, 0, BIT0 );
     // 4. #00[31] = disable SD
     InTV_Write_Bits_UMA( pcbe, 0x03, 0, BIT7 );
     // 5. #00[0] = disable PK
     InTV_Write_Bits_UMA( pcbe, 0x0, 0, BIT0 );
     // 6. #6C[12] = DAC for TV Bit
     InTV_Write_Bits_UMA( pcbe, 0x06D, 0, BIT4 );
     // 7. #DC[29:28] = TVCK PLL Power Control
     InTV_Write_Bits_UMA( pcbe, 0x0DF, 0, BIT4+BIT5 );     
     
 }

//--------------------------------------------------------------------------
//  cbEnableInTV
//  Enable internal TV, must follow the following order 
//--------------------------------------------------------------------------
void cbEnableInTV( PCBIOS_EXTENSION pcbe, DWORD dispDev )
{
    // 1. #DC[29:28] = TVCK PLL Power Control
    InTV_Write_Bits_UMA( pcbe, 0x0DF, BIT4+BIT5, BIT4+BIT5 );     
    // 2. #00[0] = Enable PK
    InTV_Write_Bits_UMA( pcbe, 0x0, BIT0, BIT0 );
    // 3. #00[31] = Enable SD
    InTV_Write_Bits_UMA( pcbe, 0x03, BIT7, BIT7 );
    // 4. #38[0] = Enable TV
    InTV_Write_Bits_UMA( pcbe, 0x038, BIT0, BIT0 );
    // 5. #6C[12] = DAC for TV Bit
    InTV_Write_Bits_UMA( pcbe, 0x06D, BIT4, BIT4 );
    cbEndResetInTV( pcbe );
    cbInTVDACSetting( pcbe, dispDev );
}

//--------------------------------------------------------------------------
//  cbStartResetInTV
//  Before disable internal TV, first reset it
//--------------------------------------------------------------------------
void cbStartResetInTV( PCBIOS_EXTENSION pcbe )
{
    // #00[20] = SW_RESET = 1
    InTV_Write_Bits_UMA(pcbe, 0x02, BIT4, BIT4);
    // #00[31] = SD_ENABLE = 0
    InTV_Write_Bits_UMA(pcbe, 0x03, 0, BIT7);
    
}

//--------------------------------------------------------------------------
//  cbEndResetInTV
//  After enable internal TV, clear sw_reset bit
//--------------------------------------------------------------------------
 void cbEndResetInTV( PCBIOS_EXTENSION pcbe )
 {
     BYTE olddpms;
     // save old DPMS state
     olddpms = cbReadRegByte( pcbe, CR_36 );
     // open DPMS
     cbWriteRegBits( pcbe, CR_36, BIT4+BIT5, 0 );
     // #00[20] = SW_RESET = 0
     InTV_Write_Bits_UMA( pcbe, 0x02, 0, BIT4 );
     // delay 50 ms
     cbDelayMicroSeconds(50*1000 );
     // #00[31] = SD_ENABLE = 1
     InTV_Write_Bits_UMA( pcbe, 0x03, BIT7, BIT7);
     // restore DPMS state
     cbWriteRegBits( pcbe, CR_36, BIT4+BIT5, olddpms );     
     
 }

//--------------------------------------------------------------------------
//  cbInTVDACSetting
//  Internal TV DAC select
//  TV reg.3B[5:4]:
//                 00: DAC1 A/B/C = C/Y/CVBS
//                 01: DAC1 A/B/C = C/Y/Y
//                 10: DAC1 A/B/C = R/G/B
//                 11: DAC1 A/B/C = Pr/Y/Pb
// SR5E[3:1]:
//             BIT3:DAC3 OFF  (B)
//             BIT2:DAC2 OFF  (G)
//             BIT1:DAC1 OFF  (R)
//  Composite <-> DAC3
//  S-Video   <-> DAC2+DAC1
//  Component <-> DAC1+DAC2+DAC3
//--------------------------------------------------------------------------
void cbInTVDACSetting( PCBIOS_EXTENSION pcbe, DWORD dispDev )
{
    BYTE TVOutType = pcbe->sPad_7.TVOutType;
    BYTE HDTVOutType = pcbe->sPad_11.HDTVOutputType;
    BYTE DacVal;

    if ((dispDev & (S3_TV | S3_HDTV)) == 0)
    {
        cbDbgPrint(0, "Invalid device, not TV or HDTV !\n");
        ASSERT(FALSE);
        return;
    }

    if (dispDev == S3_TV)
    {
        if( TVOutType == (TV_CVBS | TV_SVideo1) )
        {
            DacVal= 0x0;
        }
        else if( TVOutType & TV_CVBS )
        {
            DacVal = 0x06;
        }
        else if( TVOutType & (TV_SVideo1 | TV_SVideo2) )
        {
            DacVal = 0x08;
        }
        else if( TVOutType & (TV_RGB | TV_SDTVRGB) )
        {
            DacVal = 0x20;
        }
        else if ( TVOutType & (TV_Ycbcr | TV_SDTVYpbpr) )
        {
            DacVal = 0x30;
        }
        else
        {
            cbDbgPrint(0, "Unsupported TV output type!");
            ASSERT(0);
            return;
        }
    }
    else // HDTV
    {
        DacVal = 0x30;
        if (HDTVOutType == HDTV_RGB)
        {
            DacVal &= ~BIT4;
        }
    }
    // set DAC
    InTV_Write_Bits_UMA( pcbe, 0x03B, DacVal, BIT5+BIT4 );
    // enable DAC
    cbWriteRegBits( pcbe, SR_5E, BIT3+BIT2+BIT1, DacVal );
}

//--------------------------------------------------------------------------
//  cbIsNativeTVTiming
//  To judge if the mode is TV native mode.
//  For NTSC & NTSCJP, 720X480 is native mode
//  For PAL, 720X576 is native mode
//     IN:
//         Resolutions, H_res & V_res
//     Ret:
//         BOOL
//--------------------------------------------------------------------------
BOOL cbIsNativeTVTiming(PCBIOS_EXTENSION pcbe, 
                      IN DWORD H_Res, 
                      IN DWORD V_Res, 
                      IN DWORD dispDev)
{
    BYTE TVtypemask = pcbe->sPad_8.TV_Type;
    BYTE HDTVtypemask = pcbe->sPad_11.HDTV_Type;
    if ((dispDev & (S3_TV | S3_HDTV)) == 0)
    {
        cbDbgPrint(0, "Invalid device, not TV or HDTV !\n");
        ASSERT(FALSE);
        return FALSE;
    }

    if (dispDev == S3_TV)
    {
        switch(TVtypemask)
        {
        case NTSC:
        case NTSCJP:
            if ((H_Res == 720) && (V_Res == 480))
            {
                return TRUE;
            }
            break;
        case PAL:
        case PALD:
        case PALI:
        case PALM:
        case PALN:
        case PALNc:
            if ((H_Res == 720) && (V_Res == 576))
            {
                return TRUE;
            }
            break;
        default:
            break;
        }
    }
    else if (dispDev == S3_HDTV)
    {
        switch(HDTVtypemask)
        {
        case HDTV720P:
            if ((H_Res == 1280) && (V_Res == 720))
            {
                return TRUE;
            }
            break;
        case HDTV1080I:
            if ((H_Res == 1920) && (V_Res == 1080))
            {
                return TRUE;
            }
            break;
        default:
            break;
        }
    }
    return FALSE;

}
    
static BypassPatch BypassPatchTbl[] = { {0x02,0x81},{0x03,0x0} };

//--------------------------------------------------------------------------
//  cbPatchforBypassMode
//  If the mode is TV native mode, we should specific for bypass mode
//  Bypass could be separated to P2P or P2I
//--------------------------------------------------------------------------
void cbPatchforBypassMode(PCBIOS_EXTENSION pcbe, 
                          IN DWORD H_Res, 
                          IN DWORD V_Res, 
                          IN DWORD dispDev)
{
    BypassPatch *pByassTbl;
    BYTE InputType;
    BYTE i, NumOfRegs;
    if ((dispDev & (S3_TV | S3_HDTV)) == 0)
    {
        cbDbgPrint(0, "Invalid device, not TV or HDTV !\n");
        ASSERT(FALSE);
        return;
    }
    
    if ( dispDev == S3_TV )
    {
        pByassTbl = BypassPatchTbl;
        for(i=0; i<NELEMS(BypassPatchTbl); i++)
        {
            InTV_Write_Byte_UMA(pcbe, pByassTbl->index, pByassTbl->value);
            pByassTbl++;
        }
        
        InputType = InTV_Read_Byte_UMA(pcbe, 0x3a);
        if((InputType >> 6) == 0x02) //SDTV
        {
            InTV_Write_Bits_UMA(pcbe, 0x03, BIT0, BIT0); //P2P or I2I bypass mode
        }
        
        InTV_Write_Bits_UMA(pcbe, 0x3B, 0, BIT0);   
    }
    else if ( dispDev == S3_HDTV )
    {
        if( (pcbe->pVCPInfo == NULL) ||
            (pcbe->pVCPInfo->version < VCP1_5) )
        {
            return;
        }
        if ( (V_Res == 720) && (pcbe->pVCPInfo->InHDTV720pBPPatchTbl != 0) )
        {
            NumOfRegs = *( (BYTE *)(pcbe->RomData + pcbe->pVCPInfo->InHDTV720pBPPatchTbl) );
            pByassTbl = (pBypassPatch)( pcbe->RomData + pcbe->pVCPInfo->InHDTV720pBPPatchTbl + sizeof(BYTE) );
        }
        else if ( (V_Res == 1080) && (pcbe->pVCPInfo->InHDTV1080iBPPatchTbl != 0) )
        {
            NumOfRegs = *( (BYTE *)(pcbe->RomData + pcbe->pVCPInfo->InHDTV1080iBPPatchTbl) );
            pByassTbl = (pBypassPatch)( pcbe->RomData + pcbe->pVCPInfo->InHDTV1080iBPPatchTbl + sizeof(BYTE) );
        }
        else
        {
            return;
        }
        for (i = 0; i < NumOfRegs; i++)
        {
            InTV_Write_Byte_UMA(pcbe, pByassTbl->index, pByassTbl->value);
            pByassTbl++;
        }
    }
    
}


//--------------------------------------------------------------------------
// cb1622AutoSense
//    This function auto sense VT1622 DAC power state. Auto sense use DAC sense
// during V_Blank, so provide flicker-free sense method.
//  IN :
//      pbAttached : device connection state
//  OUT :
//      function state
//--------------------------------------------------------------------------
BOOL cb1622AutoSense(
    PCBIOS_EXTENSION pcbe, 
    OUT BOOL *pbAttached)
{
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;

    if (!pbAttached)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
        
    if(!cbGetTVI2CInfo(pcbe, &i2c))
    {
        return FALSE;
    }
    i2c.RegIndex  = 0x0E;

    if(I2C_Read_Byte_INV(pcbe, &i2c))
    {
        i2c.IndexData |= BIT6;      // enable auto sense
        I2C_Write_Byte_INV(pcbe, &i2c);
        // delay 16ms for Vertical Blank 1/60Hz
        cbDelayMicroSeconds(16000);

        I2C_Read_Byte_INV(pcbe, &i2c);

        *pbAttached = i2c.IndexData & BIT7 ? TRUE : FALSE;
    }
    else
    {
        return FALSE;
    }

    return TRUE;
}

//--------------------------------------------------------------------------
// cb1625AutoSense
//    This function auto sense VT1625 DAC power state. Auto sense use DAC sense
// during V_Blank, so provide flicker-free sense method.
//  IN :
//      pbAttached : device connection state
//  OUT :
//      function state
//--------------------------------------------------------------------------
BOOL cb1625AutoSense(
    PCBIOS_EXTENSION pcbe, 
    OUT BOOL *pbAttached)
{
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;

    if (!pbAttached)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
        
    if(!cbGetTVI2CInfo(pcbe, &i2c))
    {
        return FALSE;
    }
    i2c.RegIndex  = 0x0E;

    if(I2C_Read_Byte_INV(pcbe, &i2c))
    {
        BYTE i, RegE, RegF;
        // save reg 0E
        RegE = i2c.IndexData;
        // force all DAC open
        i2c.IndexData = 0x00;
        I2C_Write_Byte_INV(pcbe, &i2c);

        // Auto DAC Sense
        i2c.RegIndex = 0x1C;
        I2C_Read_Byte_INV(pcbe, &i2c);
        i2c.IndexData |= BIT6;
        I2C_Write_Byte_INV(pcbe, &i2c);
        // delay 16ms for Vertical Blank 1/60Hz
        cbDelayMicroSeconds(16000);
        // Read TV Reg.0F 10 times in case it didn't refresh soon
        i2c.RegIndex = 0x0F;
        for (i=0; i<10; i++)
        {
            I2C_Read_Byte_INV(pcbe, &i2c);
        }
        RegF = i2c.IndexData;

        // restore reg 0E
        i2c.RegIndex = 0x0E;
        i2c.IndexData = RegE;
        I2C_Write_Byte_INV(pcbe, &i2c);

        RegF &= 0x3F;
        // check if any DAC connected
        if(RegF == 0x3F)
        {
            *pbAttached = FALSE;
        }
        else
        {
            *pbAttached = TRUE;
        }
    }
    else
    {
        return FALSE;
    }

    return TRUE;
}

//--------------------------------------------------------------------------
//  cbInTVSense
//  This function is used for internal TV DAC sense
//     OUT:
//         Attached status
//--------------------------------------------------------------------------
BOOL cbInTVSense(PCBIOS_EXTENSION pcbe,OUT BOOL *pbAttached)
{
    BYTE TVPLL, SW_RESET,TV_ENABLE,Pri_DAC,DAC_State,BYPASSTVOSC, result;
    // 0. set TV PLL on
    TVPLL = InTV_Read_Byte_UMA(pcbe, 0xDF);
    InTV_Write_Bits_UMA(pcbe, 0xDF, 0x20, BIT4+BIT5);   //set PLL on
    // 1. set TV SW_RESET = 0
    SW_RESET = InTV_Read_Byte_UMA(pcbe, 0x02);
    InTV_Write_Bits_UMA(pcbe, 0x02, 0x0, BIT4);         //set SW_RESET = 0
    // 2. set TV_ENABLE = 1
    TV_ENABLE = InTV_Read_Byte_UMA(pcbe, 0x38);
    InTV_Write_Bits_UMA(pcbe, 0x38, 0x1, BIT0);         //set TV_ENABLE = 1
    // 3. set primary DAC = TV
    Pri_DAC = InTV_Read_Byte_UMA(pcbe, 0x6D);
    InTV_Write_Bits_UMA(pcbe, 0x6d, 0x10, BIT4);        //set primary DAC = TV
    // 4. set TV DACs all on
    DAC_State = cbReadRegByte(pcbe, SR_5E);
    cbWriteRegBits(pcbe, SR_5E, BIT1+BIT2+BIT3, 0x0);     //set TV DACs all on
    // 5. set BYPASSTVOSC = 0
    BYPASSTVOSC = InTV_Read_Byte_UMA(pcbe, 0xDC);
    InTV_Write_Bits_UMA(pcbe, 0xDC, 0x0, BIT5);         //set BYPASSTVOSC = 0
    // 6. auto sense start
    InTV_Write_Bits_UMA(pcbe, 0x3D, 0xC0, BIT6+BIT7);
    // 7. delay 20 ms
    cbDelayMicroSeconds(20000);
    // 8. auto sense end
    InTV_Write_Bits_UMA(pcbe, 0x3D, 0x0, BIT6+BIT7);
    // 9. restore BYPASSTVOSC
    InTV_Write_Byte_UMA(pcbe, 0xDC, BYPASSTVOSC);
    // 10. restore DAC state
    cbWriteRegByte(pcbe, SR_5E, DAC_State);
    // 11. restore primary DAC
    InTV_Write_Byte_UMA(pcbe, 0x6D, Pri_DAC);
    // 12. restore TV_ENABLE
    InTV_Write_Byte_UMA(pcbe, 0x38, TV_ENABLE);
    // 13. restore SW_RESET
    InTV_Write_Byte_UMA(pcbe, 0x02, SW_RESET);
    // 14. restore TV pll
    InTV_Write_Byte_UMA(pcbe, 0xDF, TVPLL);
    // 15. read sense result
    result = InTV_Read_Byte_UMA(pcbe, 0xE4);
    if (result & BIT2)
    {
        *pbAttached = TRUE;
    }
    else
    {
        *pbAttached = FALSE;
    }
    return TRUE;
}

//*****************************************************************************
// CosLut_UMA[] and SinLut_UMA[] are set to help ease the Sin/Cos calculation
//                                     in Saturation/Hue adjustment functions.
// These tables is created to avoid Sin/Cos calculation
static long CosLut_UMA[HueLevelNum] =
{
    86602,87462,88295,89101,89880,90631,91355,92050,92718,93358, // 30,29,...21
    93970,94552,95106,95630,96126,96593,97030,97437,97815,98163, // 20,19,...11
    98481,98769,99026,99254,99452,99619,99756,99862,99939,99998, // 10, 9,...1
    100000,//0
    99998,99939,99862,99756,99619,99452,99254,99026,98769,98481, // 1, 2,...,10
    98163,97815,97437,97030,96593,96126,95630,95106,94552,93970, //11,12,...20
    93358,92718,92050,91355,90631,89880,89101,88295,87462,86602  // 21,22,...30
};

static long SinLut_UMA[HueLevelNum] =
{
    -50000,-48481,-46947,-45399,-43837,-42262,-40674,-39073,-37461,-35837, //30,29,...21
    -34202,-32557,-30902,-29237,-27563,-25882,-24192,-22495,-20791,-19081, //20,19,...10
    -17365,-15643,-13917,-12187,-10453,-8716, -6976, -5234, -3490, -1745, //10,9,...1
    0,// 0
     1745, 3490, 5234, 6976, 8716,10453,12187,13917,15643,17365,  // 1,2,...10
    19081,20791,22495,24192,25882,27563,29237,30902,32557,34202,   // 11,12,...20
    35837,37461,39073,40674,42262,43837,45399,46947,48481,50000    // 21,22,...30
};


//------------------------------------------------------------------------------
//  SinHueLevel_UMA
//  Entry Condition
//        (BYTE) level - actually is the angle for the Sin function
//  Exit Condition
//        (SHORT) - product of Sin(level) function
//------------------------------------------------------------------------------
LONG SinHueLevel_UMA(IN ULONG level)
{
    long LUT_value;

    if (level < HueLevelNum)
    {
        LUT_value = (long) SinLut_UMA[level];
    }

    else    
    {
        LUT_value = 0;
    }

    return (LUT_value);
}

//----------------------------------------------------------------------------
//  CosHueLevel_UMA
//  Entry Condition:
//        (BYTE) level - actually is the angle for the Cos function
//  Exit Condition:
//        (SHORT) - product of Cos(level) function
//----------------------------------------------------------------------------
LONG CosHueLevel_UMA(IN ULONG level)
{
    long LUT_value;

    if (level < HueLevelNum)
    {
        LUT_value = (long) CosLut_UMA[level];
    }

    else    
    {
        LUT_value = 0;
    }

    return (LUT_value);
}

//-----------------------------------------------------------------------
// TV_I2CRead_BYTE_UMA
//      This function reads Regs on TV encoder, via I2C port  
//   IN :
//      RegIndex : Reg index on TV encoder
//   OUT : 
//      pData : Reg Data
//      CBIOS_STATUS 
//-----------------------------------------------------------------------
CBIOS_STATUS TV_I2CRead_BYTE_UMA(
    PCBIOS_EXTENSION pcbe,
    IN BYTE RegIndex,
    OUT PBYTE pData
    )
{
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;

    if (!pData)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if (!cbGetDII2Csetting(pcbe, &i2c, S3_TV))
    {
        return CBIOS_ER_DDCRead;
    }

    i2c.RegIndex = RegIndex;
    if (I2C_Read_Byte_INV(pcbe, &i2c) == FALSE)
    {
        return CBIOS_ER_DDCRead;
    }
    else
    {
        *pData = i2c.IndexData;
    }

    return CBIOS_OK;
}


//-----------------------------------------------------------------------
// TV_I2CWRITE_BYTE_UMA
//      This function writes Regs on TV encoder, via I2C port  
//   IN :
//      RegIndex : Reg index on TV encoder
//      RegData  : Reg data to write
//   OUT : 
//      CBIOS_STATUS 
//-----------------------------------------------------------------------
CBIOS_STATUS TV_I2CWRITE_BYTE_UMA(
    PCBIOS_EXTENSION pcbe,
    IN BYTE   RegIndex,
    IN BYTE   RegData
    )
{
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;
    
    //TV / HDTV all treat as TV in DIPort
    if (!cbGetDII2Csetting(pcbe, &i2c, S3_TV))
    {
        return CBIOS_ER_DDCRead;
    }

    i2c.RegIndex = RegIndex;
    i2c.IndexData = RegData;
   
    if (I2C_Write_Byte_INV(pcbe, &i2c) == FALSE)
    {
        //I2C error
        return CBIOS_ER_DDCRead;
    }
    
    return CBIOS_OK;
}

BYTE cbGetTVDACState(PCBIOS_EXTENSION pcbe)
{
    ULONG encodertype;
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return 0;
    }
    
    switch(encodertype)
    {
    case VT1625_6:
    case VT1625A_6A:
        return (TV_Read_Byte_UMA(pcbe, 0x0E));
        break;
    case VT1622:
    case VT1622A:
    case VT1623_3A:
        return (TV_Read_Byte_UMA(pcbe, 0x0E));
        break;
    case IN_TV:
        return (cbReadRegByte( pcbe, SR_5E));        
        break;
    default:
        return 0;
    }
}


//-----------------------------------------------------------
//cbSetTVDACState 
//     This function sets TV encoder DAC power state according
//  to the input DAC state paramter
//  now supports three types of dac state
//      ALL_DAC_OFF : close all the DAC
//     SET_DAC_ACCORDING_HDTVOutType : 
//          open DAC powerstate according to HDTV output
//     SET_DAC_ACCORDING_TVOutType :
//          open DAC powerstate according to TV output
//----------------------------------------------------------
void cbSetTVDACState(PCBIOS_EXTENSION pcbe, BYTE DACState)
{
    ULONG encodertype;
    BYTE TVOutType, HDTVOutType, TV_DAC = 0;
   
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return;
    }

    if (DACState == ALL_DAC_OFF)
    {
        // close all DAC
        switch (encodertype)
        {
        case VT1625_6:
        case VT1625A_6A:
        case VT1622:
        case VT1622A:
        case VT1623_3A:
            TV_DAC = 0x3F;   
            break;
        case IN_TV:
            TV_DAC = 0x0E;
            break;
        default:    
             cbDbgPrint(0, "Unknown TV encoder type!\n");
             break;       
        }
    }
    else if (DACState == SET_DAC_ACCORDING_HDTVOutType)
    {
        // set DAC power state according to HDTV output type
        HDTVOutType = pcbe->sPad_11.HDTVOutputType;
        switch ( encodertype )
        {
        case VT1625_6:
        case VT1625A_6A:
            // default no HDTV DACs opened
            // enable HDTV DAC according to HDTV  output setting
            TV_DAC = 0x3F;
            if (HDTV_RGB == HDTVOutType) // HDTV RGB output 
            {
                // some TV may need to use one separate DAC as SYNC output
                // so we need to open one more DAC when RGB output
                TV_DAC &= (~(BIT0 + BIT1 + BIT2 + BIT3)); // open DAC C D E F  
            }
            else // HDTV Y/Pr/Pb output 
            {
                TV_DAC &= (~(BIT0 + BIT1 + BIT2));        // open DAC D E F
            }
            break;
        case IN_TV:
            TV_DAC = 0x3E;
            if (HDTV_RGB == HDTVOutType) // HDTV RGB output 
            {
                TV_DAC &= (~(BIT1 + BIT2 + BIT3 + BIT4)); 
            }
            else // HDTV Y/Pr/Pb output 
            {
                TV_DAC &= (~(BIT1 + BIT2 + BIT3));
            }
            break;
        default:
            break;
        }
    }
    else if (DACState == SET_DAC_ACCORDING_TVOutType)
    {
        // Set DAC power state according to TV output type
        TVOutType = pcbe->sPad_7.TVOutType;
        
        switch(encodertype)
        {
        case VT1625_6:
        case VT1625A_6A:
            // default no TV DACs opened
            TV_DAC = 0x3F;
            if (TVOutType & TV_CVBS)
            {
                TV_DAC &= (~BIT3);                          // open DAC C
            }
            if (TVOutType & (TV_SVideo1 | TV_SVideo2))
            {
                TV_DAC &= (~(BIT4 + BIT5));                 // open DAC A & B
            } 
            if (TVOutType & (TV_RGB | TV_SDTVRGB))
            {
                TV_DAC &= (~(BIT0 + BIT1 + BIT2 + BIT3));   // open DAC: C D E F
            }
            if (TVOutType & (TV_Ycbcr | TV_SDTVYpbpr))
            {
                TV_DAC &= (~(BIT0 + BIT1 + BIT2));          // open DAC: D E F
            }
            break;
         case VT1622:
         case VT1622A:
         case VT1623_3A:
            // default no TV DACs opened
            TV_DAC = 0xF;
            if (TVOutType & TV_CVBS)
            {
                TV_DAC &= (~BIT3);                          // open DAC A
            }
            if (TVOutType & (TV_SVideo1 | TV_SVideo2))
            {
                TV_DAC &= (~(BIT2 + BIT1));                 // open DAC B & C
            } 
            if (TVOutType & (TV_RGB | TV_SDTVRGB))
            {
                TV_DAC &= (~(BIT0 + BIT1 + BIT2 + BIT3));   // open DAC: A B C D
            }
            if (TVOutType & (TV_Ycbcr | TV_SDTVYpbpr))
            {
                TV_DAC &= (~(BIT0 + BIT1 + BIT2));          // open DAC: B C D
            }
            break;
         case IN_TV:
            TV_DAC = 0x3E;
            if (TVOutType & TV_CVBS)
            {
                TV_DAC &= (~(BIT3 + BIT4 + BIT5));
            }
            if (TVOutType & TV_SVideo1)
            {
                TV_DAC &= (~(BIT5 + BIT4 + BIT2 + BIT1));
            }
            if (TVOutType & (TV_RGB | TV_SDTVRGB))
            {
                TV_DAC &= (~(BIT4 + BIT3 + BIT2 + BIT1));
            }
            if (TVOutType & (TV_Ycbcr | TV_SDTVYpbpr))
            {
                TV_DAC &= (~(BIT3 + BIT2 + BIT1));
            }
            break;
         default:
             cbDbgPrint(0, "Now CBIOS only support VT1625\n");
             break;
         }
         
    }
    
    switch(encodertype)
    {
    case VT1625_6:
    case VT1625A_6A:
        TV_Write_Byte_UMA(pcbe, 0x0E, TV_DAC);
        break;
    case VT1622:
    case VT1622A:
    case VT1623_3A:
        TV_Write_Byte_UMA(pcbe, 0x0E, TV_DAC);
        break;
    case IN_TV:
        InTV_Write_Bits_UMA(pcbe, 0x3B, TV_DAC, BIT4+BIT5);
        cbWriteRegBits(pcbe, SR_5E, BIT1+BIT2+BIT3, TV_DAC);
        break;
    default:
        break;
    }
}

//--------------------------------------------------------------------
//cbSetTVVContraction
//  This function sets TV V contraction level, now it includes three level
// of contraction:
//      0. Normal Scan
//      1. Fit Scan
//      2. Over Scan
//    In fact these three tables not only modify V contraction, but also
//  modifies H contraction level. So this may need further modification
//  IN :
//      VContractionLevel : V contraction level to be set
//  OUT:
//      CBIOS_STATUS
//--------------------------------------------------------------------
#define     VT1625_V_Contraction_Total      0x03   // 3 levels of V contraction level

CBIOS_STATUS cbSetTVVContraction(
    PCBIOS_EXTENSION pcbe,
    IN ULONG VContractionLevel
    )
{
    CBIOS_STATUS status = CBIOS_OK;

    // For safety check
    if (VContractionLevel > VT1625_V_Contraction_Total-1)
    {
        VContractionLevel = VT1625_V_Contraction_Total-1;
    }  
    
    // 1. update TV V contraction level
    // since scratch pad stores contraction level is 0 , 1,  2
    pcbe->sPad_5.TV_Contraction = (BYTE)VContractionLevel; 
    pcbe->tvparameter.CurVContraction = VContractionLevel;
    //Write scratch pad,so update hardware registers too
    cbWriteRegBits(pcbe, CR_4B, BIT0+BIT1+BIT2, STRUCT_BYTE(pcbe->sPad_5, 0));

    // 2. reload GFX & TV encoder Register according to 
    //  contraction level in ScratchPad
    // only when TV is the primary device on that IGA can we do 
    // contraction level adjustment
    if (cbGetPrimaryDevice(pcbe->IGA1Info.dispDev) == S3_TV)
    {
        // turn off all the TV DAC to forbid garbage
        cbSetTVDACState(pcbe, ALL_DAC_OFF);
        status = cbSetIGA1DevMode(pcbe, 
                                  pcbe->IGA1Info.HRes,
                                  pcbe->IGA1Info.VRes,
                                  pcbe->IGA1Info.ColorDepth,
                                  pcbe->IGA1Info.RRateInfo);
    }
    else if (cbGetPrimaryDevice(pcbe->IGA2Info.dispDev) == S3_TV)
    {
        // turn off all the TV DAC to forbid garbage
        cbSetTVDACState(pcbe, ALL_DAC_OFF);
        status = cbSetIGA2DevMode(pcbe, 
                                  pcbe->IGA2Info.HRes,
                                  pcbe->IGA2Info.VRes,
                                  pcbe->IGA2Info.ColorDepth,
                                  pcbe->IGA2Info.RRateInfo);
    }
    else
    {
        // other device do not support V contraction level so just return OK
        cbDbgPrint(1, "TV haven't configured to one IGA. Need not to load V Contraction!\n");
        return CBIOS_OK;
    }

    
    // 3. Adjust TV power state 
    //    since set TV contraction level should not change TV 
    // set TV power state includes
    //  1. IGA clock path
    //  2. DIPort config(DPA, source)
    //  3. Device power state
    if (pcbe->devicepowerstate[TVbit] == S3PM_ON && status == CBIOS_OK)
    {
        cbSetTVPowerState(pcbe, S3PM_ON);
    }
    
    return status;
}


//--------------------------------------------------------------------
//cbSetTVHContraction
//      This function sets TV H contraction level. For H contraction level 
//  we do not need to reload the full timing table. Just adjust H scaling
//  factor & H display active.
//      For scaling factor , 0x00 means biggest scaling factor 
//  IN :
//      ContractionLevel : contraction level to be set
//  OUT:
//      CBIOS_STATUS
//--------------------------------------------------------------------
#define     VT1625_HSCALE_Delta             0x03     
#define     VT1625_H_Contraction_Total      0x05

CBIOS_STATUS cbSetTVHContraction(
    PCBIOS_EXTENSION pcbe,
    IN ULONG HContractionLevel
    )
{
    ULONG encodertype;
    CBIOS_STATUS status = CBIOS_OK;
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        // if no TV exists
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }

    switch (encodertype)
    {
    case VT1622:
    case VT1622A:
    case VT1623_3A:
        // adjust VT1622A H contraction level
        //cbSetTVHContraction_1622A(pcbe, HContractionLevel);
        break;
    case VT1625_6:
    case VT1625A_6A:
        // adjust VT1625 H contraction level
        cbSetTVHContraction_1625(pcbe, HContractionLevel);
        break;
    case IN_TV:
        cbDbgPrint(1, "InTV doesn't support H contraction set now!\n");
        status = CBIOS_ER_NOT_YET_IMPLEMENTED;
        break;
    default:
        cbDbgPrint(1, "Error encoder type!\n");    
    }

    return status;
    
}

//--------------------------------------------------------------------
//cbSetTVHContraction
//      This function sets TV H contraction level for VT1622A. For H contraction
//  level we do not need to reload the full timing table. Just adjust H scaling
//  factor & H display active.
//      For scaling factor , 0x00 means biggest scaling factor 
//      It means that when H contraction level increase
//      Scaling factor decrease & display activer increase
//  IN :
//      ContractionLevel : contraction level to be set
//  OUT:
//      CBIOS_STATUS
//--------------------------------------------------------------------
CBIOS_STATUS cbSetTVHContraction_1622A(
    PCBIOS_EXTENSION pcbe,
    IN ULONG HContractionLevel
    )
{
    // other device do not support contraction level  
    cbDbgPrint(0, "Not ready!\n");
    return CBIOS_OK;
}


//--------------------------------------------------------------------
//cbSetTVHContraction
//      This function sets TV H contraction level for VT1625. For H contraction
//  level we do not need to reload the full timing table. Just adjust H scaling
//  factor & H display active.
//      For scaling factor , 0x00 means biggest scaling factor 
//      It means that when H contraction level increase
//      Scaling factor decrease & display activer increase
//  IN :
//      ContractionLevel : contraction level to be set
//  OUT:
//      CBIOS_STATUS
//--------------------------------------------------------------------
CBIOS_STATUS cbSetTVHContraction_1625(
    PCBIOS_EXTENSION pcbe,
    IN ULONG HContractionLevel
    )
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG HContractionlevel_Ori, TVHScaleFactor, TVHDisp_Active;
    BYTE bTV61, bTV58;
    
    // 1. update TV H contraction level
    // For safety check
    if (HContractionLevel > VT1625_H_Contraction_Total-1)
    {
        HContractionLevel = VT1625_H_Contraction_Total-1;
    }  
    //update Current H contraction level
    HContractionlevel_Ori = pcbe->tvparameter.CurHContraction;
    pcbe->tvparameter.CurHContraction = HContractionLevel;
            

    // 2. Adjust H_disp_end & H scaling factor to adjust H contraction level
    if (pcbe->IGA1Info.dispDev & S3_TV || pcbe->IGA2Info.dispDev & S3_TV )
    {
        //Read original Horizontal Scale Factor
        bTV61 = TV_Read_Byte_UMA(pcbe, 0x61);
        TVHScaleFactor = (((ULONG) bTV61 & 0x0F) << 8) 
                        | TV_Read_Byte_UMA(pcbe, 0x5F);

        bTV58 = TV_Read_Byte_UMA(pcbe, 0x58);
        TVHDisp_Active = (((DWORD) bTV58 & 0xF0) <<4) 
                        | TV_Read_Byte_UMA(pcbe, 0x56);
        
        
        if ( HContractionLevel >= HContractionlevel_Ori )
        {             
            // Scale up
            // whether need to update H scale factor
            if( TVHScaleFactor >= VT1625_HSCALE_Delta * (HContractionLevel - HContractionlevel_Ori) )
            {
                TVHScaleFactor = TVHScaleFactor - 
                        VT1625_HSCALE_Delta * (HContractionLevel - HContractionlevel_Ori);        
            }
                 
            TVHDisp_Active += HContractionLevel - HContractionlevel_Ori;
        }
        else
        {   
            // Scale down
            // Sub the difference
            TVHScaleFactor = TVHScaleFactor + 
                    VT1625_HSCALE_Delta * (HContractionlevel_Ori - HContractionLevel);
            TVHDisp_Active -= HContractionlevel_Ori - HContractionLevel;
        }

        //Write new Horizontal Scale Factor. TV60[5:4], TV5F[7:0]
        TV_Write_Byte_UMA(pcbe, 0x5F, (BYTE)(TVHScaleFactor & 0xFF));
        bTV61 = (bTV61 & 0xF0) | (BYTE)((TVHScaleFactor >> 8));
        TV_Write_Byte_UMA(pcbe, 0x61, bTV61);
        
            
        //Write new TH_Active. TV58[5:4], TV56[7:0]
        TV_Write_Byte_UMA(pcbe, 0x56, (BYTE)(TVHDisp_Active & 0xFF));
        bTV58 = (bTV58 & 0x0F) | (BYTE)((TVHDisp_Active & 0xF00) >> 4);
        TV_Write_Byte_UMA(pcbe, 0x58, bTV58);
    }
    else
    {
        // other device do not support contraction level  
        cbDbgPrint(1, "TV haven't configured to one IGA. Need not to load V Contraction!\n");
        return CBIOS_OK;
    }

    
    return status;
}

BOOL cbGetRefreshRatesForTVorHDTV (
    IN PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN OUT RefreshRateInfo *pRRatesInfoBuf,
    IN OUT DWORD *pBufSize
)
{
    BYTE rrNum = 0;
	ULONG i = 0;

    if (!pRRatesInfoBuf || !pBufSize)
    {
        cbDbgPrint(0, "cbGetRefreshRatesForTVorHDTV: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    if(dispDev == S3_HDTV)
    {
        // search in HDTV resolution refreshrate table
        // to get refresh rate info
        for (i = 0; i < HDTV_REFRESHRATE_NUM; i++)
        {
            if (HDTVResolutionRefreshRate[i].xRes == H_Res
             && HDTVResolutionRefreshRate[i].yRes == V_Res)
            {
                pRRatesInfoBuf[rrNum].rRateX100 = HDTVResolutionRefreshRate[i].RefreshRate * 100;
                pRRatesInfoBuf[rrNum].interlaced = HDTVResolutionRefreshRate[i].interlaced;
                rrNum++;
                //Is buffer size enough for saving next refresh rate info?
                if ( ((rrNum+1) * sizeof(RefreshRateInfo)) > (*pBufSize) )
                {
                    // if no enough space in the buffer, jump out
                    break;
                }
            }
        }
        *pBufSize = rrNum * sizeof(RefreshRateInfo);
    }
    else if(dispDev == S3_TV)
    {
        switch (pcbe->sPad_8.TV_Type)
        {
        case PAL:
        case PALN:
        case PALNc:
        case PALI:
        case PALD:
            // only support one refresh rate of 50Hz
            pRRatesInfoBuf[rrNum].rRateX100 = 50 * 100; 
            pRRatesInfoBuf[rrNum].interlaced = PROGRESSIVE;
            break;
        case NTSC:
        case NTSCJP:
        case PALM:                      // PALM is base on NTSC to adjust
        default:
            // only support one refresh rate of 60Hz
            pRRatesInfoBuf[rrNum].rRateX100 = 60 * 100; 
            pRRatesInfoBuf[rrNum].interlaced = PROGRESSIVE;
            break;
        }
        rrNum = 1;
        *pBufSize = rrNum * sizeof(RefreshRateInfo);
    }
    else
    {
        cbDbgPrint(1, "cbGetRefreshRatesForTVorHDTV: Error, incorrectly parameter !\n");
        return FALSE;
    }

    return TRUE;
}

