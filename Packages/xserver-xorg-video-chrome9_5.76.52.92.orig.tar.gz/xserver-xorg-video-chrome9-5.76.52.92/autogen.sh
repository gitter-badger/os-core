#! /bin/sh

CONFIGURE_AC="./configure.ac"
SRC_MAKEFILE_AM="./src/Makefile.am"

# input    : sub module's path name
# function : to Modify the file "configure.ac" and "./src/Makefile.am"
ModifyFiles()
{
    # delete SubModule component in ./configure.ac and ./src/Makefile.am fisrt, no matter it is exist or not.
    sed -i "/src\/$1\/Makefile/"d $CONFIGURE_AC 
    sed -i "s/ $1//g" $SRC_MAKEFILE_AM
    if [  -d "./src/$1" ];  then              # if the SubModule exists
        # add string to the end of line beginning of "SUBDIRS" in src/Makefile.am
        sed -i "/^SUBDIRS/s/$/ $1/" $SRC_MAKEFILE_AM
        # add a line below the line "man/Makefile" in configure.ac
        sed -i "/man\/Makefile/a\	src\/$1\/Makefile" $CONFIGURE_AC
        echo ".... SubModule <$1> found."
    else
        echo ".... SubModule <$1> not found."
    fi
}

check_Kernel_Version()
{
    REAL_KERNEL_MAKEFILE=/lib/modules/$(uname -r)/build/Makefile
    USER_LINUX_VERSION_FILE=/usr/include/linux/version.h
    if [ ! -e ${REAL_KERNEL_MAKEFILE} ]; then
        echo "File: ${REAL_KERNEL_MAKEFILE} does not exist! Skip checking kernel verison."
        return 1
    fi
    if [ ! -e ${USER_LINUX_VERSION_FILE} ]; then
        echo "File: ${USER_LINUX_VERSION_FILE} does not exist! Skip checking kernel verison."
        return 1
    fi
    VERSION=$(sed -n 1p ${REAL_KERNEL_MAKEFILE} | cut -d" " -f 3)
    PATCHLEVEL=$(sed -n 2p ${REAL_KERNEL_MAKEFILE} | cut -d" " -f 3)
    SUBLEVEL=$(sed -n 3p ${REAL_KERNEL_MAKEFILE} | cut -d" " -f 3)
    REAL_KERNEL_VERSION=`expr $((VERSION << 16)) + $((PATCHLEVEL << 8)) + $((SUBLEVEL))`
    #echo ${REAL_KERNEL_VERSION}

    USER_LINUX_VERSION=$(sed -n 1p ${USER_LINUX_VERSION_FILE} | cut -d" " -f 3)
    #echo ${USER_LINUX_VERSION}

    if [ ${REAL_KERNEL_VERSION} != ${USER_LINUX_VERSION} ]; then
        #echo "Real kernel verison: ${VERSION}.${PATCHLEVEL}.${SUBLEVEL}"
        echo "WARNING: Real kenel verison(${REAL_KERNEL_VERSION}) is different from verison in /usr/include/linux/verison.h(${USER_LINUX_VERSION})."
        echo "Modify version in /usr/include/linux/version.h to real kernel version(${REAL_KERNEL_VERSION})!"
        sed -i "1s/${USER_LINUX_VERSION}/${REAL_KERNEL_VERSION}/g" ${USER_LINUX_VERSION_FILE}
    fi
}

srcdir=`dirname $0`
test -z "$srcdir" && srcdir=.

ORIGDIR=`pwd`
cd $srcdir
if [ ! -d m4 ];then
    mkdir  m4
fi

#ModifyFiles vt1625
#ModifyFiles AD9389
#ModifyFiles SIL164
#ModifyFiles CH7301

check_Kernel_Version
autoreconf -v --install || exit 1
cd $ORIGDIR || exit $?

$srcdir/configure --enable-maintainer-mode --disable-debug "$@"
