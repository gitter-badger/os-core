/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
 
#ifndef __VIA_OUTPUT_H__
#define __VIA_OUTPUT_H__

#include "xf86Crtc.h"

typedef struct _subChipVerInfo
{
    CARD8 address;
    CARD8 numOfRevReg;
    CARD8 *revOffset;
    CARD8 *revId;
    CARD32 subChipName;
} subChipVerInfo, *subChipVerInfoPtr;

/*TV Encoder*/
static CARD8 vt1625VerReg[SUBCHIP_VT1625_VERSION_REG_NUM] = {
    SUBCHIP_VT1625_VERSION_REG
};

static CARD8 vt1625VerId[SUBCHIP_VT1625_VERSION_REG_NUM] = {
    SUBCHIP_VT1625_VERSION
};

static subChipVerInfo vt1625Info = {
    SUBCHIP_VT1625_SLAVE_ADDR,
    SUBCHIP_VT1625_VERSION_REG_NUM,
    vt1625VerReg,
    vt1625VerId,
    SUBCHIP_VT1625
};

/*TMDS Transmitter*/
static CARD8 vt1632VerReg[SUBCHIP_VT1632_VERSION_REG_NUM] = {
    SUBCHIP_VT1632_VERSION_LOW_REG,
    SUBCHIP_VT1632_VERSION_HI_REG
};

static CARD8 vt1632VerId[SUBCHIP_VT1632_VERSION_REG_NUM] = {
    SUBCHIP_VT1632_VERSION_LOW,
    SUBCHIP_VT1632_VERSION_HI
};

static subChipVerInfo vt1632Info = {
    SUBCHIP_VT1632_SLAVE_ADDR,
    SUBCHIP_VT1632_VERSION_REG_NUM,
    vt1632VerReg,
    vt1632VerId,
    SUBCHIP_VT1632
};

static unsigned char sil164VerReg[SUBCHIP_SIL164_VERSION_REG_NUM] = {
    SUBCHIP_SIL164_VENDOR_LOW_REG,
    SUBCHIP_SIL164_VENDOR_HI_REG,
    SUBCHIP_SIL164_DEVICEID_LOW_REG,
    SUBCHIP_SIL164_DEVICEID_HI_REG
};

static unsigned char sil164VerId[SUBCHIP_SIL164_VERSION_REG_NUM] = {
    SUBCHIP_SIL164_VENDOR_LOW,
    SUBCHIP_SIL164_VENDOR_HI,
    SUBCHIP_SIL164_DEVICEID_LOW,
    SUBCHIP_SIL164_DEVICEID_HI
};

static subChipVerInfo sil164Info = {
    SUBCHIP_SIL164_SLAVE_ADDR,
    SUBCHIP_SIL164_VERSION_REG_NUM,
    sil164VerReg,
    sil164VerId,
    SUBCHIP_SIL164
};

static CARD8 ch7301VerReg[SUBCHIP_CH7301_VERSION_REG_NUM] = {
    SUBCHIP_CH7301_VERSIONID_REG,
    SUBCHIP_CH7301_DEVICEID_REG,
};

static CARD8 ch7301VerId[SUBCHIP_CH7301_VERSION_REG_NUM] = {
    SUBCHIP_CH7301_VERSIONID,
    SUBCHIP_CH7301_DEVICEID,
};

static subChipVerInfo ch7301Info_Ec = {
    SUBCHIP_CH7301_SLAVE_ADDR_EC,
    SUBCHIP_CH7301_VERSION_REG_NUM,
    ch7301VerReg,
    ch7301VerId,
    SUBCHIP_CH7301
};

static subChipVerInfo ch7301Info_Ea = {
    SUBCHIP_CH7301_SLAVE_ADDR_EA,
    SUBCHIP_CH7301_VERSION_REG_NUM,
    ch7301VerReg,
    ch7301VerId,
    SUBCHIP_CH7301
};

/*LVDS Transmitter*/
static CARD8 vt1636VerReg[SUBCHIP_VT1636_VERSION_REG_NUM] = {
    SUBCHIP_VT1636_VERSION_LOW_REG,
    SUBCHIP_VT1636_VERSION_HI_REG
};

static CARD8 vt1636VerId[SUBCHIP_VT1636_VERSION_REG_NUM] = {
    SUBCHIP_VT1636_VERSION_LOW,
    SUBCHIP_VT1636_VERSION_HI
};

static subChipVerInfo vt1636Info = {
    SUBCHIP_VT1636_SLAVE_ADDR,
    SUBCHIP_VT1636_VERSION_REG_NUM,
    vt1636VerReg,
    vt1636VerId,
    SUBCHIP_VT1636
};

typedef struct _serialPortInfo
{
    CARD32 serialPort;
    Bool isFree;
} serialPortInfo, *serialPortInfoPtr;

static serialPortInfo serialPortTable[] = {
    {DISP_SERIALP_2C, TRUE},
    {DISP_SERIALP_31, TRUE},
    {DISP_SERIALP_25, TRUE},
    {DISP_SERIALP_3D, TRUE},
    {DISP_SERIALP_26, TRUE}
};

#define NUM_SERIAL_PORT CMDISP_ARRAYSIZE(serialPortTable)

#define ANALOG_DEVICE  0x00
#define DIGITER_DEVICE 0x01

#define OUTPUT_CRT_NAME       "CRT"
#define OUTPUT_CRT2_NAME      "CRT-2"
#define OUTPUT_LCD_NAME       "LCD"
#define OUTPUT_LCD2_NAME      "LCD-2"
#define OUTPUT_DVI_NAME       "DVI"
#define OUTPUT_DVI2_NAME      "DVI-2"
#define OUTPUT_TV_NAME        "TV"
#define OUTPUT_TV2_NAME       "TV-2"
#define OUTPUT_HDMI_NAME      "HDMI"
#define OUTPUT_HDMI2_NAME     "HDMI-2"
#define OUTPUT_DP_NAME        "DP"
#define OUTPUT_DP2_NAME       "DP-2"

typedef struct _ViaOutputInfo
{
    CARD32 serialPort;
    CARD32 ddcPort;
    CARD32 subChipName;
    CARD32 slaveAddress;
    CARD32 diPort;
    CARD32 physicalWidth;
    CARD32 physicalHeight;
    CARD32 type;
    Bool NoDDCValue;
    Bool hasHotplug;
    Bool isOuputIgnored;	       /* This output is ignored by XF86ConfigFile */
    unsigned char *rawEDID;
} ViaOutputInfo, *ViaOutputInfoPtr;

typedef struct _ViaGfxDPA
{
    CARD8 clkPolarity;		       /*Clock Polarity */
    CARD8 clkAdjust;		       /*Clock Adjust */
    CARD8 clkDrivingSel;	       /*DVP0 or DVP1 Clock Driving Selection */
    CARD8 dataDrivingSel;	       /*DVP0 or DVP1 Data Driving Selection */
    Bool isClkPolarityUsed;
    Bool isClkAdjustUsed;
    Bool isClkDrivingSelUsed;
    Bool isDataDrivingSelUsed;
} ViaGfxDPA, *ViaGfxDPAPtr;

typedef struct _ViaLvdsDPA
{
    CARD8 Vt1636ClkSelST1;
    CARD8 Vt1636ClkSelST2;
    Bool isVt1636ClkSelST1Used;
    Bool isVt1636ClkSelST2Used;
} ViaLvdsDPA, *ViaLvdsDPAPtr;

typedef struct _ViaCrtPrivateInfo
{
    ViaOutputInfo commonInfo;
    ViaGfxDPA userGfxDPA;
} ViaCrtPrivateInfo, *ViaCrtPrivateInfoPtr;

typedef struct _ViaDviPrivateInfo
{
    ViaOutputInfo commonInfo;
    ViaGfxDPA userGfxDPA;
} ViaDviPrivateInfo, *ViaDviPrivateInfoPtr;

typedef struct _ViaLcdPrivateInfo
{
    ViaOutputInfo commonInfo;
    ViaGfxDPA userGfxDPA;
    ViaLvdsDPA userLvdsDPA;
    CARD32 panelIndex;
    CARD32 dualChannel;
    CARD32 noDithering;
    CARD32 center;
    CARD32 msb;
    CARD32 fixOnIGA1;
    DisplayModePtr confMode;
} ViaLcdPrivateInfo, *ViaLcdPrivateInfoPtr;

typedef struct _ViaHdmiPrivateInfo
{
    ViaOutputInfo commonInfo;
    Bool hasExtEDID;
    Bool attachAllModes;
    OsTimerPtr hotplugTimer;
    OsTimerPtr ctsUpdateTimer;
    ViaGfxDPA userGfxDPA;
    Bool isAD9389CircuitStateAdjustUsed;
    CARD8 AD9389CircuitStateAdjust;
    void *savedRegs;	   /*device related registers is used when light it */
    Bool fixOnIGA1;
} ViaHdmiPrivateInfo, *ViaHdmiPrivateInfoPtr;

typedef struct _ViaInternalHdmiReg
{
    CARD32 C000;
    CARD32 C0B4;
    CARD32 C200;

    /* AVI Info Frame */
    CARD32 AVI_C204;
    CARD32 AVI_C208;
    CARD32 AVI_C20C;
    CARD32 AVI_C210;
    CARD32 AVI_C214;
    CARD32 AVI_C218;
    CARD32 AVI_C21C;
    CARD32 AVI_C220;
    CARD32 AVI_C224;

    /* Audio Info Frame */
    CARD32 Audio_C204;
    CARD32 Audio_C208;
    CARD32 Audio_C20C;
    CARD32 Audio_C210;
    CARD32 Audio_C214;
    CARD32 Audio_C218;
    CARD32 Audio_C21C;
    CARD32 Audio_C220;
    CARD32 Audio_C224;

    /* HD Aduio Para */
    CARD32 C400;
    CARD32 C404;
    CARD32 C410;
    CARD32 C414;
    CARD32 C424;

    /* HDMI general control */
    CARD32 C280;
    CARD32 C284;
    CARD32 C294;
    CARD32 C298;
    CARD32 C29C;

    /* DP1 general control */
    CARD32 C640;

    /* Ephy control */
    CARD32 C740;
    CARD32 C744;
    CARD32 C748;
    CARD32 C74C;
} ViaInternalHdmiReg;

typedef struct _ViaDPPrivateInfo
{
    ViaOutputInfo commonInfo;
    int DPCDVersion;
    int LinkSpeed;
    CARD32 TURatio;
    OsTimerPtr hotplugTimer;
    Bool IsLinkTrainingDone;
    Bool IsDPConnected;
} ViaDPPrivateInfo, *ViaDPPrivateInfoPtr;

/*****************************************************/
/*                Function declaration               */
/*****************************************************/
void via_output_init(ScrnInfoPtr pScrn);
void viaDIPortPadOff(int scrnIndex, int DIPort);
void viaSetOutputPath(int scrnIndex, CARD32 diPort, int igaPath, int chipset);
CARD32 transformDiPort(char *pStr);
CARD32 transformOutputType(char *pStr);
Bool checkDiPortUsage(VIAPtr pVia, CARD32 diPort);
void loadTvDefaultDPASetting(xf86OutputPtr output, CARD32 chipset,
    CARD32 resIndex);
void LoadUserGfxDPASetting(CARD32 port, ViaGfxDPAPtr pVal);
void viaSetScalePath(CARD32 IgaPath, CARD32 ScaleType);
xf86OutputPtr viaOutputCreate(ScrnInfoPtr pScrn,
    const xf86OutputFuncsRec * funcs, const char *name);

#endif
