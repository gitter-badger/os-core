/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*************************************************************************
 *
 *  File:       hw.h
 *  Content:    migration from frame buffer device driver's function.
 *
 ************************************************************************/

#ifndef __HW_H__
#define __HW_H__ 1

/* MISC */
#define ARRAY_SIZE(x)   (sizeof(x) / sizeof(*(x)))

/* Sequencer Registers */
#define SR01    0x01
#define SR10    0x10
#define SR12    0x12
#define SR15    0x15
#define SR16    0x16
#define SR17    0x17
#define SR18    0x18
#define SR1A    0x1A
#define SR1B    0x1B
#define SR1C    0x1C
#define SR1D    0x1D
#define SR1E    0x1E
#define SR1F    0x1F
#define SR19    0x19
#define SR20    0x20
#define SR21    0x21
#define SR22    0x22
#define SR26    0x26
#define SR2A    0x2A
#define SR2C    0x2C
#define SR2D    0x2D
#define SR2E    0x2E
#define SR31    0x31
#define SR39    0x39
#define SR3A    0x3A
#define SR3D    0x3D
#define SR3E    0x3E
#define SR3F    0x3F
#define SR40    0x40
#define SR42    0x42
#define SR43    0x43
#define SR44    0x44
#define SR45    0x45
#define SR46    0x46
#define SR47    0x47
#define SR48    0x48
#define SR49    0x49
#define SR4A    0x4A
#define SR4B    0x4B
#define SR4C    0x4C
#define SR4F    0x4F
#define SR50    0x50
#define SR51    0x51
#define SR57    0x57
#define SR58    0x58
#define SR59    0x59
#define SR5D    0x5D
#define SR5E    0x5E
#define SR65    0x65


/* CRT Controller Registers */
#define CR00    0x00
#define CR01    0x01
#define CR02    0x02
#define CR03    0x03
#define CR04    0x04
#define CR05    0x05
#define CR06    0x06
#define CR07    0x07
#define CR08    0x08
#define CR09    0x09
#define CR0A    0x0A
#define CR0B    0x0B
#define CR0C    0x0C
#define CR0D    0x0D
#define CR0E    0x0E
#define CR0F    0x0F
#define CR10    0x10
#define CR11    0x11
#define CR12    0x12
#define CR13    0x13
#define CR14    0x14
#define CR15    0x15
#define CR16    0x16
#define CR17    0x17
#define CR18    0x18


/* Extend CRT Controller Registers */
#define CR30    0x30
#define CR31    0x31
#define CR32    0x32
#define CR33    0x33
#define CR34    0x34
#define CR35    0x35
#define CR36    0x36
#define CR37    0x37
#define CR3B    0x3B
#define CR3C    0x3C
#define CR3E    0x3E
#define CR41    0x41
#define CR42    0x42
#define CR43    0x43
#define CR45    0x45
#define CR47    0x47
#define CR48    0x48
#define CR4F    0x4F
#define CR50    0x50
#define CR51    0x51
#define CR52    0x52
#define CR53    0x53
#define CR54    0x54
#define CR55    0x55
#define CR56    0x56
#define CR57    0x57
#define CR58    0x58
#define CR59    0x59
#define CR5A    0x5A
#define CR5B    0x5B
#define CR5C    0x5C
#define CR5D    0x5D
#define CR5E    0x5E
#define CR5F    0x5F
#define CR62    0x62
#define CR63    0x63
#define CR64    0x64
#define CR65    0x65
#define CR66    0x66
#define CR67    0x67
#define CR68    0x68
#define CR69    0x69
#define CR6A    0x6A
#define CR6B    0x6B
#define CR6C    0x6C
#define CR6D    0x6D
#define CR6E    0x6E
#define CR6F    0x6F
#define CR70    0x70
#define CR71    0x71
#define CR72    0x72
#define CR73    0x73
#define CR74    0x74
#define CR75    0x75
#define CR76    0x76
#define CR77    0x77
#define CR78    0x78
#define CR79    0x79
#define CR7A    0x7A
#define CR7B    0x7B
#define CR7C    0x7C
#define CR7D    0x7D
#define CR7E    0x7E
#define CR7F    0x7F
#define CR80    0x80
#define CR81    0x81
#define CR82    0x82
#define CR83    0x83
#define CR84    0x84
#define CR85    0x85
#define CR86    0x86
#define CR87    0x87
#define CR88    0x88
#define CR89    0x89
#define CR8A    0x8A
#define CR8B    0x8B
#define CR8C    0x8C
#define CR8D    0x8D
#define CR8E    0x8E
#define CR8F    0x8F
#define CR90    0x90
#define CR91    0x91
#define CR92    0x92
#define CR94    0x94
#define CR95    0x95
#define CR96    0x96
#define CR97    0x97
#define CR99    0x99
#define CR9B    0x9B
#define CR9D    0x9D
#define CR9E    0x9E
#define CR9F    0x9F
#define CRA2    0xA2
#define CRA3    0xA3
#define CRAB    0xAB
#define CRAC    0xAC
#define CRD2    0xD2
#define CRD3    0xD3
#define CRD4    0xD4
#define CRD9    0xD9
#define CRDA    0xDA
#define CRDB    0xDB
#define CRDC    0xDC
#define CRDD    0xDD
#define CRDE    0xDE
#define CRDF    0xDF
#define CRE0    0xE0
#define CRE1    0xE1
#define CRE2    0xE2
#define CRE3    0xE3
#define CRE4    0xE4
#define CRE5    0xE5
#define CRE6    0xE6
#define CRE7    0xE7
#define CRE8    0xE8
#define CRE9    0xE9
#define CREA    0xEA
#define CREB    0xEB
#define CREC    0xEC
#define CRF3    0xF3
#define CRFB    0xFB
#define CRFC    0xFC
#define CRFD    0xFD
#define CRFF    0xFF

/* Definition Refresh Rate */
#define REFRESH_43      43
#define REFRESH_47      47
#define REFRESH_50      50
#define REFRESH_60      60
#define REFRESH_70      70
#define REFRESH_75      75
#define REFRESH_85      85
#define REFRESH_90      90
#define REFRESH_100     100
#define REFRESH_120     120
#define REFRESH_160     160


/* Definition Sync Polarity*/
#define NEGATIVE        1
#define POSITIVE        0

/* 640x480@60 Sync Polarity (DMT Mode) */
#define M640X480_R60_HSP        NEGATIVE
#define M640X480_R60_VSP        NEGATIVE

/* 640x480@75 Sync Polarity (DMT Mode) */
#define M640X480_R75_HSP        NEGATIVE
#define M640X480_R75_VSP        NEGATIVE

/* 640x480@85 Sync Polarity (DMT Mode) */
#define M640X480_R85_HSP        NEGATIVE
#define M640X480_R85_VSP        NEGATIVE

/* 640x480@100 Sync Polarity (GTF Mode) */
#define M640X480_R100_HSP       NEGATIVE
#define M640X480_R100_VSP       POSITIVE

/* 640x480@120 Sync Polarity (GTF Mode) */
#define M640X480_R120_HSP       NEGATIVE
#define M640X480_R120_VSP       POSITIVE

/* 640x480@160 Sync Polarity (CVT Mode)*/
#define M640X480_R160_HSP       NEGATIVE
#define M640X480_R160_VSP       POSITIVE

/* 720x480@60 Sync Polarity  (GTF Mode) */
#define M720X480_R60_HSP        NEGATIVE
#define M720X480_R60_VSP        POSITIVE

/* 720x576@60 Sync Polarity  (GTF Mode) */
#define M720X576_R60_HSP        NEGATIVE
#define M720X576_R60_VSP        POSITIVE

/* 800x480@60 Sync Polarity  (GFT Mode) */
#define M800X480_R60_HSP        NEGATIVE
#define M800X480_R60_VSP        POSITIVE

/* 800x600@60 Sync Polarity (DMT Mode) */
#define M800X600_R60_HSP        POSITIVE
#define M800X600_R60_VSP        POSITIVE

/* 800x600@75 Sync Polarity (DMT Mode) */
#define M800X600_R75_HSP        POSITIVE
#define M800X600_R75_VSP        POSITIVE

/* 800x600@85 Sync Polarity (DMT Mode) */
#define M800X600_R85_HSP        POSITIVE
#define M800X600_R85_VSP        POSITIVE

/* 800x600@100 Sync Polarity (GTF Mode) */
#define M800X600_R100_HSP       NEGATIVE
#define M800X600_R100_VSP       POSITIVE

/* 800x600@120 Sync Polarity (GTF Mode) */
#define M800X600_R120_HSP       NEGATIVE
#define M800X600_R120_VSP       POSITIVE

/* 800x600@160 Sync Polarity (CVT Mode) */
#define M800X600_R160_HSP       NEGATIVE
#define M800X600_R160_VSP       POSITIVE

/* 848x480@60 Sync Polarity  (CVT Mode) */
#define M848X480_R60_HSP        NEGATIVE
#define M848X480_R60_VSP        POSITIVE

/* 852x480@60 Sync Polarity  (GTF Mode) */
#define M852X480_R60_HSP        NEGATIVE
#define M852X480_R60_VSP        POSITIVE

/* 960x600@60 Sync Polarity (GTF Mode) */
#define M960X600_R60_HSP        NEGATIVE
#define M960X600_R60_VSP        POSITIVE

/* 1000x600@60 Sync Polarity (GTF Mode) */
#define M1000X600_R60_HSP       NEGATIVE
#define M1000X600_R60_VSP       POSITIVE

/* 1024x512@60 Sync Polarity (GTF Mode) */
#define M1024X512_R60_HSP       NEGATIVE
#define M1024X512_R60_VSP       POSITIVE

/* 1024x576@60 Sync Polarity (GTF Mode) */
#define M1024X576_R60_HSP       NEGATIVE
#define M1024X576_R60_VSP       POSITIVE

/*1024x600@60 Sync Polarity (GTF Mode)*/
#define M1024X600_R60_HSP       NEGATIVE
#define M1024X600_R60_VSP       POSITIVE

/* 1024x768@60 Sync Polarity (DMT Mode) */
#define M1024X768_R60_HSP       NEGATIVE
#define M1024X768_R60_VSP       NEGATIVE

/* 1024x768@70 Sync Polarity (DMT Mode) */
#define M1024X768_R70_HSP       NEGATIVE
#define M1024X768_R70_VSP       NEGATIVE

/* 1024x768@75 Sync Polarity (DMT Mode) */
#define M1024X768_R75_HSP       POSITIVE
#define M1024X768_R75_VSP       POSITIVE

/* 1024x768@85 Sync Polarity (DMT Mode) */
#define M1024X768_R85_HSP       POSITIVE
#define M1024X768_R85_VSP       POSITIVE

/* 1024x768@100 Sync Polarity (GTF Mode) */
#define M1024X768_R100_HSP      NEGATIVE
#define M1024X768_R100_VSP      POSITIVE

/* 1024x768@120 Sync Polarity (CVT Mode) */
#define M1024X768_R120_HSP      NEGATIVE
#define M1024X768_R120_VSP      POSITIVE

/* 1088x612@60 Sync Polarity (CVT Mode) */
#define M1088X612_R60_HSP       NEGATIVE
#define M1088X612_R60_VSP       POSITIVE

/* 1152x720@60 Sync Polarity (CVT Mode) */
#define M1152X720_R60_HSP       NEGATIVE
#define M1152X720_R60_VSP       POSITIVE

/* 1152x864@60 Sync Polarity (GTF Mode) */
#define M1152X864_R60_HSP       NEGATIVE
#define M1152X864_R60_VSP       POSITIVE

/* 1152x864@70 Sync Polarity (CVT Mode) */
#define M1152X864_R70_HSP       NEGATIVE
#define M1152X864_R70_VSP       POSITIVE

/* 1152x864@75 Sync Polarity (DMT Mode) */
#define M1152X864_R75_HSP       POSITIVE
#define M1152X864_R75_VSP       POSITIVE

/* 1200x720@60 Sync Polarity (GTF Mode) */
#define M1200X720_R60_HSP       NEGATIVE
#define M1200X720_R60_VSP       POSITIVE

/* 1280x600@60 Sync Polarity (GTF Mode) */
#define M1280x600_R60_HSP       NEGATIVE
#define M1280x600_R60_VSP       POSITIVE

/* 1280x720@50 Sync Polarity  (GTF Mode) */
#define M1280X720_R50_HSP       NEGATIVE
#define M1280X720_R50_VSP       POSITIVE

/* 1280x720@60 Sync Polarity  (GTF Mode) */
#define M1280X720_R60_HSP       POSITIVE
#define M1280X720_R60_VSP       POSITIVE

/* 1280x720@75 Sync Polarity  (CVT Mode) */
#define M1280X720_R75_HSP       NEGATIVE
#define M1280X720_R75_VSP       POSITIVE

/* 1280x768@50 Sync Polarity  (GTF Mode) */
#define M1280X768_R50_HSP       NEGATIVE
#define M1280X768_R50_VSP       POSITIVE

/* 1280x768@60 Sync Polarity  (GTF Mode) */
#define M1280X768_R60_HSP       NEGATIVE
#define M1280X768_R60_VSP       POSITIVE

/* 1280x800@60 Sync Polarity  (GTF Mode) */
#define M1280X800_R60_HSP       NEGATIVE
#define M1280X800_R60_VSP       POSITIVE

/* 1280x854@60 Sync Polarity  (CVT Mode) */
#define M1280X854_R60_HSP       NEGATIVE
#define M1280X854_R60_VSP       POSITIVE

/* 1280x960@60 Sync Polarity (DMT Mode) */
#define M1280X960_R60_HSP       POSITIVE
#define M1280X960_R60_VSP       POSITIVE

/* 1280x1024@60 Sync Polarity (DMT Mode) */
#define M1280X1024_R60_HSP      POSITIVE
#define M1280X1024_R60_VSP      POSITIVE

/* 1280x1024@75 Sync Polarity (DMT Mode) */
#define M1280X1024_R75_HSP      POSITIVE
#define M1280X1024_R75_VSP      POSITIVE

/* 1280x1024@85 Sync Polarity (DMT Mode) */
#define M1280X1024_R85_HSP      POSITIVE
#define M1280X1024_R85_VSP      POSITIVE

/* 1360x768@60 Sync Polarity (CVT Mode) */
#define M1360X768_R60_HSP       POSITIVE
#define M1360X768_R60_VSP       POSITIVE

/* 1368x768@50 Sync Polarity (GTF Mode) */
#define M1368X768_R50_HSP       NEGATIVE
#define M1368X768_R50_VSP       POSITIVE

/* 1368x768@60 Sync Polarity (GTF Mode) */
#define M1368X768_R60_HSP       NEGATIVE
#define M1368X768_R60_VSP       POSITIVE

/* 1400x1050@60 Sync Polarity (CVT Mode) */
#define M1400X1050_R60_HSP      NEGATIVE
#define M1400X1050_R60_VSP      POSITIVE

/* 1440x900@60 Sync Polarity (CVT Mode) */
#define M1440X900_R60_HSP       NEGATIVE
#define M1440X900_R60_VSP       POSITIVE

/* 1440x1050@60 Sync Polarity (GTF Mode) */
#define M1440X1050_R60_HSP      NEGATIVE
#define M1440X1050_R60_VSP      POSITIVE

/* 1600x900@60 Sync Polarity (CVT Mode) */
#define M1600X900_R60_HSP       NEGATIVE
#define M1600X900_R60_VSP       POSITIVE

/* 1600x1024@60 Sync Polarity (GTF Mode) */
#define M1600X1024_R60_HSP      NEGATIVE
#define M1600X1024_R60_VSP      POSITIVE

/* 1600x1200@60 Sync Polarity (DMT Mode) */
#define M1600X1200_R60_HSP      POSITIVE
#define M1600X1200_R60_VSP      POSITIVE

/* 1600x1200@75 Sync Polarity (DMT Mode) */
#define M1600X1200_R75_HSP      POSITIVE
#define M1600X1200_R75_VSP      POSITIVE

/* 1600x1200@85 Sync Polarity */
#define M1600X1200_R85_HSP      POSITIVE
#define M1600X1200_R85_VSP      POSITIVE

/* 1680x600@60 Sync Polarity (GTF Mode) */
#define M1680x600_R60_HSP       NEGATIVE
#define M1680x600_R60_VSP       POSITIVE

/* 1680x1050@60 Sync Polarity (CVT Mode) */
#define M1680x1050_R60_HSP      NEGATIVE
#define M1680x1050_R60_VSP      POSITIVE

/* 1792x1344@60 Sync Polarity (DMT Mode) */
#define M1792x1344_R60_HSP      NEGATIVE
#define M1792x1344_R60_VSP      POSITIVE

/* 1856x1392@60 Sync Polarity (DMT Mode) */
#define M1856x1392_R60_HSP      NEGATIVE
#define M1856x1392_R60_VSP      POSITIVE

/* 1920x1080@60 Sync Polarity (DMT Mode) */
#define M1920X1080_R60_HSP      POSITIVE
#define M1920X1080_R60_VSP      POSITIVE

/* 1920x1080@75 Sync Polarity (CVT Mode) */
#define M1920X1080_R75_HSP      NEGATIVE
#define M1920X1080_R75_VSP      POSITIVE

/* 1920x1080@60 Sync Polarity (CVT Reduce Blanking Mode) */
#define M1920X1080_RB_R60_HSP  POSITIVE
#define M1920X1080_RB_R60_VSP  NEGATIVE

/* 1920x1200@60 Sync Polarity (CVT Mode) */
#define M1920X1200_R60_HSP      NEGATIVE
#define M1920X1200_R60_VSP      POSITIVE

/* 1920x1200@75 Sync Polarity (CVT Mode) */
#define M1920X1200_R75_HSP      NEGATIVE
#define M1920X1200_R75_VSP      POSITIVE

/* 1920x1200@60 Sync Polarity (CVT Mode) */
#define M1920X1200_RB_R60_HSP  POSITIVE
#define M1920X1200_RB_R60_VSP  NEGATIVE

/* 1920x1440@60 Sync Polarity (DMT Mode) */
#define M1920X1440_R60_HSP      NEGATIVE
#define M1920X1440_R60_VSP      POSITIVE

/* 1920x1440@75 Sync Polarity (DMT Mode) */
#define M1920X1440_R75_HSP      NEGATIVE
#define M1920X1440_R75_VSP      POSITIVE

/* 1920x1440@85 Sync Polarity (CVT Mode) */
#define M1920X1440_R85_HSP      NEGATIVE
#define M1920X1440_R85_VSP      POSITIVE

/* 2048x1536@60 Sync Polarity (GTF Mode) */
#define M2048x1536_R60_HSP      NEGATIVE
#define M2048x1536_R60_VSP      POSITIVE

/* 2048x1536@75 Sync Polarity (GTF Mode) */
#define M2048X1536_R75_HSP      NEGATIVE
#define M2048X1536_R75_VSP      POSITIVE

/* 720X400@60 Sync Polarity (CVT Mode) */
#define M720X400_R90_HSP        NEGATIVE
#define M720X400_R90_VSP        POSITIVE

/* 832X624@60 Sync Polarity (CVT Mode) */
#define M832X624_R60_HSP        NEGATIVE
#define M832X624_R60_VSP        POSITIVE

/* define PLL index: */
#define CLK_22_000M     22000000
#define CLK_25_175M     25175000
#define CLK_26_719M     26719000
#define CLK_26_880M     26880000
#define CLK_27_000M     27000000
#define CLK_29_581M     29581000
#define CLK_29_829M     29829000
#define CLK_31_490M     31490000
#define CLK_31_500M     31500000
#define CLK_31_728M     31728000
#define CLK_32_668M     32688000
#define CLK_33_750M     33750000
#define CLK_36_000M     36000000
#define CLK_40_000M     40000000
#define CLK_41_291M     41291000
#define CLK_43_163M     43163000
/* 45.46MHz */
#define CLK_45_250M     45250000
#define CLK_46_000M     46000000
#define CLK_46_980M     46980000
#define CLK_46_996M     46996000
#define CLK_48_000M     48000000
#define CLK_48_875M     48875000
#define CLK_49_500M     49500000
#define CLK_52_406M     52406000
#define CLK_52_977M     52977000
#define CLK_56_250M     56250000
#define CLK_60_466M     60466000
#define CLK_61_500M     61500000
#define CLK_65_000M     65000000
#define CLK_66_750M     66750000
#define CLK_65_178M     65178000
#define CLK_67_295M     67295000
#define CLK_67_500M     67500000
#define CLK_68_179M     68179000
#define CLK_68_369M     68369310
#define CLK_69_924M     69924000
#define CLK_70_159M     70159000
#define CLK_72_000M     72000000
#define CLK_73_023M     73023000
#define CLK_74_250M     74250000
#define CLK_74_481M     74481000
#define CLK_78_750M     78750000
#define CLK_79_466M     79466000
#define CLK_80_136M     80136000
#define CLK_81_627M     81627000
#define CLK_83_375M     83375000
#define CLK_83_527M     83527000
#define CLK_83_950M     83950000
#define CLK_84_537M     84537000
/* 84.537Mhz */
#define CLK_84_750M     84750000
#define CLK_85_500M     85500000
#define CLK_85_860M     85860000
#define CLK_85_909M     85909000
#define CLK_88_750M     88750000
#define CLK_89_489M     89489000
#define CLK_94_500M     94500000
#define CLK_96_648M     96648000
#define CLK_97_750M     97750000
#define CLK_101_000M    101000000
#define CLK_106_500M    106500000
#define CLK_108_000M    108000000
#define CLK_110_125M    110125000
#define CLK_112_000M    112000000
#define CLK_113_309M    113309000
#define CLK_115_000M    115000000
#define CLK_118_840M    118840000
#define CLK_119_000M    119000000
/* 121.704MHz */
#define CLK_121_750M    121750000
#define CLK_122_614M    122614000
#define CLK_126_266M    126266000
/* 130.250MHz */
#define CLK_130_250M    130250000
#define CLK_135_000M    135000000
#define CLK_136_700M    136700000
#define CLK_137_750M    137750000
#define CLK_138_400M    138400000
#define CLK_144_300M    144300000
#define CLK_146_760M    146760000
#define CLK_148_500M    148500000
#define CLK_150_340M    150340000
#define CLK_153_920M    153920000
#define CLK_156_000M    156000000
#define CLK_156_867M    156867000
#define CLK_157_500M    157500000
#define CLK_162_000M    162000000
#define CLK_172_798M    172798000
#define CLK_187_000M    187000000
#define CLK_193_295M    193295000
#define CLK_202_500M    202500000
#define CLK_204_000M    204000000
#define CLK_218_500M    218500000
#define CLK_220_750M    220750000
#define CLK_229_500M    229500000
#define CLK_234_000M    234000000
#define CLK_245_250M    245250000
#define CLK_267_250M    267250000
#define CLK_297_500M    297500000
#define CLK_339_500M    339500000
#define CLK_340_772M    340772000


/* Define Bit Field */
/* TODO: Should share with video BIT define!! */
#ifndef BIT0
#define BIT0    0x01
#endif
#ifndef BIT1
#define BIT1    0x02
#endif
#ifndef BIT2
#define BIT2    0x04
#endif
#ifndef BIT3
#define BIT3    0x08
#endif
#ifndef BIT4
#define BIT4    0x10
#endif
#ifndef BIT5
#define BIT5    0x20
#endif
#ifndef BIT6
#define BIT6    0x40
#endif
#ifndef BIT7
#define BIT7    0x80
#endif

/* Definition CRTC Timing Index */
#define H_TOTAL_INDEX               0
#define H_ADDR_INDEX                1
#define H_BLANK_START_INDEX         2
#define H_BLANK_END_INDEX           3
#define H_SYNC_START_INDEX          4
#define H_SYNC_END_INDEX            5
#define V_TOTAL_INDEX               6
#define V_ADDR_INDEX                7
#define V_BLANK_START_INDEX         8
#define V_BLANK_END_INDEX           9
#define V_SYNC_START_INDEX          10
#define V_SYNC_END_INDEX            11


/* Cacalate PLL */
#define SORT_BY_PHASE_MARGIN    1
#define SORT_BY_F_REF_BW        2
#define SORT_BY_PIXEL_CLOCK     3

#define FIN     14.31818
#define PI      3.141592654
#define TWO_PI  6.283185307

typedef struct {
    double clock;
    int M;
    int N;
    int R;
    double f_refDivBW;
    double PhaseMargin;
} CLOCK_SETTING;


/*Define display timing*/
struct display_timing {
    CARD16  hor_total;
    CARD16  hor_addr;
    CARD16  hor_blank_start;
    CARD16  hor_blank_end;
    CARD16  hor_sync_start;
    CARD16  hor_sync_end;
    CARD16  ver_total;
    CARD16  ver_addr;
    CARD16  ver_blank_start;
    CARD16  ver_blank_end;
    CARD16  ver_sync_start;
    CARD16  ver_sync_end;
};

/************************************************/
/*      Define IGA1 Display Timing              */
/************************************************/
struct io_register {
    CARD8   io_addr;
    CARD8   start_bit;
    CARD8   end_bit;
};

typedef struct IODATA {
    CARD8   Index;
    CARD8   Mask;
    CARD8   Data;
} IODATA, *IODATAPTR;

#include "viamode.h"

#endif /* __HW_H__ */
