/*
  * Copyright 2009-2012 VIA Technologies, Inc. All Rights Reserved.
  * Copyright 2009-2012 S3 Graphics, Inc. All Rights Reserved.
  *
  * Permission is hereby granted, free of charge, to any person obtaining a
  * copy of this software and associated documentation files (the "Software"),
  * to deal in the Software without restriction, including without limitation
  * the rights to use, copy, modify, merge, publish, distribute, sub license,
  * and/or sell copies of the Software, and to permit persons to whom the
  * Software is furnished to do so, subject to the following conditions:
  *
  * The above copyright notice and this permission notice (including the
  * next paragraph) shall be included in all copies or substantial portions
  * of the Software.
  *
  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
  * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
  * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
  * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  * DEALINGS IN THE SOFTWARE.
  */

/*  
 * EDID info by http://en.wikipedia.org/wiki/Extended_display_identification_data
 */
 
#include "via_driver.h"
#include "via_dp.h"
#include "via_regs.h"
#include "hw.h"
#include "viamode.h"
#include "via_output.h"

#define DP_LINKSTATUS_DONE 0x0
#define DP_LINKSTATUS_LOST 0x1

void
MMIO_WR(DWORD addr, DWORD data)
{
    *(volatile unsigned int *)(MMIO_MB1 + (addr)) = (data);
}

DWORD
MMIO_RD(DWORD addr)
{
    DWORD val;

    val = *(volatile unsigned int *)(MMIO_MB1 + (addr));
    return val;
}

void
MMIO_WR_MASK(DWORD addr, DWORD data, DWORD mask)
{
    *(volatile unsigned int *)(MMIO_MB1 + (addr)) =
        (data & mask) | (MMIO_RD(addr) & (~mask));

}

#ifdef VIA_RANDR12_SUPPORT

/******************************************************************
*
*                                          DP1 Function
*
*******************************************************************/
void
viaDPDisableEPHY()
{
    //Disable Bandgap to disable all EPHY functions
    MMIO_WR_MASK(DP_EPHY_PLL_REG, 0x00000000, 0x00000001);
}

Bool
viaDPInitEPHY(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwData;

    DEBUG(ErrorF("viaDPInitEPHY\n"));

    // (1) enable Bandgap and set EPHY symbol rate
    dwData = MMIO_RD(DP_EPHY_PLL_REG) & 0xFFF800FF;
    // real EPHY symbol rate decided by HW link training
    switch (viaDPInfo->LinkSpeed) {
    case Speed_162MHz:
        dwData |= 0x0004BE00;
        break;
    case Speed_270MHz:
        dwData |= 0x00029E00;
        break;
    default:
        dwData |= 0x00029E00;
        break;
    }
    dwData |= 0x00000001;
    MMIO_WR(DP_EPHY_PLL_REG, dwData);
    viaDelayIn_usec(pVia, 1000);

    // (2) start AUX channel, CMOP is on, Tx and Rx are off
    dwData = MMIO_RD(DP_EPHY_MISC_PWR_REG) & 0xFFFF3FFF;
    dwData |= 0x00004000;
    MMIO_WR(DP_EPHY_MISC_PWR_REG, dwData);
    viaDelayIn_usec(pVia, 4000);
    dwData = MMIO_RD(DP_EPHY_MISC_PWR_REG) & 0xFFFF3FFF;
    dwData |= 0x00008000;
    MMIO_WR(DP_EPHY_MISC_PWR_REG, dwData);
    viaDelayIn_usec(pVia, 4000);

    // (3) enable Mpll and Mpll reg power
    dwData = MMIO_RD(DP_EPHY_PLL_REG) & 0xF9FFFFF9;
    dwData |= 0x00000006;
    MMIO_WR(DP_EPHY_PLL_REG, dwData);
    viaDelayIn_usec(pVia, 1000);
    //enable DP
    MMIO_WR(DP_ENABLE_IF_REG, (MMIO_RD(DP_ENABLE_IF_REG) | 0x00000001));
    viaDelayIn_usec(pVia, 1000);

    // (4) enable Tpll and Tpll reg power
    MMIO_WR(DP_EPHY_PLL_REG, (MMIO_RD(DP_EPHY_PLL_REG) | 0x06000000));
    viaDelayIn_usec(pVia, 1000);

    // (5) Resister Tuning (RT), RT reset
    MMIO_WR(DP_EPHY_TX_PWR_REG, (MMIO_RD(DP_EPHY_TX_PWR_REG) & 0xFFFFFFFD));
    // power up RT
    MMIO_WR(DP_EPHY_TX_PWR_REG, (MMIO_RD(DP_EPHY_TX_PWR_REG) | 0x00000001));
    // disable RT reset
    MMIO_WR(DP_EPHY_TX_PWR_REG, (MMIO_RD(DP_EPHY_TX_PWR_REG) | 0x00000002));
    viaDelayIn_usec(pVia, 1000);
    // enable RT auto calibration mode
    MMIO_WR(DP_EPHY_TX_PWR_REG, (MMIO_RD(DP_EPHY_TX_PWR_REG) | 0x00000004));
    viaDelayIn_usec(pVia, 1000);
    // disable RT mode
    MMIO_WR(DP_EPHY_TX_PWR_REG, (MMIO_RD(DP_EPHY_TX_PWR_REG) & 0xFFFFFFFB));
    viaDelayIn_usec(pVia, 1000);
    // power down RT
    MMIO_WR(DP_EPHY_TX_PWR_REG, (MMIO_RD(DP_EPHY_TX_PWR_REG) & 0xFFFFFFFE));

    // (6)
    // [19:8] Tx power status default settings for all 4 lanes
    // [7:0] Tx power down mode for all 4 lanes,
    // [15:8] HDMI TX output voltage swing 1200 mV for all 4 lanes
    dwData = MMIO_RD(DP_EPHY_TX_PWR_REG) & 0x0000F0FF;
    dwData |= 0xAAFF0F00;
    MMIO_WR(DP_EPHY_TX_PWR_REG, dwData);
    viaDelayIn_usec(pVia, 4000);
    // [7:0] Tx power control function CMOP on / PISO off for all 4 lanes
    // Tx power control function on for all 4 lanes
    MMIO_WR(DP_EPHY_TX_PWR_REG, (MMIO_RD(DP_EPHY_TX_PWR_REG) & 0x00FFFFFF));
    viaDelayIn_usec(pVia, 1000);
    // Driver awaken for all 4 lanes
    MMIO_WR(DP_EPHY_TX_PWR_REG, (MMIO_RD(DP_EPHY_TX_PWR_REG) | 0x0000F000));
    MMIO_WR(DP_EPHY_MISC_PWR_REG,
	(MMIO_RD(DP_EPHY_MISC_PWR_REG) | 0x00000001));
    viaDelayIn_usec(pVia, 2000);
}

void
viaDPClearAuxWriteRegs()
{
    MMIO_WR(AUX_W_DATA0_REG, 0x0);
    MMIO_WR(AUX_W_DATA1_REG, 0x0);
    MMIO_WR(AUX_W_DATA2_REG, 0x0);
    MMIO_WR(AUX_W_DATA3_REG, 0x0);
}

void
viaDPClearAuxReadRegs()
{
    MMIO_WR(AUX_R_DATA0_REG, 0x0);
    MMIO_WR(AUX_R_DATA1_REG, 0x0);
    MMIO_WR(AUX_R_DATA2_REG, 0x0);
    MMIO_WR(AUX_R_DATA3_REG, 0x0);
}

Bool
viaDPReplyCmdStatus(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    CARD32 dwAUXCMDStatus;
    CARD32 dwData;
    int i, j;

    //DEBUG(ErrorF("viaDPReplyCmdStatus\n"));

    for (i = 0; i < NUM_RE_ISSUE_COMMAND; i++) {
        for (j = 0; j < NUM_RECHECK; j++) {
            viaDelayIn_usec(pVia, 1000);

            dwAUXCMDStatus = MMIO_RD(AUX_TIMER_REG) & 0x3C000007;

            if (VIAGetChipsetRevisionID() > REVISION_VX900_A1 &&
                dwAUXCMDStatus == ACK_OK) {
                return TRUE;
            } else if (dwAUXCMDStatus == 0x00000001) {	// hardware issue
                return TRUE;
            } else if ((dwAUXCMDStatus & 0xFFFF) == RE_ISSUE_CMD) {
                // re-issue Cmd
                dwData = MMIO_RD(AUX_TIMER_REG) & 0xFFFFFFF0;
                dwData |= 0x03;
                MMIO_WR(AUX_TIMER_REG, dwData);
                break;
            }
        }
    }

    return FALSE;
}

Bool
viaDPWriteDPCD(xf86OutputPtr output, CARD32 dwoffset, int ByteCount)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    CARD32 dwCmd;
    CARD32 dwData;

    DEBUG(ErrorF("viaDPWriteDPCD\n"));

    dwCmd = dwoffset << 12;	       // AUX read offset
    dwCmd |= ByteCount << 4;	       // AUX read length
    dwCmd |= AUX_CMD_WRITE;	       // AUX write CMD
    MMIO_WR(AUX_CMD_REG, dwCmd);

    // issue request based on above
    dwData = MMIO_RD(AUX_TIMER_REG) & 0xFFFFFFF0;
    dwData |= 0x03;
    MMIO_WR(AUX_TIMER_REG, dwData);    // trigger

    viaDelayIn_usec(pVia, 10000);

    return viaDPReplyCmdStatus(output);
}

Bool
viaDPReadDPCD(xf86OutputPtr output, CARD32 dwOffset)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    CARD32 dwCmd;
    CARD32 dwData;

    DEBUG(ErrorF("viaDPReadDPCD\n"));

    viaDPClearAuxReadRegs();

    // assign command
    dwCmd = dwOffset << 12;	       // AUX read offset
    dwCmd |= 1 << 4;		       // AUX read length
    dwCmd |= AUX_CMD_READ;	       // AUX read CMD
    MMIO_WR(AUX_CMD_REG, dwCmd);

    // issue request based on above
    dwData = MMIO_RD(AUX_TIMER_REG) & 0xFFFFFFF0;
    dwData |= 0x03;
    MMIO_WR(AUX_TIMER_REG, dwData);

    return viaDPReplyCmdStatus(output);
}

void
viaDPReadDPCDVersion(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwData;
    CARD32 dwDPCDVersion;

    DEBUG(ErrorF("viaDPReadDPCDVersion\n"));

    // read DPCD Version
    if (viaDPReadDPCD(output, 0x00)) {
        dwDPCDVersion = MMIO_RD(AUX_R_DATA0_REG) & 0xFF;

        switch (dwDPCDVersion) {
        case 0x10:
            // Version 1.0
            viaDPInfo->DPCDVersion |= DPCD_VER_1 | DPCD_REV_0;
            break;
        case 0x11:
            // Version 1.1
            viaDPInfo->DPCDVersion |= DPCD_VER_1 | DPCD_REV_1;
            break;
        default:
            viaDPInfo->DPCDVersion = NONEVERSION;
            break;
        }
    }
    // Let HW use AUX channel
    MMIO_WR(AUX_TIMER_REG, 0x0);
}

CARD8
viaDPReadDPCDLinkStatus(xf86OutputPtr output)
{
    DEBUG(ErrorF("viaDPReadDPCDLinkStatus\n"));

    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwData;
    CARD32 dwLaneAlign;
    CARD32 dwLaneStatus[4];
    CARD8 linkStatus = DP_LINKSTATUS_DONE;
    int i;

    // read DPCD Lane Status
    viaDPReadDPCD(output, 0x202);
    dwData = MMIO_RD(AUX_R_DATA0_REG) & 0xFF;
    dwLaneStatus[0] = dwData & 0xF;
    dwLaneStatus[1] = (dwData >> 4) & 0xF;

    viaDPReadDPCD(output, 0x203);
    dwData = MMIO_RD(AUX_R_DATA0_REG) & 0xFF;
    dwLaneStatus[2] = dwData & 0xF;
    dwLaneStatus[3] = (dwData >> 4) & 0xF;

    viaDPReadDPCD(output, 0x204);
    dwData = MMIO_RD(AUX_R_DATA0_REG) & 0xFF;
    dwLaneAlign = dwData & BIT0;

    if (!dwLaneAlign) {
        linkStatus = DP_LINKSTATUS_LOST;
    } else {
        for (i = 0; i < LANE; i++) {
            if (dwLaneStatus[i] != 0x7) {
                linkStatus = DP_LINKSTATUS_LOST;
                break;
            }
        }
    }

    // Let HW use AUX channel
    MMIO_WR(AUX_TIMER_REG, 0x0);

    return linkStatus;
}

Bool
viaDPLinkTraining(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwData;

    DEBUG(ErrorF("viaDPLinkTraining\n"));

    viaDPClearAuxReadRegs();
    viaDPClearAuxWriteRegs();
    viaDPInfo->IsLinkTrainingDone = FALSE;

    // reset link training
    MMIO_WR_MASK(DP_DATA_PASS_ENABLE_REG, 0x01, 0x01);
    MMIO_WR_MASK(DP_NAUD_MUTE_REG, 0x80000000, 0x80000000);
    viaDelayIn_usec(pVia, 1000);
    MMIO_WR_MASK(DP_NAUD_MUTE_REG, 0x0, 0x80000000);
    viaDelayIn_usec(pVia, 1000);

    // [9:7]=100b, 4 lanes, [10]=0, disable SW link training ,
    // [12:11]=01b, set clock recovery state
    dwData = MMIO_RD(DP_LINK_TRAINING_REG) & 0xFFFF0000;
    dwData |= 0x00000200;

    switch (viaDPInfo->LinkSpeed) {
    case Speed_162MHz:
        dwData &= 0xFFFFFFFD;
        break;
    case Speed_270MHz:
        dwData |= 0x00000002;
        break;
    default:
        dwData |= 0x00000002;
        break;
    }
    MMIO_WR(DP_LINK_TRAINING_REG, dwData);

    // Reset EPHY
    MMIO_WR_MASK(DP_EPHY_TX_PWR_REG, 0x55000000, 0xFF000000);
    viaDelayIn_usec(pVia, 2000);
    MMIO_WR_MASK(DP_EPHY_TX_PWR_REG, 0x00000000, 0xFF000000);

    // enable scramble
    MMIO_WR_MASK(DP_VIDEO_CTRL_REG, 0x00000001, 0x00000001);

    // enable DP, set enhanced mode
    dwData = MMIO_RD(DP_ENABLE_IF_REG) & 0xC3000000;
    dwData |= 0x00000005;	       // if enable standard mode , set 0x00000001
    MMIO_WR(DP_ENABLE_IF_REG, dwData);

    switch (viaDPInfo->LinkSpeed) {
    case Speed_162MHz:
        // if enable standard mode , set 0x000010406
        MMIO_WR(AUX_W_DATA0_REG, 0x000018406);
        break;
    case Speed_270MHz:
        // if enable standard mode , set 0x00001040A
        MMIO_WR(AUX_W_DATA0_REG, 0x00001840A);
        break;
    default:
        MMIO_WR(AUX_W_DATA0_REG, 0x00001840A);
        break;
    }

    MMIO_WR(AUX_W_DATA1_REG, 0x0);

    if (!viaDPWriteDPCD(output, 0x100, 2)) {
        //Let HW use AUX channel
        MMIO_WR(AUX_TIMER_REG, 0x0);
        return FALSE;
    }
    //Let HW use AUX channel
    MMIO_WR(AUX_TIMER_REG, 0x0);
    viaDelayIn_usec(pVia, 20000);

    dwData = MMIO_RD(DP_LINK_TRAINING_REG) & 0x7FFFFFFF;
    dwData |= 0x0000003C;

    if (viaDPInfo->LinkSpeed == Speed_270MHz)
        dwData |= 0x00000002;

    MMIO_WR(DP_LINK_TRAINING_REG, dwData);

    // enable HW link training
    MMIO_WR_MASK(DP_LINK_TRAINING_REG, 0x00000001, 0x00000001);

    viaDelayIn_usec(pVia, 20000);

    if ((MMIO_RD(DP_LINK_TRAINING_REG) & 0x80000000) != 0x80000000) {
        //Let HW use AUX channel
        MMIO_WR(AUX_TIMER_REG, 0x0);
        return FALSE;
    }

    viaDelayIn_usec(pVia, 4000);

    if ((MMIO_RD(DP_ENABLE_IF_REG) & 0x30000000) != 0x30000000) {
        //Let HW use AUX channel
        MMIO_WR(AUX_TIMER_REG, 0x0);

        return FALSE;
    }

    viaDPInfo->IsLinkTrainingDone = TRUE;

    // clear [31], and [0]
    MMIO_WR_MASK(DP_LINK_TRAINING_REG, 0x0, 0x80000001);

    //Let HW use AUX channel
    MMIO_WR(AUX_TIMER_REG, 0x0);

    return TRUE;
}

int
viaDPGetLinkSpeed(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwLinkSpeed;

    if (viaDPInfo->IsLinkTrainingDone)
        return viaDPInfo->LinkSpeed;

    DEBUG(ErrorF("viaDPGetLinkSpeed\n"));

    viaDPReadDPCD(output, 0x01);
    dwLinkSpeed = MMIO_RD(AUX_R_DATA0_REG) & 0xFF;
    // Let HW use AUX channel
    MMIO_WR(AUX_TIMER_REG, 0x0);

    // Use default link speed of DP monitor
    switch (dwLinkSpeed) {
    case 0x06:
        viaDPInfo->LinkSpeed = Speed_162MHz;
        break;
    case 0x0A:
        viaDPInfo->LinkSpeed = Speed_270MHz;
        break;
    default:
        viaDPInfo->LinkSpeed = Speed_270MHz;
        break;
    }

    // Start link training to confirm link speed
    if ((!viaDPLinkTraining(output))
        && (viaDPInfo->LinkSpeed == Speed_270MHz)) {

        // Reduce link speed to 162 MHz and retry link training
        // if 270 MHz link training fails
        MMIO_WR(DP_LINK_TRAINING_REG,
            (MMIO_RD(DP_LINK_TRAINING_REG) & 0x7FFFFFFC));
        viaDPClearAuxWriteRegs();
        // Clear DPCD training pattern
        viaDPWriteDPCD(output, 0x102, 1);
        viaDPInfo->LinkSpeed = Speed_162MHz;

        //Reset EPHY for changed link speed
        viaDPInitEPHY(output);

        if (!viaDPLinkTraining(output)) {
            viaDPInfo->LinkSpeed = Speed_NONE;
            viaDPInfo->IsLinkTrainingDone = FALSE;
            xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "Output %s link training fails\n", output->name);
        }
    }

    return viaDPInfo->LinkSpeed;
}

void
viaEnableDP(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    xf86CrtcPtr crtc = output->crtc;

    DEBUG(ErrorF("viaEnableDP\n"));

    // Must Enable first
    MMIO_WR_MASK(DP_DATA_PASS_ENABLE_REG, 0x01, 0x01);
    MMIO_WR_MASK(DP_EPHY_PLL_REG, 0x0, 0xC0000000);

    // if DP mode, video input selection - sp1
    MMIO_WR(DP_VIDEO_CTRL_REG, (MMIO_RD(DP_VIDEO_CTRL_REG) & 0x3FFC0001));

    // enable DP and video
    MMIO_WR(DP_ENABLE_IF_REG, MMIO_RD(DP_ENABLE_IF_REG) | 0x00000009);

    // Let HW use AUX channel
    MMIO_WR(AUX_TIMER_REG, 0x0);
}

void
viaDisableDP(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);

    DEBUG(ErrorF("viaDisableDP\n"));

    // disable DP and video
    MMIO_WR(DP_ENABLE_IF_REG, (MMIO_RD(DP_ENABLE_IF_REG) & 0xFFFFFFF6));

    // Let HW use AUX channel
    MMIO_WR(AUX_TIMER_REG, 0x0);
}

void
viaDpHorWidthAndTu(xf86OutputPtr output, DisplayModePtr mode)
{
    ScrnInfoPtr pScrn = output->scrn;
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;
    int TUSize = 48;
    int Width;

    viaCalculate_TU(output, mode->Clock, pScrn->bitsPerPixel);
    Width = (mode->CrtcHDisplay / 4) - 1;
    dwTemp = viaDPInfo->TURatio << 17 | (TUSize - 1) << 11 | Width;
    MMIO_WR(DP_HWIDTH_TUSIZE_REG, dwTemp);
}

void
viaDpHorLineDuration(xf86OutputPtr output, DisplayModePtr mode)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;
    int LinkClock;
    int HTotal;
    int HBlank;

    // units of Dclk and Ls_clk are MHz
    switch (viaDPInfo->LinkSpeed) {
    case Speed_162MHz:
        LinkClock = 162;
        break;
    case Speed_270MHz:
        LinkClock = 270;
        break;
    default:
        LinkClock = 270;
        break;
    }

    HBlank = ((((mode->CrtcHTotal - mode->CrtcHDisplay) * LinkClock) /
	    (mode->Clock / 1000)) - 15) & 0x00000FFF;
    HTotal = ((LinkClock * mode->CrtcHTotal / (mode->Clock / 1000)) - 15) &
        0x00007FFF;

    dwTemp = HBlank << 15 | HTotal;
    MMIO_WR(DP_HLINE_DUR_REG, dwTemp);
}

void
viaDpMvid(xf86OutputPtr output, DisplayModePtr mode)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;
    int LinkClock;
    int StreamClockRecovery_M;

    // units of Dclk and Ls_clk are MHz
    switch (viaDPInfo->LinkSpeed) {
    case Speed_162MHz:
        LinkClock = 162;
        break;
    case Speed_270MHz:
        LinkClock = 270;
        break;
    default:
        LinkClock = 270;
        break;
    }

    dwTemp = ((mode->Clock / 1000) * 32768 / LinkClock) & 0x19FFFFFF;
    dwTemp |= 0x20000000;	       // 8 bits, MMC6CC[31:29]=001b
    dwTemp &= 0xFEFFFFFF;
    MMIO_WR(DP_MVID_MISC0_REG, dwTemp);	// [24]=0: Asynchronous mode
    // Generate MVID in Asynchronous mode
    MMIO_WR_MASK(DP_ENABLE_IF_REG, 0x02000000, 0x02000000);
}

void
viaDpHorVerTotal(xf86OutputPtr output, DisplayModePtr mode)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;

    dwTemp = mode->CrtcVTotal << 16 | mode->CrtcHTotal;
    MMIO_WR(DP_H_ATTR_REG, dwTemp);
}

void
viaDpHorVerOffset(xf86OutputPtr output, DisplayModePtr mode)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;

    dwTemp = (mode->CrtcVTotal - mode->CrtcVSyncStart) << 16 |
	(mode->CrtcHTotal - mode->CrtcHSyncStart);
    MMIO_WR(DP_HV_START_REG, dwTemp);
}

void
viaDpHorVerSyncWidthAndPolarity(xf86OutputPtr output, DisplayModePtr mode)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;
    int HSyncPolarity, VSyncPolarity, VSyncInterval, HSyncInterval;

    if (mode->Flags & V_PHSYNC)
        HSyncPolarity = POSITIVE;

    if (mode->Flags & V_NHSYNC)
        HSyncPolarity = NEGATIVE;

    if (mode->Flags & V_PVSYNC)
        VSyncPolarity = POSITIVE;

    if (mode->Flags & V_NVSYNC)
        VSyncPolarity = NEGATIVE;

    VSyncInterval = mode->CrtcVSyncEnd - mode->CrtcVSyncStart;
    HSyncInterval = mode->CrtcHSyncEnd - mode->CrtcHSyncStart;

    dwTemp = VSyncPolarity << 31 | VSyncInterval << 16 |
	HSyncPolarity << 15 | HSyncInterval;
    MMIO_WR(DP_POLARITY_WIDTH_REG, dwTemp);
}

void
viaDpHorVerActive(xf86OutputPtr output, DisplayModePtr mode)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;

    dwTemp = mode->CrtcVDisplay << 16 | mode->CrtcHDisplay;
    MMIO_WR(DP_ACITVE_WH_REG, dwTemp);
}

void
viaDpNvid()
{
    // [23:0] Stream Clock Recovery :N
    MMIO_WR_MASK(DP_ATTR_DATA_REG, 32768, 0x00FFFFFF);
}

void
viaDpDelayReg()
{
    // Default: [29:24] = 20h for delay
    MMIO_WR_MASK(DP_VIDEO_CTRL_REG, 0x20000000, 0x3F000000);
}

Bool
viaDPSetupMainLink(xf86OutputPtr output, DisplayModePtr mode)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;

    DEBUG(ErrorF("viaDPSetupMainLink\n"));

    if (viaDPInfo->LinkSpeed) {
        // Field ID flag not invert
        MMIO_WR_MASK(DP_ENABLE_IF_REG, 0x0, BIT1);

        viaDpHorWidthAndTu(output, mode);
        viaDpHorLineDuration(output, mode);
        viaDpMvid(output, mode);
        viaDpHorVerTotal(output, mode);
        viaDpHorVerOffset(output, mode);
        viaDpHorVerSyncWidthAndPolarity(output, mode);
        viaDpHorVerActive(output, mode);
        viaDpNvid();
        viaDpDelayReg();

        DEBUG(ErrorF("End Setup MainLink!!\n"));
    }
}

Bool
viaDPReadEDID(xf86OutputPtr output,
    CARD32 slave_addr, CARD32 dwOffset, CARD8 *pData)
{
    CARD32 dwCmd;

    viaDPClearAuxReadRegs();
    viaDPClearAuxWriteRegs();

    // 1. write slave addr offset for start
    dwCmd = dwOffset & 0x000000FF;
    MMIO_WR(AUX_W_DATA0_REG, dwCmd);
    dwCmd = slave_addr << 11 | 1 << 4 | AUX_CMD_I2C_WRITE;
    MMIO_WR(AUX_CMD_REG, dwCmd);
    // issue request based on above
    dwCmd = MMIO_RD(AUX_TIMER_REG) & 0xFFFFFFF0;
    dwCmd |= 0x03;
    MMIO_WR(AUX_TIMER_REG, dwCmd);

    if (!viaDPReplyCmdStatus(output))
        return FALSE;

    // 2. write command with read length
    dwCmd = slave_addr << 11 | 1 << 4 | AUX_CMD_I2C_READ;
    MMIO_WR(AUX_CMD_REG, dwCmd);
    // issue request based on above
    dwCmd = MMIO_RD(AUX_TIMER_REG) & 0xFFFFFFF0;
    dwCmd |= 0x03;
    MMIO_WR(AUX_TIMER_REG, dwCmd);

    if (!viaDPReplyCmdStatus(output))
        return FALSE;

    // 3. read
    *pData = (MMIO_RD(AUX_R_DATA0_REG) & 0xFF);

    return TRUE;
}

/******************************************************************
*
*                                          DP2 Function
*
*******************************************************************/
void
viaDP2DisableEPHY()
{
    MMIO_WR_MASK(DP2_ENABLE_IF_REG, 0x00000000, 0x00000001);
}

Bool
viaDP2InitEPHY(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwData;

    DEBUG(ErrorF("viaDP2InitEPHY\n"));

    // (1) enable Bandgap and set EPHY symbol rate
    dwData = MMIO_RD(DP2_EPHY_PLL_REG) & 0x0C7000FF;
    // real EPHY symbol rate decided by HW link training
    switch (viaDPInfo->LinkSpeed) {
    case Speed_162MHz:
        dwData |= 0x0002BE00;
        break;
    case Speed_270MHz:
        dwData |= 0x00019E00;
        break;
    default:
        dwData |= 0x00019E00;
        break;
    }
    dwData |= 0xF1080001;
    MMIO_WR(DP2_EPHY_PLL_REG, dwData);
    viaDelayIn_usec(pVia, 1000);

    // (2) start AUX channel, CMOP is on, Tx and Rx are off
    dwData = MMIO_RD(DP2_EPHY_TX_PWR_REG) & 0xCFFFFFFF;
    dwData |= 0x10000000;
    MMIO_WR(DP2_EPHY_TX_PWR_REG, dwData);
    viaDelayIn_usec(pVia, 4000);
    dwData = MMIO_RD(DP2_EPHY_TX_PWR_REG) & 0xCFFFFFFF;
    dwData |= 0x20000000;
    MMIO_WR(DP2_EPHY_TX_PWR_REG, dwData);
    viaDelayIn_usec(pVia, 4000);

    // (3) enable Mpll and Mpll reg power
    // (4) enable Tpll and Tpll reg power
    MMIO_WR(DP2_EPHY_PLL_REG, (MMIO_RD(DP2_EPHY_PLL_REG) & (~0x02000000)));
    viaDelayIn_usec(pVia, 1000);

    // (5) Resister Tuning (RT), RT reset
    // (6)
    // [19:8] Tx power status default settings for all 4 lanes
    dwData = MMIO_RD(DP2_EPHY_TX_PWR_REG2) & 0xFFF000FF;
    dwData |= 0x0000AA00;
    MMIO_WR(DP2_EPHY_TX_PWR_REG2, dwData);
    // [7:0] Tx power down mode for all 4 lanes,
    // [15:8] HDMI TX output voltage swing 1200 mV for all 4 lanes
    dwData = MMIO_RD(DP2_EPHY_TX_PWR_REG) & 0xFFFF0000;
    dwData |= 0x0000FFFF;
    MMIO_WR(DP2_EPHY_TX_PWR_REG, dwData);
    viaDelayIn_usec(pVia, 4000);
    // [7:0] Tx power control function CMOP on / PISO off for all 4 lanes
    // Tx power control function on for all 4 lanes
    MMIO_WR(DP2_EPHY_TX_PWR_REG, (MMIO_RD(DP2_EPHY_TX_PWR_REG) & 0xFFFFFFAA));
    viaDelayIn_usec(pVia, 4000);
    // [7:0] Tx power control function on for all 4 lanes
    // Tx power control function on for all 4 lanes
    MMIO_WR(DP2_EPHY_TX_PWR_REG, (MMIO_RD(DP2_EPHY_TX_PWR_REG) & 0xFFFFFF00));
    viaDelayIn_usec(pVia, 1000);
    // [19:16] Driver awaken for all 4 lanes
    MMIO_WR(DP2_EPHY_TX_IDLE_REG,
	(MMIO_RD(DP2_EPHY_TX_IDLE_REG) | 0x000F0000));

    //(7) DP2 enable
    MMIO_WR(DP2_ENABLE_IF_REG, (MMIO_RD(DP2_ENABLE_IF_REG) | 0x00000001));
    viaDelayIn_usec(pVia, 2000);
}

void
viaDP2ClearAuxWriteRegs()
{
    MMIO_WR(DP2_AUX_W_DATA0_REG, 0x0);
    MMIO_WR(DP2_AUX_W_DATA1_REG, 0x0);
    MMIO_WR(DP2_AUX_W_DATA2_REG, 0x0);
    MMIO_WR(DP2_AUX_W_DATA3_REG, 0x0);
}

void
viaDP2ClearAuxReadRegs()
{
    MMIO_WR(DP2_AUX_R_DATA0_REG, 0x0);
    MMIO_WR(DP2_AUX_R_DATA1_REG, 0x0);
    MMIO_WR(DP2_AUX_R_DATA2_REG, 0x0);
    MMIO_WR(DP2_AUX_R_DATA3_REG, 0x0);
}

Bool
viaDP2ReplyCmdStatus(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    CARD32 dwAUXCMDStatus;
    CARD32 dwData;
    int i, j;

    //DEBUG(ErrorF("viaDP2ReplyCmdStatus\n"));

    for (i = 0; i < NUM_RE_ISSUE_COMMAND; i++) {
        for (j = 0; j < NUM_RECHECK; j++) {
            viaDelayIn_usec(pVia, 1000);

            dwAUXCMDStatus = MMIO_RD(DP2_AUX_TIMER_REG) & 0x3C000007;

            if (VIAGetChipsetRevisionID() > REVISION_VX900_A1 &&
                dwAUXCMDStatus == ACK_OK) {
                return TRUE;
            } else if (dwAUXCMDStatus == 0x00000001) {	// hardware issue
                return TRUE;
            } else if ((dwAUXCMDStatus & 0xFFFF) == RE_ISSUE_CMD) {
                // re-issue Cmd
                dwData = MMIO_RD(DP2_AUX_TIMER_REG) & 0xFFFFFFF0;
                dwData |= 0x03;
                MMIO_WR(DP2_AUX_TIMER_REG, dwData);
                break;
            }
        }
    }

    return FALSE;
}

void
viaDp2TurnOnAuxPowerSequence(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);

    viaDelayIn_usec(pVia, 10);	       // Delay TD0 time to wait HPD signal from sink
    viaDelayIn_usec(pVia, 10);	       // Delay TD5 time
}

void
viaDp2TurnOffAuxPowerSequence(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);

    viaDelayIn_usec(pVia, 10);	       // Delay TD5 time
}

Bool
viaDP2WriteDPCD(xf86OutputPtr output, CARD32 dwoffset, int ByteCount)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    CARD32 dwCmd;
    CARD32 dwData;

    DEBUG(ErrorF("viaDP2WriteDPCD\n"));

    // if EPHY disable, turn on power sequence
    if (!(MMIO_RD(DP2_ENABLE_IF_REG) & BIT0))
        viaDp2TurnOnAuxPowerSequence(output);

    dwCmd = dwoffset << 12;	       // AUX read offset
    dwCmd |= ByteCount << 4;	       // AUX read length
    dwCmd |= AUX_CMD_WRITE;	       // AUX write CMD
    MMIO_WR(DP2_AUX_CMD_REG, dwCmd);

    // issue request based on above
    dwData = MMIO_RD(DP2_AUX_TIMER_REG) & 0xFFFFFFF0;
    dwData |= 0x03;
    MMIO_WR(DP2_AUX_TIMER_REG, dwData);	// trigger

    viaDelayIn_usec(pVia, 10000);

    // when leave, turn off power sequence
    if (!(MMIO_RD(DP2_ENABLE_IF_REG) & BIT0))
        viaDp2TurnOffAuxPowerSequence(output);

    return viaDP2ReplyCmdStatus(output);
}

CARD32
viaDP2ReadDPCD(xf86OutputPtr output, CARD32 dwOffset)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    CARD32 dwCmd;
    CARD32 dwData;

    DEBUG(ErrorF("viaDP2ReadDPCD\n"));

    viaDP2ClearAuxReadRegs();

    // assign command
    dwCmd = dwOffset << 12;	       // AUX read offset
    dwCmd |= 1 << 4;		       // AUX read length
    dwCmd |= AUX_CMD_READ;	       // AUX read CMD
    MMIO_WR(DP2_AUX_CMD_REG, dwCmd);

    // issue request based on above
    dwData = MMIO_RD(DP2_AUX_TIMER_REG) & 0xFFFFFFF0;
    dwData |= 0x03;
    MMIO_WR(DP2_AUX_TIMER_REG, dwData);

    return viaDP2ReplyCmdStatus(output);
}

void
viaDP2ReadDPCDVersion(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwData;
    CARD32 dwDPCDVersion;

    DEBUG(ErrorF("viaDP2ReadDPCDVersion\n"));

    // read DPCD Version
    if (viaDP2ReadDPCD(output, 0x00)) {
        dwDPCDVersion = MMIO_RD(DP2_AUX_R_DATA0_REG) & 0xFF;

        switch (dwDPCDVersion) {
        case 0x10:
            // Version 1.0
            viaDPInfo->DPCDVersion |= DPCD_VER_1 | DPCD_REV_0;
            break;
        case 0x11:
            // Version 1.1
            viaDPInfo->DPCDVersion |= DPCD_VER_1 | DPCD_REV_1;
            break;
        default:
            viaDPInfo->DPCDVersion = NONEVERSION;
            break;
        }
    }
    // Let HW use AUX channel
    MMIO_WR(DP2_AUX_TIMER_REG, 0x0);
}

CARD8
viaDP2ReadDPCDLinkStatus(xf86OutputPtr output)
{
    DEBUG(ErrorF("viaDP2ReadDPCDLinkStatus\n"));

    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwData;
    CARD32 dwLaneAlign;
    CARD32 dwLaneStatus[4];
    CARD8 linkStatus = DP_LINKSTATUS_DONE;
    int i;

    // read DPCD Lane Status
    viaDP2ReadDPCD(output, 0x202);
    dwData = MMIO_RD(DP2_AUX_R_DATA0_REG) & 0xFF;
    dwLaneStatus[0] = dwData & 0xF;
    dwLaneStatus[1] = (dwData >> 4) & 0xF;

    viaDP2ReadDPCD(output, 0x203);
    dwData = MMIO_RD(DP2_AUX_R_DATA0_REG) & 0xFF;
    dwLaneStatus[2] = dwData & 0xF;
    dwLaneStatus[3] = (dwData >> 4) & 0xF;

    viaDP2ReadDPCD(output, 0x204);
    dwData = MMIO_RD(DP2_AUX_R_DATA0_REG) & 0xFF;
    dwLaneAlign = dwData & BIT0;

    if (!dwLaneAlign) {
        linkStatus = DP_LINKSTATUS_LOST;
    } else {
        for (i = 0; i < LANE; i++) {
            if (dwLaneStatus[i] != 0x7) {
                linkStatus = DP_LINKSTATUS_LOST;
                break;
            }
        }
    }

    // Let HW use AUX channel
    MMIO_WR(DP2_AUX_TIMER_REG, 0x0);

    return linkStatus;
}

Bool
viaDP2LinkTraining(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwData;

    DEBUG(ErrorF("viaDP2LinkTraining\n"));

    viaDP2ClearAuxReadRegs();
    viaDP2ClearAuxWriteRegs();
    viaDPInfo->IsLinkTrainingDone = FALSE;

    // reset link training
    MMIO_WR_MASK(DP_DATA_PASS_ENABLE_REG, 0x01, 0x01);
    MMIO_WR_MASK(DP2_NAUD_MUTE_REG, 0x80000000, 0x80000000);
    viaDelayIn_usec(pVia, 1000);
    MMIO_WR_MASK(DP2_NAUD_MUTE_REG, 0x0, 0x80000000);
    viaDelayIn_usec(pVia, 1000);

    // [9:7]=100b, 4 lanes, [10]=0, disable SW link training ,
    // [12:11]=01b, set clock recovery state
    dwData = MMIO_RD(DP2_LINK_TRAINING_REG) & 0xFFFF0000;
    dwData |= 0x0000023C;

    switch (viaDPInfo->LinkSpeed) {
    case Speed_162MHz:
        dwData &= 0xFFFFFFFD;
        break;
    case Speed_270MHz:
        dwData |= 0x00000002;
        break;
    default:
        dwData |= 0x00000002;
        break;
    }
    MMIO_WR(DP2_LINK_TRAINING_REG, dwData);

    // Reset EPHY
    MMIO_WR_MASK(DP2_EPHY_TX_PWR_REG, 0x00000055, 0x000000FF);
    viaDelayIn_usec(pVia, 2000);
    MMIO_WR_MASK(DP2_EPHY_TX_PWR_REG, 0x00000000, 0x000000FF);

    // enable scramble
    MMIO_WR_MASK(DP2_VIDEO_CTRL_REG, 0x00000001, 0x00000001);

    // enable DP, set enhanced mode
    dwData = MMIO_RD(DP2_ENABLE_IF_REG) & 0xC3000000;
    dwData |= 0x00000005;	       // if enable standard mode , set 0x00000001
    MMIO_WR(DP2_ENABLE_IF_REG, dwData);

    switch (viaDPInfo->LinkSpeed) {
    case Speed_162MHz:
        // if enable standard mode , set 0x000010406
        MMIO_WR(DP2_AUX_W_DATA0_REG, 0x000018406);
        break;
    case Speed_270MHz:
        // if enable standard mode , set 0x00001040A
        MMIO_WR(DP2_AUX_W_DATA0_REG, 0x00001840A);
        break;
    default:
        MMIO_WR(DP2_AUX_W_DATA0_REG, 0x00001840A);
        break;
    }

    MMIO_WR(DP2_AUX_W_DATA1_REG, 0x0);

    if (!viaDP2WriteDPCD(output, 0x100, 2)) {
        // Let HW use AUX channel
        MMIO_WR(DP2_AUX_TIMER_REG, 0x0);
        return FALSE;
    }
    // Let HW use AUX channel
    MMIO_WR(DP2_AUX_TIMER_REG, 0x0);
    viaDelayIn_usec(pVia, 20000);

    dwData = MMIO_RD(DP2_LINK_TRAINING_REG) & 0x7FFFFFFF;
    dwData |= 0x0000003C;

    if (viaDPInfo->LinkSpeed == Speed_270MHz)
        dwData |= 0x00000002;

    MMIO_WR(DP2_LINK_TRAINING_REG, dwData);

    // enable HW link training
    MMIO_WR_MASK(DP2_LINK_TRAINING_REG, 0x00000001, 0x00000001);

    viaDelayIn_usec(pVia, 20000);;

    if ((MMIO_RD(DP2_LINK_TRAINING_REG) & 0x80000000) != 0x80000000) {
        // Let HW use AUX channel
        MMIO_WR(DP2_AUX_TIMER_REG, 0x0);
        return FALSE;
    }

    viaDelayIn_usec(pVia, 4000);

    if ((MMIO_RD(DP2_ENABLE_IF_REG) & 0x30000000) != 0x30000000) {
        // Let HW use AUX channel
        MMIO_WR(DP2_AUX_TIMER_REG, 0x0);

        return FALSE;
    }

    viaDPInfo->IsLinkTrainingDone = TRUE;

    // clear [31], and [0]
    MMIO_WR_MASK(DP2_LINK_TRAINING_REG, 0x0, 0x80000001);

    // Let HW use AUX channel
    MMIO_WR(DP2_AUX_TIMER_REG, 0x0);

    return TRUE;

}

int
viaDP2GetLinkSpeed(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwLinkSpeed;

    if (viaDPInfo->IsLinkTrainingDone)
        return viaDPInfo->LinkSpeed;

    DEBUG(ErrorF("viaDP2GetLinkSpeed\n"));

    viaDP2ReadDPCD(output, 0x01);
    dwLinkSpeed = MMIO_RD(DP2_AUX_R_DATA0_REG) & 0xFF;
    // Let HW use AUX channel
    MMIO_WR(DP2_AUX_TIMER_REG, 0x0);

    // Use default link speed of DP monitor
    switch (dwLinkSpeed) {
    case 0x06:
        viaDPInfo->LinkSpeed = Speed_162MHz;
        break;
    case 0x0A:
        viaDPInfo->LinkSpeed = Speed_270MHz;
        break;
    default:
        viaDPInfo->LinkSpeed = Speed_270MHz;
        break;
    }

    // Start link training to confirm link speed
    if ((!viaDP2LinkTraining(output))
        && (viaDPInfo->LinkSpeed == Speed_270MHz)) {
        // Reduce link speed to 162 MHz and retry link training
        // if 270 MHz link training fails
        MMIO_WR(DP2_LINK_TRAINING_REG,
            (MMIO_RD(DP2_LINK_TRAINING_REG) & 0x7FFFFFFC));
        viaDP2ClearAuxWriteRegs();
        // Clear DPCD training pattern
        viaDP2WriteDPCD(output, 0x102, 1);
        viaDPInfo->LinkSpeed = Speed_162MHz;

        // Reset EPHY for changed link speed
        viaDP2InitEPHY(output);

        if (!viaDP2LinkTraining(output)) {
            viaDPInfo->LinkSpeed = Speed_NONE;
            viaDPInfo->IsLinkTrainingDone = FALSE;
            xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "Output %s link training fails\n", output->name);
        }
    }

    return viaDPInfo->LinkSpeed;
}

void
viaEnableDP2(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    xf86CrtcPtr crtc = output->crtc;

    DEBUG(ErrorF("viaEnableDP2\n"));

    // Must Enable first
    MMIO_WR_MASK(DP_DATA_PASS_ENABLE_REG, 0x01, 0x01);

    // if DP mode, video input selection - sp1
    MMIO_WR(DP2_VIDEO_CTRL_REG, (MMIO_RD(DP2_VIDEO_CTRL_REG) & 0x3FFC0001));

    // enable DP and video
    MMIO_WR(DP2_ENABLE_IF_REG, MMIO_RD(DP2_ENABLE_IF_REG) | 0x00000009);

    // Let HW use AUX channel
    MMIO_WR(DP2_AUX_TIMER_REG, 0x0);
}

void
viaDisableDP2(xf86OutputPtr output)
{
    DEBUG(ErrorF("viaDisableDP2\n"));

    // disable DP and video
    MMIO_WR(DP2_ENABLE_IF_REG, MMIO_RD(DP2_ENABLE_IF_REG) & 0xFFFFFFF6);

    // Let HW use AUX channel
    MMIO_WR(DP2_AUX_TIMER_REG, 0x0);
}

void
viaDp2HorWidthAndTu(xf86OutputPtr output, DisplayModePtr mode)
{
    ScrnInfoPtr pScrn = output->scrn;
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;
    int TUSize = 48;
    int Width;

    viaCalculate_TU(output, mode->Clock, pScrn->bitsPerPixel);
    Width = (mode->CrtcHDisplay / 4) - 1;
    dwTemp = viaDPInfo->TURatio << 17 | (TUSize - 1) << 11 | Width;
    MMIO_WR(DP2_HWIDTH_TUSIZE_REG, dwTemp);
}

void
viaDp2HorLineDuration(xf86OutputPtr output, DisplayModePtr mode)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;
    int LinkClock;
    int HTotal;
    int HBlank;

    // units of Dclk and Ls_clk are MHz
    switch (viaDPInfo->LinkSpeed) {
    case Speed_162MHz:
        LinkClock = 162;
        break;
    case Speed_270MHz:
        LinkClock = 270;
        break;
    default:
        LinkClock = 270;
        break;
    }

    HBlank = ((((mode->CrtcHTotal - mode->CrtcHDisplay) * LinkClock) /
	    (mode->Clock / 1000)) - 15) & 0x00000FFF;
    HTotal = ((LinkClock * mode->CrtcHTotal / (mode->Clock / 1000)) - 15) &
        0x00007FFF;

    dwTemp = HBlank << 15 | HTotal;
    MMIO_WR(DP2_HLINE_DUR_REG, dwTemp);
}

void
viaDp2Mvid(xf86OutputPtr output, DisplayModePtr mode)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;
    int LinkClock;
    int StreamClockRecovery_M;

    // units of Dclk and Ls_clk are MHz
    switch (viaDPInfo->LinkSpeed) {
    case Speed_162MHz:
        LinkClock = 162;
        break;
    case Speed_270MHz:
        LinkClock = 2700;
        break;
    default:
        LinkClock = 270;
        break;
    }

    dwTemp = ((mode->Clock / 1000) * 32768 / LinkClock) & 0x19FFFFFF;
    dwTemp |= 0x20000000;	       // 8 bits, MMC6CC[31:29]=001b
    dwTemp &= 0xFEFFFFFF;
    MMIO_WR(DP2_MVID_MISC0_REG, dwTemp);	// [24]=0: Asynchronous mode
    // Generate MVID in Asynchronous mode
    MMIO_WR_MASK(DP2_ENABLE_IF_REG, 0x02000000, 0x02000000);
}

void
viaDp2HorVerTotal(xf86OutputPtr output, DisplayModePtr mode)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;

    dwTemp = mode->CrtcVTotal << 16 | mode->CrtcHTotal;
    MMIO_WR(DP2_H_ATTR_REG, dwTemp);
}

void
viaDp2HorVerOffset(xf86OutputPtr output, DisplayModePtr mode)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;

    dwTemp = (mode->CrtcVTotal - mode->CrtcVSyncStart) << 16 |
	(mode->CrtcHTotal - mode->CrtcHSyncStart);
    MMIO_WR(DP2_HV_START_REG, dwTemp);
}

void
viaDp2HorVerSyncWidthAndPolarity(xf86OutputPtr output, DisplayModePtr mode)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;
    int HSyncPolarity, VSyncPolarity, VSyncInterval, HSyncInterval;

    if (mode->Flags & V_PHSYNC)
        HSyncPolarity = POSITIVE;

    if (mode->Flags & V_NHSYNC)
        HSyncPolarity = NEGATIVE;

    if (mode->Flags & V_PVSYNC)
        VSyncPolarity = POSITIVE;

    if (mode->Flags & V_NVSYNC)
        VSyncPolarity = NEGATIVE;

    VSyncInterval = mode->CrtcVSyncEnd - mode->CrtcVSyncStart;
    HSyncInterval = mode->CrtcHSyncEnd - mode->CrtcHSyncStart;

    dwTemp = VSyncPolarity << 31 | VSyncInterval << 16 |
	HSyncPolarity << 15 | HSyncInterval;
    MMIO_WR(DP2_POLARITY_WIDTH_REG, dwTemp);
}

void
viaDp2HorVerActive(xf86OutputPtr output, DisplayModePtr mode)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD32 dwTemp;

    dwTemp = mode->CrtcVDisplay << 16 | mode->CrtcHDisplay;
    MMIO_WR(DP2_ACITVE_WH_REG, dwTemp);
}

void
viaDp2Nvid()
{
    // [23:0] Stream Clock Recovery :N
    MMIO_WR_MASK(DP2_NVID_MISC0_REG, 32768, 0x00FFFFFF);
}

void
viaDp2DelayReg()
{
    // Default: [29:24] = 20h for delay
    MMIO_WR_MASK(DP2_VIDEO_CTRL_REG, 0x20000000, 0x3F000000);
}

Bool
viaDP2SetupMainLink(xf86OutputPtr output, DisplayModePtr mode)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;

    DEBUG(ErrorF("viaDP2SetupMainLink\n"));

    if (viaDPInfo->LinkSpeed) {
        // Field ID flag not invert
        MMIO_WR_MASK(DP2_ENABLE_IF_REG, 0x0, BIT1);

        viaDp2HorWidthAndTu(output, mode);
        viaDp2HorLineDuration(output, mode);
        viaDp2Mvid(output, mode);
        viaDp2HorVerTotal(output, mode);
        viaDp2HorVerOffset(output, mode);
        viaDp2HorVerSyncWidthAndPolarity(output, mode);
        viaDp2HorVerActive(output, mode);
        viaDp2Nvid();
        viaDp2DelayReg();

        DEBUG(ErrorF("End Setup MainLink!!\n"));
    }
}

Bool
viaDP2ReadEDID(xf86OutputPtr output,
    CARD32 slave_addr, CARD32 dwOffset, CARD8 *pData)
{
    CARD32 dwData;

    viaDP2ClearAuxReadRegs();
    viaDP2ClearAuxWriteRegs();

    // 1. write slave addr offset for start
    dwData = dwOffset & 0x000000FF;
    MMIO_WR(DP2_AUX_W_DATA0_REG, dwData);
    dwData = slave_addr << 11 | 1 << 4 | AUX_CMD_I2C_WRITE;
    MMIO_WR(DP2_AUX_CMD_REG, dwData);

    // AUX trigger
    MMIO_WR(DP2_AUX_TIMER_REG, (MMIO_RD(DP2_AUX_TIMER_REG) | 0x3));
    if (!viaDP2ReplyCmdStatus(output))
        return FALSE;

    // 2. write command with read length
    dwData = slave_addr << 11 | 1 << 4 | AUX_CMD_I2C_READ;
    MMIO_WR(DP2_AUX_CMD_REG, dwData);

    // AUX trigger
    MMIO_WR(DP2_AUX_TIMER_REG, (MMIO_RD(DP2_AUX_TIMER_REG) | 0x3));
    if (!viaDP2ReplyCmdStatus(output))
        return FALSE;

    // 3. read
    *pData = (MMIO_RD(DP2_AUX_R_DATA0_REG) & 0xFF);

    return TRUE;
}

/******************************************************************
*
*                                          Common Function
*
*******************************************************************/
void
viaCalculate_TU(xf86OutputPtr output, unsigned long PixelClock, int bpp_byte)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;

    int LinkClock;

    DEBUG(ErrorF("viaCalculate_TU\n"));

    switch (viaDPInfo->LinkSpeed) {
    case Speed_162MHz:
        LinkClock = 162;
        break;
    case Speed_270MHz:
        LinkClock = 270;
        break;
    default:
        LinkClock = 270;
        break;
    }

    bpp_byte = 24;

    viaDPInfo->TURatio = ((PixelClock / 1000) * bpp_byte * 4096) /
        (LinkClock * LANE);
}

void
viaGetDPEDIDBlockData(xf86OutputPtr output, CARD8 * pEDIDData)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    CARD8 EDIDHeader[3];
    CARD8 i = 0;

    switch (viaDPInfo->commonInfo.subChipName) {
    case SUBCHIP_INTEGRATED_DP:
        /* First Read EDID Block 0 */
        for (i = 0; i < 3; i++) {
            viaDPReadEDID(output, 0xA0, i, EDIDHeader + i);
        }

         
        /* EDID Header is 00 FF FF FF FF FF FF 00 */
        if ((EDIDHeader[0] == 0) && (EDIDHeader[1] == 0xFF) &&
            (EDIDHeader[2] == 0xFF)) {
            /* Read Block 0 Raw Data. */
            for (i = 0; i < 128; i++) {
                viaDPReadEDID(output, 0xA0, i, pEDIDData + i);
            }
        }
        break;
    case SUBCHIP_INTEGRATED_DP2:
        /* First Read EDID Block 0 */
        for (i = 0; i < 3; i++) {
            viaDP2ReadEDID(output, 0xA0, i, EDIDHeader + i);
        }

         
        /* EDID Header is 00 FF FF FF FF FF FF 00 */
        if ((EDIDHeader[0] == 0) && (EDIDHeader[1] == 0xFF) &&
            (EDIDHeader[2] == 0xFF)) {
            /* Read Block 0 Raw Data. */
            for (i = 0; i < 128; i++) {
                viaDP2ReadEDID(output, 0xA0, i, pEDIDData + i);
            }
        }
        break;
    default:
        break;
    }
}

CARD32
viaDPHotplugTimer(OsTimerPtr timer, CARD32 now, pointer arg)
{
    DEBUG(ErrorF("viaDPHotplugTimer\n"));

    xf86OutputPtr output = (xf86OutputPtr) arg;
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    CARD8 LinkStatus;

    switch (viaDPInfo->commonInfo.subChipName) {
    case SUBCHIP_INTEGRATED_DP:
        // Detect interrupt
        if ((MMIO_RD(0x1280) & 0x800) == 0x800) {
            DEBUG(ErrorF("Detect interrupt\n"));

            // Clear interrupt
            MMIO_WR_MASK(0x1280, 0x800, 0x800);

            if ((MMIO_RD(0xC730) & 0xc0000000) == 0x80000000) {
                viaDPInfo->IsDPConnected = FALSE;
                DEBUG(ErrorF("DP is un-plugged\n"));
                break;
            }

            viaDPInfo->DPCDVersion = NONEVERSION;
            viaDPReadDPCDVersion(output);
            if (viaDPInfo->DPCDVersion) {
                viaDPInfo->IsDPConnected = TRUE;
                LinkStatus = viaDPReadDPCDLinkStatus(output);

                if (LinkStatus == DP_LINKSTATUS_LOST) {
                    DEBUG(ErrorF("LinkTrainingLost. Redo set-mode\n"));
                    viaDPInfo->LinkSpeed = Speed_NONE;
                    viaDPInfo->IsLinkTrainingDone = FALSE;
                    viaDPInitEPHY(output);

                    if (xf86InitialConfiguration(pScrn, FALSE))
                        xf86SetDesiredModes(pScrn);
                    else
                        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                            "No valid initial configuration found\n");
                }
            } else {
                viaDPInfo->IsDPConnected = FALSE;
                DEBUG(ErrorF("Can not read DPCD Version!\n"));
            }
        }

        break;
    case SUBCHIP_INTEGRATED_DP2:
        // Detect interrupt
        if ((MMIO_RD(0x1280) & 0x2000) == 0x2000) {
            DEBUG(ErrorF("Detect interrupt\n"));

            // Clear interrupt
            MMIO_WR_MASK(0x1280, 0x2000, 0x2000);

            if ((MMIO_RD(0xC7B0) & 0xc0000000) == 0x80000000) {
                viaDPInfo->IsDPConnected = FALSE;
                DEBUG(ErrorF("DP2 is un-plugged\n"));
                break;
            }

            viaDPInfo->DPCDVersion = NONEVERSION;
            viaDP2ReadDPCDVersion(output);
            if (viaDPInfo->DPCDVersion) {
                viaDPInfo->IsDPConnected = TRUE;
                LinkStatus = viaDP2ReadDPCDLinkStatus(output);

                if (LinkStatus == DP_LINKSTATUS_LOST) {
                    DEBUG(ErrorF("LinkTrainingLost. Redo set-mode\n"));
                    viaDPInfo->LinkSpeed = Speed_NONE;
                    viaDPInfo->IsLinkTrainingDone = FALSE;
                    viaDP2InitEPHY(output);

                    if (xf86InitialConfiguration(pScrn, FALSE))
                        xf86SetDesiredModes(pScrn);
                    else
                        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                            "No valid initial configuration found\n");
                }
            } else {
                viaDPInfo->IsDPConnected = FALSE;
                DEBUG(ErrorF("Can not read DPCD Version!\n"));
            }
        }
        break;
    default:
        break;
    }

/* HOT_IRQ will make the following method fail. Besides, it can not detect the status */
/* that changes within 5 secs (HotplugTimer). So we use 0x1280 to detect hotplug.*/
#if 0
    switch (viaDPInfo->commonInfo.subChipName) {
    case SUBCHIP_INTEGRATED_DP:
        if (viaDPInfo->IsDPConnected) {
            // Detect unhotplug
            if (MMIO_RD(0xC730) & 0x80000000) {
                viaDPInfo->IsDPConnected = FALSE;
                viaDPInfo->DPCDVersion = NONEVERSION;
                viaDPInfo->LinkSpeed = Speed_NONE;
                viaDPInfo->IsLinkTrainingDone = FALSE;
            }
        } else {
            // Detect hotplug
            if (MMIO_RD(0xC730) & 0x40000000) {
                viaDPReadDPCDVersion(output);
                if (viaDPInfo->DPCDVersion) {
                    viaDPInfo->IsDPConnected = TRUE;
                    if (xf86InitialConfiguration(pScrn, FALSE))
                        xf86SetDesiredModes(pScrn);
                    else
                        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                            "No valid initial configuration found\n");
                }
            }
        }
        break;
    case SUBCHIP_INTEGRATED_DP2:
        if (viaDPInfo->IsDPConnected) {
            // Detect unhotplug
            if (MMIO_RD(0xC7B0) & 0x80000000) {
                viaDPInfo->IsDPConnected = FALSE;
                viaDPInfo->DPCDVersion = NONEVERSION;
                viaDPInfo->LinkSpeed = Speed_NONE;
                viaDPInfo->IsLinkTrainingDone = FALSE;
            }
        } else {
            // Detect hotplug
            if (MMIO_RD(0xC7B0) & 0x40000000) {
                viaDP2ReadDPCDVersion(output);
                if (viaDPInfo->DPCDVersion) {
                    viaDPInfo->IsDPConnected = TRUE;
                    if (xf86InitialConfiguration(pScrn, FALSE))
                        xf86SetDesiredModes(pScrn);
                    else
                        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                            "No valid initial configuration found\n");
                }
            }
        }
        break;
    }
#endif

    /* 5 sec */
    return 5000;
}

#endif
