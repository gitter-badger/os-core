/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 * Copyright 2006 Thomas Hellstrom. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef VIA_3D_H
#define VIA_3D_H

#include "xf86.h"
#include "picturestr.h"

#include "via_dmabuffer.h"
/* for use of VIA_HAVE_UXA macro */
#include "config_via.h"

/* A flag to make H5 ps instruction easy reading/writing */
#define VIA_H5_SHADER_INSTRUCTION_TRANSLATE_ENABLE  1
#define TEX_PITCH_LIMIT_INBYTE    8192
#define TEX_DIMENSION_LIMIT_INPIXEL   2048
#define DIMENSION_2D_LIMIT_INPIXEL  4096
#define HWDIMENSION_BOX_WIDTH_INPIXEL   1024
#define HWDIMENSION_BOX_HEIGHT_INPIXEL   1024
#define H5_CLIPPING_WINDOW_LIMIT_INPIXEL  4095
/* H2 chips 3D engine only support clipping window range: 0 ~ 2047 */
#define HW_H2_CLIPRANG(x)    min(x, ((1<<11)-1))
/* H5 chips 3D engine only support clipping window range: 0 ~ 4095 */
#define HW_H5_CLIPRANG(x)    min(x, ((1<<12)-1))

#define VIA_NUM_TEXUNITS 2

typedef enum
{
    via_single,
    via_clamp,
    via_repeat,
    via_mirror,
    via_warp
} ViaTextureModes;

typedef enum
{
    via_src,
    via_src_onepix_mask,
    via_src_onepix_comp_mask,
    via_mask,
    via_comp_mask,

    src_Aa,
    src_Ca,
    mask_Ca,
} ViaTexBlendingModes;

typedef enum
{
    via_FilterNearest,
    via_FilterBilinear,
    via_FilterFast,
    via_FilterGood,
    via_FilterBest
} ViaTexFilterModes;
#if VIA_H5_SHADER_INSTRUCTION_TRANSLATE_ENABLE
/* ensure the pack instruction to avoid the compiler apply byte
   alignment optimization */
#pragma pack(push,1)

typedef enum
{
    via_mad = 0,
    /* reserved 1 */
    via_dp3 = 2,
    via_dp4,
    via_exp,
    via_log,
    via_rcp,
    via_rsq,
    /* reserved 8 */
    via_cmp = 9,
    via_cmd,
    via_max,
    via_min,
    via_mov,
    via_frc,
    via_sincos,
    via_madfix,
    via_blendfix,
    /* reserved 18 */
    /* reserved 19 */
    via_texkill3 = 20,
    via_texkill4,
    /* reserved 22 ~ 31 */
} via3DALUOp;

typedef enum
{
    via_texld = 0,
    via_tesldb,
    via_teskill,
    via_texldp,
    /* reserved 4 */
    /* reserved 5 ~ 7 */
} via3DTAUOp;

typedef enum
{
    selT_r = 0,
    selT_g,
    selT_b,
    selT_a,
} via3DTAUSrcSelector;

typedef enum
{
    selA_r = 0,
    selA_g,
    selA_b,
    selA_a,
    selA_1f,
    selA_0f,
    /* reserved 6 */
    /* reserved 7 */
} via3DALUSrcSelector;

typedef enum
{
    dstT_nodefined = 0,
    dstT_temp,
} via3DTAUDstTempReg;

typedef enum
{
    modi_no = 0,
    modi_bias,
    modi_invert,
    /* reserved 3 */
    modi_scaleX2 = 4,
    /* reserved 5 ~ 7 */
    modi_negate = 8,
    /* reserved 9 ~ 15 */
} via3DSrcModifier;

typedef enum
{
    src_temp = 0,
    src_color,
    src_const,
    src_texture,
    src_aluOut,
    src_preConstant,
    src_fogCoordinate,
    src_notrequired,
} via3DSrcRegtype;

typedef enum
{
    dst_temp = 0,
    dst_texture,
    dst_output,
    dst_internaltemp,
    dst_nodefined = dst_internaltemp,
} via3DDstRegtype;

#define NO_DEST_INDEX  15

typedef enum
{
    scale_disable = 0,
    scale_x2,
    scale_x4,
    scale_x8,
    /* reserved 4 */
    scale_d2 = 5,
    scale_d4,
    scale_d8,
} via3DInsScale;

typedef enum
{
    mask_none= 0,
    mask_r = 1,
    mask_g = 2,
    mask_b = 4,
    mask_a = 8,
    mask_all = 15,
} via3DWriteMask;

typedef union _Via3DTAUInstruction
{
    struct {
        CARD32  s1index: 4;      /*[3:0]*/
        CARD32  s0sel_a:  2;     /*[5:4]*/
        CARD32  s0sel_b:  2;     /*[7:6]*/
        CARD32  s0sel_g:  2;     /*[9:8]*/
        CARD32  s0sel_r:  2;     /*[11:10]*/
        CARD32  s0index:  4;    /*[15:12]*/
        CARD32  dindex:  4;      /*[19:16]*/
        CARD32  dreg:  1;         /*[20]*/
        CARD32  op:  3;            /*[23:21]*/
        CARD32  tstage:  4;      /*[27:24]*/
        CARD32  sfire:  1;         /*[28]*/
        CARD32  pvalid:  1;      /*[29]*/
        CARD32  debug:  1;      /*[30]*/
        CARD32  dfire:  1;        /*[31]*/
    };
    CARD32  uint[1];
} Via3DTAUInstructionRec, *Via3DTAUInstructionPtr;

typedef union _Via3DALUInstruction
{
    struct {
        CARD32  s2mod: 4;                   /*[3:0]*/
        CARD32  s2sel_a:  3;                /*[6:4]*/
        CARD32  s2sel_b:  3;                /*[9:7]*/
        CARD32  s2sel_g:  3;                /*[12:10]*/
        CARD32  s2sel_r:  3;                 /*[15:13]*/
        CARD32  s2index:  6;                /*[21:16]*/
        CARD32  s2reg:  3;                    /*[24:22]*/
        CARD32  s2fire:  1;                    /*[25]*/
        CARD32  s2reserved: 2;            /*[27:26]*/
        CARD32  s1mod:  4;                   /*[31:28]*/
        CARD32  s1sel_a:  3;                 /*[34:32]*/
        CARD32  s1sel_b:  3;                 /*[37:35]*/
        CARD32  s1sel_g:  3;                 /*[40:38]*/
        CARD32  s1sel_r:  3;                 /*[43:41]*/
        CARD32  s1index:  6;                /*[49:44]*/
        CARD32  s1reg:  3;                    /*[52:50]*/
        CARD32  s1fire:  1;                    /*[53]*/
        CARD32  s1reserved:  2;           /*[55:54]*/
        CARD32  s0mod:  4;                   /*[59:56]*/
        CARD32  s0sel_a:  3;                 /*[62:60]*/
        CARD32  s0sel_b:  3;                 /*[65:63]*/
        CARD32  s0sel_g:  3;                 /*[68:66]*/
        CARD32  s0sel_r:  3;                 /*[71:69]*/
        CARD32  s0index:  6;                /*[77:72]*/
        CARD32  s0reg:  3;                   /*[80:78]*/
        CARD32  s0fire:  1;                   /*[81]*/
        CARD32  s0reserved:  2;          /*[83:82]*/
        CARD32  dwmask:  4;               /*[87:84]*/
        CARD32  dreserved: 8;             /*[95:88]*/
        CARD32  dindex1:  4;                /*[99:96]*/
        CARD32  dreg1:  2;                    /*[101:100]*/
        CARD32  dindex0:  4;                /*[105:102]*/
        CARD32  dreg0:  2;                    /*[107:106]*/
        CARD32  isat:  1;                       /*[108]*/
        CARD32  iscale:  3;                    /*[111:109]*/
        CARD32  op:  5;                         /*[116:112]*/
        CARD32  opreserved:  5;          /*[121:117]*/
        CARD32  coissue:  1;                 /*[122]*/
        CARD32  debug:  1;                   /*[123]*/
        CARD32  d1fire:  1;                   /*[124]*/
        CARD32  d0fire:  1;                   /*[125]*/
        CARD32  reserved:  2;              /*[127:126]*/
    };
    CARD32  uint[4];
} Via3DALUInstructionRec, *Via3DALUInstructionPtr;

#pragma pack(pop)
#endif
typedef struct tagH5VS_Inst
{
    union
    {
        CARD32 Uint_Src0;
        struct
        {
            // D[0:0]       Source 0 Negation
            CARD32   S0Negate    :   1;
            // D[1:1]       Reserved
            CARD32   Reserved1   :   1;
            // D[4:2]       Source 0 W channel swizzling
            CARD32   S0Sel_W     :   3;
            // D[7:5]       Source 0 Z channel swizzling
            CARD32   S0Sel_Z     :   3;
            // D[10:8]      Source 0 Y channel swizzling
            CARD32   S0Sel_Y     :   3;
            // D[13:11]     Source 0 X channel swizzling
            CARD32   S0Sel_X     :   3;
            // D[18:14]     Source 0 Register index
            CARD32   S0RegIdx    :   5;
            // D[22:19]     Source 0 Register type
            CARD32   S0RegType   :   4;
            // D[31:23]     Reserved
            CARD32   Reserved2   :   9;
        };
    };

    union
    {
        CARD32 Uint_Src1;
        // For non loop, jnz cases
        struct
        {
            // D[32:32]     Source 1 Negation
            CARD32   S1Negate    :   1;
            // D[33:33]     Reserved
            CARD32   Reserved3   :   1;
            // D[36:34]     Source 1 W channel swizzling
            CARD32   S1Sel_W     :   3;
            // D[39:37]     Source 1 Z channel swizzling
            CARD32   S1Sel_Z     :   3;
            // D[42:40]     Source 1 Y channel swizzling
            CARD32   S1Sel_Y     :   3;
            // D[45:43]     Source 1 X channel swizzling
            CARD32   S1Sel_X     :   3;
            // D[50:46]     Source 1 Register index
            CARD32   S1RegIdx    :   5;
            // D[54:51]     Source 1 Register type
            CARD32   S1RegType   :   4;
            // D[63:55]     Reserved
            CARD32   Reserved4   :   9;
        };
        // For loop, jnz cases
        struct
        {
            // D[41:32]     Reserved
            CARD32   Reserved5    :  10;
            // D[50:42]     LoopStartOffset/Offset1
            CARD32   Offset1      :   9;
            // D[54:51]     Source 1 Register type - LoopStartOffset/Offset1
            CARD32   S1Offset_Type:   4;
            // D[63:55]     Reserved
            CARD32   Reserved6    :   9;
        };
    };

    union
    {
        CARD32 Uint_Src2;
        // For non loop, jnz cases
        struct
        {
            // D[64:64]     Source 2 Negation
            CARD32   S2Negate    :   1;
            // D[65:65]     Reserved
            CARD32   Reserved7   :   1;
            // D[68:66]     Source 2 W channel swizzling
            CARD32   S2Sel_W     :   3;
            // D[71:69]     Source 2 Z channel swizzling
            CARD32   S2Sel_Z     :   3;
            // D[74:72]     Source 2 Y channel swizzling
            CARD32   S2Sel_Y     :   3;
            // D[77:75]     Source 2 X channel swizzling
            CARD32   S2Sel_X     :   3;
            // D[82:78]     Source 2 Register index
            CARD32   S2RegIdx    :   5;
            // D[86:83]     Source 2 Register type
            CARD32   S2RegType   :   4;
            // D[95:87]     Reserved
            CARD32   Reserved8   :   9;
        };
        // For loop, jnz cases
        struct
        {
            // D[73:64]     Reserved
            CARD32   Reserved9    :  10;
            // D[82:74]     LoopEndOffset/Offset2
            CARD32   Offset2      :   9;
            // D[86:83]     Source 2 Register type - LoopEndOffset/Offset2
            CARD32   S2Offset_Type:   4;
            // D[95:87]     Reserved
            CARD32   Reserved10   :   9;
        };
    };

    union
    {
        CARD32 Uint_Misc_Dest;
        struct
        {
            // D[99:96]     WriteMask
            CARD32   WriteMask   :   4;
            // D[103:100]   Destination Register Index
            CARD32   DestReg_Idx :   4;
            // D[105:104]   Destination Register Type
            CARD32   DestReg_Type:   2;
            // D[106:106]   Initialize Temp Register unwritten channel
            CARD32   TempInit    :   1;
            // D[107:107]   Write data to IR0 also
            CARD32   WriteIR0    :   1;
            // D[109:108]   Reserved
            CARD32   Reserved11  :   2;
            // D[110:110]   Output Clamp to [0,1], or push S2 to stack for JNZ
            CARD32   OClampPush  :   1;
            // D[112:111]   Reserved
            CARD32   Reserved12  :   2;
            // D[117:113]   OpCode
            CARD32   OpCode      :   5;
            // D[118:118]   Reserved
            CARD32   Reserved13  :   1;
            // D[119:119]   Return to address stored in stack after OpCode has been executed
            CARD32   Return      :   1;
            // D[121:120]   Relative addressing swizzling
            CARD32   RelativeSwz :   2;
            // D[123:122]   Relative addressing
            CARD32   RelativeAddr:   2;
            // D[127:124]   Reserved
            CARD32   Reserved14  :   4;
        };
    };
}H5VSInst, *LPH5VSInst;

#define H5VSOP_S0(lpInst, op, dreg_type, dreg_idx, wm, sat, wir0, tmpinit,  \
                  s0Type, s0Idx, s0sel_x, s0sel_y, s0sel_z, s0sel_w, s0neg) \
    {                                           \
        lpInst->OpCode = (op);                  \
        lpInst->DestReg_Type = (dreg_type);     \
        lpInst->DestReg_Idx = (dreg_idx);       \
        lpInst->WriteIR0 = (wir0);              \
        lpInst->TempInit = (tmpinit);           \
        lpInst->WriteMask = (wm);               \
        lpInst->OClampPush = (sat);             \
        lpInst->S0RegType = (s0Type);           \
        lpInst->S0RegIdx = (s0Idx);             \
        lpInst->S0Sel_X = (s0sel_x);            \
        lpInst->S0Sel_Y = (s0sel_y);            \
        lpInst->S0Sel_Z = (s0sel_z);            \
        lpInst->S0Sel_W = (s0sel_w);            \
        lpInst->S0Negate = (s0neg);             \
        lpInst->Uint_Src1 = 0;                  \
        lpInst->Uint_Src2 = 0;                  \
    }

#define H5VSOP_S0_S1_S2(lpInst, op, dreg_type, dreg_idx, wm, sat, wir0, \
                tmpinit, s0type, s0idx, s0sel_x, s0sel_y, s0sel_z, \
                s0sel_w, s0neg, s1type, s1idx, s1sel_x, s1sel_y, \
                s1sel_z, s1sel_w, s1neg, s2type, s2idx, s2sel_x, \
                s2sel_y, s2sel_z, s2sel_w, s2neg)  \
    {                                           \
        lpInst->OpCode = (op);                  \
        lpInst->DestReg_Type = (dreg_type);     \
        lpInst->DestReg_Idx = (dreg_idx);       \
        lpInst->WriteIR0 = (wir0);              \
        lpInst->TempInit = (tmpinit);           \
        lpInst->WriteMask = (wm);               \
        lpInst->OClampPush = (sat);             \
        lpInst->S0RegType = (s0type);           \
        lpInst->S0RegIdx = (s0idx);             \
        lpInst->S0Sel_X = (s0sel_x);            \
        lpInst->S0Sel_Y = (s0sel_y);            \
        lpInst->S0Sel_Z = (s0sel_z);            \
        lpInst->S0Sel_W = (s0sel_w);            \
        lpInst->S0Negate = (s0neg);             \
        lpInst->S1RegType = (s1type);           \
        lpInst->S1RegIdx = (s1idx);             \
        lpInst->S1Sel_X = (s1sel_x);            \
        lpInst->S1Sel_Y = (s1sel_y);            \
        lpInst->S1Sel_Z = (s1sel_z);            \
        lpInst->S1Sel_W = (s1sel_w);            \
        lpInst->S1Negate = (s1neg);             \
        lpInst->S2RegType = (s2type);           \
        lpInst->S2RegIdx = (s2idx);             \
        lpInst->S2Sel_X = (s2sel_x);            \
        lpInst->S2Sel_Y = (s2sel_y);            \
        lpInst->S2Sel_Z = (s2sel_z);            \
        lpInst->S2Sel_W = (s2sel_w);            \
        lpInst->S2Negate = (s2neg);             \
    }

/*OP*/
enum
{
    H5VSOP_NOP      = 0,
    H5VSOP_MAD      = 2,
    H5VSOP_DP4      = 3,
    H5VSOP_MOV      = 4,
    H5VSOP_MOVA     = 5,
    H5VSOP_FLOOR    = 6,
    H5VSOP_FRC      = 7,
    H5VSOP_MAX      = 8,
    H5VSOP_MIN      = 9,
    H5VSOP_SGE      = 10,
    H5VSOP_SLT      = 11,
    H5VSOP_SGN      = 12,
    H5VSOP_CMPGT    = 13,
    H5VSOP_DIVMC    = 14,
    H5VSOP_EXP      = 16,
    H5VSOP_EXPP     = 17,
    H5VSOP_LOG      = 18,
    H5VSOP_LOGP     = 19,
    H5VSOP_RCP      = 20,
    H5VSOP_RSQ      = 21,
    H5VSOP_SINCOS   = 22,
    H5VSOP_LIT      = 24,
    H5VSOP_DP4MOV   = 26,
    H5VSOP_LOOPREP  = 28,
    H5VSOP_JNZ      = 29,
} H5_OPCODE;
// Destination register Type
enum
{
    H5_VS_DREGTYPE_NONE = 0x0,
    H5_VS_DREGTYPE_A0 = 0x0,
    H5_VS_DREGTYPE_TEMP = 0x1,
    H5_VS_DREGTYPE_OUTPUT = 0x2,
    H5_VS_DREGTYPE_CLIPPLANE = 0x3,
} H5_DREGTYPE;

#define H5_dNODEST            (H5_VS_DREGTYPE_NONE)
#define H5_dA0                (H5_VS_DREGTYPE_A0)
#define H5_dTEMP              (H5_VS_DREGTYPE_TEMP)
#define H5_dOUTPUT            (H5_VS_DREGTYPE_OUTPUT)
#define H5_dCLIPPLANE         (H5_VS_DREGTYPE_CLIPPLANE)

// Destination Register Index
#define H5_IDX_NoDest           0x0
#define H5_IDX_Address          0x1
#define H5_IDX_oCL0             0x0 // User clipping plane 0~2
#define H5_IDX_oCL1             0x1 // User clipping plane 3~5

//------------------------------------------------------------------------------
//
//                               FFVS Temp Reigster
//
//------------------------------------------------------------------------------
#define H5FFVSR_EYEPOS                      0
#define H5FFVSR_EYENORMAL                   1

enum
{
    H5_IDX_oPos = 0x0,
    H5_IDX_oSpos = 0x1,
    H5_IDX_oD0 = 0x2,
    H5_IDX_oD1 = 0x3,
    H5_IDX_oB0 = 0x4,
    H5_IDX_oB1 = 0x5,
    H5_IDX_oFog = 0x6,
    H5_IDX_oPSize = 0x7,
    H5_IDX_oT0 = 0x8,
    H5_IDX_oT1 = 0x9,
    H5_IDX_oT2 = 0xA,
    H5_IDX_oT3 = 0xB,
    H5_IDX_oT4 = 0xC,
    H5_IDX_oT5 = 0xD,
    H5_IDX_oT6 = 0xE,
    H5_IDX_oT7 = 0xF,
} H5VS_DOUTPUTREGIDX;

enum
{
    H5_WM_X = 0x1,
    H5_WM_R = 0x1,
    H5_WM_Y = 0x2,
    H5_WM_G = 0x2,
    H5_WM_Z = 0x4,
    H5_WM_B = 0x4,
    H5_WM_W = 0x8,
    H5_WM_A = 0x8,
    H5_WM_XY   = 0x3,
    H5_WM_XYZ  = 0x7,
    H5_WM_XYZW = 0xF,
    H5_WM_RGBA = 0xF,
} H5_WM;


enum
{
    H5_VS_SRCREGTYPE_NONE = 0x0,
    H5_VS_SRCREGTYPE_INPUT = 0x1,
    H5_VS_SRCREGTYPE_TEMP = 0x2,
    H5_VS_SRCREGTYPE_INTEGER = 0x3,
    H5_VS_SRCREGTYPE_BOOLEAN = 0x3,
    H5_VS_SRCREGTYPE_INTERNAL_SPECIAL_TEMP = 0x4,
    H5_VS_SRCREGTYPE_PREDEFINE_FLOAT_CONST = 0x4,
    H5_VS_SRCREGTYPE_PREDEFINE_BOOLEAN_CONST = 0x4,
    H5_VS_SRCREGTYPE_LOOPOFFSET1 = 0x5,
    H5_VS_SRCREGTYPE_LOOPOFFSET2 = 0x6,
    H5_VS_SRCREGTYPE_INTERNAL_CONST = 0x7,
    H5_VS_SRCREGTYPE_CONST_OFFSET0 = 0x8,
    H5_VS_SRCREGTYPE_CONST_OFFSET32 = 0x9,
    H5_VS_SRCREGTYPE_CONST_OFFSET64 = 0xa,
    H5_VS_SRCREGTYPE_CONST_OFFSET96 = 0xb,
    H5_VS_SRCREGTYPE_CONST_OFFSET128 = 0xc,
    H5_VS_SRCREGTYPE_CONST_OFFSET160 = 0xd,
    H5_VS_SRCREGTYPE_CONST_OFFSET192 = 0xe,
    H5_VS_SRCREGTYPE_CONST_OFFSET224 = 0xf,
} H5_VS_SRCREGTYPE;

#define H5_sNOSRC                (H5_VS_SRCREGTYPE_NONE)
#define H5_sCONST_INTERNAL       (H5_VS_SRCREGTYPE_INTERNAL_CONST)
#define H5_sCONST_INT            (H5_VS_SRCREGTYPE_INTEGER)      // S0 only
#define H5_sCONST_BOOL           (H5_VS_SRCREGTYPE_BOOLEAN)      // S0 only
#define H5_sINPUT                (H5_VS_SRCREGTYPE_INPUT)
#define H5_sTEMP                 (H5_VS_SRCREGTYPE_TEMP)
#define H5_sIR0                  (H5_VS_SRCREGTYPE_INTERNAL_SPECIAL_TEMP)
#define H5_sFLOAT                (H5_VS_SRCREGTYPE_PREDEFINE_FLOAT_CONST)
#define H5_sBOOLEAN              (H5_VS_SRCREGTYPE_PREDEFINE_BOOLEAN_CONST)
#define H5_sLOOPSTART            (H5_VS_SRCREGTYPE_LOOPOFFSET1)   // S1 only
#define H5_sLOOPEND              (H5_VS_SRCREGTYPE_LOOPOFFSET2)   // S2 only
#define H5_sOFFSET1              (H5_VS_SRCREGTYPE_LOOPOFFSET1)   // S1 only
#define H5_sOFFSET2              (H5_VS_SRCREGTYPE_LOOPOFFSET2)   // S2 only
#define H5_sCONST_OFFSET0        (H5_VS_SRCREGTYPE_CONST_OFFSET0)
#define H5_sCONST_OFFSET32       (H5_VS_SRCREGTYPE_CONST_OFFSET32)
#define H5_sCONST_OFFSET64       (H5_VS_SRCREGTYPE_CONST_OFFSET64)
#define H5_sCONST_OFFSET96       (H5_VS_SRCREGTYPE_CONST_OFFSET96)
#define H5_sCONST_OFFSET128      (H5_VS_SRCREGTYPE_CONST_OFFSET128)
#define H5_sCONST_OFFSET160      (H5_VS_SRCREGTYPE_CONST_OFFSET160)
#define H5_sCONST_OFFSET192      (H5_VS_SRCREGTYPE_CONST_OFFSET192)
#define H5_sCONST_OFFSET224      (H5_VS_SRCREGTYPE_CONST_OFFSET224)
// For checking
#define H5_sLABEL                0xffffffff

#define H5VSC_SHARE_BASE                 256
// 256 (ScaleX, ScaleY, ScaleZ, NotUsed)
#define H5VSC_VIEWPORT_SCALE            (H5VSC_SHARE_BASE)
// 257 (OffsetX, OffsetY, OffsetZ, NotUsed) for TnL and PVS
#define H5VSC_VIEWPORT_OFFSET           (H5VSC_VIEWPORT_SCALE + 1)
// 258 (OffsetX, OffsetY, NotUsed, NotUsed) for transformed vertex
#define H5VSC_VIEWPORT_OFFSET_TLVERTEX  (H5VSC_VIEWPORT_OFFSET + 1)

#define H5_CONST_INTERNAL_IDX(idx)      ((idx)-256)

enum
{
    H5_VSSEL_X = 0,
    H5_VSSEL_Y = 1,
    H5_VSSEL_Z = 2,
    H5_VSSEL_W = 3,
    H5_VSSEL_R = 0,
    H5_VSSEL_G = 1,
    H5_VSSEL_B = 2,
    H5_VSSEL_A = 3,
    H5_VSSEL_1 = 4,   // Constant 1.0
    H5_VSSEL_0 = 5,   // Constant 0.0
} H5_VSSEL;

typedef struct _ViaTextureUnit
{
    struct generic_bo *textureLevel0Bo;
    CARD32 textureLevel0Bo_delta;
    unsigned int textureLevel0Location;
    CARD32 textureLevel0Offset;
    CARD32 textureLevel0UOffset; /* used for video Texture YV12 format only */
    CARD32 textureLevel0VOffset; /* used for video Texture YV12 format only */
    CARD32 textureLevel0Pitch;
    CARD32 textureLevel0Width;
    CARD32 textureLevel0Height;
    CARD32 textureLevel0WExp;
    CARD32 textureLevel0HExp;
    CARD32 textureBlendMode;
    CARD32 textureDrawable_width;
    CARD32 textureDrawable_height;
    CARD32 bytePerPixel;
    CARD32 textureFormat;
    CARD32 textureModesT;
    CARD32 textureModesS;
    CARD32 texCsat;
    CARD32 texRCa;
    CARD32 texAsat;
    CARD32 texRAa;
    int pictureFormat;
    int pictureFilter;
    struct generic_bo *PictureBo;
    unsigned int PictureLocation;
    CARD32 PictureOffset;
    Bool agpTexture;
    Bool textureDirty;
    Bool texBColDirty;
    Bool npot;
    Bool textureRepeat;
    Bool isaffine;
    /** Transform pointers for teture, or NULL if identity */
    PictTransform *transform;
    CARD32 texturefilter;
} ViaTextureUnit;

typedef struct _Via3DState
{
    Bool destDirty;
    Bool blendDirty;
    Bool enableDirty;
    Bool drawingDirty;
    Bool attributeDirty;
    Bool vertexDirty;
    CARD32 rop;
    CARD32 planeMask;
    CARD32 solidColor;
    CARD32 solidAlpha;
    struct generic_bo *destBo;
    CARD32 destBo_delta;
    unsigned int destLocation;
    CARD32 destOffset;
    CARD32 destPitch;
    CARD32 destFormat;
    int destDepth;
    int numTextures;
    Bool blend;
    CARD32 blendCol0;
    CARD32 blendCol1;
    CARD32 blendAl0;
    CARD32 blendAl1;
    Bool writeAlpha;
    Bool writeColor;
    Bool useDestAlpha;
    Bool forceUpload;
    Bool componentAlpha;
    Bool srcRepeat;
    Bool maskRepeat;
    ViaTextureUnit tex[VIA_NUM_TEXUNITS];
#if VIA_H5_SHADER_INSTRUCTION_TRANSLATE_ENABLE
    Via3DTAUInstructionRec  viaTAUIns;
    Via3DALUInstructionRec  viaALUIns;
#endif
    H5VSInst HWInstBuffer;
    Bool chipset410;
    void (*setDestination_uxa) (struct _Via3DState *, struct generic_bo *,
            CARD32, int);
    void (*setDestination) (struct _Via3DState *, CARD32,
            CARD32, int);
    void (*setDrawing) (struct _Via3DState *, int,
            CARD32, CARD32, CARD32);
    void (*setFlags) (struct _Via3DState *, int,
    Bool writeAlpha, Bool, Bool);
    Bool(*setTexture_uxa) (struct _Via3DState *, int, struct generic_bo *,
            CARD32, Bool, CARD32, CARD32, int,
            ViaTextureModes, ViaTextureModes, ViaTexBlendingModes,
            Bool,PictTransformPtr, ViaTexFilterModes);
    Bool(*setTexture) (struct _Via3DState *, int, CARD32,
            CARD32, Bool, CARD32, CARD32, int,
            ViaTextureModes, ViaTextureModes, ViaTexBlendingModes,
            Bool, PictTransformPtr, ViaTexFilterModes);
    Bool(*setTexUVOffset) (struct _Via3DState *, int, CARD32, CARD32);
    void (*setTexBlendCol) (struct _Via3DState *, int, Bool,
            CARD32);
    void (*setCompositeOperator) (struct _Via3DState *, CARD8, Bool);
    Bool(*opSupported) (CARD8);
    void (*emitQuad) (struct _Via3DState *, ViaCommandBuffer *,
            int, int, int, int, int, int, int,
            int);
    void (*emitState) (struct _Via3DState *, ViaCommandBuffer *,
            Bool);
    void (*emitClipRect) (struct _Via3DState *, ViaCommandBuffer *,
            int, int, int, int);
    void (*emitPixelShader) (struct _Via3DState *, ViaCommandBuffer *,
    int, int, int);
    void (*emitVetexShader) (struct _Via3DState *, ViaCommandBuffer *);
    Bool(*dstSupported) (int);
    Bool(*texSupported) (int);
    int (*MarkSync)(ScreenPtr);
    void (*WaitMarker)(ScreenPtr, int);
} Via3DState;

typedef union _via2DBltSrc {
    struct {
        unsigned bpp;
        unsigned long offset;
        unsigned pitch;
        unsigned x;
        unsigned y;
        unsigned long colorKey;
        unsigned memLoc;
    }m1;
    struct {
        unsigned bpp;
        unsigned long color;
    }m2;
} via2DBltSrcRec, *via2DBltSrcPtr;

typedef struct {
    unsigned bpp;
    unsigned long offset;
    unsigned pitch;
    unsigned x;
    unsigned y;
    unsigned w;
    unsigned h;
    unsigned long colorKey;
} via2DBltDstRec, *via2DBltDstPtr;

typedef union _via2DBltConfig {
    struct {
        unsigned srckey:1;
        unsigned dstey:1;
        unsigned solidfill:1;
        unsigned reservered:29;
    };
    unsigned unit;
} via2DBltConfigRec, *via2DBltConfigPtr;

typedef struct {
    unsigned format;        /* src format in viaFormats[] */
#ifdef VIA_HAVE_UXA
    struct generic_bo *srcBo; /* src bo */
    CARD32 Bo_delta;
    CARD32 srcBo_udelta;
    CARD32 srcBo_vdelta;
#endif
    /*offset, uoffset, voffset temporily reserve for xv texture*/
    unsigned long offset;   /* src offset */
    unsigned long uoffset;  /* src u(cb) offset */
    unsigned long voffset;  /* src v(cr) offset */
    unsigned pitch;         /* src pitch */
    unsigned x;             /* src start x */
    unsigned y;             /* src start y */
    unsigned w;             /* src width */
    unsigned h;             /* src height */
    unsigned surfwidth;     /* src surface width */
    unsigned surfheight;    /* src surface height */
    unsigned filter;        /* src filter mode */
    unsigned memLoc;        /* src surface memory location */
} viaTexture3DBltSrcRec, *viaTexture3DBltSrcPtr;
typedef struct {
    unsigned format;       /* dst format in viaFormats[] */
#ifdef VIA_HAVE_UXA
    struct generic_bo *dstBo; /* dst bo */
    CARD32 Bo_delta;
#endif
    unsigned long offset;  /* dst offset
                              this should be reserved for texture video */
    unsigned pitch;        /* dst pitch */
    unsigned x;            /* dst start x */
    unsigned y;            /* dst start y */
    unsigned w;            /* dst width */
    unsigned h;            /* dst height */
} viaTexture3DBltDstRec, *viaTexture3DBltDstPtr;

typedef struct {
    unsigned rotate;         /* rotation/reflection flag in R&R define */
    unsigned width;          /* rotate/reflect area width */
    unsigned height;         /* rotate/reflect area height */
} viaTexture3DBltRotationRec, *viaTexture3DBltRotationPtr;

_X_EXPORT void
viaAccelTexture3DBlt(ScrnInfoPtr, viaTexture3DBltSrcPtr, viaTexture3DBltDstPtr,
                    viaTexture3DBltRotationPtr, RegionPtr);

Bool viaOrder(CARD32 val, CARD32 *shift);
void viaInit3DState(Via3DState *v3d);
void viaInit3DState_H5(Via3DState *v3d);
void viaInit3DState_H6(Via3DState *v3d);
void Modulate_H5_via_src(Via3DState *v3d, ViaCommandBuffer *cb);
void Modulate_H5_via_src_onepix_mask_no_alpha(Via3DState *v3d,
        ViaCommandBuffer *cb);
void Modulate_H5_via_src_onepix_mask(Via3DState *v3d, ViaCommandBuffer *cb);
void Modulate_H5_via_mask(Via3DState *v3d, ViaCommandBuffer *cb);
void Modulate_H5_via_mask2(Via3DState *v3d, ViaCommandBuffer *cb);
void Modulate_H5_No_Tex(Via3DState *v3d, ViaCommandBuffer *cb);
#endif
