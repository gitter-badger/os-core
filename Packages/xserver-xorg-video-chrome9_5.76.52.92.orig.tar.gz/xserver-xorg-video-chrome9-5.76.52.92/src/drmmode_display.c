/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
 
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#include "X11/Xatom.h"
#include "via_driver.h"
#include "drmmode_display.h"
#include "via_bo.h"
#include "via_bo_gem.h"
#include "drm.h"
#include "xf86drmMode.h"
#include "via_common.h"
#include "debug.h"
#include "via_dri2.h"
#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include "via_dp.h"
#ifdef HAVE_LIBUDEV
#include "libudev.h"
#endif

extern CARD32 transformTvStandard(char *pStr);
extern CARD32 transformTvSignal(char *pStr);
extern CARD32 transformTvScan(char *pStr);
void drmmode_uevent_init_handle(ScrnInfoPtr, drmmode_ptr);

struct drmmode_rec {
    int fd;
    uint32_t fb_id;
    drmModeResPtr mode_res;
    int cpp;
    ScrnInfoPtr scrn;
    struct udev_monitor *uevent_monitor;
    InputHandlerProc uevent_handler;
    void *udev_handle;
    int udev_out_date;
    drmEventContext event_context;
};

typedef struct {
    drmmode_ptr drmmode;
    drmModeCrtcPtr mode_crtc;
    struct generic_bo *cursor;
    struct generic_bo *rotate_bo;
    uint32_t rotate_fb_id;
    int hw_id;
} drmmode_crtc_private_rec, *drmmode_crtc_private_ptr;

typedef struct {
    drmModePropertyPtr mode_prop;
    uint64_t value;
    int num_atoms;
    Atom *atoms;
} drmmode_prop_rec, *drmmode_prop_ptr;

typedef struct {
    drmmode_ptr drmmode;
    int output_id;
    drmModeConnectorPtr mode_output;
    drmModeEncoderPtr *mode_encoders;
    drmModePropertyBlobPtr edid_blob;
    int dpms_enum_id;
    int num_props;
    drmmode_prop_ptr props;
    int enc_mask;
    int enc_clone_mask;
    int physicalWidth;
    int physicalHeigth;
    int edidMaxPixelClock;  
} drmmode_output_private_rec, *drmmode_output_private_ptr;

enum {XORG_CONF_NAMESPACE_OLD, XORG_CONF_NAMESPACE_NEW};

static int subpixel_conv_table[7] = {
    0, SubPixelUnknown,
    SubPixelHorizontalRGB,
    SubPixelHorizontalBGR,
    SubPixelVerticalRGB,
    SubPixelVerticalBGR,
    SubPixelNone
};


// sync polarity, same define as CBIOS
enum {
    CBIOS_POSITIVE    = 0,
    CBIOS_NEGATIVE    = 1
};
// sync interlace/progressive, same define as CBIOS
enum {
    CBIOS_PROGRESSIVE    = 0,
    CBIOS_INTERLACE    = 1
};

//*****************************************************************************
//  Customize timing data structure
//  Defined in CBIOS, We need to keep same size as CBIOS, 
//  Because value of sizeof(int) in i386 and x86-64 is different.
//  So.... <<PAY ATTENTION>> we shouldn't use CARD8 CARD32 in these two struct.
typedef struct __customize_timing_head
{
    /* pay attention to the comments below! */
    unsigned short  version;        // current CustomizeTiming file version
    unsigned char    checkSum;       // to make whole customize timing table in file + checksum  to zero
    unsigned char    reserved;       // reserve BYTE must be zero
    unsigned int   fileLength;     // whole file from begining
    unsigned int   timingNum;      // CustomizeTiming number in file
} customize_timing_head_rec, *customize_timing_head_ptr;

//  Defined in CBIOS, We need to keep same size as CBIOS, 
//  Because value of sizeof(int) in i386 and x86-64 is different.
//  So.... <<PAY ATTENTION>> we shouldn't use CARD8 CARD32 in these two struct.
typedef struct __customize_timing_entity
{
    /* pay attention to the comments below! */
    unsigned int   dispDev;        // Display device   
    unsigned int   H_Res;          // Horizontal resulotion
    unsigned int   V_Res;          // Vertical resulotion
    unsigned int   colorDepth;     // 8 / 16 / 32 (bpp)
    unsigned int   rRateX100;      // Refresh Rate in Hz * 100 (decimal)
    unsigned int   vPLL;           // HW PLL value with format 0MRN
    unsigned short    HTotal;         // HorTotalTime
    unsigned short    HDisEnd;        // HorAddrTime
    unsigned short    HBlankStart;    // HorBlankStart
    unsigned short    HBlankEnd;      // HorBlankTime
    unsigned short    HSyncStart;     // HorSyncStart
    unsigned short    HSyncEnd;       // HorSyncEnd
    unsigned short    VTotal;         // VerTotalTime
    unsigned short    VDisEnd;        // VerAddrTime
    unsigned short    VBlankStart;    // VerBlankStart
    unsigned short    VBlankEnd;      // VerBlankEnd
    unsigned short    VSyncStart;     // VerSyncStart
    unsigned short    VSyncEnd;       // VerSyncEnd
    unsigned char    HPolarity;      // HorPolarity - 0:positive, 1:negative
    unsigned char    VPolarity;      // VorPolarity - 0:positive, 1:negative
    unsigned char    Interlaced;     // Interlace mode
    unsigned char    reserved;       // reserve BYTE must be zero
}customize_timing_entity_rec, *customize_timing_entity_ptr;


static const char *output_names[] = {
    "None",
    "VGA",
    "DVI",
    "DVI",
    "DVI",
    "Composite",
    "S-video",
    "LVDS",
    "CTV",
    "DIN",
    "DisplayPort",
    "HDMI",
    "HDMI",
    "TV",
    "eDP"
};
static const char *output_names_old[] = {
    "None",
    "CRT",
    "DVI",
    "DVI",
    "DVI",
    "Composite",
    "S-video",
    "LCD",
    "CTV",
    "DIN",
    "DP",
    "HDMI",
    "HDMI",
    "TV",
    "eDP"
};

static int
drmmode_get_output_name(int connector_type,
        int id, int namespace, char *name_buf)
{
    const char *name;

    switch (namespace) {
    case XORG_CONF_NAMESPACE_OLD:
        name = output_names_old[connector_type];
        if((name =="Composite")||(name =="S-video"))
            name = "TV";
        if (id == 1)
            snprintf(name_buf, 31, "%s", name);
        else
            snprintf(name_buf, 31, "%s-%d", name, id);
        break;
    case XORG_CONF_NAMESPACE_NEW:
    default:
        name = output_names[connector_type];
        if((name =="Composite")||(name =="S-video"))
            name = "TV";
			
        snprintf(name_buf, 31, "%s-%d", name, id);
        break;
    }

    return 0;
}

typedef enum
{
    DRM_OPTION_CRT_TYPE,
    DRM_OPTION_CRT_DIPORT,
    DRM_OPTION_CRT_SERIALPORT,
    DRM_OPTION_CRT_DDCPORT,
    DRM_OPTION_CRT_NoDDCValue,
    DRM_OPTION_CRT_CLOCK_POLARITY,
    DRM_OPTION_CRT_CLOCK_ADJUST,
    DRM_OPTION_CRT_CLOCK_DRIVING_SELECTION,
    DRM_OPTION_CRT_DATA_DRIVING_SELECTION
} drm_crt_opts;

typedef enum
{
    DRM_OPTION_LCD_TYPE,
    DRM_OPTION_LCD_DIPORT,
    DRM_OPTION_LCD_SERIALPORT,
    DRM_OPTION_LCD_DDCPORT,
    DRM_OPTION_LCD_PANEL_SIZE,
    DRM_OPTION_LCD_DUAL_CHANNEL,
    DRM_OPTION_LCD_MSB,
    DRM_OPTION_LCD_NO_DITHERING,
    DRM_OPTION_LCD_CENTER,
    DRM_OPTION_LCD_FIXONIGA1,
    DRM_OPTION_LCD_CLOCK_POLARITY,
    DRM_OPTION_LCD_CLOCK_ADJUST,
    DRM_OPTION_LCD_CLOCK_DRIVING_SELECTION,
    DRM_OPTION_LCD_DATA_DRIVING_SELECTION,
    DRM_OPTION_LCD_VT1636_CLOCK_SEL_ST1,
    DRM_OPTION_LCD_VT1636_CLOCK_SEL_ST2
} drm_lcd_opts;

typedef enum
{
    DRM_OPTION_DVI_TYPE,
    DRM_OPTION_DVI_DIPORT,
    DRM_OPTION_DVI_SERIALPORT,
    DRM_OPTION_DVI_DDCPORT,
    DRM_OPTION_DVI_NoDDCValue,
    DRM_OPTION_DVI_CLOCK_POLARITY,
    DRM_OPTION_DVI_CLOCK_ADJUST,
    DRM_OPTION_DVI_CLOCK_DRIVING_SELECTION,
    DRM_OPTION_DVI_DATA_DRIVING_SELECTION,
    DRM_OPTION_DVI_AD9389_CIRCUIT_STATE_ADJUST
} via_dvi_opts;


typedef enum
{
    DRM_OPTION_DP_NoDDCValue,
    DRM_OPTION_DP_SWLinkTraining
}via_dp_opts;

typedef enum
{
    DRM_OPTION_HDMI_TYPE,
    DRM_OPTION_HDMI_DIPORT,
    DRM_OPTION_HDMI_SERIALPORT,
    DRM_OPTION_HDMI_DDCPORT,
    DRM_OPTION_HDMI_Hotplug,
    DRM_OPTION_HDMI_CLOCK_POLARITY,
    DRM_OPTION_HDMI_CLOCK_ADJUST,
    DRM_OPTION_HDMI_CLOCK_DRIVING_SELECTION,
    DRM_OPTION_HDMI_DATA_DRIVING_SELECTION,
    DRM_OPTION_HDMI_ATTACH_ALL_MODES,
    DRM_OPTION_HDMI_AD9389_CIRCUIT_STATE_ADJUST,
    DRM_OPTION_HDMI_LEFT_BORDER,
    DRM_OPTION_HDMI_RIGHT_BORDER,
    DRM_OPTION_HDMI_TOP_BORDER,
    DRM_OPTION_HDMI_BOTTOM_BORDER,
    DRM_OPTION_HDMI_DISABLE_AUDIO
} via_hdmi_opts;

typedef enum
{
	DRM_OPTION_TV_STANDARD,
	DRM_OPTION_TV_SIGNAL,
	DRM_OPTION_TV_SCAN,
	DRM_OPTION_TV_DEDOTCRAWL,
	DRM_OPTION_TV_CLOCK_POLARITY,
	DRM_OPTION_TV_CLOCK_ADJUST,
	DRM_OPTION_TV_CLOCK_DRIVING_SELECTION,
	DRM_OPTION_TV_DATA_DRIVING_SELECTION,
	DRM_OPTION_TV_VT162x_DPA,	
}via_tv_opts;

static OptionInfoRec via_crt_options[] =
{
    {DRM_OPTION_CRT_NoDDCValue,             "NoDDCValue",
            OPTV_BOOLEAN,   {0}, FALSE},
    {DRM_OPTION_CRT_CLOCK_POLARITY,         "ClockPolarity",
            OPTV_INTEGER,    {0}, FALSE},
    {DRM_OPTION_CRT_CLOCK_ADJUST,           "ClockAdjust",
            OPTV_INTEGER,   {0}, FALSE},
    {DRM_OPTION_CRT_CLOCK_DRIVING_SELECTION, "ClockDrivingSelection",
            OPTV_INTEGER,   {0}, FALSE},
    {DRM_OPTION_CRT_DATA_DRIVING_SELECTION, "DataDrivingSelection",
            OPTV_INTEGER,   {0}, FALSE},
    {-1,                                    NULL,
            OPTV_NONE,      {0}, FALSE}
};

static OptionInfoRec via_lcd_options[] =
{
    {DRM_OPTION_LCD_PANEL_SIZE,                "PanelSize",
            OPTV_STRING,     {0}, FALSE},
    {DRM_OPTION_LCD_DUAL_CHANNEL,            "DualChannel",
            OPTV_BOOLEAN,    {0}, FALSE},
    {DRM_OPTION_LCD_MSB,                    "MSB",
            OPTV_BOOLEAN,    {0}, FALSE},
    {DRM_OPTION_LCD_NO_DITHERING,            "NoDithering",
            OPTV_BOOLEAN,    {0}, FALSE},
    {DRM_OPTION_LCD_CENTER,                    "Center",
            OPTV_BOOLEAN,    {0}, FALSE},
    {DRM_OPTION_LCD_FIXONIGA1,                "FixOnIGA1",
            OPTV_BOOLEAN,    {0}, FALSE},
    {DRM_OPTION_LCD_CLOCK_POLARITY,            "ClockPolarity",
            OPTV_INTEGER,    {0}, FALSE},
    {DRM_OPTION_LCD_CLOCK_ADJUST,            "ClockAdjust",
            OPTV_INTEGER,    {0}, FALSE},
    {DRM_OPTION_LCD_CLOCK_DRIVING_SELECTION,"ClockDrivingSelection",
            OPTV_INTEGER,    {0}, FALSE},
    {DRM_OPTION_LCD_DATA_DRIVING_SELECTION,    "DataDrivingSelection",
            OPTV_INTEGER,    {0}, FALSE},
    {DRM_OPTION_LCD_VT1636_CLOCK_SEL_ST1,     "Vt1636ClockSelST1",
            OPTV_INTEGER,    {0}, FALSE},
    {DRM_OPTION_LCD_VT1636_CLOCK_SEL_ST2,     "Vt1636ClockSelST2",
            OPTV_INTEGER,    {0}, FALSE},
    {-1,                                    NULL,
            OPTV_NONE,      {0}, FALSE}
};

static OptionInfoRec via_dvi_options[] =
{
    {DRM_OPTION_DVI_NoDDCValue,                  "NoDDCValue",
            OPTV_BOOLEAN,   {0}, FALSE},         
    {DRM_OPTION_DVI_CLOCK_POLARITY,              "ClockPolarity",
            OPTV_INTEGER,    {0}, FALSE},         
    {DRM_OPTION_DVI_CLOCK_ADJUST,                "ClockAdjust",
            OPTV_INTEGER,   {0}, FALSE},         
    {DRM_OPTION_DVI_CLOCK_DRIVING_SELECTION,     "ClockDrivingSelection",
            OPTV_INTEGER,   {0}, FALSE},         
    {DRM_OPTION_DVI_DATA_DRIVING_SELECTION,      "DataDrivingSelection",
            OPTV_INTEGER,   {0}, FALSE},
    {DRM_OPTION_DVI_AD9389_CIRCUIT_STATE_ADJUST, "AD9389CircuitStateAdjust",
            OPTV_INTEGER,   {0}, FALSE},
    {-1,                                         NULL,
            OPTV_NONE,      {0}, FALSE}
};

static OptionInfoRec via_hdmi_options[] =
{
    {DRM_OPTION_HDMI_CLOCK_POLARITY,               "ClockPolarity",
            OPTV_INTEGER,   {0}, FALSE},
    {DRM_OPTION_HDMI_CLOCK_ADJUST,                 "ClockAdjust",
            OPTV_INTEGER,   {0}, FALSE},
    {DRM_OPTION_HDMI_CLOCK_DRIVING_SELECTION,      "ClockDrivingSelection",
            OPTV_INTEGER,   {0}, FALSE},
    {DRM_OPTION_HDMI_DATA_DRIVING_SELECTION,       "DataDrivingSelection",
            OPTV_INTEGER,   {0}, FALSE},
    {DRM_OPTION_HDMI_ATTACH_ALL_MODES,             "AttachAllModes",
            OPTV_BOOLEAN,   {0}, FALSE},
    {DRM_OPTION_HDMI_AD9389_CIRCUIT_STATE_ADJUST,  "AD9389CircuitStateAdjust",
            OPTV_INTEGER,   {0}, FALSE},
    {DRM_OPTION_HDMI_LEFT_BORDER,                  "LeftBorder",
            OPTV_INTEGER,   {0}, FALSE},
    {DRM_OPTION_HDMI_RIGHT_BORDER,                 "RightBorder",
            OPTV_INTEGER,   {0}, FALSE},
    {DRM_OPTION_HDMI_TOP_BORDER,                   "TopBorder",
            OPTV_INTEGER,   {0}, FALSE},
    {DRM_OPTION_HDMI_BOTTOM_BORDER,                "BottomBorder",
            OPTV_INTEGER,   {0}, FALSE},
    {DRM_OPTION_HDMI_DISABLE_AUDIO,             "DisableAudio",
            OPTV_BOOLEAN,   {0}, FALSE},
    {-1,                                           NULL,
            OPTV_NONE,      {0}, FALSE}
};

static OptionInfoRec via_dp_options[] =
{
    {DRM_OPTION_DP_NoDDCValue, "NoDDCValue",   OPTV_BOOLEAN,   {0}, FALSE},
    {DRM_OPTION_DP_SWLinkTraining, "Swlinktraining" ,   OPTV_BOOLEAN,   {0}, FALSE},
    {-1,                       NULL,           OPTV_NONE,      {0}, FALSE}
};

static OptionInfoRec via_tv_options[] =
{
	{DRM_OPTION_TV_STANDARD, "Standard",   OPTV_STRING,   {0}, FALSE},
	{DRM_OPTION_TV_SIGNAL, "Signal",   OPTV_STRING,   {0}, FALSE},
	{DRM_OPTION_TV_SCAN, "Scan",   OPTV_STRING,   {0}, FALSE},
	{DRM_OPTION_TV_DEDOTCRAWL, "DeDotCrawl",   OPTV_BOOLEAN,   {0}, FALSE},
	{DRM_OPTION_TV_CLOCK_POLARITY, "ClockPolarity",   OPTV_INTEGER,   {0}, FALSE},
	{DRM_OPTION_TV_CLOCK_ADJUST, "ClockAdjust",   OPTV_INTEGER,   {0}, FALSE},
	{DRM_OPTION_TV_CLOCK_DRIVING_SELECTION, "ClockDrivingSelection",   OPTV_INTEGER,   {0}, FALSE},
	{DRM_OPTION_TV_DATA_DRIVING_SELECTION, "DataDrivingSelection",   OPTV_INTEGER,   {0}, FALSE},
	{DRM_OPTION_TV_VT162x_DPA, "TVEncoderDPA",   OPTV_INTEGER,   {0}, FALSE},
    {-1,                   NULL,           OPTV_NONE,      {0}, FALSE}
};
void drmmode_output_create_resources(xf86OutputPtr output);

static PixmapPtr
drmmode_create_bo_pixmap(ScreenPtr pScreen,
            int width, int height,
            int depth, int bpp,
            int pitch, struct generic_bo *bo)
{
    PixmapPtr pixmap;

    pixmap = (*pScreen->CreatePixmap)(pScreen, 0, 0, depth, 0);
    if (!pixmap)
        return NULL;

    if (!(*pScreen->ModifyPixmapHeader)(pixmap, width, height,
        depth, bpp, pitch, NULL)) {
        return NULL;
    }

    via_set_pixmap_bo(pixmap, bo);

    return pixmap;
}

static void
drmmode_destroy_bo_pixmap(PixmapPtr pixmap)
{
    ScreenPtr pScreen = pixmap->drawable.pScreen;

    (*pScreen->DestroyPixmap)(pixmap);
}

static void
drmmode_ConvertFromKMode(ScrnInfoPtr    scrn,
        drmModeModeInfo *kmode,
        DisplayModePtr    mode)
{
    memset(mode, 0, sizeof(DisplayModeRec));
    mode->status = MODE_OK;

    mode->Clock = kmode->clock;

    mode->HDisplay = kmode->hdisplay;
    mode->HSyncStart = kmode->hsync_start;
    mode->HSyncEnd = kmode->hsync_end;
    mode->HTotal = kmode->htotal;
    mode->HSkew = kmode->hskew;

    mode->VDisplay = kmode->vdisplay;
    mode->VSyncStart = kmode->vsync_start;
    mode->VSyncEnd = kmode->vsync_end;
    mode->VTotal = kmode->vtotal;
    mode->VScan = kmode->vscan;

    mode->Flags = kmode->flags; //& FLAG_BITS;
    //convert kmode name to xf86 mode name 
    xf86SetModeDefaultName(mode);
    //mode->name = strdup(kmode->name);
    if (kmode->type & DRM_MODE_TYPE_DRIVER)
        mode->type = M_T_DRIVER;
    if (kmode->type & DRM_MODE_TYPE_PREFERRED)
        mode->type |= M_T_PREFERRED;
    xf86SetModeCrtc (mode, scrn->adjustFlags);
}

static void
drmmode_ConvertToKMode(ScrnInfoPtr  scrn,
                drmModeModeInfo *kmode,
                DisplayModePtr  mode)
{
    memset(kmode, 0, sizeof(*kmode));

    kmode->clock = mode->Clock;
    kmode->hdisplay = mode->HDisplay;
    kmode->hsync_start = mode->HSyncStart;
    kmode->hsync_end = mode->HSyncEnd;
    kmode->htotal = mode->HTotal;
    kmode->hskew = mode->HSkew;

    kmode->vdisplay = mode->VDisplay;
    kmode->vsync_start = mode->VSyncStart;
    kmode->vsync_end = mode->VSyncEnd;
    kmode->vtotal = mode->VTotal;
    kmode->vscan = mode->VScan;

    kmode->flags = mode->Flags; //& FLAG_BITS;
	kmode->type = mode->type; /* TYPE_BITS */
    if (mode->name)
        strncpy(kmode->name, mode->name, DRM_DISPLAY_MODE_LEN);
    kmode->name[DRM_DISPLAY_MODE_LEN - 1] = 0;

}
static void
drmmode_crtc_dpms(xf86CrtcPtr crtc, int mode)
{
    drmmode_crtc_private_ptr drmmode_crtc = crtc->driver_private;
    ScrnInfoPtr pScrn = crtc->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    struct drm_crtc_dpms_info crtc_dpms_info;
    int ret;

    if ( !crtc->enabled ) {
        /* if crtc disabled, do dpms off */
        if ( mode == DPMSModeOff ) {
            memset(&crtc_dpms_info, 0, sizeof(crtc_dpms_info));
            crtc_dpms_info.crtc_id = drmmode_crtc->mode_crtc->crtc_id;
            ret = drmCommandWriteRead(pVia->drmFD,
                        DRM_VIA_CHROME9_CRTC_DPMS, 
                        &crtc_dpms_info, sizeof(crtc_dpms_info));
            if (ret) {
                xf86DrvMsg(crtc->scrn->scrnIndex, X_ERROR,
                    "failed to set disabled crtc dpms off: %s", strerror(-ret));
                return;
            }
        }
    }
}

static Bool
drmmode_set_mode_major(xf86CrtcPtr crtc, DisplayModePtr mode,
        Rotation rotation, int x, int y)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    xf86CrtcConfigPtr   xf86_config = XF86_CRTC_CONFIG_PTR(crtc->scrn);
    drmmode_crtc_private_ptr drmmode_crtc = crtc->driver_private;
    drmmode_ptr drmmode = drmmode_crtc->drmmode;
    int saved_x, saved_y;
    Rotation saved_rotation;
    DisplayModeRec saved_mode;
    uint32_t *output_ids;
    int output_count = 0;
    Bool ret = TRUE;
    int i;
    int fb_id;
    drmModeModeInfo kmode;
    int pitch = pScrn->displayWidth * (pScrn->bitsPerPixel >> 3);

    pitch = CMDISP_ALIGN_TO(pitch, 32);
    if (drmmode->fb_id == 0) {
        ret = drmModeAddFB(drmmode->fd,
            pScrn->virtualX, pScrn->virtualY,
            pScrn->depth, pScrn->bitsPerPixel,
            pitch,
            ((struct via_bo *)(pVia->front_bo))->handle,
            &drmmode->fb_id);
        if (ret < 0) {
            ErrorF("failed to add fb\n");
            return FALSE;
        }
    }

    saved_mode = crtc->mode;
    saved_x = crtc->x;
    saved_y = crtc->y;
    saved_rotation = crtc->rotation;

    if (mode) {
        crtc->mode = *mode;
        crtc->x = x;
        crtc->y = y;
        crtc->rotation = rotation;
    }

    output_ids = calloc(sizeof(uint32_t), xf86_config->num_output);
    if (!output_ids) {
        ret = FALSE;
        goto done;
    }

    if (mode) {
        for (i = 0; i < xf86_config->num_output; i++) {
            xf86OutputPtr output = xf86_config->output[i];
            drmmode_output_private_ptr drmmode_output;

            if (output->crtc != crtc)
                continue;

            drmmode_output = output->driver_private;
            output_ids[output_count] =
                drmmode_output->mode_output->connector_id;
            output_count++;
        }

        if (!xf86CrtcRotate(crtc)) {
            goto done;
        }
#if XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1, 7, 0, 0, 0)
        crtc->funcs->gamma_set(crtc, crtc->gamma_red, crtc->gamma_green,
            crtc->gamma_blue, crtc->gamma_size);
#endif

        drmmode_ConvertToKMode(crtc->scrn, &kmode, mode);

        fb_id = drmmode->fb_id;
        if (drmmode_crtc->rotate_fb_id) {
            fb_id = drmmode_crtc->rotate_fb_id;
            x = y = 0;
        }
        ret = drmModeSetCrtc(drmmode->fd, drmmode_crtc->mode_crtc->crtc_id,
            fb_id, x, y, output_ids, output_count, &kmode);
        if (ret)
            xf86DrvMsg(crtc->scrn->scrnIndex, X_ERROR,
                "failed to set mode: %s", strerror(-ret));
        else
            ret = TRUE;

        /* go through all the outputs and force DPMS them back on? */
        for (i = 0; i < xf86_config->num_output; i++) {
            xf86OutputPtr output = xf86_config->output[i];
            drmmode_output_private_ptr drmmode_output;

            if (output->crtc != crtc)
                continue;
            drmmode_output = output->driver_private;
            if (!strcmp(output->name, "TV-1")) {
                drmModeConnectorPtr koutput = NULL;
                koutput = drmModeGetConnector(drmmode->fd, drmmode_output->mode_output->connector_id);
                if (koutput) {					
                    if (output->randr_output) {
						RRPropertyPtr prop, next;
						const char *prop_name;
						for (prop = output->randr_output->properties; prop; prop = next) {
							next = prop->next;
							prop_name = NameForAtom(prop->propertyName);
							if (!strcmp(prop_name, "DPMS") || !strcmp(prop_name, "EDID")) {
								continue;
							} else {
								if (prop->valid_values) {
									/* this patch is to fix xorg-server-1.7.6 issue.
									 The prop->valid_value was free twice in xorg-server-1.7.6, 
									 which will cause segment fault */
									free (prop->valid_values);
									prop->valid_values = NULL;
								}
								RRDeleteOutputProperty(output->randr_output, prop->propertyName);
							}
						}
                    }
                    drmModeFreeConnector(drmmode_output->mode_output);
                    drmmode_output->mode_output = koutput;
                    drmmode_output_create_resources(output);					
					RRPostPendingProperties (output->randr_output);
                } else {
                    DBG_DD(("TV koutput get fail, pay attation here!!!\n"));
                }
            }
            output->funcs->dpms(output, DPMSModeOn);
        }
    }

    if (pScrn->pScreen && (!pVia->ForceSWCursor))
        xf86_reload_cursors(pScrn->pScreen);

    done:
    if (!ret) {
        crtc->x = saved_x;
        crtc->y = saved_y;
        crtc->rotation = saved_rotation;
        crtc->mode = saved_mode;
    }

    return ret;
}

void
drmmode_set_cursor(ScrnInfoPtr scrn, int id, struct generic_bo *bo)
{
    xf86CrtcConfigPtr   xf86_config = XF86_CRTC_CONFIG_PTR(scrn);
    xf86CrtcPtr crtc = xf86_config->crtc[id];
    drmmode_crtc_private_ptr drmmode_crtc = crtc->driver_private;

    drmmode_crtc->cursor = bo;
}

static void
drmmode_set_cursor_colors (xf86CrtcPtr crtc, int bg, int fg)
{

}

static void
drmmode_set_cursor_position (xf86CrtcPtr crtc, int x, int y)
{
    drmmode_crtc_private_ptr drmmode_crtc = crtc->driver_private;
    drmmode_ptr drmmode = drmmode_crtc->drmmode;

    drmModeMoveCursor(drmmode->fd, drmmode_crtc->mode_crtc->crtc_id, x, y);
}

static void
drmmode_load_cursor_argb (xf86CrtcPtr crtc, CARD32 *image)
{
    drmmode_crtc_private_ptr drmmode_crtc = crtc->driver_private;
    void *ptr;

    ptr = drmmode_crtc->cursor->virtual;
    memcpy (ptr, image, 64 * 64 * 4);
}

static void
drmmode_hide_cursor (xf86CrtcPtr crtc)
{
    drmmode_crtc_private_ptr drmmode_crtc = crtc->driver_private;
    drmmode_ptr drmmode = drmmode_crtc->drmmode;

    drmModeSetCursor(drmmode->fd, drmmode_crtc->mode_crtc->crtc_id, 0, 64, 64);
}

static void
drmmode_show_cursor (xf86CrtcPtr crtc)
{
    drmmode_crtc_private_ptr drmmode_crtc = crtc->driver_private;
    drmmode_ptr drmmode = drmmode_crtc->drmmode;
    uint32_t handle = ((struct via_bo *)drmmode_crtc->cursor)->handle;

    drmModeSetCursor(drmmode->fd,
        drmmode_crtc->mode_crtc->crtc_id, handle, 64, 64);
}

static void *
drmmode_crtc_shadow_allocate(xf86CrtcPtr crtc, int width, int height)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    drmmode_crtc_private_ptr drmmode_crtc = crtc->driver_private;
    drmmode_ptr drmmode = drmmode_crtc->drmmode;
    int size, rotate_pitch, ret;

    size = CMDISP_ALIGN_TO(height * CMDISP_ALIGN_TO(width * drmmode->cpp, 32),
                256);
    rotate_pitch = CMDISP_ALIGN_TO(width * drmmode->cpp, 16);

    drmmode_crtc->rotate_bo = dri_bo_alloc(pVia->bufmgr, "rotate", size,
               0, VIA_CHROME9_GEM_DOMAIN_VRAM | VIA_CHROME9_GEM_FLAG_NO_EVICT);
    if (dri_bo_map(drmmode_crtc->rotate_bo, 0)) {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "can not mmap the rotate bo \n");
        return NULL;
    }

    memset(drmmode_crtc->rotate_bo->virtual, '\0', size);
    ret = drmModeAddFB(drmmode->fd, width, height, crtc->scrn->depth,
        crtc->scrn->bitsPerPixel, rotate_pitch,
        ((struct via_bo *)drmmode_crtc->rotate_bo)->handle,
        &drmmode_crtc->rotate_fb_id);
    if (ret) {
        ErrorF("failed to add the rotate fb\n");
        dri_bo_unreference(drmmode_crtc->rotate_bo);
        return NULL;
    }

    return drmmode_crtc->rotate_bo->virtual;
}

static PixmapPtr
drmmode_crtc_shadow_create(xf86CrtcPtr crtc,
        void *data, int width, int height)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    drmmode_crtc_private_ptr drmmode_crtc = crtc->driver_private;
    drmmode_ptr drmmode = drmmode_crtc->drmmode;
    int rotatePitch;
    PixmapPtr rotatePixmap;
#ifdef VIA_HAVE_UXA
    struct via_pixmap *vRotatePix;
#endif

    if (!data) {
        data = drmmode_crtc_shadow_allocate (crtc, width, height);
        if (!data) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "can not allocate shadow bo for rotated \n");
            return NULL;
        }
    }

    rotatePitch = CMDISP_ALIGN_TO(width * drmmode->cpp, 32);
    rotatePixmap = drmmode_create_bo_pixmap(pScrn->pScreen,
        width, height,
        pScrn->depth,
        pScrn->bitsPerPixel,
        rotatePitch, drmmode_crtc->rotate_bo);
    return rotatePixmap;
}

static void
drmmode_crtc_shadow_destroy(xf86CrtcPtr crtc,
        PixmapPtr rotate_pixmap, void *data)
{
    drmmode_crtc_private_ptr drmmode_crtc = crtc->driver_private;
    drmmode_ptr drmmode = drmmode_crtc->drmmode;

    if (rotate_pixmap)
        drmmode_destroy_bo_pixmap(rotate_pixmap);
    if (data) {
        drmModeRmFB(drmmode->fd, drmmode_crtc->rotate_fb_id);
        drmmode_crtc->rotate_fb_id = 0;
        dri_bo_unmap(drmmode_crtc->rotate_bo);
        dri_bo_unreference(drmmode_crtc->rotate_bo);
        drmmode_crtc->rotate_bo = NULL;
    }
}

static void
drmmode_crtc_set_origin(xf86CrtcPtr crtc, int x, int y)
{
   if(crtc->enabled)
   {
   	VIAPtr pVia;    
   	ScrnInfoPtr pScrn = crtc->scrn;
   	pVia = VIAPTR(pScrn);
	//info video 
   	pVia->crtc_info_changed = TRUE;        

        drmmode_set_mode_major(crtc, &crtc->mode,crtc->rotation, x, y);
   }
}


static void
drmmode_crtc_gamma_set(xf86CrtcPtr crtc,
            CARD16 *red, CARD16 *green, CARD16 *blue, int size)
{
    drmmode_crtc_private_ptr drmmode_crtc = crtc->driver_private;
    drmmode_ptr drmmode = drmmode_crtc->drmmode;

    drmModeCrtcSetGamma(drmmode->fd, drmmode_crtc->mode_crtc->crtc_id,
        size, red, green, blue);
}



static const xf86CrtcFuncsRec drmmode_crtc_funcs = {
    .dpms = drmmode_crtc_dpms,
    .set_mode_major = drmmode_set_mode_major,
    .set_cursor_colors = drmmode_set_cursor_colors,
    .set_cursor_position = drmmode_set_cursor_position,
    .show_cursor = drmmode_show_cursor,
    .hide_cursor = drmmode_hide_cursor,
    .load_cursor_argb = drmmode_load_cursor_argb,
    .shadow_create = drmmode_crtc_shadow_create,
    .shadow_allocate = drmmode_crtc_shadow_allocate,
    .shadow_destroy = drmmode_crtc_shadow_destroy,
    .gamma_set = drmmode_crtc_gamma_set,
    .set_origin = drmmode_crtc_set_origin,
    .destroy = NULL,
};

int
drmmode_get_crtc_id(xf86CrtcPtr crtc)
{
    drmmode_crtc_private_ptr drmmode_crtc = crtc->driver_private;
    return drmmode_crtc->hw_id;
}

void
drmmode_crtc_hw_id(xf86CrtcPtr crtc)
{
    drmmode_crtc_private_ptr drmmode_crtc = crtc->driver_private;
    ScrnInfoPtr pScrn = crtc->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    struct drm_get_crtc_id_info crtc_info;
    int ret;

    memset(&crtc_info, 0, sizeof(crtc_info));
    crtc_info.crtc_id = drmmode_crtc->mode_crtc->crtc_id;
    ret = drmCommandWriteRead(pVia->drmFD,
        DRM_VIA_CHROME9_GET_CRTC_ID, &crtc_info, sizeof(crtc_info));
    if (ret) {
        drmmode_crtc->hw_id = -1;
        return;
    }
    drmmode_crtc->hw_id = crtc_info.crtc_hw_id;
}

static void
drmmode_crtc_init(ScrnInfoPtr pScrn, drmmode_ptr drmmode, int num)
{
    xf86CrtcPtr crtc;
    drmmode_crtc_private_ptr drmmode_crtc;

    crtc = xf86CrtcCreate(pScrn, &drmmode_crtc_funcs);
    if (crtc == NULL)
        return;

    drmmode_crtc = xnfcalloc(sizeof(drmmode_crtc_private_rec), 1);
    drmmode_crtc->mode_crtc = drmModeGetCrtc(drmmode->fd,
                                drmmode->mode_res->crtcs[num]);
    drmmode_crtc->drmmode = drmmode;
    crtc->driver_private = drmmode_crtc;
    drmmode_crtc_hw_id(crtc);

    return;
}

static Bool
drmmode_xf86crtc_resize (ScrnInfoPtr scrn, int width, int height)
{
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(scrn);
    drmmode_crtc_private_ptr
        drmmode_crtc = xf86_config->crtc[0]->driver_private;
    drmmode_ptr drmmode = drmmode_crtc->drmmode;
    VIAPtr pVia = VIAPTR(scrn);
    struct generic_bo *old_front = NULL;
    Bool tiled, ret;
    ScreenPtr   screen = screenInfo.screens[scrn->scrnIndex];
    uint32_t    old_fb_id;
    int i, pitch, old_width, old_height, old_pitch;
    int frontSize;
    PixmapPtr ppix;
    struct via_pixmap *vpix;

    if (scrn->virtualX == width && scrn->virtualY == height)
        return TRUE;
    if (pVia->driType == DRI_1) {
        old_width = scrn->virtualX;
        old_height = scrn->virtualY;
        old_pitch = scrn->displayWidth;
        old_fb_id = drmmode->fb_id;
        scrn->virtualX = width;
        scrn->virtualY = height;
        scrn->frameX1 = scrn->virtualX;
        scrn->frameY1 = scrn->virtualY;

        pitch = CMDISP_ALIGN_TO((scrn->displayWidth * scrn->bitsPerPixel >> 3),
            32);
        ret = drmModeAddFB(drmmode->fd, width, height, scrn->depth,
                   scrn->bitsPerPixel, pitch,
                   ((struct via_bo *)pVia->front_bo)->handle,
                   &drmmode->fb_id);
        if (ret < 0) {
            scrn->virtualX = old_width;
            scrn->virtualY = old_height;
            scrn->displayWidth = old_pitch;
            drmmode->fb_id = old_fb_id;
            return FALSE;
        }
        screen->ModifyPixmapHeader(screen->GetScreenPixmap(screen),
                           width, height, -1, -1, pitch, NULL);

        via_set_pixmap_bo(screen->GetScreenPixmap(screen), pVia->front_bo);
        for (i = 0; i < xf86_config->num_crtc; i++) {
            xf86CrtcPtr crtc = xf86_config->crtc[i];

            if (!crtc->enabled)
                continue;

            drmmode_set_mode_major(crtc, &crtc->mode,
                crtc->rotation, crtc->x, crtc->y);
        }
        return TRUE;
    }

    old_width = scrn->virtualX;
    old_height = scrn->virtualY;
    old_pitch = scrn->displayWidth;
    old_fb_id = drmmode->fb_id;
    old_front = pVia->front_bo;

    scrn->virtualX = width;
    scrn->virtualY = height;
    scrn->frameX1 = scrn->virtualX;
    scrn->frameY1 = scrn->virtualY;
    scrn->displayWidth = width;

    pitch = CMDISP_ALIGN_TO((scrn->displayWidth * scrn->bitsPerPixel >> 3), 32);
    frontSize = pitch * scrn->virtualY;

    pVia->front_bo = dri_bo_alloc(pVia->bufmgr, "front_bo", frontSize,
        0, VIA_CHROME9_GEM_DOMAIN_VRAM | VIA_CHROME9_GEM_FLAG_NO_EVICT);
    if (!pVia->front_bo)
        goto fail;

    if (dri_bo_map(pVia->front_bo, 0)) {
        xf86DrvMsg(scrn->scrnIndex, X_INFO, "can not mmap the front bo \n");
        goto fail;
    }
    memset(pVia->front_bo->virtual, '\0', frontSize);
    dri_bo_unmap(pVia->front_bo);

    ret = drmModeAddFB(drmmode->fd, width, height, scrn->depth,
        scrn->bitsPerPixel, pitch,
        ((struct via_bo *)pVia->front_bo)->handle,
        &drmmode->fb_id);
    if (ret)
        goto fail;

    screen->ModifyPixmapHeader(screen->GetScreenPixmap(screen),
        width, height, -1, -1, pitch, NULL);

    via_set_pixmap_bo(screen->GetScreenPixmap(screen), pVia->front_bo);	
    if (old_fb_id)
        drmModeRmFB(drmmode->fd, old_fb_id);
    if (old_front)
        dri_bo_unreference(old_front);
    for (i = 0; i < xf86_config->num_crtc; i++) {
        xf86CrtcPtr crtc = xf86_config->crtc[i];

        if (!crtc->enabled)
            continue;

        drmmode_set_mode_major(crtc, &crtc->mode,
            crtc->rotation, crtc->x, crtc->y);
    }

    return TRUE;

    fail:
    if (pVia->front_bo)
        dri_bo_unreference(pVia->front_bo);
    pVia->front_bo = old_front;
    scrn->virtualX = old_width;
    scrn->virtualY = old_height;
    scrn->displayWidth = old_pitch;
    drmmode->fb_id = old_fb_id;

    return FALSE;
}

static const xf86CrtcConfigFuncsRec drmmode_xf86crtc_config_funcs = {
    drmmode_xf86crtc_resize
};

static void
via_xf86_crtc_notify(ScreenPtr pScreen)
{
    VIAPtr          pVia;
    int num = pScreen->myNum;
    ScrnInfoPtr pScrn = xf86Screens[num];
    pVia = VIAPTR(pScrn);
    pVia->crtc_info_changed = TRUE;
    DBG_DD((" enter %s \n", __func__));
}

static void
drmmode_output_dpms_backlight(xf86OutputPtr output, int oldmode, int mode)
{
}

static void
drmmode_output_dpms(xf86OutputPtr output, int mode)
{
    drmmode_output_private_ptr drmmode_output = output->driver_private;
    drmModeConnectorPtr koutput = drmmode_output->mode_output;
    drmmode_ptr drmmode = drmmode_output->drmmode;

    drmModeConnectorSetProperty(drmmode->fd, koutput->connector_id,
        drmmode_output->dpms_enum_id, mode);

    return;
}

static Bool
drmmode_property_ignore(drmModePropertyPtr prop)
{
    if (!prop)
        return TRUE;

    if (prop->flags & DRM_MODE_PROP_BLOB)
        return TRUE;

    if (!strcmp(prop->name, "EDID") ||
        !strcmp(prop->name, "DPMS"))
        return TRUE;

    return FALSE;
}

#define CHIPID_NAME "ChipId"
static Atom chipid_atom;

#define CLOCKS_NAME "Clocks"
static Atom clocks_atom;

#define     VIAGETBIOSVER          0x02
#define     VIAGETBIOSDATE         0x01
#define BIOSINFO_NAME "BiosInfo"
static Atom biosinfo_atom;

static void
createChipIDProperty(xf86OutputPtr output)
{
   //CARD32 ChiD;
   ScrnInfoPtr pScrn = output->scrn;
   DEBUG(xf86DRVMsg(pscrn->scrnIndex,X_INFO,"VIA_UI_BIOS_GetChipID\n"));
   VIAPtr pVia = VIAPTR(pScrn);
   //ChiD = pVia->ChipId;

   chipid_atom = MakeAtom(CHIPID_NAME,sizeof(CHIPID_NAME)- 1,TRUE);
   RRConfigureOutputProperty(output->randr_output,chipid_atom,
                                TRUE,FALSE,FALSE,1,(INT32 *)&pVia->ChipId);

   RRChangeOutputProperty(output->randr_output,chipid_atom,
                        XA_INTEGER,32,PropModeReplace,1,
                        &pVia->ChipId,FALSE,TRUE);

   return;
}

static void
createClocksProperty(xf86OutputPtr output)
{
    drmmode_output_private_ptr drmmode_output = output->driver_private;
    struct drm_via_chrome9_clocks  via_clocks;
    unsigned int     clocks[3] = {0};    
    int ret = 0;

    clocks_atom = MakeAtom(CLOCKS_NAME, sizeof(CLOCKS_NAME) - 1, TRUE);

    memset(&via_clocks,0,sizeof(struct drm_via_chrome9_clocks));
    ret = drmCommandWriteRead(drmmode_output->drmmode->fd,
           					DRM_VIA_CHROME9_GET_CLOCKS,			
           					&via_clocks,			
           					sizeof(struct drm_via_chrome9_clocks));			

    //Store as MHz
    clocks[0] = (via_clocks.eng_clock   + 500000)/1000000;
    clocks[1] = (via_clocks.gpu_clock   + 500000)/1000000;
    clocks[2] = (via_clocks.mem_clock + 500000)/1000000;
	
    RRConfigureOutputProperty(output->randr_output, clocks_atom,
                              TRUE, FALSE, FALSE,
                              3, (INT32 *)clocks);

    RRChangeOutputProperty(output->randr_output, clocks_atom,
                           XA_INTEGER, 32, PropModeReplace, 3,
                           clocks, FALSE, TRUE);

    return;

}

static void
createBiosInfoProperty(xf86OutputPtr output)
{
  ScrnInfoPtr pScrn = output->scrn;
  unsigned int bios_info[6]={0};
  VIAPtr pVia = VIAPTR(pScrn);
  VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
  DEBUG(xf86DrvMsg(pScrn->scrnIndex,X_INFO,"VIA_UIBIOS_GetVersion\n"));
  VIAGetBIOSInfoFromROM(pVia,VIAGETBIOSVER);
  DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, 
          "VIA_UT_BIOS_GetVideoMemSizeMB\n"));
  bios_info[0] = pVia->pChipInfo->biosVerMajorNum;
  bios_info[1] = pVia->pChipInfo->biosVerMinorNum;
  DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, 
          "VIA_UT_BIOS_Getbiosdate\n"));
  VIAGetBIOSInfoFromROM(pVia,VIAGETBIOSDATE);
  bios_info[2] = pVia->pChipInfo->biosDateYear;
  bios_info[3] = pVia->pChipInfo->biosDateMonth;
  bios_info[4] = pVia->pChipInfo->biosDateDay;
  DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, 
          "VIA_UT_BIOS_GetVideoMemSizeMB\n"));
  bios_info[5] = pScrn->videoRam >> 10;
  biosinfo_atom = MakeAtom(BIOSINFO_NAME, sizeof(BIOSINFO_NAME) - 1, TRUE);
    
  RRConfigureOutputProperty(output->randr_output, biosinfo_atom,
                    TRUE, FALSE, FALSE,
                    6, (INT32 *)bios_info);

  RRChangeOutputProperty(output->randr_output, biosinfo_atom,
                    XA_INTEGER, 32, PropModeReplace, 6,
                    bios_info,FALSE, TRUE);

    return;
}

static void
getTVProperty(xf86OutputPtr output)
{
    drmmode_output_private_ptr drmmode_output = output->driver_private;
    struct drm_via_chrome9_tv_type  tv_configure;
    int ret = 0;

    memset(&tv_configure,0,sizeof(struct drm_via_chrome9_tv_type));
    ret = drmCommandWriteRead(drmmode_output->drmmode->fd,
           					DRM_VIA_CHROME9_GET_TV_CONFIGURE,			
           					&tv_configure,			
           					sizeof(struct drm_via_chrome9_tv_type));		
    
    xf86DrvMsg(output->scrn->scrnIndex, X_INFO,
            "tv_configure.hdtv_enabled = %d\n",
            tv_configure.hdtv_enabled);

    return;

}


void
drmmode_output_create_resources(xf86OutputPtr output)
{
    drmmode_output_private_ptr drmmode_output = output->driver_private;
    drmModeConnectorPtr mode_output = drmmode_output->mode_output;
    drmmode_ptr drmmode = drmmode_output->drmmode;
    drmModePropertyPtr drmmode_prop;
    int i, j, err;

    drmmode_output->props =
        calloc(mode_output->count_props, sizeof(drmmode_prop_rec));
    if (!drmmode_output->props)
        return;

    drmmode_output->num_props = 0;
    for (i = 0, j = 0; i < mode_output->count_props; i++) {
        drmmode_prop = drmModeGetProperty(drmmode->fd, mode_output->props[i]);
        if (drmmode_property_ignore(drmmode_prop)) {
            drmModeFreeProperty(drmmode_prop);
            continue;
        }
        drmmode_output->props[j].mode_prop = drmmode_prop;
        drmmode_output->props[j].value = mode_output->prop_values[i];
        drmmode_output->num_props ++;
        j++;
    }

    for (i = 0; i < drmmode_output->num_props; i++) {
        drmmode_prop_ptr p = &drmmode_output->props[i];
        drmmode_prop = p->mode_prop;

        if (drmmode_prop->flags & DRM_MODE_PROP_RANGE) {
            INT32 range[2];
            INT32 value = p->value;

            p->num_atoms = 1;
            p->atoms = calloc(p->num_atoms, sizeof(Atom));
            if (!p->atoms)
                continue;
            p->atoms[0] = MakeAtom(drmmode_prop->name,
                strlen(drmmode_prop->name), TRUE);
            range[0] = drmmode_prop->values[0];
            range[1] = drmmode_prop->values[1];
            err = RRConfigureOutputProperty(output->randr_output,
                p->atoms[0], FALSE, TRUE,
                drmmode_prop->flags & DRM_MODE_PROP_IMMUTABLE ? TRUE : FALSE,
                2, range);
            if (err != 0) {
                xf86DrvMsg(output->scrn->scrnIndex, X_ERROR,
                    "RRConfigureOutputProperty error, %d\n", err);
            }
            err = RRChangeOutputProperty(output->randr_output, p->atoms[0],
                XA_INTEGER, 32, PropModeReplace, 1, &value, FALSE, TRUE);
            if (err != 0 ) {
                xf86DrvMsg(output->scrn->scrnIndex, X_ERROR,
                    "RRChangeOutputProperty error, %d\n", err);
            }
        } else if (drmmode_prop->flags & DRM_MODE_PROP_ENUM) {
            p->num_atoms = drmmode_prop->count_enums + 1;
            p->atoms = calloc(p->num_atoms, sizeof(Atom));
            if (!p->atoms)
                continue;
            p->atoms[0] = MakeAtom(drmmode_prop->name,
                strlen(drmmode_prop->name), TRUE);
            for (j = 0; j < drmmode_prop->count_enums; j ++) {
                struct drm_mode_property_enum *e = &drmmode_prop->enums[j];
                p->atoms[j+1] = MakeAtom(e->name, strlen(e->name), TRUE);
            }

            err = RRConfigureOutputProperty(output->randr_output,
                p->atoms[0], drmmode_prop->flags & DRM_MODE_PROP_PENDING ? TRUE : FALSE, FALSE,
                drmmode_prop->flags & DRM_MODE_PROP_IMMUTABLE ? TRUE : FALSE,
                drmmode_prop->count_enums, (INT32 *)&p->atoms[1]);
            if (err != 0) {
                xf86DrvMsg(output->scrn->scrnIndex, X_ERROR,
                    "RRConfigureOutputProperty error, %d\n", err);
            }

            for (j = 0; j < drmmode_prop->count_enums; j ++)
                if (drmmode_prop->enums[j].value == p->value)
                    break;
            err = RRChangeOutputProperty(output->randr_output, p->atoms[0],
                XA_ATOM, 32, PropModeReplace, 1, &p->atoms[j + 1], FALSE, TRUE);
            if (err != 0 ) {
                xf86DrvMsg(output->scrn->scrnIndex, X_ERROR,
                    "RRChangeOutputProperty error, %d\n", err);
            }
        }
    }
    createBiosInfoProperty(output);
    createClocksProperty(output);
    createChipIDProperty(output);
}

static Bool
drmmode_output_set_property(xf86OutputPtr output,
        Atom property,
        RRPropertyValuePtr value)
{
    drmmode_output_private_ptr drmmode_output = output->driver_private;
    drmmode_ptr drmmode = drmmode_output->drmmode;
    int i;

    for (i = 0; i < drmmode_output->num_props; i ++) {
        drmmode_prop_ptr p = &drmmode_output->props[i];

        if (p->atoms[0] != property)
            continue;

        if (p->mode_prop->flags & DRM_MODE_PROP_RANGE) {
            uint32_t val;

            if (value->type != XA_INTEGER || value->format != 32
                || value->size != 1)
                return FALSE;

            val = *(uint32_t *)value->data;
            drmModeConnectorSetProperty(drmmode->fd, drmmode_output->output_id,
                p->mode_prop->prop_id, (uint64_t) val);
            return TRUE;
        } else if (p->mode_prop->flags & DRM_MODE_PROP_ENUM) {
            Atom atom;
            const char *name;
            int j;

            if (value->type != XA_ATOM || value->format != 32 ||
                value->size != 1)
                return FALSE;

            memcpy(&atom, value->data, 4);
            name = NameForAtom(atom);

            for (j = 0; j < p->mode_prop->count_enums; j ++) {
                if (!strcmp(p->mode_prop->enums[j].name, name)) {
                    drmModeConnectorSetProperty(drmmode->fd,
                        drmmode_output->output_id, p->mode_prop->prop_id,
                        p->mode_prop->enums[j].value);
                    return TRUE;
                }
            }
        }
    }
    return TRUE;
}

static Bool
drmmode_output_get_property(xf86OutputPtr output, Atom property)
{
    return TRUE;
}

static xf86OutputStatus
drmmode_output_detect(xf86OutputPtr output)
{
    /* go to the hw and retrieve a new output struct */
    drmmode_output_private_ptr drmmode_output = output->driver_private;
    drmmode_ptr drmmode = drmmode_output->drmmode;
    drmModeConnectorPtr koutput = drmmode_output->mode_output;
    ScrnInfoPtr scrn = output->scrn;
    VIAPtr pVia = VIAPTR(scrn);
    xf86OutputStatus status;

    if (pVia->IsHpd) {
        drmModeFreeConnector(drmmode_output->mode_output);
        drmmode_output->mode_output =
            drmModeGetConnector(drmmode->fd, drmmode_output->output_id);
    }

    switch (drmmode_output->mode_output->connection) {
    case DRM_MODE_CONNECTED:
        status = XF86OutputStatusConnected;
        break;
    case DRM_MODE_DISCONNECTED:
        status = XF86OutputStatusDisconnected;
        break;
    default:
    case DRM_MODE_UNKNOWNCONNECTION:
        status = XF86OutputStatusUnknown;
        break;
    }
    return status;
}

static void
drmmode_get_monitor_physical_size(xf86MonPtr edidMon, 
        int *phyW, int *phyH)
{
    int width = 0, height = 0, i = 0;

    /* established timing */
    if (edidMon->timings1.t1 & 0xD0) {
        width = 720;
        height = 400;
    }
    if (edidMon->timings1.t1 & 0x3D) {
        width = 640;
        height = 480;
    }
    if (edidMon->timings1.t1 & 0x03) {
        width = 800;
        height = 600;
    }
    if (edidMon->timings1.t2 & 0xD0) {
        width = 800;
        height = 600;
    }
    if (edidMon->timings1.t2 & 0x20) {
        width = 832;
        height = 624;
    }
    if (edidMon->timings1.t2 & 0x1E) {
        width = 1024;
        height = 768;
    }
    if (edidMon->timings1.t2 & 0x01) {
        width = 1280;
        height = 1024;
    }

    /* standard timing */    
    for (i = 0; i < STD_TIMINGS; i++) {
        if (edidMon->timings2[i].hsize > width)
            width = edidMon->timings2[i].hsize;
        if (edidMon->timings2[i].vsize > height)
            height = edidMon->timings2[i].vsize;           
    }      

    /* detail timing */
    for (i = 0; i < DET_TIMINGS; i++) {
        if (edidMon->det_mon[i].type == DT) {
            if (edidMon->det_mon[i].section.d_timings.h_active > width)
                width = edidMon->det_mon[i].section.d_timings.h_active;
            if (edidMon->det_mon[i].section.d_timings.v_active > height)
                height = edidMon->det_mon[i].section.d_timings.v_active;  
        }        
    }

    *phyW = width;
    *phyH = height;
}

void
drm_get_lvds_physical_size(xf86OutputPtr output,
            int *width,
            int *height)
{
    char *s = NULL, *b = NULL;
    OptionInfoRec tmp_rec_options[2] = {
        {DRM_OPTION_LCD_PANEL_SIZE, "PanelSize", OPTV_STRING, {0}, FALSE},
        {-1,                         NULL,       OPTV_NONE,   {0}, FALSE}};

    if (output->conf_monitor) {
        xf86ProcessOptions(output->scrn->scrnIndex,
            output->conf_monitor->mon_option_lst, tmp_rec_options);
    }
    /* parse option  "PanelSize" */
    s = xf86GetOptValString(tmp_rec_options, DRM_OPTION_LCD_PANEL_SIZE);
    if (s) {
        b = strdup(s);
        s = strtok(b, "x");
        *width = (int)atoi(s);
        s = strtok(NULL, "x");
        *height = (int)atoi(s);
    }else {
        /*If panel has EDID and there is no "PanelSize" option in xorg.conf*/
        drmmode_output_private_ptr drmmode_output = output->driver_private;
        *width = drmmode_output->physicalWidth;
        *height = drmmode_output->physicalHeigth;
    }
}

static int
drmmode_output_mode_valid(xf86OutputPtr output, DisplayModePtr pModes)
{
	drmmode_output_private_ptr drmmode_output = output->driver_private;
	drmModeConnectorPtr koutput = drmmode_output->mode_output;	
	drmModeModeInfo kmode;
	struct drm_via_chrome9_output_kmode output_kmode;
	int ret = 0;

	if (output->status == XF86OutputStatusDisconnected)
	{
		DBG_DD((" Disconnected device have no valid modes!\n" ));
		return MODE_BAD;
	}
	
	memset(&output_kmode,0,sizeof(struct drm_via_chrome9_output_kmode));
	drmmode_ConvertToKMode(output->scrn, &kmode, pModes);
	output_kmode.connector_id = koutput->connector_id;
	output_kmode.output_kmode = &kmode;
	ret = drmCommandWriteRead(drmmode_output->drmmode->fd,
								DRM_VIA_CHROME9_OUTPUT_MODE_VALID,
								&output_kmode,
								sizeof(struct drm_via_chrome9_output_kmode));
	if (ret) {
		DBG_DD(("Mode valid in kms return error!\n"));
	} else {
		/* DBG_DD(("this mode status is %d\n", output_kmode.mode_status)); */
		return output_kmode.mode_status;
	}
}


static int via_get_customize_timing_info(int fd,
        struct drm_get_customize_timing_info *args_ptr)
{
    int ret;

    ret = drmCommandWriteRead(fd,
                DRM_VIA_CHROME9_GET_CUSTOMIZE_TIMING_INFO,
                args_ptr,
                sizeof(struct drm_get_customize_timing_info));
    if (ret) {
        fprintf(stderr, "error get customize timing info\n");
        return ret;
    }
    return 0;
}

static int via_mode_line_transfer(int fd,
        struct drm_pass_customize_timing args)
{
    int ret;

    ret = drmCommandWriteRead(fd,
                DRM_VIA_CHROME9_PASS_MODE_LINE,
                &args,
                sizeof(args));
    if (ret) {
        fprintf(stderr, "error mode line transfer\n");
        return ret;
    }
    return 0;
}

static CARD8 drmmode_get_check_sum(CARD8 *buf_ptr, CARD32 length)
{
    CARD8    checkSum = 0;
    CARD32   i;

    if (!buf_ptr) {
        return 0xff;
    }
    
    for (i=0; i<length; i++) {
        checkSum += buf_ptr[i];
    }

    return (0xff - checkSum + 1);
}

int via_dump_memory(void *tb, unsigned int len, char *flag)
{
    unsigned char *tb_tmp = (unsigned char *)tb;
    unsigned int i,j;

#define via_dump_func_head(fmt,arg...)    xf86Msg(X_INFO,"DUMP:%s():" fmt,__FUNCTION__, ##arg)
#define via_dump_func(fmt,arg...)    xf86Msg(X_INFO, fmt, ##arg)

    via_dump_func_head("%s Begin len = %d\n", flag, len);
    for(i=0; i<len; ) {
        via_dump_func("tb[%d]~tb[%d] ", i, i+15);
        for(j=0; j<16; j++) {
            via_dump_func("%x ",tb_tmp[i]);
            i++;
            if(i>=len) {
                break;
            }
        }
        via_dump_func("\n");
    }
    via_dump_func_head("%s End\n", flag);
}

static CARD8 num_of_mode_list(DisplayModePtr mode_list)
{
    DisplayModePtr mode_list_tmp = mode_list;
    CARD8 list_num = 0;

    while(mode_list_tmp) {
        list_num++;
        mode_list_tmp = mode_list_tmp->next;
    }
    return list_num;
}

static Bool is_lvds_output(xf86OutputPtr  output)
{
    drmmode_output_private_ptr drmmode_output = output->driver_private;
    drmModeConnectorPtr koutput = drmmode_output->mode_output;

    if (!strcmp(output_names[koutput->connector_type], "LVDS")) {
        return TRUE;
    } else {
        return FALSE;
    }
}

static CARD8 num_of_outputs_mode_line(ScrnInfoPtr scrn)
{
    xf86CrtcConfigPtr   config = XF86_CRTC_CONFIG_PTR(scrn);
    CARD8 o = 0, num = 0, nums = 0;
    /* Probe the list of modes for each output. */
    for (o = 0; o < config->num_output; o++) {
        xf86OutputPtr  output = config->output[o];
        DisplayModePtr config_modes = NULL;
        XF86ConfMonitorPtr  conf_monitor;

        /**
         *  do not need to collect LCD's mode line number here, 
         *  consider it as a mode, not timing. 
         */
        if(TRUE == is_lvds_output(output)) {
            continue;
        }

        conf_monitor = output->conf_monitor;
        config_modes = xf86GetMonitorModes (scrn, conf_monitor);
        num = num_of_mode_list(config_modes);
        xf86DrvMsg(scrn->scrnIndex, X_INFO,
            "output[%u] has %u ModeLines.\n", o, num);
        nums += num;
    }
    return nums;
}

static void *
construct_cust_tm_pkg(CARD8 mlNum, CARD32 *buffLen)
{
    CARD32 custTmBuffLen = 0;
    customize_timing_head_ptr custTmHeadPtr = NULL;
    void *buffTmp = NULL;

    *buffLen = 0;

    custTmBuffLen = mlNum * sizeof(customize_timing_entity_rec) + 
                    sizeof(customize_timing_head_rec);

    buffTmp = (CARD8 *)calloc(1, custTmBuffLen);
    
    if(NULL == buffTmp) {
        return NULL;
    } 

    custTmHeadPtr = (customize_timing_head_ptr)buffTmp;

    custTmHeadPtr->timingNum = mlNum;
    custTmHeadPtr->fileLength = custTmBuffLen;

    *buffLen = custTmBuffLen;

    /* update check sum last. */
    
    return buffTmp;
}


static void * 
update_mode_line_to_cust_tm_pkg(ScrnInfoPtr scrn, 
                CARD8 *custTmBuffPtr,
                uint32_t *custTmAuxInfoLenPtr)
{
    VIAPtr pVia = VIAPTR(scrn);
    xf86CrtcConfigPtr   config = XF86_CRTC_CONFIG_PTR(scrn);
    customize_timing_head_ptr custTmHeadPtr = NULL;
    customize_timing_entity_ptr tmpCustTmTbPtr = NULL, custTmTbHead = NULL;
    CARD8 o = 0, i = 0, num_of_ml= 0;
    void *custTmAuxInfoPtr = NULL;
    uint32_t *tmpCustTmAuxInfoPtr = NULL;
    uint32_t *tmpCustTmAuxInfoHead =NULL;


#define VIA_MAX_OUTPUT_NUM 20


    if( (NULL == custTmAuxInfoLenPtr) || (NULL == custTmBuffPtr)) {
        xf86DrvMsg(scrn->scrnIndex, X_ERROR,
            "NULL Pointer exist!! custTmAuxInfoLenPtr =0x%p, custTmBuffPtr=0x%p \n", 
            custTmAuxInfoLenPtr, custTmBuffPtr);
        return NULL;
    }


    custTmHeadPtr = (customize_timing_head_ptr)custTmBuffPtr;
    if( 0 == custTmHeadPtr->timingNum ) {
        /* There is no mode line need to update to customize timing package.*/
        *custTmAuxInfoLenPtr = 0;
        return NULL;
    }
    custTmTbHead = (customize_timing_entity_ptr)
            (custTmBuffPtr + sizeof(customize_timing_head_rec));
    tmpCustTmTbPtr = custTmTbHead;


    tmpCustTmAuxInfoHead = (uint32_t *)malloc( 2 * VIA_MAX_OUTPUT_NUM * sizeof(uint32_t) );
    if(NULL == tmpCustTmAuxInfoHead) {
        return NULL;
    }
    tmpCustTmAuxInfoPtr = tmpCustTmAuxInfoHead;


    *custTmAuxInfoLenPtr = 0;


    /* Probe the list of config_modes for each output. */
    for (o = 0; o < config->num_output; o++) {
        xf86OutputPtr  output = config->output[o];
        DisplayModePtr config_modes = NULL, config_mode = NULL;
        XF86ConfMonitorPtr  conf_monitor;
        drmmode_output_private_ptr drmmode_output = output->driver_private;
        drmModeConnectorPtr koutput = drmmode_output->mode_output;

        /* do not need to add LCD's mode line to customize timing package. */
        if(TRUE == is_lvds_output(output)) {
            continue;
        }

        conf_monitor = output->conf_monitor;
        config_modes = xf86GetMonitorModes (scrn, conf_monitor);
        config_mode = config_modes;
        num_of_ml = num_of_mode_list(config_modes);

        if(0 == num_of_ml) {
            continue;
        } else {
            /**
             *  customize timing Aux info package contains:
             *      dispDev(4Bytes, m[x][0]) and ModeLineNum(4Bytes, m[x][1]) 
             *      for each ModeLine set output. 
             *  so here if found mode line num is not 0, add 8 to length.
             */
            (*custTmAuxInfoLenPtr) += (2 * sizeof(uint32_t));
            /* record mode lines number to m[x][1], for prepare passing it to kernel. */
            *(tmpCustTmAuxInfoPtr+1) =  num_of_ml;
        }

        for(i = 0; i < num_of_ml; i++) {
            struct drm_get_customize_timing_info cust_tm_info_args;
            int ret = 0;
           
            if( NULL == config_mode ) {
                break;
            }

            cust_tm_info_args.connector_id = koutput->connector_id;
            cust_tm_info_args.pixel_clock = config_mode->Clock * 1000;
            /**
             *  we couldn't get crtc info colorDepth(bpp) from kernel now.
             *  because pick up crtc hasn't done, 
             *  so output->crtc is NULL, 
             *  here fix crtc_id to 0, but kernel driver do not handle it.
             */
            cust_tm_info_args.crtc_id = 0;
            
            /* get dispDev, vPLL value(customize timing package need) from kernel driver. */
            ret = via_get_customize_timing_info(pVia->drmFD, &cust_tm_info_args);
            xf86DrvMsg(output->scrn->scrnIndex, X_INFO, 
                        "output %s, get info from ioctl %s: dispDev = %d, colorDepth = %d, vPLL = %d, \n", 
                        output->name, 
                        (ret == 0) ? "PASS":"FAILED", 
                        cust_tm_info_args.dispDev, 
                        cust_tm_info_args.colorDepth, 
                        cust_tm_info_args.vPLL);

            /* record dispDev to m[x][0], for prepare passing it to kernel. */
            *tmpCustTmAuxInfoPtr =  cust_tm_info_args.dispDev;

            /**
             *  calculate Blank Start and Blank End for cbios  
             *      customize timing from mode line parameters.
             *  we think there is no interlaced mode line! 
             */
            xf86SetModeCrtc(config_mode, 0);

            /* refresh it with value ioctl getting from kernel driver. */
            tmpCustTmTbPtr->dispDev = cust_tm_info_args.dispDev;

            tmpCustTmTbPtr->H_Res = config_mode->HDisplay;
            tmpCustTmTbPtr->V_Res = config_mode->VDisplay;

            /**
             *  CBIOS do not use customize timing info colorDepth now. 
             *  refresh it with value ioctl getting from kernel driver.
             */
            tmpCustTmTbPtr->colorDepth = cust_tm_info_args.colorDepth;

            /* config_mode->VRefresh is 0.0 , so we need to calculate it by ourself. */
            tmpCustTmTbPtr->rRateX100 = 
                        ((( 1000 * config_mode->Clock )  / config_mode->HTotal) * 100) / config_mode->VTotal;

            xf86DrvMsg(output->scrn->scrnIndex, X_INFO, 
                        "output %s, rRateX100 = %d, config_mode->VRefresh = %f\n", 
                        output->name, (int)tmpCustTmTbPtr->rRateX100, config_mode->VRefresh);

            /* refresh it with value ioctl getting from kernel driver. */
            tmpCustTmTbPtr->vPLL = cust_tm_info_args.vPLL;

            tmpCustTmTbPtr->HTotal = config_mode->HTotal;
            tmpCustTmTbPtr->HDisEnd = config_mode->HDisplay;
            tmpCustTmTbPtr->HBlankStart = config_mode->CrtcHBlankStart;
            tmpCustTmTbPtr->HBlankEnd = config_mode->CrtcHBlankEnd;
            tmpCustTmTbPtr->HSyncStart = config_mode->HSyncStart;
            tmpCustTmTbPtr->HSyncEnd = config_mode->HSyncEnd;

            tmpCustTmTbPtr->VTotal = config_mode->VTotal;
            tmpCustTmTbPtr->VDisEnd = config_mode->VDisplay;
            tmpCustTmTbPtr->VBlankStart = config_mode->CrtcVBlankStart;
            tmpCustTmTbPtr->VBlankEnd = config_mode->CrtcVBlankEnd;
            tmpCustTmTbPtr->VSyncStart = config_mode->VSyncStart;
            tmpCustTmTbPtr->VSyncEnd = config_mode->VSyncEnd;

            tmpCustTmTbPtr->HPolarity = (config_mode->Flags & V_PHSYNC) ? CBIOS_POSITIVE : CBIOS_NEGATIVE;
            tmpCustTmTbPtr->VPolarity = (config_mode->Flags & V_PVSYNC) ? CBIOS_POSITIVE : CBIOS_NEGATIVE;
            tmpCustTmTbPtr->Interlaced = (config_mode->Flags & V_INTERLACE) ? CBIOS_INTERLACE : CBIOS_PROGRESSIVE;

            tmpCustTmTbPtr->reserved = 0;

            tmpCustTmTbPtr++;
            
            config_mode = config_mode->next;

        }
        /* if mode line num is not 0, record its' dispDev and modeline num to AuxInfo */
        tmpCustTmAuxInfoPtr += 2;
    }

    custTmAuxInfoPtr = malloc( *custTmAuxInfoLenPtr );

    if(NULL == custTmAuxInfoPtr) {
        goto ret_point;
    }

    memcpy(custTmAuxInfoPtr, tmpCustTmAuxInfoHead, *custTmAuxInfoLenPtr);

    via_dump_memory(custTmAuxInfoPtr, *custTmAuxInfoLenPtr, "ret_devs_mls");

ret_point:
    if(NULL != tmpCustTmAuxInfoHead) {
        free(tmpCustTmAuxInfoHead);
        tmpCustTmAuxInfoPtr =NULL;
        tmpCustTmAuxInfoHead = NULL;
    }
    return custTmAuxInfoPtr;
}


static void
update_check_sum_to_cust_tm_pkg(CARD8 *custTmBuffPtr)
{
    customize_timing_head_ptr custTmHeadPtr = NULL;

    custTmHeadPtr = (customize_timing_head_ptr)custTmBuffPtr;
    
    /* Update check sum byte. */
     custTmHeadPtr->checkSum += 
            drmmode_get_check_sum(custTmBuffPtr, custTmHeadPtr->fileLength);
}

/**
 *  Pass monitor config_mode as customize timing to CBIOS.
 *
 *  Do not need to pass LCD's mode line to CBIOS as customize timing. 
 *  Because we consider LCD's mode line as a mode, not a timing.
 */
static Bool
drmmode_pass_mode_line_to_cbios(ScrnInfoPtr scrn)
{
    VIAPtr pVia = VIAPTR(scrn);
    struct drm_pass_customize_timing args;
    CARD8 *custTmBuffPtr = NULL;
    void *custTmBuffPtrTmp = NULL;
    CARD32 custTmBuffLen = 0;
    CARD8 outputs_ml_num = 0;
    uint32_t cust_tm_aux_info_len = 0xFF;
    void *cust_tm_aux_info_ptr = NULL;
    int ret = 0;

    outputs_ml_num = num_of_outputs_mode_line(scrn);
    if( 0 == outputs_ml_num ) {
        /* if no ModeLine set, we need to clear kernel driver mode line data. */
        xf86DrvMsg(scrn->scrnIndex, X_INFO, "outputs NO ModeLines setting.\n");
    }

    /* malloc memory for customize timing: failed -> return */
    custTmBuffPtrTmp = construct_cust_tm_pkg(outputs_ml_num, &custTmBuffLen);
    if(NULL == custTmBuffPtrTmp) {
        xf86DrvMsg(scrn->scrnIndex, X_ERROR,
            "alloc memory for customize timing failed!!\n");
        return FALSE;
    }
    custTmBuffPtr =(CARD8 *)custTmBuffPtrTmp;

    cust_tm_aux_info_ptr = update_mode_line_to_cust_tm_pkg(scrn, 
                    custTmBuffPtr, &cust_tm_aux_info_len);
    if(NULL == cust_tm_aux_info_ptr) {
        if(0 == cust_tm_aux_info_len) {
            xf86DrvMsg(scrn->scrnIndex, X_INFO, "No outputs No ModeLines setting.\n");
        } else {
            xf86DrvMsg(scrn->scrnIndex, X_ERROR, "May be issue, pls check here.\n");
        }
    }

    update_check_sum_to_cust_tm_pkg(custTmBuffPtr);

    args.ml_pkg = custTmBuffPtrTmp;
    args.pkg_size = custTmBuffLen;
    args.cust_tm_aux_info_len = cust_tm_aux_info_len;
    args.cust_tm_aux_info_ptr = cust_tm_aux_info_ptr;
    via_dump_memory(args.ml_pkg, args.pkg_size, "args.ml_pkg");
    ret = via_mode_line_transfer(pVia->drmFD, args);

    free(custTmBuffPtr);
    custTmBuffPtr = NULL;
    free(cust_tm_aux_info_ptr);
    cust_tm_aux_info_ptr = NULL;

    if (ret) {
        xf86DrvMsg(scrn->scrnIndex, X_ERROR,
            "failed to pass mode line to kernel driver : %s", strerror(-ret));
        return FALSE;
    }

    return TRUE;
}


static DisplayModePtr
drmmode_output_get_modes(xf86OutputPtr output)
{
    drmmode_output_private_ptr drmmode_output = output->driver_private;
    drmModeConnectorPtr koutput = drmmode_output->mode_output;
    drmmode_ptr drmmode = drmmode_output->drmmode;
    int i;
    DisplayModePtr Modes = NULL, Mode;
    drmModePropertyPtr props;
    xf86MonPtr mon = NULL;

    if (output->MonInfo != NULL) {
        free(output->MonInfo);
        output->MonInfo = NULL;
    }

    /* look for an EDID property */
    for (i = 0; i < koutput->count_props; i++) {
        props = drmModeGetProperty(drmmode->fd, koutput->props[i]);
        if (props && (props->flags & DRM_MODE_PROP_BLOB)) {
            if (!strcmp(props->name, "EDID")) {
                if (drmmode_output->edid_blob)
                    drmModeFreePropertyBlob(drmmode_output->edid_blob);

                drmmode_output->edid_blob =
                    drmModeGetPropertyBlob(drmmode->fd, koutput->prop_values[i]);
            }
        }
        drmModeFreeProperty(props);
    }

    if (drmmode_output->edid_blob) {
        mon = xf86InterpretEDID(output->scrn->scrnIndex,
                drmmode_output->edid_blob->data);

        Bool bSupportBasicAudio = FALSE;
        if (mon->ver.revision > 2 && drmmode_output->edid_blob->length > 128){
            mon->flags |= EDID_COMPLETE_RAWDATA;
            bSupportBasicAudio = mon->rawData[128 + 3] & 0x40 ? TRUE : FALSE;
        }

        xf86DrvMsg(output->scrn->scrnIndex, X_INFO,
                "%s %s support basic audio\n", 
                output->name,
                (bSupportBasicAudio == TRUE) ? "does": "doesn't");
        xf86DrvMsg(output->scrn->scrnIndex, X_INFO,
                "== EDID of monitor %s ==\n",
                output->name);
        xf86PrintEDID(mon);

        xf86OutputSetEDID(output, mon);
        
       /* get panel size of DP, DVI, and LCD devices, for validate mode. */
       drmmode_get_monitor_physical_size(mon, 
                                    &(drmmode_output->physicalWidth), 
                                    &(drmmode_output->physicalHeigth));

    } else {
        xf86OutputSetEDID(output,
            xf86InterpretEDID(output->scrn->scrnIndex, NULL));
    }

    if (!output->MonInfo) {
        if (!strncmp(output->name, "LVDS", 4) ||
            !strncmp(output->name, "LCD", 3)) {
            output->MonInfo = calloc (1, sizeof (xf86Monitor));
            if (output->MonInfo) {
                /* defaultly display support continuous-freqencey
                if the parameter is not set, the xorg build in modes will not
                add, then lcd do not have edid, will have only one valid mode */
                output->MonInfo->features.msc |= 0x1;
                /**
                 * Set wide sync ranges so we get all modes
                 * handed to valid_mode for checking
                 */
                output->MonInfo->det_mon[0].type = DS_RANGES;
                output->MonInfo->det_mon[0].section.ranges.min_v = 0;
                output->MonInfo->det_mon[0].section.ranges.max_v = 200;
                output->MonInfo->det_mon[0].section.ranges.min_h = 0;
                output->MonInfo->det_mon[0].section.ranges.max_h = 200;
            }
        }
    }

    /* modes should already be available */
    for (i = 0; i < koutput->count_modes; i++) {
        Mode = xnfalloc(sizeof(DisplayModeRec));
        drmmode_ConvertFromKMode(output->scrn, &koutput->modes[i], Mode);
        Modes = xf86ModesAdd(Modes, Mode);
    }
    return Modes;
}

static void
drmmode_output_destroy(xf86OutputPtr output)
{
}

static int via_xorg_options_transfer(int fd,
        struct drm_via_chrome9_xorg_options args)
{
    int ret;

    ret = drmCommandWriteRead(fd,
                            DRM_VIA_CHROME9_XORG_OPTIONS,
                            &args,
                            sizeof(args));
    if (ret) {
        fprintf(stderr, "error xorg options transfer\n");
        return ret;
    }
    return 0;
}

static int via_kms_helper_set_mode(int fd,
        struct drm_via_chrome9_mode_set_par args)
{
    int ret;

    ret = drmCommandWriteRead(fd,
                            DRM_VIA_CHROME9_HELPER_SET_MODE,
                            &args,
                            sizeof(args));
    if (ret) {
        fprintf(stderr, "error helper set mode\n");
        return ret;
    }
    return 0;
}

static void
drmmode_pre_parse_crt_option(int fd, drmModeConnectorPtr koutput)
{
    via_crt_xorg_options_ptr crt_xorg_options_ptr = NULL;
    struct drm_via_chrome9_xorg_options args;

    crt_xorg_options_ptr =
        (via_crt_xorg_options_ptr)malloc(sizeof(via_crt_xorg_options));
    if (!crt_xorg_options_ptr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memset(crt_xorg_options_ptr, 0, sizeof(via_crt_xorg_options));
    args.connector_id = koutput->connector_id;
    args.xorg_options = (void *)crt_xorg_options_ptr;
    args.options_size = sizeof(via_crt_xorg_options);
    via_xorg_options_transfer(fd, args);

    free(crt_xorg_options_ptr);
}

static void
drmmode_parse_crt_option(int fd,
    xf86OutputPtr output,
    drmModeConnectorPtr koutput)
{
    int value = 0;
    OptionInfoPtr tempRecOptionsPtr;
    via_crt_xorg_options_ptr crt_xorg_options_ptr = NULL;
    struct drm_via_chrome9_xorg_options args;

    crt_xorg_options_ptr =
        (via_crt_xorg_options_ptr)malloc(sizeof(via_crt_xorg_options));
    if (!crt_xorg_options_ptr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    crt_xorg_options_ptr->no_ddc_value = FALSE;
    crt_xorg_options_ptr->is_clk_adjust_used = FALSE;
    crt_xorg_options_ptr->is_clk_driving_sel_used = FALSE;
    crt_xorg_options_ptr->is_clk_polarity_used = FALSE;
    crt_xorg_options_ptr->is_data_driving_sel_used = FALSE;

    tempRecOptionsPtr= (OptionInfoPtr)malloc(sizeof(via_crt_options));
    if (!tempRecOptionsPtr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memcpy(tempRecOptionsPtr, via_crt_options, sizeof(via_crt_options));
    /* if no "CRT" monitor section, all use default settting */
    if (output->conf_monitor) {
        xf86ProcessOptions(output->scrn->scrnIndex,
            output->conf_monitor->mon_option_lst,
            tempRecOptionsPtr);
    }

    /* parse option "NoDDCValue" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr,
        DRM_OPTION_CRT_NoDDCValue, FALSE))
        crt_xorg_options_ptr->no_ddc_value = TRUE;

    /* parse user clock skew setting*/
    /* 1. parse option "ClockPolarity" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_CRT_CLOCK_POLARITY, &value)) {
        crt_xorg_options_ptr->clk_polarity = value & BIT0;
        crt_xorg_options_ptr->is_clk_polarity_used = TRUE;
    }
    /* 2. parse option "ClockAdjust" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_CRT_CLOCK_ADJUST, &value)) {
        crt_xorg_options_ptr->clk_adjust = value;
        crt_xorg_options_ptr->is_clk_adjust_used = TRUE;
    }
    /* 3. parse option "ClockDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_CRT_CLOCK_DRIVING_SELECTION, &value)) {
        crt_xorg_options_ptr->clk_driving_sel = value;
        crt_xorg_options_ptr->is_clk_driving_sel_used = TRUE;
    }
    /* 4. parse option "DataDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_CRT_DATA_DRIVING_SELECTION, &value)) {
        crt_xorg_options_ptr->data_driving_sel = value;
        crt_xorg_options_ptr->is_data_driving_sel_used = TRUE;
    }

    args.connector_id = koutput->connector_id;
    args.xorg_options = (void *)crt_xorg_options_ptr;
    args.options_size = sizeof(via_crt_xorg_options);
    via_xorg_options_transfer(fd, args);

    free(tempRecOptionsPtr);
    free(crt_xorg_options_ptr);
}

static void
drmmode_pre_parse_lcd_option(int fd, drmModeConnectorPtr koutput)
{
    via_lcd_xorg_options_ptr lcd_xorg_options_ptr = NULL;
    struct drm_via_chrome9_xorg_options args;

    lcd_xorg_options_ptr =
        (via_lcd_xorg_options_ptr)malloc(sizeof(via_lcd_xorg_options));
    if (!lcd_xorg_options_ptr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memset(lcd_xorg_options_ptr, 0, sizeof(via_lcd_xorg_options));
    args.connector_id = koutput->connector_id;
    args.xorg_options = (void *)lcd_xorg_options_ptr;
    args.options_size = sizeof(via_lcd_xorg_options);
    via_xorg_options_transfer(fd, args);

    free(lcd_xorg_options_ptr);
}

static void
drmmode_parse_lcd_option(int fd,
            xf86OutputPtr output, drmModeConnectorPtr koutput)
{
    char *s = NULL, *b = NULL;
    unsigned int panel_width = 0, panel_height = 0;
    int value = 0;
    OptionInfoPtr temp_rec_options_ptr;
    via_lcd_xorg_options_ptr lcd_xorg_options_ptr = NULL;
    struct drm_via_chrome9_xorg_options args;

    lcd_xorg_options_ptr =
        (via_lcd_xorg_options_ptr)malloc(sizeof(via_lcd_xorg_options));
    if (!lcd_xorg_options_ptr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    lcd_xorg_options_ptr->panel_index = 0;
    lcd_xorg_options_ptr->physical_height = 0;
    lcd_xorg_options_ptr->physical_width = 0;
    lcd_xorg_options_ptr->dual_channel = FALSE;
    lcd_xorg_options_ptr->msb = FALSE;
    lcd_xorg_options_ptr->no_dithering = FALSE;

    lcd_xorg_options_ptr->center = FALSE;
    lcd_xorg_options_ptr->fix_on_iga1 = FALSE;
    lcd_xorg_options_ptr->is_clk_adjust_used = FALSE;
    lcd_xorg_options_ptr->is_clk_driving_sel_used = FALSE;
    lcd_xorg_options_ptr->is_clk_polarity_used = FALSE;
    lcd_xorg_options_ptr->is_data_driving_sel_used = FALSE;
    lcd_xorg_options_ptr->is_vt_1636_clk_sel_st1_used = FALSE;
    lcd_xorg_options_ptr->is_vt_1636_clk_sel_st2_used = FALSE;

    temp_rec_options_ptr = (OptionInfoPtr)malloc(sizeof(via_lcd_options));
    if (!temp_rec_options_ptr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memcpy(temp_rec_options_ptr, via_lcd_options, sizeof(via_lcd_options));
    /* if no "lcd" monitor section, all use default settting */
    if (output->conf_monitor) {
        xf86ProcessOptions(output->scrn->scrnIndex,
            output->conf_monitor->mon_option_lst,
            temp_rec_options_ptr);
	}
    /* parse option  "PanelSize" */
    s = xf86GetOptValString(temp_rec_options_ptr, DRM_OPTION_LCD_PANEL_SIZE);
    if (s) {
        b = strdup(s);
        s = strtok(b, "x");
        panel_width = (CARD32)atoi(s);
        s = strtok(NULL, "x");
        panel_height = (CARD32)atoi(s);
        lcd_xorg_options_ptr->panel_index = VIA_MAKE_ID(panel_width,
            panel_height);

        /* If 1366x768 panel, we consider it as a 1368x768 panel. */
        if ((panel_width == 1366) && (panel_height == 768)) {
            panel_width = 1368;
        }

        lcd_xorg_options_ptr->physical_height = panel_height;
        lcd_xorg_options_ptr->physical_width = panel_width;
    }

    /* parse option "DualChannel"*/
    if (xf86ReturnOptValBool(temp_rec_options_ptr,
        DRM_OPTION_LCD_DUAL_CHANNEL, FALSE))
        lcd_xorg_options_ptr->dual_channel = TRUE;

    /* parse option "Dithering"*/
    if (xf86ReturnOptValBool(temp_rec_options_ptr,
        DRM_OPTION_LCD_NO_DITHERING, FALSE))
        lcd_xorg_options_ptr->no_dithering = TRUE;

    /* parse option "MSB"*/
    if (xf86ReturnOptValBool(temp_rec_options_ptr,
        DRM_OPTION_LCD_MSB, FALSE))
        lcd_xorg_options_ptr->msb = TRUE;

    /* parse option "Center"*/
    if (xf86ReturnOptValBool(temp_rec_options_ptr,
        DRM_OPTION_LCD_CENTER, FALSE))
        lcd_xorg_options_ptr->center= TRUE;

    /* parse option "FixOnIGA1"*/
    if (xf86ReturnOptValBool(temp_rec_options_ptr,
        DRM_OPTION_LCD_FIXONIGA1, FALSE))
        lcd_xorg_options_ptr->fix_on_iga1 = TRUE;

    /* parse user clock skew setting*/
    /* 1. parse option "ClockPolarity" */
    if (xf86GetOptValInteger(temp_rec_options_ptr,
        DRM_OPTION_LCD_CLOCK_POLARITY, &value)) {
        lcd_xorg_options_ptr->clk_polarity = value & BIT0;
        lcd_xorg_options_ptr->is_clk_polarity_used = TRUE;
    }
    /* 2. parse option "ClockAdjust" */
    if (xf86GetOptValInteger(temp_rec_options_ptr,
        DRM_OPTION_LCD_CLOCK_ADJUST, &value)) {
        lcd_xorg_options_ptr->clk_adjust = value;
        lcd_xorg_options_ptr->is_clk_adjust_used = TRUE;
    }
    /* 3. parse option "ClockDrivingSelection" */
    if (xf86GetOptValInteger(temp_rec_options_ptr,
        DRM_OPTION_LCD_CLOCK_DRIVING_SELECTION, &value)) {
        lcd_xorg_options_ptr->clk_driving_sel = value;
        lcd_xorg_options_ptr->is_clk_driving_sel_used = TRUE;
    }
    /* 4. parse option "DataDrivingSelection" */
    if (xf86GetOptValInteger(temp_rec_options_ptr,
        DRM_OPTION_LCD_DATA_DRIVING_SELECTION, &value)) {
        lcd_xorg_options_ptr->data_driving_sel = value;
        lcd_xorg_options_ptr->is_data_driving_sel_used = TRUE;
    }
    /* 5. parse option "Vt1636ClockSelST1" */
    if (xf86GetOptValInteger(temp_rec_options_ptr,
        DRM_OPTION_LCD_VT1636_CLOCK_SEL_ST1, &value)) {
        lcd_xorg_options_ptr->vt1636_clk_sel_st1 = value;
        lcd_xorg_options_ptr->is_vt_1636_clk_sel_st1_used = TRUE;
    }
    /* 6. parse option "Vt1636ClockSelST2" */
    if (xf86GetOptValInteger(temp_rec_options_ptr,
        DRM_OPTION_LCD_VT1636_CLOCK_SEL_ST2, &value)) {
        lcd_xorg_options_ptr->vt1636_clk_sel_st2 = value;
        lcd_xorg_options_ptr->is_vt_1636_clk_sel_st2_used = TRUE;
    }

    args.connector_id = koutput->connector_id;
    args.xorg_options = (void *)lcd_xorg_options_ptr;
    args.options_size = sizeof(via_lcd_xorg_options);
    via_xorg_options_transfer(fd, args);

    free(temp_rec_options_ptr);
    free(lcd_xorg_options_ptr);
}

static void
drmmode_pre_parse_dvi_option(int fd, drmModeConnectorPtr koutput)
{
    via_dvi_xorg_options_ptr dvi_xorg_options_ptr = NULL;
    struct drm_via_chrome9_xorg_options args;

    dvi_xorg_options_ptr =
        (via_dvi_xorg_options_ptr)malloc(sizeof(via_dvi_xorg_options));
    if (!dvi_xorg_options_ptr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memset(dvi_xorg_options_ptr, 0, sizeof(via_dvi_xorg_options));
    args.connector_id = koutput->connector_id;
    args.xorg_options = (void *)dvi_xorg_options_ptr;
    args.options_size = sizeof(via_dvi_xorg_options);
    via_xorg_options_transfer(fd, args);

    free(dvi_xorg_options_ptr);
}

static void
drmmode_parse_dvi_option(int fd,
        xf86OutputPtr output, drmModeConnectorPtr koutput)
{
    int value = 0;
    OptionInfoPtr tempRecOptionsPtr;
    via_dvi_xorg_options_ptr dvi_xorg_options_ptr = NULL;
    struct drm_via_chrome9_xorg_options args;

    dvi_xorg_options_ptr =
        (via_dvi_xorg_options_ptr)malloc(sizeof(via_dvi_xorg_options));
    if (!dvi_xorg_options_ptr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    dvi_xorg_options_ptr->no_ddc_value = FALSE;
    dvi_xorg_options_ptr->is_clk_adjust_used = FALSE;
    dvi_xorg_options_ptr->is_clk_driving_sel_used = FALSE;
    dvi_xorg_options_ptr->is_clk_polarity_used = FALSE;
    dvi_xorg_options_ptr->is_data_driving_sel_used = FALSE;
    dvi_xorg_options_ptr->is_ad9389_circuit_state_adjust_used = FALSE;
    dvi_xorg_options_ptr->clk_adjust = 0;
    dvi_xorg_options_ptr->clk_driving_sel = 0;
    dvi_xorg_options_ptr->clk_polarity = 0;
    dvi_xorg_options_ptr->data_driving_sel = 0;
    dvi_xorg_options_ptr->ad9389_circuit_state_adjust = 0;

    tempRecOptionsPtr= (OptionInfoPtr)malloc(sizeof(via_dvi_options));
    if (!tempRecOptionsPtr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memcpy(tempRecOptionsPtr, via_dvi_options, sizeof(via_dvi_options));
    /* if no "DVI" monitor section, all use default settting */
    if (output->conf_monitor) {
        xf86ProcessOptions(output->scrn->scrnIndex,
                output->conf_monitor->mon_option_lst, tempRecOptionsPtr);
    }

    /* parse option "NoDDCValue" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr,
        DRM_OPTION_DVI_NoDDCValue, FALSE))
        dvi_xorg_options_ptr->no_ddc_value = TRUE;

    /* parse user clock skew setting*/
    /* 1. parse option "ClockPolarity" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_DVI_CLOCK_POLARITY, &value)) {
        dvi_xorg_options_ptr->clk_polarity = value & BIT0;
        dvi_xorg_options_ptr->is_clk_polarity_used = TRUE;
    }
    /* 2. parse option "ClockAdjust" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_DVI_CLOCK_ADJUST, &value)) {
        dvi_xorg_options_ptr->clk_adjust = value;
        dvi_xorg_options_ptr->is_clk_adjust_used = TRUE;
    }
    /* 3. parse option "ClockDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_DVI_CLOCK_DRIVING_SELECTION, &value)) {
        dvi_xorg_options_ptr->clk_driving_sel = value;
        dvi_xorg_options_ptr->is_clk_driving_sel_used = TRUE;
    }
    /* 4. parse option "DataDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_DVI_DATA_DRIVING_SELECTION, &value)) {
        dvi_xorg_options_ptr->data_driving_sel = value;
        dvi_xorg_options_ptr->is_data_driving_sel_used = TRUE;
    }

    /* parse option  "AD9389CircuitStateAdjust" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_DVI_AD9389_CIRCUIT_STATE_ADJUST, &value)) {
        dvi_xorg_options_ptr->ad9389_circuit_state_adjust = value;
        dvi_xorg_options_ptr->is_ad9389_circuit_state_adjust_used = TRUE;
    }

    args.connector_id = koutput->connector_id;
    args.xorg_options = (void *)dvi_xorg_options_ptr;
    args.options_size = sizeof(via_dvi_xorg_options);
    via_xorg_options_transfer(fd, args);

    free(tempRecOptionsPtr);
    free(dvi_xorg_options_ptr);
}

static void
drmmode_pre_parse_hdmi_option(int fd, drmModeConnectorPtr koutput)
{
    via_hdmi_xorg_options_ptr hdmi_xorg_options_ptr = NULL;
    struct drm_via_chrome9_xorg_options args;

    hdmi_xorg_options_ptr =
        (via_hdmi_xorg_options_ptr)malloc(sizeof(via_hdmi_xorg_options));
    if (!hdmi_xorg_options_ptr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memset(hdmi_xorg_options_ptr, 0, sizeof(via_hdmi_xorg_options));
    args.connector_id = koutput->connector_id;
    args.xorg_options = (void *)hdmi_xorg_options_ptr;
    args.options_size = sizeof(via_hdmi_xorg_options);
    via_xorg_options_transfer(fd, args);

    free(hdmi_xorg_options_ptr);
}

static void
drmmode_parse_hdmi_option(int fd, xf86OutputPtr output, 
                drmModeConnectorPtr koutput, ScrnInfoPtr pScrn)
{
    int value = 0;
    OptionInfoPtr tempRecOptionsPtr;
    via_hdmi_xorg_options_ptr hdmi_xorg_options_ptr = NULL;
    struct drm_via_chrome9_xorg_options args;
    VIAPtr pVia = VIAPTR(pScrn);

    hdmi_xorg_options_ptr =
        (via_hdmi_xorg_options_ptr)malloc(sizeof(via_hdmi_xorg_options));
    if (!hdmi_xorg_options_ptr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    hdmi_xorg_options_ptr->attachAllModes = FALSE;
    hdmi_xorg_options_ptr->is_ad9389_circuit_state_adjust_used = FALSE;
    hdmi_xorg_options_ptr->is_clk_adjust_used = FALSE;
    hdmi_xorg_options_ptr->is_clk_driving_sel_used = FALSE;
    hdmi_xorg_options_ptr->is_clk_polarity_used = FALSE;
    hdmi_xorg_options_ptr->is_data_driving_sel_used = FALSE;

    hdmi_xorg_options_ptr->left_border = 0;
    hdmi_xorg_options_ptr->right_border = 0;
    hdmi_xorg_options_ptr->top_border = 0;
    hdmi_xorg_options_ptr->bottom_border = 0;

    hdmi_xorg_options_ptr->is_hdmi_audio_disable = FALSE;

    tempRecOptionsPtr = (OptionInfoPtr)malloc(sizeof(via_hdmi_options));
    if (!tempRecOptionsPtr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memcpy(tempRecOptionsPtr, via_hdmi_options, sizeof(via_hdmi_options));
    /* if no "HDMI" monitor section, all use default settting */
    if (output->conf_monitor) {
        xf86ProcessOptions(output->scrn->scrnIndex,
            output->conf_monitor->mon_option_lst, tempRecOptionsPtr );
    }

    /* parse option "AttachAllModes" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr,
        DRM_OPTION_HDMI_ATTACH_ALL_MODES, FALSE))
        hdmi_xorg_options_ptr->attachAllModes = TRUE;

    /* parse user clock skew setting*/
    /* 1. parse option "ClockPolarity" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_HDMI_CLOCK_POLARITY, &value)) {
        hdmi_xorg_options_ptr->clk_polarity = value & BIT0;
        hdmi_xorg_options_ptr->is_clk_polarity_used = TRUE;
    }
    /* 2. parse option "ClockAdjust" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_HDMI_CLOCK_ADJUST, &value)) {
        hdmi_xorg_options_ptr->clk_adjust = value;
        hdmi_xorg_options_ptr->is_clk_adjust_used = TRUE;
    }
    /* 3. parse option "ClockDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_HDMI_CLOCK_DRIVING_SELECTION, &value)) {
        hdmi_xorg_options_ptr->clk_driving_sel = value;
        hdmi_xorg_options_ptr->is_clk_driving_sel_used = TRUE;
    }
    /* 4. parse option "DataDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_HDMI_DATA_DRIVING_SELECTION, &value)) {
        hdmi_xorg_options_ptr->data_driving_sel = value;
        hdmi_xorg_options_ptr->is_data_driving_sel_used = TRUE;
    }

    /* parse option  "AD9389CircuitStateAdjust" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_HDMI_AD9389_CIRCUIT_STATE_ADJUST, &value)) {
        hdmi_xorg_options_ptr->ad9389_circuit_state_adjust = value;
        hdmi_xorg_options_ptr->is_ad9389_circuit_state_adjust_used = TRUE;
    }

    /* parse option left/right/top/bottom borders. */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_HDMI_LEFT_BORDER, &value)) {
        hdmi_xorg_options_ptr->left_border = value;
    }
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_HDMI_RIGHT_BORDER, &value)) {
        hdmi_xorg_options_ptr->right_border = value;
    }
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_HDMI_TOP_BORDER, &value)) {
        hdmi_xorg_options_ptr->top_border = value;
    }
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        DRM_OPTION_HDMI_BOTTOM_BORDER, &value)) {
        hdmi_xorg_options_ptr->bottom_border = value;
    }

    /* parse option "DisableAudio" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr,
        DRM_OPTION_HDMI_DISABLE_AUDIO, FALSE))
        hdmi_xorg_options_ptr->is_hdmi_audio_disable = TRUE;

    if( pVia->AD9389HdmiConId == koutput->connector_id ) {
        /**
         * transfer xorg hdmi audio set option to pVia for ad9389 . 
         * Notice: we use this option in XServer driver for ad9389,
         *            but in kernel driver for internal hdmi.
         */
        pVia->isAD9389HdmiAudioDisable = 
                hdmi_xorg_options_ptr->is_hdmi_audio_disable;
    }

    args.connector_id = koutput->connector_id;
    args.xorg_options = (void *)hdmi_xorg_options_ptr;
    args.options_size = sizeof(via_hdmi_xorg_options);
    via_xorg_options_transfer(fd, args);

    free(tempRecOptionsPtr);
    free(hdmi_xorg_options_ptr);
}

static void
drmmode_pre_parse_dp_option(int fd, drmModeConnectorPtr koutput)
{
    via_dp_xorg_options_ptr dp_xorg_options_ptr = NULL;
    struct drm_via_chrome9_xorg_options args;

    dp_xorg_options_ptr =
        (via_dp_xorg_options_ptr)malloc(sizeof(via_dp_xorg_options));
    if (!dp_xorg_options_ptr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memset(dp_xorg_options_ptr, 0, sizeof(via_dp_xorg_options));
    args.connector_id = koutput->connector_id;
    args.xorg_options = (void *)dp_xorg_options_ptr;
    args.options_size = sizeof(via_dp_xorg_options);
    via_xorg_options_transfer(fd, args);

    free(dp_xorg_options_ptr);
}

static void
drmmode_parse_dp_option(int fd,
        xf86OutputPtr output, drmModeConnectorPtr koutput)
{
    OptionInfoPtr tempRecOptionsPtr;
    via_dp_xorg_options_ptr dp_xorg_options_ptr = NULL;
    struct drm_via_chrome9_xorg_options args;

    dp_xorg_options_ptr =
        (via_dp_xorg_options_ptr)malloc(sizeof(via_dp_xorg_options));
    if (!dp_xorg_options_ptr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memset(dp_xorg_options_ptr, 0, sizeof(via_dp_xorg_options));

    tempRecOptionsPtr = (OptionInfoPtr)malloc(sizeof(via_dp_options));
    if (!tempRecOptionsPtr) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memcpy(tempRecOptionsPtr, via_dp_options, sizeof(via_dp_options));

    /* if no "dp" monitor section, all use default settting */
    if (output->conf_monitor) {
        xf86ProcessOptions(output->scrn->scrnIndex,
                output->conf_monitor->mon_option_lst, tempRecOptionsPtr);
    }
	
    /* parse option "Swlinktraining" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr,
        DRM_OPTION_DP_SWLinkTraining, FALSE))
        dp_xorg_options_ptr->sw_link_training = TRUE;

    args.connector_id = koutput->connector_id;
    args.xorg_options = (void *)dp_xorg_options_ptr;
    args.options_size = sizeof(via_dp_xorg_options);
    via_xorg_options_transfer(fd, args);

    free(tempRecOptionsPtr);
    free(dp_xorg_options_ptr);
}

static void
drmmode_pre_parse_tv_option(int fd, drmModeConnectorPtr koutput)
{
	via_tv_xorg_options_ptr tv_xorg_options_ptr = NULL;
	struct drm_via_chrome9_xorg_options args;

	if (!(tv_xorg_options_ptr = (via_tv_xorg_options_ptr)malloc(sizeof(via_tv_xorg_options)))) {
		ErrorF("%s:Allocate memory Failed\n",__FUNCTION__);
		return;
	}
	memset(tv_xorg_options_ptr, 0, sizeof(via_tv_xorg_options));
	args.connector_id = koutput->connector_id;
	args.xorg_options = (void *)tv_xorg_options_ptr;
	args.options_size = sizeof(via_tv_xorg_options);
	via_xorg_options_transfer(fd,args);

	free(tv_xorg_options_ptr);
}

static void
drmmode_parse_tv_option(int fd, xf86OutputPtr output, drmModeConnectorPtr koutput)
{
	char *s=NULL;
	int value = 0;
	OptionInfoPtr tempRecOptionsPtr;
	via_tv_xorg_options_ptr tv_xorg_options_ptr = NULL;
	struct drm_via_chrome9_xorg_options args;

	if (!(tv_xorg_options_ptr = (via_tv_xorg_options_ptr)malloc(sizeof(via_tv_xorg_options)))) {
		ErrorF("%s:Allocate memory Failed\n",__FUNCTION__);
		return;
	}
	memset(tv_xorg_options_ptr, 0, sizeof(via_tv_xorg_options));
	if (!(tempRecOptionsPtr= (OptionInfoPtr)malloc(sizeof(via_tv_options)))) {
		ErrorF("%s:Allocate memory Failed\n",__FUNCTION__);
		return;
	}
	memcpy(tempRecOptionsPtr, via_tv_options, sizeof(via_tv_options));
	if (output->conf_monitor) {
		xf86ProcessOptions(output->scrn->scrnIndex,
	                              output->conf_monitor->mon_option_lst,
	                              tempRecOptionsPtr);
	}
	/* parse option "Standard" */
	if (s = xf86GetOptValString(tempRecOptionsPtr, DRM_OPTION_TV_STANDARD)) {
		tv_xorg_options_ptr->standard = transformTvStandard(s);
	}
	/* parse option "Signal" */
	if (s = xf86GetOptValString(tempRecOptionsPtr, DRM_OPTION_TV_SIGNAL)) {
		tv_xorg_options_ptr->signal = transformTvSignal(s);
	}
	/* parse option "Scan" */
	if (s = xf86GetOptValString(tempRecOptionsPtr, DRM_OPTION_TV_SCAN)) {
		tv_xorg_options_ptr->scan= transformTvScan(s);
	}
	/* parse option "DeDotCrawl" */
	if (xf86ReturnOptValBool(tempRecOptionsPtr, DRM_OPTION_TV_DEDOTCRAWL, FALSE)) {
		tv_xorg_options_ptr->de_dot_crawl = TRUE;
	}	
	/* parse user clock skew setting */
	/* parse option "ClockPolarity" */
	if (xf86GetOptValInteger(tempRecOptionsPtr, DRM_OPTION_TV_CLOCK_POLARITY, &value)) {
		tv_xorg_options_ptr->clk_polarity = value & BIT0;
		tv_xorg_options_ptr->is_clk_polarity_used = TRUE;
	}
	/* parse option "ClockAdjust" */
	if (xf86GetOptValInteger(tempRecOptionsPtr, DRM_OPTION_TV_CLOCK_ADJUST, &value)) {
		tv_xorg_options_ptr->clk_adjust= value;
		tv_xorg_options_ptr->is_clk_adjust_used = TRUE;
	}
	/* parse option "ClockDrivingSelection" */
	if (xf86GetOptValInteger(tempRecOptionsPtr, DRM_OPTION_TV_CLOCK_DRIVING_SELECTION, &value)) {
		tv_xorg_options_ptr->clk_driving_sel= value;
		tv_xorg_options_ptr->is_clk_driving_sel_used = TRUE;
	}	
	/* parse option "DataDrivingSelection" */
	if (xf86GetOptValInteger(tempRecOptionsPtr, DRM_OPTION_TV_DATA_DRIVING_SELECTION, &value)) {
		tv_xorg_options_ptr->data_driving_sel= value;
		tv_xorg_options_ptr->is_data_driving_sel_used = TRUE;
	}
	/* parse option "UserEncoderDPA" */
	if (xf86GetOptValInteger(tempRecOptionsPtr, DRM_OPTION_TV_VT162x_DPA, &value)) {
		tv_xorg_options_ptr->vt1625_clk_adjust = value;
		tv_xorg_options_ptr->is_vt1625_clk_adjust_used = TRUE;
	}
	if (output->crtc) {
		tv_xorg_options_ptr->mode_index = VIA_MAKE_ID(output->crtc->desiredMode.HDisplay, output->crtc->desiredMode.VDisplay);
	} else {
		tv_xorg_options_ptr->mode_index = 0;
	}
	args.connector_id = koutput->connector_id;
	args.xorg_options = (void *)tv_xorg_options_ptr;
	args.options_size = sizeof(via_tv_xorg_options);
	via_xorg_options_transfer(fd,args);

	free(tempRecOptionsPtr);
	free(tv_xorg_options_ptr);
}


static void
drmmode_pre_parse_device_option(int fd,
        drmModeConnectorPtr koutput)
{
    if (!strcmp(output_names[koutput->connector_type], "VGA")) {
        drmmode_pre_parse_crt_option(fd, koutput);
    } else if (!strcmp(output_names[koutput->connector_type], "DVI")) {
        drmmode_pre_parse_dvi_option(fd, koutput);
    } else if (!strcmp(output_names[koutput->connector_type], "LVDS")) {
        drmmode_pre_parse_lcd_option(fd, koutput);
    } else if (!strcmp(output_names[koutput->connector_type], "HDMI")) {
        drmmode_pre_parse_hdmi_option(fd, koutput);
    } else if (!strcmp(output_names[koutput->connector_type], "DisplayPort")) {
        drmmode_pre_parse_dp_option(fd, koutput);
	} else if ((!strcmp(output_names[koutput->connector_type], "TV")) 
		||(!strcmp(output_names[koutput->connector_type], "Composite"))
		||(!strcmp(output_names[koutput->connector_type], "S-video"))){
		drmmode_pre_parse_tv_option(fd, koutput);
    }
}

static const xf86OutputFuncsRec drmmode_output_funcs = {
    .dpms = drmmode_output_dpms,
    .create_resources = drmmode_output_create_resources,
#ifdef RANDR_12_INTERFACE
    .set_property = drmmode_output_set_property,
    .get_property = drmmode_output_get_property,
#endif
    .detect = drmmode_output_detect,
    .mode_valid = drmmode_output_mode_valid,

    .get_modes = drmmode_output_get_modes,
    .destroy = drmmode_output_destroy
};

/*
* this function is used to record ad9389 connector id
* and internal hdmi connector id
*/
static void
drmmode_record_connector_id(ScrnInfoPtr pScrn,
        drmModeConnectorPtr koutput)
{
    VIAPtr pVia = VIAPTR(pScrn);
    int connector_type = koutput->connector_type;
    int connector_type_id = koutput->connector_type_id;
    
    if (!strcmp(output_names[connector_type], "HDMI")) {
        if (1 == connector_type_id) {
            switch (pVia->Chipset) {
            case VIA_VX800:
            case VIA_VX855:
                pVia->AD9389HdmiConId = koutput->connector_id;
                break;
            case VIA_VX900:
            default :
                break;
            }
        } else if (2 == connector_type_id) {
            switch (pVia->Chipset) {
            case VIA_VX900:
                pVia->AD9389HdmiConId = koutput->connector_id;
                break;
            case VIA_VX800:
            case VIA_VX855:
            default :
                break;
            }
        }
    } else if (!strcmp(output_names[connector_type], "DVI")) {
        if (1 == connector_type_id) {
            switch (pVia->Chipset) {
            case VIA_VX855:
                if (pVia->IsAD9389Exist)
                    pVia->AD9389DviConId = koutput->connector_id;
                break;
            case VIA_VX800:
            case VIA_VX900:
            default:
                break;
            }
        } else if (2 == connector_type_id) {
            switch (pVia->Chipset) {
            case VIA_VX800:
            case VIA_VX900:
                if (pVia->IsAD9389Exist)
                    pVia->AD9389DviConId = koutput->connector_id;
                break;
            case VIA_VX855:
            default:
                break;
            }
        }
    }
}

static xf86OutputPtr
drmmode_output_create(ScrnInfoPtr pScrn,
        drmModeConnectorPtr koutput)
{
    xf86CrtcConfigPtr   xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
    char old_name[32], new_name[32];
    xf86OutputPtr name_new_output, name_old_output;
    VIAPtr pVia = VIAPTR(pScrn);
    int connector_type = koutput->connector_type;
    int connector_type_id = koutput->connector_type_id;
    int o;

    memset(old_name, '\0', 32);
    memset(new_name, '\0', 32);

    drmmode_get_output_name(connector_type,
        connector_type_id, XORG_CONF_NAMESPACE_OLD, old_name);
    name_old_output = xf86OutputCreate (pScrn,
        &drmmode_output_funcs, old_name);
    drmmode_get_output_name(connector_type,
        connector_type_id, XORG_CONF_NAMESPACE_NEW, new_name);
    name_new_output = xf86OutputCreate (pScrn,
        &drmmode_output_funcs, new_name);

    if (!name_new_output || !name_old_output) {
        if (name_new_output)
            goto ret_name_old;
        else if (name_old_output)
            goto ret_name_new;
        else
            return NULL;
    }

    if (name_new_output->conf_monitor) {
        goto ret_name_new;
    }

    if (!name_new_output->conf_monitor && !name_old_output->conf_monitor)
        goto ret_name_new;

    if (name_old_output->conf_monitor)
        goto ret_name_old;

ret_name_new:
    for (o = 0; o < xf86_config->num_output; o++)
        if (xf86_config->output[o] == name_old_output) {
            memmove (&xf86_config->output[o],
                &xf86_config->output[o + 1],
                ((xf86_config->num_output - (o + 1)) * sizeof(void*)));
            xf86_config->num_output--;
            break;
        }

    if (name_old_output->name &&
        name_old_output->name != (char *) (name_old_output + 1))
        free(name_old_output->name);
    free(name_old_output);
    return name_new_output;

ret_name_old:
    for (o = 0; o < xf86_config->num_output; o++)
        if (xf86_config->output[o] == name_new_output) {
            memmove (&xf86_config->output[o],
                    &xf86_config->output[o + 1],
                    ((xf86_config->num_output - (o + 1)) * sizeof(void*)));
            xf86_config->num_output--;
            break;
        }

    if (name_new_output->name &&
        name_new_output->name != (char *) (name_new_output + 1))
        free(name_new_output->name);
    free(name_new_output);
    return name_old_output;
}

static void
drmmode_output_init(ScrnInfoPtr pScrn, drmmode_ptr drmmode, int num)
{
    xf86OutputPtr output;
    drmModeConnectorPtr koutput;
    drmModeEncoderPtr *kencoders = 0;
    drmmode_output_private_ptr drmmode_output;
    drmModePropertyPtr props;
    int i;

    koutput =
        drmModeGetConnector(drmmode->fd, drmmode->mode_res->connectors[num]);
    if (!koutput)
        return;

    drmmode_pre_parse_device_option(drmmode->fd, koutput);
    drmmode_record_connector_id(pScrn, koutput);
    output = drmmode_output_create(pScrn, koutput);

    if (!output) {
        goto out_free_encoders;
    }

    if (output->conf_monitor) {
        if (!strcmp(output_names[koutput->connector_type], "VGA")) {
            output->interlaceAllowed = TRUE;
            output->doubleScanAllowed = FALSE;
            drmmode_parse_crt_option(drmmode->fd, output, koutput);
        } else if (!strcmp(output_names[koutput->connector_type], "DVI")) {
            output->interlaceAllowed = FALSE;
            output->doubleScanAllowed = FALSE;
            drmmode_parse_dvi_option(drmmode->fd, output, koutput);
        } else if (!strcmp(output_names[koutput->connector_type], "LVDS")) {
            output->interlaceAllowed = FALSE;
            output->doubleScanAllowed = FALSE;
            drmmode_parse_lcd_option(drmmode->fd, output, koutput);
        } else if (!strcmp(output_names[koutput->connector_type], "HDMI")) {
            output->interlaceAllowed = TRUE;
            output->doubleScanAllowed = FALSE;
            drmmode_parse_hdmi_option(drmmode->fd, output, koutput, pScrn );
        } else if (!strcmp(output_names[koutput->connector_type], "DisplayPort")) {
            output->interlaceAllowed = FALSE;
            output->doubleScanAllowed = FALSE;
			drmmode_parse_dp_option(drmmode->fd, output, koutput);
		} else if (!strcmp(output_names[koutput->connector_type], "TV")) {
			output->interlaceAllowed = TRUE;
			output->doubleScanAllowed= FALSE;
		}
    }

    drmmode_output = calloc(sizeof(drmmode_output_private_rec), 1);
    if (!drmmode_output) {
        xf86OutputDestroy(output);
        goto out_free_encoders;
    }

    drmModeFreeConnector(koutput);
    koutput = NULL;
    koutput = drmModeGetConnector(drmmode->fd,
        drmmode->mode_res->connectors[num]);
    if (!koutput)
        return;
    kencoders = calloc(sizeof(drmModeEncoderPtr), koutput->count_encoders);
    if (!kencoders) {
        goto out_free_encoders;
    }

    for (i = 0; i < koutput->count_encoders; i++) {
        kencoders[i] = drmModeGetEncoder(drmmode->fd, koutput->encoders[i]);
        if (!kencoders[i])
            goto out_free_encoders;
    }

    drmmode_output->output_id = drmmode->mode_res->connectors[num];
    drmmode_output->mode_output = koutput;
    drmmode_output->mode_encoders = kencoders;
    drmmode_output->drmmode = drmmode;
    output->mm_width = koutput->mmWidth;
    output->mm_height = koutput->mmHeight;

    output->subpixel_order = subpixel_conv_table[koutput->subpixel];
    output->driver_private = drmmode_output;

    output->possible_crtcs = 0x03;
    for (i = 0; i < koutput->count_encoders; i++) {
        output->possible_crtcs &= kencoders[i]->possible_crtcs;
    }

    /*work out the possible clones later*/
    output->possible_clones = 0;

    for (i = 0; i < koutput->count_props; i++) {
        props = drmModeGetProperty(drmmode->fd, koutput->props[i]);
        if (props && (props->flags && DRM_MODE_PROP_ENUM)) {
            if (!strcmp(props->name, "DPMS")) {
                drmmode_output->dpms_enum_id = koutput->props[i];
                drmModeFreeProperty(props);
                break;
            }
        }
        drmModeFreeProperty(props);
    }
    return;

out_free_encoders:
    if (kencoders) {
        for (i = 0; i < koutput->count_encoders; i++)
            drmModeFreeEncoder(kencoders[i]);
        free(kencoders);
    }
    drmModeFreeConnector(koutput);
}

uint32_t
find_clones(ScrnInfoPtr scrn, xf86OutputPtr output)
{
    drmmode_output_private_ptr drmmode_output = output->driver_private;
    drmmode_output_private_ptr clone_drmoutput;
    int i;
    xf86OutputPtr clone_output;
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(scrn);
    int index_mask = 0;

    if (drmmode_output->enc_clone_mask == 0)
        return index_mask;

    for (i = 0; i < xf86_config->num_output; i++) {
        clone_output = xf86_config->output[i];
        clone_drmoutput = clone_output->driver_private;
        if (output == clone_output)
            continue;
        if (clone_drmoutput->enc_mask == 0)
            continue;
        if (drmmode_output->enc_clone_mask == clone_drmoutput->enc_mask)
            index_mask |= (1 << i);
    }

    return index_mask;
}

static void
drmmode_clones_init(ScrnInfoPtr scrn, drmmode_ptr drmmode)
{
    int i, j;
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(scrn);

    for (i = 0; i < xf86_config->num_output; i++) {
        xf86OutputPtr output = xf86_config->output[i];
        drmmode_output_private_ptr drmmode_output;

        drmmode_output = output->driver_private;
        drmmode_output->enc_clone_mask = 0xff;

        for (j = 0; j < drmmode_output->mode_output->count_encoders; j ++) {
            int k;
            for (k = 0; k < drmmode->mode_res->count_encoders; k ++) {
                if (drmmode->mode_res->encoders[k] ==
                    drmmode_output->mode_encoders[j]->encoder_id)
                    drmmode_output->enc_mask |= (1 << k);
            }
            drmmode_output->enc_clone_mask &=
            drmmode_output->mode_encoders[j]->possible_clones;
        }

    }

    for (i = 0; i < xf86_config->num_output; i ++) {
        xf86OutputPtr output = xf86_config->output[i];
        output->possible_clones = find_clones(scrn, output);
    }
}

static void
drmmode_vblank_handler(int fd,
            unsigned int frame, unsigned int tv_sec,
            unsigned int tv_usec, void *event_data)
{
    via_dri2_frame_event_handler(frame, tv_sec, tv_usec, event_data);
}

static void
drm_wakeup_handler(pointer data, int err, pointer p)
{
    drmmode_ptr drmmode = data;
    fd_set *read_mask = p;

    if (err >= 0 && FD_ISSET(drmmode->fd, read_mask)) {
        drmHandleEvent(drmmode->fd, &drmmode->event_context);
    }
}

static void
drm_event_context_init(drmmode_ptr drmmode)
{
    /* Event context function was thought supported by default. */
    drmmode->event_context.version = DRM_EVENT_CONTEXT_VERSION;

    /**
     * FC12 libdrm event context version support.
     * Because libdrm in FC12 is not standard v2.4.15, 
     * and its' event version is 1 but support the second page_flip interface.
     * if you are building driver for FC12, please do like this after autogen:
     *     # make CFLAGS+=-D_VIA_FC12_
     * DEFAULT: _VIA_FC12_ will not be defined.
     */
#ifdef _VIA_FC12_
    drmmode->event_context.page_flip_handler = NULL;
    xf86Msg(X_INFO, "_VIA_FC12_ defined!\n");
#else
    /* Version 1: support vblank handle interface. */
    if (drmmode->event_context.version >= 1)
        drmmode->event_context.vblank_handler = drmmode_vblank_handler;
    /* Version 2: support vblank and page_flip handle interfaces. */
    if (drmmode->event_context.version >= 2)
        drmmode->event_context.page_flip_handler = NULL;
#endif
}

Bool
drmmode_pre_init(ScrnInfoPtr pScrn, int fd, int cpp)
{
    xf86CrtcConfigPtr   xf86_config;
    drmmode_ptr drmmode;
    VIAPtr pVia = VIAPTR(pScrn);
    int i;
    drmmode = xnfalloc(sizeof *drmmode);
    drmmode->fd = fd;
    drmmode->fb_id = 0;

    xf86CrtcConfigInit(pScrn, &drmmode_xf86crtc_config_funcs);
    xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
    xf86_config->xf86_crtc_notify = via_xf86_crtc_notify;

    drmmode->cpp = cpp;
    drmmode->mode_res = drmModeGetResources(drmmode->fd);
    if (!drmmode->mode_res) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "failed to get resources: %s\n", strerror(errno));
        return FALSE;
    }
    pVia->drmmode = drmmode;

    xf86CrtcSetSizeRange(pScrn, 320, 200, drmmode->mode_res->max_width,
        drmmode->mode_res->max_height);
    for (i = 0; i < drmmode->mode_res->count_crtcs; i++)
        drmmode_crtc_init(pScrn, drmmode, i);

    for (i = 0; i < drmmode->mode_res->count_connectors; i++)
        drmmode_output_init(pScrn, drmmode, i);

    /*pass xorg.conf's mode line parameters to CBIOS's customized timing.*/
    drmmode_pass_mode_line_to_cbios(pScrn);

    drmmode_clones_init(pScrn, drmmode);
    xf86InitialConfiguration(pScrn, TRUE);
	for (i = 0; i < xf86_config->num_output; i++)
	{
		xf86OutputPtr	output = xf86_config->output[i];
		if (!xf86NameCmp(output->name, "TV-1") ||
			!xf86NameCmp(output->name, "TV-2")) {
			drmModeConnectorPtr koutput = NULL;
			drmmode_output_private_ptr drmmode_output = (drmmode_output_private_ptr)output->driver_private;			
			drmmode_parse_tv_option(drmmode->fd, output, drmmode_output->mode_output);
			koutput = drmModeGetConnector(drmmode->fd, drmmode_output->mode_output->connector_id);
			if (koutput) {
				drmModeFreeConnector(drmmode_output->mode_output);
				drmmode_output->mode_output = koutput;
			} else {
				DBG_DD(("TV koutput get fail, pay attation here!!!\n"));
			}
		}	
	}

    drm_event_context_init(drmmode);

    AddGeneralSocket(drmmode->fd);
    RegisterBlockAndWakeupHandlers((BlockHandlerProcPtr)NoopDDA,
        drm_wakeup_handler, drmmode);

    return TRUE;
}

static int
drm_fb_hpd_properties_verify(struct udev_device *udev_device,
            const char *key,
            const char *value,
            void *data)
{
    int *val = data;
    char *event_string = "FBHPD";
    *val = 0;
    if (0 == strcmp(key, event_string)) {
        *val = 1;
        return 1;
    }
    return 0;
}

static void
drmmode_handle_uevents(int fd, void *closure)
{
    drmmode_ptr drmmode = closure;
    ScrnInfoPtr scrn = drmmode->scrn;
    VIAPtr pVia = VIAPTR(scrn);
    struct udev_device *dev;
    char *subsystem;
    char *test2 = NULL;
    int val2 = 0;
    int i = 0;
    int o=0, c=0;
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(scrn);
    xf86DrvMsg(scrn->pScreen->myNum, X_INFO, "enter %s\n", __func__);

    pVia->IsHpd = TRUE;
    dev = udev_monitor_receive_device(drmmode->uevent_monitor);
    if (!dev)
        return;

#ifndef HAVE_LIBUDEV_NEW
        subsystem = udev_device_get_subsystem(dev);
        if (strcmp(subsystem, "drm"))
            goto failure;
#endif

#ifndef HAVE_LIBUDEV_NEW
        /* for sled11 */
        udev_device_get_properties(dev, drm_fb_hpd_properties_verify, &val2);
#else
        test2 = udev_device_get_property_value(dev, "FBHPD");	
#endif
    if (val2 || test2) {
        DBG_DD(("FBHOTPLUG is called\n"));
        /* RRGetInfo only let Xrandr to know output's change and layout change */
        RRGetInfo(screenInfo.screens[scrn->scrnIndex], TRUE);
        /* Get crtc changed status */
        for (o = 0; o < xf86_config->num_output; o++) {
            xf86OutputPtr output = xf86_config->output[o];
            if(output->status == XF86OutputStatusDisconnected)
                output->crtc = NULL;
        }
        for (c = 0; c < xf86_config->num_crtc; c++) {
            xf86CrtcPtr crtc = xf86_config->crtc[c];
            for (o = 0; o < xf86_config->num_output; o++) {
                xf86OutputPtr output = xf86_config->output[o];
                if(output->crtc==crtc)
                    break;
                }
                /* No any output use this crtc */
                if(o==xf86_config->num_output)
                    crtc->enabled=FALSE;
        }
        /* Let drm device to know crtc and output's unused status*/
        xf86DisableUnusedFunctions(scrn);
        /* tell Xrandr crtc's change if has */
        xf86RandR12TellChanged(scrn->pScreen);
    }
    
failure:
    pVia->IsHpd = FALSE;
    udev_device_unref(dev);
}

void
drmmode_uevent_init(ScrnInfoPtr scrn, drmmode_ptr drmmode)
{
#ifdef HAVE_LIBUDEV
    void *udev_create, *udev_add;

    drmmode->uevent_handler = drmmode->udev_handle = NULL;
    drmmode->udev_out_date = TRUE;

    /* ubuntu 9.04 11.10 sled 11 sp1 udev path */
    drmmode->udev_handle = dlopen("/lib/libudev.so.0", RTLD_LAZY | RTLD_GLOBAL);
    if (drmmode->udev_handle == NULL) {
        /* ubuntu 11.04 udev path */
        drmmode->udev_handle = dlopen("/lib/i386-linux-gnu/libudev.so.0",
            RTLD_LAZY | RTLD_GLOBAL);
    }
    if (drmmode->udev_handle == NULL) {
        /* consider x86_64 U11.04 */
        drmmode->udev_handle = dlopen("/lib/x86_64-linux-gnu/libudev.so.0",
            RTLD_LAZY | RTLD_GLOBAL);
    }
    if (drmmode->udev_handle == NULL) {
        xf86DrvMsg(scrn->pScreen->myNum, X_INFO,
                "hotplug detect is not enable,"
                " pls make sure that you have install libudev \n");
        return;
    }

	drmmode_uevent_init_handle(scrn, drmmode);
#else
    xf86DrvMsg(scrn->pScreen->myNum, X_INFO,
                "hotplug detect is not enable,"
                "because your compiler env don't include libudev header \n");
#endif
}

#ifdef HAVE_LIBUDEV
void
drmmode_uevent_init_handle(ScrnInfoPtr scrn, drmmode_ptr drmmode)
{
    struct udev *udev;
    struct udev_monitor *mon;

    udev = udev_new();
    if (!udev)
        return;
#ifdef HAVE_LIBUDEV_NEW
        mon = udev_monitor_new_from_netlink(udev, "udev");
        if (!mon) {
            udev_unref(udev);
            return;
        }

        if (udev_monitor_filter_add_match_subsystem_devtype(mon,
            "drm", "drm_minor") < 0 || udev_monitor_enable_receiving(mon) < 0) {
            udev_monitor_unref(mon);
            udev_unref(udev);
            return;
        }
#else
        mon = udev_monitor_new_from_netlink(udev);
        if (!mon) {
            udev_unref(udev);
            return;
        }
        udev_monitor_enable_receiving(mon);
#endif

    drmmode->uevent_handler =
        xf86AddGeneralHandler(udev_monitor_get_fd(mon),
            drmmode_handle_uevents, drmmode);

    drmmode->uevent_monitor = mon;
    drmmode->scrn = scrn;

    xf86DrvMsg(scrn->pScreen->myNum, X_INFO, "hotplug detect is enabled \n");
}
#endif

void
drmmode_uevent_fini(ScrnInfoPtr scrn, drmmode_ptr drmmode)
{
#ifdef HAVE_LIBUDEV
    if (drmmode->uevent_handler) {
        struct udev *u = udev_monitor_get_udev(drmmode->uevent_monitor);
        xf86RemoveGeneralHandler(drmmode->uevent_handler);
        udev_monitor_unref(drmmode->uevent_monitor);
        udev_unref(u);
        dlclose(drmmode->udev_handle);
    }
#endif
}
