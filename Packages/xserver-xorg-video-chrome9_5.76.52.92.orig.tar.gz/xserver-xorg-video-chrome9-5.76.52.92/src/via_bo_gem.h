/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef VIA_BO_GEM_H
#define VIA_BO_GEM_H
#define VIA_BO_POOL_NUM 7 /*max bo =128k*/
#define VIA_BO_TYPE 2
#define VIA_BO_POOL_TYPE_PCIE 1
#define VIA_BO_POOL_TYPE_VRAM 0

#include "via_bo.h"
#include "libdrm_lists.h"
#include <pthread.h>

struct via_bo_reloc_info {
    struct drm_via_chrome9_gem_relocation_entry *relocs; /* the reloc list */
    struct via_bo **target_bo_list; /* the list record the target bo */
    int reloc_count; /* the count of bo at reloc list */
    unsigned int max_reloc; /* the maximum count for bo at reloc list */
    /* cmd_type for one flush */
    uint32_t cmd_type;
};

struct via_branchbuf_bo {
    struct generic_bo *bo; /*buff BO*/
    drmMMListHead list;
    uint32_t cmd_type; /*command type in this buffer*/
    int num; /*number of this BO*/
    /* reloc info of this cmd BO */
    struct via_bo_reloc_info reloc_info;
    /* record the buffer and reloc list */
    struct drm_via_chrome9_gem_exec_object *exec_objects;
};

struct via_branch_buffer_mgr {
    struct via_branchbuf_bo *buf_bo;
    int buffer_num;
    int buffer_size;
    drmMMListHead free;
    drmMMListHead busy;
    pthread_mutex_t lock;
};

struct via_bo_bufmgr {
    struct generic_bo_bufmgr bo_bufmgr;
    /* record the buffer and reloc list */
    struct drm_via_chrome9_gem_exec_object *exec_objects;
    struct via_bo_reloc_info reloc_info;
    /* add whatever needed */
    struct via_branch_buffer_mgr * branchbuf_mgr;
    struct via_bo_pool_mgr *bo_pool_mgr;
};

struct via_bo {
    struct generic_bo bo;
    /* the gem object handle  */
    int handle;
    /* the domain indicate which region we allocate */
    uint32_t domains;
    /* the buffer object name */
    const char *name;
    /* the global name when we want to share this buffer object */
    unsigned int global_name;
    /* the buffer object reference count */
    unsigned int reference_count;
   /* list of the same size BO for reuse */
    drmMMListHead list;
    int reusable;
    pthread_mutex_t lock;
    /* Add whatever needed */
};

struct via_bo_bucket {
        pthread_mutex_t lock;
        drmMMListHead list;
        /* number of BOs*/
        int num;
        int size;
};

struct via_bo_pool_mgr {
    /* pools for bo reuse */
    struct via_bo_bucket buckets[VIA_BO_TYPE][VIA_BO_POOL_NUM];
    int bucket_num;
    int initialized;
};
struct generic_bo_bufmgr * via_bo_bufmgr_con(int drmfd);
void via_bo_bufmgr_decon(struct generic_bo_bufmgr *p_generic_bo_bufmgr);

#endif
