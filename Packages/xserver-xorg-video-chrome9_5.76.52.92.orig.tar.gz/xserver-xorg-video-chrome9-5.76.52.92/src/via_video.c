/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * I N C L U D E S
 */
#include <xorg/xorg-server.h>
#include "Xv.h"
#include "dixstruct.h"
#include "pixman.h"
#include "xf86_OSproc.h"
#include "via_include.h"
#include "compiler.h"
#include "xf86PciInfo.h"
#include "xf86Pci.h"
#include "xf86fbman.h"
#include "regionstr.h"
#include "via_driver.h"
#include "via_video.h"
#include "via_eng_reg_fops.h"
#include "via_rotate.h"
#include "drmmode_display.h"
#include "via_output.h"

#include "debug.h"               /* for DBG_DD */
#include "via_eng_regs.h"
#include "fourcc.h"
#include "xf86.h"
#include "xf86xv.h"
#if GET_ABI_MAJOR(ABI_VIDEODRV_VERSION) < 6
#include "xf86Resources.h"
#endif

/*
 * D E F I N E
 */
#define  XV_IMAGE          0
#define MAKE_ATOM(a) MakeAtom(a, sizeof(a) - 1, TRUE)

#define MAXWIDTH 2048
#define MAXHEIGHT 2048
#ifndef REGION_NULL
#define REGION_NULL(_pScreen,_pReg)\
    REGION_INIT(_pScreen,_pReg,NullBox,1)
#endif

#ifndef REGION_EQUAL
#define  REGION_EQUAL(_pScreen, _pReg1, _pReg2)\
     miRegionEqual(_pReg1,_pReg2)
#endif
#ifdef XvExtension

/* FUNCTION DECLARATION */
static int viaSetupImageVideoG(ScreenPtr, XF86VideoAdaptorPtr *);
static int viaSetupImageVideoTextureG(ScreenPtr, XF86VideoAdaptorPtr *);
static void viaStopVideoG(ScrnInfoPtr, pointer, Bool);
static int viaSetPortAttributeG(ScrnInfoPtr, Atom, INT32, pointer);
static int viaGetPortAttributeG(ScrnInfoPtr, Atom, INT32 *, pointer);
static void viaQueryBestSizeG(ScrnInfoPtr, Bool,
    short, short, short, short, unsigned int *, unsigned int *, pointer);
/*FUNCTION TO GET VIAGFXINFO*/
static void FillViaGfxMemInfo(ScrnInfoPtr);
static int RelationOfIGA1andIGA2(ScrnInfoPtr);
static void GetScrnAndIgaAttr(ScrnInfoPtr);
static void GetScrnInfo(ScrnInfoPtr);
static ActiveDeviceRec GetActiveDevice(char *);
static void GetIgaInfo(ScrnInfoPtr);
static void GetSrcnAndIgaInfo(ScrnInfoPtr);
static void GetViaGfxInfo(ScrnInfoPtr);

int viaPutImageG(ScrnInfoPtr,
    short, short, short, short, short, short, short, short,
    int, unsigned char *, short, short, Bool, RegionPtr, pointer,
    DrawablePtr);
extern int viaPutImageTexturedG(ScrnInfoPtr, short, short, short, short,
    short, short, short, short, int, unsigned char *, short, short, Bool,
    RegionPtr, pointer, DrawablePtr);
static int viaReputImageG(ScrnInfoPtr, short, short, RegionPtr, pointer,
    DrawablePtr);

unsigned long viaCreateXvSurface(ScrnInfoPtr, viaPortPrivPtr, unsigned long,
    unsigned long, unsigned long);
void viaDestroyXvSurface(ScrnInfoPtr, viaPortPrivPtr);
unsigned long viaDestroyOverlaySurface(ScrnInfoPtr, viaPortPrivPtr,
    unsigned long);

static int viaQueryImageAttributesG(ScrnInfoPtr, int, unsigned short *,
    unsigned short *, int *, int *);
void StopOVerlay(ScrnInfoPtr, viaPortPrivPtr);

/* GLOBALS */
static Atom xvBrightness, xvContrast, xvColorKey, xvHue, xvSaturation,
    xvOverlayStatus, xv_autopaint_colorkey;

/* EXTERN GLOBALS*/

/* STRUCTS */

/* client libraries expect an encoding */
static XF86VideoEncodingRec DummyEncoding[1] = {
    {XV_IMAGE, "XV_IMAGE", MAXWIDTH, MAXHEIGHT, {1, 1}}
};

#define NUM_FORMATS_G 9

static XF86VideoFormatRec FormatsG[NUM_FORMATS_G] = {
    {8, TrueColor},               /* Dithered */
    {8, PseudoColor},               /* Using .. */
    {8, StaticColor},
    {8, GrayScale},
    {8, StaticGray},               /* .. TexelLUT */
    {16, TrueColor},
    {24, TrueColor},
    {16, DirectColor},
    {24, DirectColor}
};

#define NUM_ATTRIBUTES_G 7

static XF86AttributeRec AttributesG[NUM_ATTRIBUTES_G] = {
    {XvSettable | XvGettable, 0, 10000, "XV_BRIGHTNESS"},
    {XvSettable | XvGettable, 0, 20000, "XV_CONTRAST"},
    {XvSettable | XvGettable, 0, 20000, "XV_SATURATION"},
    {XvSettable | XvGettable, -180, 180, "XV_HUE"},
    {XvGettable, 0, 1, "XV_OVERLAYSTATUS"},
    {XvSettable | XvGettable, 0, (1 << 24) - 1, "XV_COLORKEY"},
    {XvSettable | XvGettable, 0, 1, "XV_AUTOPAINT_COLORKEY"}
};

#define NUM_ATTRIBUTES_G_TEXTURE 5

static XF86AttributeRec AttributesG_TEXTURE[NUM_ATTRIBUTES_G_TEXTURE] = {
    {XvSettable | XvGettable, 0, 10000, "XV_BRIGHTNESS"},
    {XvSettable | XvGettable, 0, 20000, "XV_CONTRAST"},
    {XvSettable | XvGettable, 0, 20000, "XV_SATURATION"},
    {XvSettable | XvGettable, -180, 180, "XV_HUE"},
    {XvSettable | XvGettable, 0, 1, "XV_AUTOPAINT_COLORKEY"}
};

#define NUM_ATTRIBUTES_G_CLEAX 7

static XF86AttributeRec AttributesG_CLEAX[NUM_ATTRIBUTES_G_CLEAX] = {
    {XvSettable | XvGettable, 0, (1 << 24) - 1, "XV_COLORKEY"},
    {XvSettable | XvGettable, 0, 255, "XV_MUTE"},
    {XvSettable | XvGettable, 0, 255, "XV_VOLUME"},
    {XvSettable | XvGettable, 0, 255, "XV_ENCODING"},
    {XvSettable, 0, -1, "XV_FREQ"},
    {XvSettable, 0, 2, "XV_AUDIOCTRL"},
    {XvSettable | XvGettable, 0, 1, "XV_AUTOPAINT_COLORKEY"}

};

#define NUM_IMAGES_G 5

static XF86ImageRec ImagesG[NUM_IMAGES_G] = {
    XVIMAGE_YUY2,
    XVIMAGE_YV12,
    XVIMAGE_I420,
    XVIMAGE_VDPAU,
    XVIMAGE_VMI
};

/*
 *  F U N C T I O N
 */
void
viaResetVideo(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    volatile video_via_regs *viaVidEng = NULL;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));
    viaVidEng = (volatile video_via_regs *)pVia->VidMapBase;

    viaVidEng->video1_ctl = 0;
    viaVidEng->video3_ctl = 0;
    viaVidEng->compose = 0x80000000;
    viaVidEng->compose = 0x40000000;
}

void
viaSaveVideo(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    volatile video_via_regs *viaVidEng = NULL;
    video_via_regs *localVidEng = &pVia->VidEngSaved;;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));
    viaVidEng = (volatile video_via_regs *)pVia->VidMapBase;
    memcpy((void *)localVidEng, (void *)viaVidEng, sizeof(video_via_regs));
#if 0
    if (pVia->ChipId != PCI_CHIP_VT3314)
        viaVidEng->compose |= V1_COMMAND_FIRE;    /*fire V1 */
    viaVidEng->compose |= V3_COMMAND_FIRE;
#endif
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "video1 CSC(%lx,%lx)\n",
        localVidEng->video1_CSC1, localVidEng->video1_CSC2));
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "video1 addr0:%lx,addr1:%lx\n",
        localVidEng->video1y_addr0, localVidEng->video1y_addr1));
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "video3 CSC(%lx,%lx)\n",
        localVidEng->video3_CSC1, localVidEng->video3_CSC2));
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "video3 addr0:%lx,addr1:%lx\n",
        localVidEng->video3_addr0, localVidEng->video3_addr1));
}

void
viaRestoreVideo(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    volatile video_via_regs *viaVidEng = NULL;
    video_via_regs *localVidEng = &pVia->VidEngSaved;;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    viaVidEng = (volatile video_via_regs *)pVia->VidMapBase;
    /*flush restored video engines' setting to VidMapBase */
    viaVidEng = (volatile video_via_regs *)pVia->VidMapBase;
    viaVidEng->alphawin_hvstart = localVidEng->alphawin_hvstart;
    viaVidEng->alphawin_size = localVidEng->alphawin_size;
    viaVidEng->alphawin_ctl = localVidEng->alphawin_ctl;
    viaVidEng->alphafb_stride = localVidEng->alphafb_stride;
    viaVidEng->color_key = localVidEng->color_key;
    viaVidEng->alphafb_addr = localVidEng->alphafb_addr;
    viaVidEng->chroma_low = localVidEng->chroma_low;
    viaVidEng->chroma_up = localVidEng->chroma_up;
    viaVidEng->interruptflag = localVidEng->interruptflag;

    if (pVia->ChipId != PCI_CHIP_VT3314) {
        /*VT3314 only has V3 */
        viaVidEng->video1_ctl = localVidEng->video1_ctl;
        viaVidEng->video1_fetch = localVidEng->video1_fetch;
        viaVidEng->video1y_addr1 = localVidEng->video1y_addr1;
        viaVidEng->video1_stride = localVidEng->video1_stride;
        viaVidEng->video1_hvstart = localVidEng->video1_hvstart;
        viaVidEng->video1_size = localVidEng->video1_size;
        viaVidEng->video1y_addr2 = localVidEng->video1y_addr2;
        viaVidEng->video1_zoom = localVidEng->video1_zoom;
        viaVidEng->video1_mictl = localVidEng->video1_mictl;
        viaVidEng->video1y_addr0 = localVidEng->video1y_addr0;
        viaVidEng->video1_fifo = localVidEng->video1_fifo;
        viaVidEng->video1y_addr3 = localVidEng->video1y_addr3;
        viaVidEng->v1_source_w_h = localVidEng->v1_source_w_h;
        viaVidEng->video1_CSC1 = localVidEng->video1_CSC1;
        viaVidEng->video1_CSC2 = localVidEng->video1_CSC2;
    }
    viaVidEng->snd_color_key = localVidEng->snd_color_key;
    viaVidEng->v3alpha_prefifo = localVidEng->v3alpha_prefifo;
    viaVidEng->v3alpha_fifo = localVidEng->v3alpha_fifo;
    viaVidEng->video3_CSC2 = localVidEng->video3_CSC2;
    viaVidEng->video3_CSC2 = localVidEng->video3_CSC2;
    viaVidEng->v3_source_width = localVidEng->v3_source_width;
    viaVidEng->video3_ctl = localVidEng->video3_ctl;
    viaVidEng->video3_addr0 = localVidEng->video3_addr0;
    viaVidEng->video3_addr1 = localVidEng->video3_addr1;
    viaVidEng->video3_stride = localVidEng->video3_stride;
    viaVidEng->video3_hvstart = localVidEng->video3_hvstart;
    viaVidEng->video3_size = localVidEng->video3_size;
    viaVidEng->v3alpha_fetch = localVidEng->v3alpha_fetch;
    viaVidEng->video3_zoom = localVidEng->video3_zoom;
    viaVidEng->video3_mictl = localVidEng->video3_mictl;
    viaVidEng->video3_CSC1 = localVidEng->video3_CSC1;
    viaVidEng->video3_CSC2 = localVidEng->video3_CSC2;
    viaVidEng->compose = localVidEng->compose;
#if 0
    if (pVia->ChipId != PCI_CHIP_VT3314)
        viaVidEng->compose |= V1_COMMAND_FIRE;    /*fire V3 */
    viaVidEng->compose |= V3_COMMAND_FIRE;
#endif
}

void
viaSaveHqv(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    volatile hqv_via_regs *viaHqvEng = NULL;
    hqv_via_regs *localHqvEng0 = &pVia->HqvSaved[0];
    hqv_via_regs *localHqvEng1 = &pVia->HqvSaved[1];

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    localHqvEng0->subp_ctl = INREG(0x3c0);
    localHqvEng0->subp_addr = INREG(0x3c4);
    localHqvEng0->subp_palette = INREG(0x3c8);
    localHqvEng0->src_data_offset = INREG(0x3cc);
    localHqvEng0->src_y = INREG(0x3d4);
    localHqvEng0->src_u = INREG(0x3d8);
    localHqvEng0->misc_ctl = INREG(0x3dc);
    localHqvEng0->src_linefetch = INREG(0x3e0);
    localHqvEng0->mad_ctl = INREG(0x3e4);
    localHqvEng0->scal_ctl = INREG(0x3e8);
    localHqvEng0->dst_addr0 = INREG(0x3ec);
    localHqvEng0->dst_addr1 = INREG(0x3f0);
    localHqvEng0->dst_stride = INREG(0x3f4);
    localHqvEng0->src_stride_flip = INREG(0x3f8);
    localHqvEng0->dst_addr2 = INREG(0x3fc);
    localHqvEng0->hqv_ctl = INREG(0x3d0);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Hqv0Saved.hqv_ctl:%lx\n",
        localHqvEng0->hqv_ctl);

    if (pVia->ChipId != PCI_CHIP_VT3314) {

        localHqvEng1->subp_ctl = INREG(0x13c0);
        localHqvEng1->subp_addr = INREG(0x13c4);
        localHqvEng1->subp_palette = INREG(0x13c8);
        localHqvEng1->src_data_offset = INREG(0x13cc);
        localHqvEng1->src_y = INREG(0x13d4);
        localHqvEng1->src_u = INREG(0x13d8);
        localHqvEng1->misc_ctl = INREG(0x13dc);
        localHqvEng1->src_linefetch = INREG(0x13e0);
        localHqvEng1->mad_ctl = INREG(0x13e4);
        localHqvEng1->scal_ctl = INREG(0x13e8);
        localHqvEng1->dst_addr0 = INREG(0x13ec);
        localHqvEng1->dst_addr1 = INREG(0x13f0);
        localHqvEng1->dst_stride = INREG(0x13f4);
        localHqvEng1->src_stride_flip = INREG(0x13f8);
        localHqvEng1->dst_addr2 = INREG(0x13fc);
        localHqvEng1->hqv_ctl = INREG(0x13d0);

        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Hqv1Saved.hqv_ctl:%lx\n",
            localHqvEng1->hqv_ctl);
    }
}

void
viaRestoreHqv(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    volatile hqv_via_regs *viaHqvEng = NULL;
    hqv_via_regs *localHqvEng0 = &pVia->HqvSaved[0];
    hqv_via_regs *localHqvEng1 = &pVia->HqvSaved[1];

    viaHqvEng = (volatile hqv_via_regs *)(pVia->VidMapBase + 0x1c0);

    /*flush all HQV0 settings to start address 0x3c0 */
    OUTREG(0x3c0, localHqvEng0->subp_ctl);
    OUTREG(0x3c4, localHqvEng0->subp_addr);
    OUTREG(0x3c8, localHqvEng0->subp_palette);
    OUTREG(0x3cc, localHqvEng0->src_data_offset);
    OUTREG(0x3d4, localHqvEng0->src_y);
    OUTREG(0x3d8, localHqvEng0->src_u);
    OUTREG(0x3dc, localHqvEng0->misc_ctl);
    OUTREG(0x3e0, localHqvEng0->src_linefetch);
    OUTREG(0x3e4, localHqvEng0->mad_ctl);
    OUTREG(0x3e8, localHqvEng0->scal_ctl);
    OUTREG(0x3ec, localHqvEng0->dst_addr0);
    OUTREG(0x3f0, localHqvEng0->dst_addr1);
    OUTREG(0x3f4, localHqvEng0->dst_stride);
    OUTREG(0x3f8, localHqvEng0->src_stride_flip);
    OUTREG(0x3fc, localHqvEng0->dst_addr2);
    OUTREG(0x3d0, localHqvEng0->hqv_ctl);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Hqv0 hqv_ctl:%lx\n",
    viaHqvEng->hqv_ctl);

    if (pVia->ChipId != PCI_CHIP_VT3314) {

        OUTREG(0x13c0, localHqvEng1->subp_ctl);
        OUTREG(0x13c4, localHqvEng1->subp_addr);
        OUTREG(0x13c8, localHqvEng1->subp_palette);
        OUTREG(0x13cc, localHqvEng1->src_data_offset);
        OUTREG(0x13d4, localHqvEng1->src_y);
        OUTREG(0x13d8, localHqvEng1->src_u);
        OUTREG(0x13dc, localHqvEng1->misc_ctl);
        OUTREG(0x13e0, localHqvEng1->src_linefetch);
        OUTREG(0x13e4, localHqvEng1->mad_ctl);
        OUTREG(0x13e8, localHqvEng1->scal_ctl);
        OUTREG(0x13ec, localHqvEng1->dst_addr0);
        OUTREG(0x13f0, localHqvEng1->dst_addr1);
        OUTREG(0x13f4, localHqvEng1->dst_stride);
        OUTREG(0x13f8, localHqvEng1->src_stride_flip);
        OUTREG(0x13fc, localHqvEng1->dst_addr2);
        OUTREG(0x13d0, localHqvEng1->hqv_ctl);

        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Hqv1 hqv_ctl:%lx\n",
            viaHqvEng->hqv_ctl);
    }

}

void
viaExitVideo(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    volatile video_via_regs *viaVidEng = NULL;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    /*destroy XV reserved memory structure here. */

    viaVidEng = (volatile video_via_regs *)pVia->VidMapBase;
    viaVidEng->video1_ctl = 0;
    viaVidEng->video3_ctl = 0;
    viaVidEng->compose = V1_COMMAND_FIRE;
    viaVidEng->compose = V3_COMMAND_FIRE;
}

static char *XvAdaptorName[XV_ADAPT_NUM] = {
    "XV_SWOV",
    "XV_TEXTURE"
};

static char *XVOVERLAYPORTNAME[XV_PORT_NUM_OVERLAY] = {
    "XV_SWOV0",
    "XV_SWOV1"
};

static char *XVTEXVIDEOPORTNAME[XV_PORT_NUM_TEXTURE] = {
    "XV_TEXTURE0",
    "XV_TEXTURE1",
    "XV_TEXTURE2",
    "XV_TEXTURE3",
    "XV_TEXTURE4",
    "XV_TEXTURE5",
    "XV_TEXTURE6",
    "XV_TEXTURE7",
    "XV_TEXTURE8",
    "XV_TEXTURE9",
    "XV_TEXTURE10",
    "XV_TEXTURE11",
    "XV_TEXTURE12",
    "XV_TEXTURE13",
    "XV_TEXTURE14",
    "XV_TEXTURE15"
};

static XF86VideoAdaptorPtr viaAdaptPtr[XV_ADAPT_NUM];
static viaPortPrivRec *gviaPortPriv[XV_ADAPT_NUM][XV_SCREEN_NUM];
static unsigned numAdaptPort[XV_ADAPT_NUM] =
    { XV_PORT_NUM_OVERLAY, XV_PORT_NUM_TEXTURE };
extern Bool noPanoramiXExtension;
static BlockHandlerProcPtr video_blockhandle;

static void
FillViaGfxMemInfo(ScrnInfoPtr pScrn)
{

    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    DBG_DD(("enter %s \n \n", __func__));
    viaGfxInfo->chipId = pVia->ChipId;
    viaGfxInfo->revisionId = pVia->ChipRev;
    viaGfxInfo->fbPhybase = pVia->FrameBufferBase;
    viaGfxInfo->mmioPhybase = pVia->MmioBase;
    viaGfxInfo->mmioSize = VIA_MMIO_REGSIZE;
    viaGfxInfo->fbSize = pVia->videoRambytes;
    viaGfxInfo->vramsize = pVia->videoRambytes;
    viaGfxInfo->vheapbase = (unsigned long)pVia->FBFreeStart;
    viaGfxInfo->vheapend = (unsigned long)pVia->FBFreeEnd;
    viaGfxInfo->drmEnabled = TRUE;
    viaGfxInfo->xrandrEnabled = TRUE;
    if (pVia->RotateDegree != VIA_ROTATE_DEGREE_0) {
        viaGfxInfo->hwIconEnalbed = TRUE;
    } else {
        viaGfxInfo->hwIconEnalbed = FALSE;
    }
}

static int
RelationOfIGA1andIGA2(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    xf86CrtcPtr crtc[2];
    int i = 0, j = 0;
    int crtcWidth[2];
    int crtcHeight[2];
    int posX[2];
    int posY[2];
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);

    for (i = 0; i < xf86_config->num_crtc; i++) {
        /*we get relation of two crtc.
         *If two outputs connect to one crtc, we don't consider this case.
         *Maybe, in video view clone is not the same as xrandr itself*/
        if (xf86_config->crtc[i]) {
            crtc[i] = xf86_config->crtc[i];
            posX[i] = crtc[i]->x;
            posY[i] = crtc[i]->y;
            j++;
        }
    }
    /*only one crtc, also means only one iga. */
    if (j == 1) {
        return RELATION_NONE;
    }
    if ((posX[0] == posX[1]) && (posY[1] == posY[0])) {
        return RELATION_SAME_OF;
    }
    if (posX[0] > posX[1]) {
        return RELATION_LEFT_OF;
    } else if (posX[0] < posX[1]) {
        return RELATION_RIGHT_OF;
    } else if (posY[0] > posY[1]) {
        return RELATION_ABOVE_OF;
    } else if (posY[0] < posY[1]) {
        return RELATION_BELOW_OF;
    }
    return RELATION_OVERLAP_OF;
}

static void
GetScrnAndIgaAttr(ScrnInfoPtr pScrn)
{

    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
    int i = 0;

    DBG_DD(("enter %s \n \n", __func__));
    /*only in samm, there is secondary screen. viaScrnIndex is always 0 under xrandr */
    int viaScrnIndex = 0;

    if (pVia->IsSecondary) {
        viaScrnIndex = 1;
    }

    memset(&(viaGfxInfo->screenAttr), 0x0, sizeof(viaGfxInfo->screenAttr));
    memset(&(viaGfxInfo->igaAttr), 0x0, sizeof(viaGfxInfo->igaAttr));
    /*get the relationship of iga1 and iga2 */
    switch (RelationOfIGA1andIGA2(pScrn)) {
    case RELATION_RIGHT_OF:
        viaGfxInfo->igaAttr.iga2_right = TRUE;
        break;
    case RELATION_LEFT_OF:
        viaGfxInfo->igaAttr.iga2_left = TRUE;
        break;
    case RELATION_ABOVE_OF:
        viaGfxInfo->igaAttr.iga2_above = TRUE;
        break;
    case RELATION_BELOW_OF:
        viaGfxInfo->igaAttr.iga2_below = TRUE;
        break;
    case RELATION_OVERLAP_OF:
        viaGfxInfo->igaAttr.overlapped = TRUE;
        break;
    }
    for (i = 0; i < xf86_config->num_crtc; i++) {
        if (xf86_config->crtc[i]) {
            if (xf86CrtcInUse(xf86_config->crtc[i])) {
                viaGfxInfo->igaInfo[i].actived = TRUE;
            } else {
                viaGfxInfo->igaInfo[i].actived = FALSE;
            }
        }
    }
    if (viaGfxInfo->igaInfo[0].actived && viaGfxInfo->igaInfo[1].actived) {
        if (viaGfxInfo->igaAttr.uint) {
            viaGfxInfo->screenAttr.uint = VIA_EXTEND;
        } else {
            viaGfxInfo->screenAttr.uint = VIA_CLONE;
        }
    } else {
        viaGfxInfo->screenAttr.uint = VIA_SINGLEVIEW;
    }
}

static void
GetScrnInfo(ScrnInfoPtr pScrn)
{

    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
    xf86CrtcPtr crtc[2];
    int i = 0;

    DBG_DD(("enter %s \n \n", __func__));
    /*under xrandr viaScrnIndex is always 0 */
    int viaScrnIndex = 0;

    if (pVia->IsSecondary) {
        viaScrnIndex = 1;
    }
    viaGfxInfo->screenInfo[viaScrnIndex].igaInuse = 0;
    viaGfxInfo->screenInfo[viaScrnIndex].bpp = pScrn->bitsPerPixel;
    viaGfxInfo->screenInfo[viaScrnIndex].rotatetype = pVia->rotateType;
    viaGfxInfo->screenInfo[viaScrnIndex].fboffset_rot = pScrn->fbOffset;
    for (i = 0; i < xf86_config->num_crtc; i++) {
        if (xf86_config->crtc[i]) {
            crtc[i] = xf86_config->crtc[i];
            /*if there is crtc0, we think iga1 is in use.
             *if there is crtc1, we think iga2 is in use.*/
            if (0 == i && xf86CrtcInUse(crtc[i])) {
                viaGfxInfo->screenInfo[viaScrnIndex].igaInuse |= IGA1;
            } else if (1 == i && xf86CrtcInUse(crtc[i])) {
                viaGfxInfo->screenInfo[viaScrnIndex].igaInuse |= IGA2;
            }
        }
    }

    DBG_DD(("screenInfo[%d] igaInuse = %ld\n", viaScrnIndex,
        viaGfxInfo->screenInfo[0].igaInuse));
}

/*GetActiveDevice should be rewrite because these names have changed in KMS*/
static ActiveDeviceRec
GetActiveDevice(char *pname)
{
    ActiveDeviceRec activeDevice;

    activeDevice.unit = 0;
    if (!xf86NameCmp(pname, "CRT") || !xf86NameCmp(pname, "VGA-1"))
        activeDevice.crt = TRUE;

    if (!xf86NameCmp(pname, "CRT-2") || !xf86NameCmp(pname, "VGA-2"))
        activeDevice.crt2 = TRUE;

    if (!xf86NameCmp(pname, "LCD") || !xf86NameCmp(pname, "LVDS-1"))
        activeDevice.lcd = TRUE;

    if (!xf86NameCmp(pname, "LCD-2") || !xf86NameCmp(pname, "LVDS-2"))
        activeDevice.lcd2 = TRUE;

    if (!xf86NameCmp(pname, "DVI") || !xf86NameCmp(pname, "DVI-1"))
        activeDevice.dvi = TRUE;

    if (!xf86NameCmp(pname, "DVI-2"))
        activeDevice.dvi2 = TRUE;

    if (!xf86NameCmp(pname, "TV") || !xf86NameCmp(pname, "TV-1"))
        activeDevice.tv = TRUE;

    if (!xf86NameCmp(pname, "TV-2"))
        activeDevice.tv2 = TRUE;

    if (!xf86NameCmp(pname, "HDMI") || !xf86NameCmp(pname, "HDMI-1"))
        activeDevice.hdmi = TRUE;

    if (!xf86NameCmp(pname, "HDMI-2"))
        activeDevice.hdmi2 = TRUE;

    if (!xf86NameCmp(pname, "DP") || !xf86NameCmp(pname, "DP-1"))
        activeDevice.dp = TRUE;

    if (!xf86NameCmp(pname, "DP-2"))
        activeDevice.dp2 = TRUE;

    return activeDevice;
}

static int
GetLCDPanelSize(xf86OutputPtr output, int *width, int *height)
{
    char *s = NULL, *b = NULL;
    ViaLcdPrivateInfoPtr lcdPriv;

    DBG_DD(("enter %s\n", __func__));

    s = xf86GetOptValString(VIAOptions, OPTION_LCD_PANEL_SIZE);
    if (s) {
        b = strdup(s);
        s = strtok(b, "x");
        *width = (CARD32) atoi(s);
        s = strtok(NULL, "x");
        *height = (CARD32) atoi(s);
    } else {
        lcdPriv = (ViaLcdPrivateInfoPtr) (output->driver_private);
        *width = lcdPriv->commonInfo.physicalWidth;
        *height = lcdPriv->commonInfo.physicalHeight;
    }

    DBG_DD(("%s width = %d, height = %d\n", __func__, *width, *height));
    return 0;
}

static ActiveDeviceRec
GetCrtcActiveDeviceInfo(xf86CrtcPtr crtc, int *width, int *height)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
    ActiveDeviceRec activeDevice;
    int i = 0;

    for (i = 0; i < xf86_config->num_output; i++) {
        xf86OutputPtr output = xf86_config->output[i];

        if (output->crtc != crtc)
            continue;

        activeDevice = GetActiveDevice(output->name);
        if (strstr(output->name, "LCD") || strstr(output->name, "LVDS")) {
            DBG_DD(("lcd is active\n"));
            drm_get_lvds_physical_size(output, width, height);
        } else {
            *width = crtc->mode.HDisplay;
            *height = crtc->mode.VDisplay;
        }

        return activeDevice;
    }
}

static void
GetIgaInfo(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
    xf86CrtcPtr crtc[2];
    int i = 0, j = 0;
    ActiveDeviceRec activeDevice;
    Rotation rotateMask =
    RR_Rotate_0 | RR_Rotate_90 | RR_Rotate_270 | RR_Rotate_180;
    Rotation reflectMask = RR_Reflect_X | RR_Reflect_Y;

    char *s = NULL, *b = NULL;
    int crtc_width, crtc_height;

    DBG_DD(("enter %s \n \n", __func__));

    for (i = 0; i < xf86_config->num_crtc; i++) {
        crtc[i] = xf86_config->crtc[i];
        if (xf86CrtcInUse(crtc[i])) {
            DBG_DD(("crtc[%d] is active\n", i));
            viaGfxInfo->igaInfo[i].actived = TRUE;
            DBG_DD(("viaGfxInfo->igaInfo[i].actived = %d\n",
                viaGfxInfo->igaInfo[i].actived));
            /*TODO: if I can use this method to get activeDevice?
             *one crtc may has one or more output, activeDevice represent
             *the first one found. It is not the same as old path, in old path
             *iga and output is 1 to 1 relationship. */

            activeDevice =
                GetCrtcActiveDeviceInfo(crtc[i], &crtc_width, &crtc_height);

            viaGfxInfo->igaInfo[i].activeDevice = activeDevice;
            viaGfxInfo->igaInfo[i].crtc_width = crtc_width;
            viaGfxInfo->igaInfo[i].crtc_height = crtc_height;
            DBG_DD(("iga[%d] crtc_width=%ld, crtc_height=%ld\n", i,
                viaGfxInfo->igaInfo[i].crtc_width,
                viaGfxInfo->igaInfo[i].crtc_height));
            /*width/height of dedired, scale, visible are common as for all devices. */

            viaGfxInfo->igaInfo[i].desired_width =
                crtc[i]->desiredMode.HDisplay;
            viaGfxInfo->igaInfo[i].desired_height =
                crtc[i]->desiredMode.VDisplay;
            DBG_DD(("iga[%d] desired_width=%ld, desired_height=%ld\n", i,
                viaGfxInfo->igaInfo[i].desired_width,
                viaGfxInfo->igaInfo[i].desired_height));
            if ((viaGfxInfo->igaInfo[i].desired_width <
                viaGfxInfo->igaInfo[i].crtc_width)
                || (viaGfxInfo->igaInfo[i].desired_height <
                viaGfxInfo->igaInfo[i].crtc_height)) {
                viaGfxInfo->igaInfo[i].igaStatus.expanded = TRUE;
            } else {
                viaGfxInfo->igaInfo[i].igaStatus.expanded = FALSE;
            }
            if ((viaGfxInfo->igaInfo[i].desired_width >
                viaGfxInfo->igaInfo[i].crtc_width)
                || (viaGfxInfo->igaInfo[i].desired_height >
                viaGfxInfo->igaInfo[i].crtc_height)) {
                viaGfxInfo->igaInfo[i].igaStatus.scaling_hw = TRUE;
            } else {
                viaGfxInfo->igaInfo[i].igaStatus.scaling_hw = FALSE;
            }
#if GET_ABI_MAJOR(ABI_EXTENSION_VERSION) >= 2
            if (crtc[i]->transformPresent) {
                HW3D_Scaling_INFO *pgfx3DScal_info = NULL;

                viaGfxInfo->igaInfo[i].igaStatus.scaling_3d = TRUE;
                pgfx3DScal_info =
                    &(viaGfxInfo->igaInfo[i].igagfx3DScaling_info);
                pgfx3DScal_info->DISP3DScalIGAPath = (i == 0) ? IGA1 : IGA2;
                pgfx3DScal_info->gfx3DScalingEnable = TRUE;
                pgfx3DScal_info->RealHActive =
                    viaGfxInfo->igaInfo[i].desired_width;
                pgfx3DScal_info->RealVActive =
                    viaGfxInfo->igaInfo[i].desired_height;
                RRCrtcGetScanoutSize(crtc[i]->randr_crtc,
                    &(pgfx3DScal_info->OrigHActive),
                    &(pgfx3DScal_info->OrigVActive));
                viaGfxInfo->igaInfo[i].scale_width =
                    pgfx3DScal_info->OrigHActive;
                viaGfxInfo->igaInfo[i].scale_height =
                    pgfx3DScal_info->OrigVActive;
            } else {
            viaGfxInfo->igaInfo[i].scale_width =
                viaGfxInfo->igaInfo[i].desired_width;
            viaGfxInfo->igaInfo[i].scale_height =
                viaGfxInfo->igaInfo[i].desired_height;
            }
#endif
            if (crtc[i]->transform_in_use) {
                HW3D_Scaling_INFO *pgfx3DScal_info = NULL;

                pgfx3DScal_info =
                    &(viaGfxInfo->igaInfo[i].igagfx3DScaling_info);
                RRCrtcGetScanoutSize(crtc[i]->randr_crtc,
                    &(pgfx3DScal_info->OrigHActive),
                    &(pgfx3DScal_info->OrigVActive));
                viaGfxInfo->igaInfo[i].scale_width =
                    pgfx3DScal_info->OrigHActive;
                viaGfxInfo->igaInfo[i].scale_height =
                    pgfx3DScal_info->OrigVActive;
            }
            viaGfxInfo->igaInfo[i].start_x = crtc[i]->x;
            viaGfxInfo->igaInfo[i].start_y = crtc[i]->y;
            DBG_DD(("iga[%d] start_x=%ld, start_y=%ld\n", i,
                viaGfxInfo->igaInfo[i].start_x,
                viaGfxInfo->igaInfo[i].start_y));
            /*what refreshrate means? */
            viaGfxInfo->igaInfo[i].refreshrate = crtc[i]->mode.VRefresh;

            /*Get iga rotate info */
            memset(&(viaGfxInfo->igaInfo[i].igaRRStatus), 0x0,
                sizeof(viaGfxInfo->igaInfo[i].igaRRStatus));
            switch (crtc[i]->rotation & rotateMask) {
            case RR_Rotate_90:
                viaGfxInfo->igaInfo[i].igaRRStatus.rotate_270 = TRUE;
                break;
            case RR_Rotate_180:
                viaGfxInfo->igaInfo[i].igaRRStatus.rotate_180 = TRUE;
                break;
            case RR_Rotate_270:
                viaGfxInfo->igaInfo[i].igaRRStatus.rotate_90 = TRUE;
                break;
            }
            /*Get iga reflect info */
            switch (crtc[i]->rotation & reflectMask) {
            case RR_Reflect_X:
                viaGfxInfo->igaInfo[i].igaRRStatus.reflect_x = TRUE;
                break;
            case RR_Reflect_Y:
                viaGfxInfo->igaInfo[i].igaRRStatus.reflect_y = TRUE;
                break;
            case RR_Reflect_X | RR_Reflect_Y:
                viaGfxInfo->igaInfo[i].igaRRStatus.reflect_x = TRUE;
                viaGfxInfo->igaInfo[i].igaRRStatus.reflect_y = TRUE;
                break;
            default:
                break;
            }
            /*
             * simplify igaRRStatus info for xy reflection. It equals to 180 degree
             * rotation in addtion to original rotation degree at nature
             */
            if ((viaGfxInfo->igaInfo[i].igaRRStatus.reflect_x == TRUE) &&
                (viaGfxInfo->igaInfo[i].igaRRStatus.reflect_y == TRUE)) {
                switch (crtc[i]->rotation & rotateMask) {
                case RR_Rotate_0:
                    viaGfxInfo->igaInfo[i].igaRRStatus.rotate_180 = TRUE;
                    break;
                case RR_Rotate_90:
                    viaGfxInfo->igaInfo[i].igaRRStatus.rotate_90 = TRUE;
                    viaGfxInfo->igaInfo[i].igaRRStatus.rotate_270 = FALSE;
                    break;
                case RR_Rotate_180:
                    viaGfxInfo->igaInfo[i].igaRRStatus.rotate_180 = FALSE;
                    break;
                case RR_Rotate_270:
                    viaGfxInfo->igaInfo[i].igaRRStatus.rotate_90 = FALSE;
                    viaGfxInfo->igaInfo[i].igaRRStatus.rotate_270 = TRUE;
                    break;
                }
                viaGfxInfo->igaInfo[i].igaRRStatus.reflect_x = FALSE;
                viaGfxInfo->igaInfo[i].igaRRStatus.reflect_y = FALSE;
            }
            /*if we do left or right rotate, we need to exchange the HDisplay VDisplay update to video */
            if ((viaGfxInfo->igaInfo[i].igaRRStatus.rotate_90)
                || (viaGfxInfo->igaInfo[i].igaRRStatus.rotate_270)) {
                viaGfxInfo->igaInfo[i].visible_width = crtc[i]->mode.VDisplay;
                viaGfxInfo->igaInfo[i].visible_height =
                    crtc[i]->mode.HDisplay;
                viaGfxInfo->igaInfo[i].scale_width =
                    viaGfxInfo->igaInfo[i].igagfx3DScaling_info.OrigVActive;
                viaGfxInfo->igaInfo[i].scale_height =
                    viaGfxInfo->igaInfo[i].igagfx3DScaling_info.OrigHActive;
                viaGfxInfo->igaInfo[i].igagfx3DScaling_info.OrigVActive =
                    viaGfxInfo->igaInfo[i].scale_height;
                viaGfxInfo->igaInfo[i].igagfx3DScaling_info.OrigHActive =
                viaGfxInfo->igaInfo[i].scale_width;

            } else {
                viaGfxInfo->igaInfo[i].visible_width = crtc[i]->mode.HDisplay;
                viaGfxInfo->igaInfo[i].visible_height =
                    crtc[i]->mode.VDisplay;
            }
            if ((viaGfxInfo->igaInfo[i].scale_width ==
                viaGfxInfo->igaInfo[i].desired_width)
                && (viaGfxInfo->igaInfo[i].scale_height ==
                viaGfxInfo->igaInfo[i].desired_height)) {
                viaGfxInfo->igaInfo[i].igagfx3DScaling_info.
                    gfx3DScalingEnable = FALSE;
            }
            DBG_DD(("iga[%d] scale_width=%ld, scale_height=%ld\n", i,
                viaGfxInfo->igaInfo[i].scale_width,
                viaGfxInfo->igaInfo[i].scale_height));
            DBG_DD(("iga[%d] visible_width=%ld, visible_height=%ld\n", i,
                viaGfxInfo->igaInfo[i].visible_width,
                viaGfxInfo->igaInfo[i].visible_height));
        }
    }
}

static void
GetSrcnAndIgaInfo(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);

    DBG_DD(("enter %s \n \n", __func__));
    GetScrnInfo(pScrn);
    GetIgaInfo(pScrn);
}

static void
GetViaGfxInfo(ScrnInfoPtr pScrn)
{
    int i;
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    DBG_DD(("enter %s \n \n", __func__));
    FillViaGfxMemInfo(pScrn);
    GetScrnAndIgaAttr(pScrn);
    GetSrcnAndIgaInfo(pScrn);
}

#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
void
viaGfxInfoBlockHandler(int screenNum, pointer blockData,
    pointer pTimeout, pointer pReadmask)
#else
void
viaGfxInfoBlockHandler(ScreenPtr pScreen,
    pointer pTimeout, pointer pReadmask)
#endif
{
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
    ScrnInfoPtr pScrn = xf86Screens[screenNum];
    ScreenPtr pScreen = screenInfo.screens[screenNum];
#else
	ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
#endif
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
    VIAPtr pVia = VIAPTR(pScrn);
    int i;

    ///////////////////////do something here/////////////////////////
    if (pVia->crtc_info_changed) {
        DBG_DD(("enter %s \n \n", __func__));
        GetViaGfxInfo(pScrn);
        for (i = 0; i < xf86_config->num_crtc; i++) {
            if (xf86_config->crtc[i]) {
                if (xf86CrtcInUse(xf86_config->crtc[i])) {
                    VIARandR12UpdateOverlay(pScrn->scrnIndex,
                        xf86_config->crtc[i]->x, xf86_config->crtc[i]->y, 0);
                    break;
                }
            }
        }
        pVia->crtc_info_changed = FALSE;
    }
    pScreen->BlockHandler = video_blockhandle;
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
    (*pScreen->BlockHandler) (screenNum, blockData, pTimeout, pReadmask);
#else
	(*pScreen->BlockHandler) (pScreen, pTimeout, pReadmask);
#endif
    video_blockhandle = pScreen->BlockHandler;

    pScreen->BlockHandler = viaGfxInfoBlockHandler;
}

void
viaInitVideo(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    XF86VideoAdaptorPtr *adaptors, *allAdaptors = NULL;
    XF86VideoAdaptorPtr newAdaptors[XV_ADAPT_NUM] = { NULL, NULL };
    int num_newAdaptors = 0;

    int num_adaptors;

    video_blockhandle = pScreen->BlockHandler;
    pScreen->BlockHandler = viaGfxInfoBlockHandler;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));
    DBG_DD(("  Screen[%d]\n", pScrn->scrnIndex));

    num_adaptors = xf86XVListGenericAdaptors(pScrn, &adaptors);
    DBG_DD(("  num_adaptors : %d\n", num_adaptors));

    num_newAdaptors = viaSetupImageVideoG(pScreen, &newAdaptors[0]);
    num_newAdaptors +=
        viaSetupImageVideoTextureG(pScreen, &newAdaptors[num_newAdaptors]);

    if (num_newAdaptors) {
        if (!num_adaptors) {
            num_adaptors = num_newAdaptors;
            allAdaptors =
                (XF86VideoAdaptorPtr *) malloc((num_newAdaptors) *
                sizeof(XF86VideoAdaptorPtr));
            memcpy(allAdaptors, newAdaptors,
                num_newAdaptors * sizeof(XF86VideoAdaptorPtr));
        } else {
            DBG_DD(("  Warning !!! MDS not supported yet !\n"));
            allAdaptors =
                (XF86VideoAdaptorPtr *) malloc((num_adaptors +
                num_newAdaptors) * sizeof(XF86VideoAdaptorPtr));
            if (allAdaptors) {
                memcpy(allAdaptors, adaptors,
                    num_adaptors * sizeof(XF86VideoAdaptorPtr));
                memcpy(allAdaptors + num_adaptors, newAdaptors,
                    num_newAdaptors * sizeof(XF86VideoAdaptorPtr));
                num_adaptors += num_newAdaptors;
            }
        }
    }

    if (num_adaptors)
        xf86XVScreenInit(pScreen, allAdaptors, num_adaptors);

    if (allAdaptors)
        free(allAdaptors);
}

static int
viaSetupImageVideoG(ScreenPtr pScreen, XF86VideoAdaptorPtr *adaptorPtr)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    DevUnion *pdevUnion;
    int i;

    int num_overlay_ports = numAdaptPort[XV_ADAPT_OVERLAY];
    int viaScrnIndex = 0;

    if (pScreen->myNum && noPanoramiXExtension) {
        viaScrnIndex = 1;
    }

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));
    DBG_DD(("  Screen[%d]\n", pScrn->scrnIndex));

    xvBrightness = MAKE_ATOM("XV_BRIGHTNESS");
    xvContrast = MAKE_ATOM("XV_CONTRAST");
    xvSaturation = MAKE_ATOM("XV_SATURATION");
    xvHue = MAKE_ATOM("XV_HUE");
    xvOverlayStatus = MAKE_ATOM("XV_OVERLAYSTATUS");
    xvColorKey = MAKE_ATOM("XV_COLORKEY");
    xv_autopaint_colorkey = MAKE_ATOM("XV_AUTOPAINT_COLORKEY");

    if (!(viaAdaptPtr[XV_ADAPT_OVERLAY] =
        xf86XVAllocateVideoAdaptorRec(pScrn)))
    return 0;

    if (gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] == NULL) {
        gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] =
            (viaPortPrivPtr) calloc(num_overlay_ports,
            sizeof(viaPortPrivRec));
    }

    pdevUnion = (DevUnion *) calloc(num_overlay_ports, sizeof(DevUnion));

    viaAdaptPtr[XV_ADAPT_OVERLAY]->type =
        XvInputMask | XvWindowMask | XvImageMask | XvVideoMask | XvStillMask;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->flags =
        VIDEO_OVERLAID_IMAGES | VIDEO_CLIP_TO_VIEWPORT;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->name = XvAdaptorName[XV_ADAPT_OVERLAY];
    viaAdaptPtr[XV_ADAPT_OVERLAY]->nEncodings = 1;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->pEncodings = DummyEncoding;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->nFormats =
        sizeof(FormatsG) / sizeof(FormatsG[0]);
    viaAdaptPtr[XV_ADAPT_OVERLAY]->pFormats = FormatsG;

    viaAdaptPtr[XV_ADAPT_OVERLAY]->nPorts = num_overlay_ports;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->pPortPrivates = pdevUnion;

    viaAdaptPtr[XV_ADAPT_OVERLAY]->nAttributes = NUM_ATTRIBUTES_G;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->pAttributes = AttributesG;

    viaAdaptPtr[XV_ADAPT_OVERLAY]->nImages = NUM_IMAGES_G;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->pImages = ImagesG;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->PutVideo = NULL;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->PutStill = NULL;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->GetVideo = NULL;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->GetStill = NULL;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->StopVideo = viaStopVideoG;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->SetPortAttribute = viaSetPortAttributeG;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->GetPortAttribute = viaGetPortAttributeG;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->QueryBestSize = viaQueryBestSizeG;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->PutImage = viaPutImageG;

    /* On FC7, gnome, fvwm, blackbox, SAMM, xv path, move video window X crash, KDE OK.
     *adaptPtr[i]->ReputImage= viaReputImageG;
     */
    viaAdaptPtr[XV_ADAPT_OVERLAY]->ReputImage = 0;
    viaAdaptPtr[XV_ADAPT_OVERLAY]->QueryImageAttributes =
        viaQueryImageAttributesG;

    for (i = 0; i < num_overlay_ports; i++) {
        (pdevUnion + i)->ptr =
            (pointer) (gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] + i);
        (gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] + i)->xv_adaptnum =
            XV_ADAPT_OVERLAY;
        (gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] + i)->xv_portnum = i;
        (gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] + i)->xv_portname =
            XVOVERLAYPORTNAME[i];
        (gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] + i)->textured = FALSE;
        (gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] + i)->framenum = 0;

        (gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] + i)->colorKey =
            (pVia->xvColorKey - i);
        (gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] + i)->brightness = 5000;
        (gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] + i)->saturation =
            10000;
        (gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] + i)->contrast = 10000;
        (gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] + i)->hue = 0;
        (gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] +
            i)->autopaint_colorkey = TRUE;

        REGION_NULL(pScreen,
            &(gviaPortPriv[XV_ADAPT_OVERLAY][viaScrnIndex] + i)->clip);
    }

    viaResetVideo(pScrn);

    *adaptorPtr = viaAdaptPtr[XV_ADAPT_OVERLAY];
    return 1;

}

static int
viaSetupImageVideoTextureG(ScreenPtr pScreen,
    XF86VideoAdaptorPtr *adaptorPtr)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    DevUnion *pdevUnion;
    int i;

    int num_texture_ports = numAdaptPort[XV_ADAPT_TEXTURE];
    int viaScrnIndex = 0;

    if (pScreen->myNum && noPanoramiXExtension) {
        viaScrnIndex = 1;
    }

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));
    DBG_DD(("  Screen[%d]\n", pScrn->scrnIndex));

    xvBrightness = MAKE_ATOM("XV_BRIGHTNESS");
    xvContrast = MAKE_ATOM("XV_CONTRAST");
    xvSaturation = MAKE_ATOM("XV_SATURATION");
    xvHue = MAKE_ATOM("XV_HUE");

    if (!(viaAdaptPtr[XV_ADAPT_TEXTURE] =
        xf86XVAllocateVideoAdaptorRec(pScrn)))
    return 0;

    if (gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] == NULL) {
        gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] =
            (viaPortPrivPtr) calloc(num_texture_ports,
            sizeof(viaPortPrivRec));
    }

    pdevUnion = (DevUnion *) calloc(num_texture_ports, sizeof(DevUnion));

    viaAdaptPtr[XV_ADAPT_TEXTURE]->type =
        XvInputMask | XvWindowMask | XvImageMask;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->flags =
        VIDEO_OVERLAID_IMAGES | VIDEO_CLIP_TO_VIEWPORT;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->name = XvAdaptorName[XV_ADAPT_TEXTURE];
    viaAdaptPtr[XV_ADAPT_TEXTURE]->nEncodings = 1;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->pEncodings = DummyEncoding;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->nFormats =
        sizeof(FormatsG) / sizeof(FormatsG[0]);
    viaAdaptPtr[XV_ADAPT_TEXTURE]->pFormats = FormatsG;

    viaAdaptPtr[XV_ADAPT_TEXTURE]->nPorts = num_texture_ports;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->pPortPrivates = pdevUnion;

    viaAdaptPtr[XV_ADAPT_TEXTURE]->nAttributes = NUM_ATTRIBUTES_G_TEXTURE;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->pAttributes = AttributesG_TEXTURE;

    viaAdaptPtr[XV_ADAPT_TEXTURE]->nImages = NUM_IMAGES_G;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->pImages = ImagesG;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->PutVideo = NULL;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->PutStill = NULL;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->GetVideo = NULL;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->GetStill = NULL;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->StopVideo = viaStopVideoG;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->SetPortAttribute = viaSetPortAttributeG;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->GetPortAttribute = viaGetPortAttributeG;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->QueryBestSize = viaQueryBestSizeG;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->PutImage = viaPutImageTexturedG;

    viaAdaptPtr[XV_ADAPT_TEXTURE]->ReputImage = 0;
    viaAdaptPtr[XV_ADAPT_TEXTURE]->QueryImageAttributes =
        viaQueryImageAttributesG;

    for (i = 0; i < num_texture_ports; i++) {
        (pdevUnion + i)->ptr =
            (pointer) (gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] + i);
        (gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] + i)->xv_adaptnum =
            XV_ADAPT_TEXTURE;
        (gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] + i)->xv_portnum = i;
        (gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] + i)->xv_portname =
            XVTEXVIDEOPORTNAME[i];
        (gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] + i)->textured = TRUE;
        (gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] + i)->framenum = 0;

        (gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] + i)->colorKey = 0;
        (gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] + i)->brightness = 5000;
        (gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] + i)->saturation =
            10000;
        (gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] + i)->contrast = 10000;
        (gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] + i)->hue = 0;
        (gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] +
            i)->autopaint_colorkey = FALSE;

        REGION_NULL(pScreen,
            &(gviaPortPriv[XV_ADAPT_TEXTURE][viaScrnIndex] + i)->clip);
    }

    *adaptorPtr = viaAdaptPtr[XV_ADAPT_TEXTURE];
    return 1;

}

void
StopOVerlay(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    static DDUPDATEOVERLAY updateOvlRec;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    if (pPriv->videoFlag & VIDEO_ACTIVE) {
        updateOvlRec.dwFlags = DDOVER_HIDE;

        if (UpdateOverlay(pScrn, pPriv, &updateOvlRec) == -1) {
            DBG_DD((" updateoverlay fail. \n"));
        }
    }
}

static void
viaStopVideoG(ScrnInfoPtr pScrn, pointer data, Bool exit)
{
    VIAPtr pVia = VIAPTR(pScrn);
    viaPortPrivPtr pPriv = (viaPortPrivPtr) data;
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    /* Handle textured video path */
    if (pPriv->textured || pPriv->redirected) {
        if (exit) {
            viaDestroyXvSurface(pScrn, pPriv);
        }
        /* Xv texture video returned here; Overlay redirectd must fall through */
        if (pPriv->textured) {
            return;
        }
    }

    DBG_DD(("  exit=%d\n", exit));

    switch (pPriv->xv_portnum) {
    case XV_SWOV_PORTID:
    case XV_SWOV_PORTID2:
        REGION_EMPTY(pScrn->pScreen, &pPriv->clip);
        if (exit) {
            if (!pPriv->redirected) {
                StopOVerlay(pScrn, pPriv);
            }

            viaDestroyOverlaySurface(pScrn, pPriv, pPriv->curIGA);

            pPriv->framenum = 0;
            pPriv->redirected = FALSE;
            pPriv->vidOnTop = FALSE;
            BACKUP_PARAMETERS(pPriv, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL,
                FALSE, NULL);

            /* reset the slot of pPriv Rec to NULL */
            pVia->pPriv[pPriv->xv_portnum] = NULL;

            if (pPriv->vidEngUpdate == VIDEO_1) {
                pVidData->vidSrcType &= ~(VIDEO_1_SDTV | VIDEO_1_HDTV);

                if (viaGfxInfo->screenAttr.uint & SCRN_ATTR_DUO_CLONE_VIEW) {
                    pVidData->vidSrcType &= ~(VIDEO_3_SDTV | VIDEO_3_HDTV);
                }
            } else if (pPriv->vidEngUpdate == VIDEO_3) {
                pVidData->vidSrcType &= ~(VIDEO_3_SDTV | VIDEO_3_HDTV);

                if (viaGfxInfo->screenAttr.uint & SCRN_ATTR_DUO_CLONE_VIEW) {
                    pVidData->vidSrcType &= ~(VIDEO_1_SDTV | VIDEO_1_HDTV);
                }
            }
        } else {
            //StopOVerlay(pScrn, pPriv);
        }
        break;
    default:
        DBG_DD(("  Shall not happen! \n"));
        break;
    }

}

static int
viaSetPortAttributeG(ScrnInfoPtr pScrn,
    Atom attribute, INT32 value, pointer data)
{
    VIAPtr pVia = VIAPTR(pScrn);
    volatile video_via_regs *viaVidEng = NULL;
    viaPortPrivPtr pPriv = (viaPortPrivPtr) data;
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;

    viaVidEng = (volatile video_via_regs *)pVia->VidMapBase;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));
    DBG_DD(("  Screen[%d]\n", pScrn->scrnIndex));

    pVidData->dwRejectOverlay = FALSE;
    DBG_DD(("  Don't need dwRejectOverlay()\n"));

    /* Color Key */
    if (attribute == xvColorKey) {
        DBG_DD(("  xvColorKey = %08lx\n", value));

        if (pScrn->bitsPerPixel == 16) {
            value &= 0xFFFF;
        } else if (pScrn->bitsPerPixel == 8) {
            value &= 0xFF;
        }

        pPriv->colorKey = value;

        viaVidEng->color_key = value;
        viaVidEng->snd_color_key = value;
        REGION_EMPTY(pScrn->pScreen, &pPriv->clip);
    } else if (attribute == xvContrast) { /* Overlay Color Control */
        DBG_DD(("     xvContrast = %08ld\n", value));
        pPriv->contrast = value;
        vidSetVideoColor(pVia, pPriv->hue, pPriv->saturation,
            pPriv->brightness, pPriv->contrast);
    } else if (attribute == xvSaturation) {
        DBG_DD(("     xvSaturation = %08ld\n", value));
        pPriv->saturation = value;
        vidSetVideoColor(pVia, pPriv->hue, pPriv->saturation,
            pPriv->brightness, pPriv->contrast);
    } else if (attribute == xvHue) {
        DBG_DD(("     xvHue = %08ld\n", value));
        pPriv->hue = value;
        vidSetVideoColor(pVia, pPriv->hue, pPriv->saturation,
            pPriv->brightness, pPriv->contrast);
    } else if (attribute == xvBrightness) {
        DBG_DD(("     xvBrightness = %08ld\n", value));
        pPriv->brightness = value;
        vidSetVideoColor(pVia, pPriv->hue, pPriv->saturation,
            pPriv->brightness, pPriv->contrast);
    } else if (attribute == xv_autopaint_colorkey) {
        DBG_DD(("  xv_autopaint_colorkey=%lx\n", value));
        pPriv->autopaint_colorkey = value;
    } else {
        DBG_DD(("  is not supported the attribute\n"));
        return BadMatch;
    }

    return Success;
}

static int
viaGetPortAttributeG(ScrnInfoPtr pScrn,
    Atom attribute, INT32 *value, pointer data)
{
    VIAPtr pVia = VIAPTR(pScrn);
    viaPortPrivPtr pPriv = (viaPortPrivPtr) data;
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    DBG_DD(("  port %d\n", pPriv->xv_portnum));
    DBG_DD(("  Screen[%d]\n", pScrn->scrnIndex));

    /*    *value = 0; */
    pVidData->IsSupportedColorSpaceChange = TRUE;

    if (attribute == xvColorKey) {
        *value = (INT32) pPriv->colorKey;
        DBG_DD(("  ColorKey 0x%lx\n", pPriv->colorKey));
    } else if (attribute == xvContrast) {  /* Color Control */
        *value = pPriv->contrast;
        DBG_DD(("  xvContrast = %08ld\n", *value));
    } else if (attribute == xvSaturation) {
        *value = pPriv->saturation;
        DBG_DD(("  xvSaturation = %08ld\n", *value));
    } else if (attribute == xvHue) {
        *value = pPriv->hue;
        DBG_DD(("  xvHue = %08ld\n", *value));
    } else if (attribute == xvBrightness) {
        *value = pPriv->brightness;
        DBG_DD(("  xvBrightness = %08ld\n", *value));
    } else if (attribute == xvOverlayStatus) {
        if ((VIDInD(V1_CONTROL) & VAL_VIDEO_ENABLE_CME) ||
            (VIDInD(V3_CONTROL) & VAL_VIDEO_ENABLE_CME)) {
            *value = 1;
            DBG_DD(("  XV Overlay Enable.\n"));
        } else {
            *value = 0;
            DBG_DD(("  XV Overlay Disable.\n"));
        }
    } else if (attribute == xv_autopaint_colorkey) { /* autopaint colorkey */
        *value = pPriv->autopaint_colorkey;
        DBG_DD(("  xv_autopaint_colorkey= %x\n", pPriv->autopaint_colorkey));
    } else {
        DBG_DD(("  Not supported the attribute\n"));
        return BadMatch;
    }

    return Success;
}

static void
viaQueryBestSizeG(ScrnInfoPtr pScrn,
    Bool motion,
    short vid_w, short vid_h,
    short drw_w, short drw_h,
    unsigned int *p_w, unsigned int *p_h, pointer data)
{
    DBG_DD(("Enter Function : %s\n", __FUNCTION__));
    *p_w = drw_w;
    *p_h = drw_h;

    if (*p_w > 2048) {
        *p_w = 2048;
    }
}

/*
 *  For FourCC : YV12 case
 */
void
CopyDataYUV420(unsigned char *src1, unsigned char *src2, unsigned char *src3,
    unsigned char *dst1, unsigned char *dst2, unsigned char *dst3,
    int srcPitch, int srcPitch2, int dstPitch, int h, int w)
{
    int count;

    /* copy Y component to video memory */
    count = h;

    while (count--) {
        memcpy(dst1, src1, w);
        src1 += srcPitch;
        dst1 += dstPitch;
    }

    /* UV component is 1/4 of Y */
    w >>= 1;
    h >>= 1;
    dstPitch >>= 1;

    /* copy V(Cr) component to video memory */
    count = h;

    while (count--) {
        memcpy(dst2, src2, w);
        src2 += srcPitch2;
        dst2 += dstPitch;
    }

    /* copy U(Cb) component to video memory */
    count = h;

    while (count--) {
        memcpy(dst3, src3, w);
        src3 += srcPitch2;
        dst3 += dstPitch;
    }
}

/*
 *  For FourCC : YUY2 case
 */
void
CopyDataYUV422(unsigned char *src,
    unsigned char *dst, int srcPitch, int dstPitch, int h, int w)
{
    int count;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    /*  copy YUY2 data to video memory,
     *  do 32 bits alignment.
     */
    count = h;

    while (count--) {
        memcpy(dst, src, w);
        src += srcPitch;
        dst += dstPitch;
    }
}

/*  CopyYUV420To422 :
 *  for VT3259 use,
 *  copy image data to frame buffer & transfer
 *  format from YUV420 to YUV422, coz VT3259
 *  HQV input source only support FourCC NV12, YUY2
 *  YUV420 format in memory is Y, V, U 3 planar mode
 *  YUV422 is Y0 U0 Y1 V0
 *            low ....High byte
 */
void
CopyYUV420To422(unsigned char *src1,   /* Y */
    unsigned char *src2,           /* V */
    unsigned char *src3,           /* U */
    unsigned char *dst1,
    int srcPitch, int srcPitch2, int dstPitch, int h, int w)
{
    CARD32 *dst = (CARD32 *) dst1;
    int i, j;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    dstPitch >>= 2;
    w >>= 1;

    for (j = 0; j < h; j++) {
        for (i = 0; i < w; i++) {
            dst[i] = src1[i << 1] | (src1[(i << 1) + 1] << 16) |
                (src3[i] << 8) | (src2[i] << 24);
        }

        dst += dstPitch;
        src1 += srcPitch;

        if (j & 1) {
            src2 += srcPitch2;
            src3 += srcPitch2;
        }
    }
}

/*  CopyI420To422 :
 *  for VT3259 use,
 *  copy image data to frame buffer & transfer
 *  format from I420 to YUY2
 *  I420 format in memory is Y, U, V 3 planar mode
 *  YUV422 is Y0 U0 Y1 V0
 *            low ....High byte
 */
void
CopyI420To422(unsigned char *src1,     /* Y */
    unsigned char *src2,           /* U */
    unsigned char *src3,           /* V */
    unsigned char *dst1,
    int srcPitch, int srcPitch2, int dstPitch, int h, int w)
{
    CARD32 *dst = (CARD32 *) dst1;
    int i, j;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    dstPitch >>= 2;
    w >>= 1;

    for (j = 0; j < h; j++) {
        for (i = 0; i < w; i++) {
            dst[i] = src1[i << 1] | (src1[(i << 1) + 1] << 16) |
            (src2[i] << 8) | (src3[i] << 24);
        }

        dst += dstPitch;
        src1 += srcPitch;

        if (j & 1) {
            src2 += srcPitch2;
            src3 += srcPitch2;
        }
    }
}

/*CbCr conversion
 *Cr00 Cr02
 *Cr20 Cr22     ---->       Cb00 Cr00 Cb02 Cr02
 *Cb00 Cb02     ---->       Cb20 Cr20 Cb20 Cr22
 *Cb20 Cb22
 */
#define makeuvPack0(u,v) ((u & 0x000000ff)| (v & 0x000000ff)<<8|(u & 0x0000ff00)<<8 |(v & 0x000ff00)<<16)
#define makeuvPack1(u,v) ((u & 0x00ff0000)>>16| (v & 0x00ff0000)>>8|(u & 0xff000000)>>8| (v & 0xff000000))
inline void
makeuvPack(unsigned long uv[], unsigned long u, unsigned long v)
{
    uv[0] = makeuvPack0(u, v);
    uv[1] = makeuvPack1(u, v);
}

/*
 *  For FourCC : NV12 case ,new version by zepengtang
 */
void
CopyYUV420ToNV12(unsigned char *src1, unsigned char *src2,
    unsigned char *src3, unsigned char *desty, unsigned char *destuv,
    int srcPitch, int srcPitch2, int dstPitch, int h, int w,
    Bool PCIe_Surface)
{
    int i, j, k;
    Bool uvoptimized = FALSE;
    Bool uvaligned;
    char *tmpDst = NULL;
    int count = 0;
    int width = 0;
    unsigned long *pU, *pV, *pUV;

    /* copy Y component to video memory */
    if (srcPitch == dstPitch) {
        memcpy(desty, src1, dstPitch * h);
    } else {
        for (i = 0; i < h; i++) {
            memcpy(desty, src1, w);
            src1 += srcPitch;
            desty += dstPitch;
        }
    }

    h >>= 1;

    /* PCIe surface dose not need this optimal code */
    if (!PCIe_Surface) {

        if ((((unsigned long)src2 & 3) == 0 && ((unsigned long)src3 & 3) == 0)
            || (((unsigned long)src2 & 3) == 2
            && ((unsigned long)src3 & 3) == 2)) {

            while (!(tmpDst = (char *)malloc(dstPitch * (h >> count) + 3))) {
                count++;
            }

            if (tmpDst != NULL) {
                uvoptimized = TRUE;
            }
        }
    }

    /* here is for the optimized code for convert YV12 to NV12 */
    if (uvoptimized) {

        for (j = 0; j < h; j++) {

            /* we can process h>>count lines in each block, the subline num
               is j%(h>>count) in each block */
            pUV =
                (unsigned long *)(ALIGN_TO((unsigned long)tmpDst,
                4) + dstPitch * (j % (h >> count)));

            if (((unsigned long)src2 & 3) == 2) {
                uvaligned = FALSE;
                *pUV++ =
                    src3[0] | (src2[0] << 8) | (src3[1] << 16) | (src2[1] <<
                    24);
                pV = (unsigned long *)ALIGN_TO((unsigned long)src2, 4);
                pU = (unsigned long *)ALIGN_TO((unsigned long)src3, 4);
                width = ALIGN_TO((w - 2), 8);
            } else {
                uvaligned = TRUE;
                pV = (unsigned long *)src2;
                pU = (unsigned long *)src3;
                width = ALIGN_TO(w, 8);
            }

            /*now we construct 64 bit at one time for the  uv buffer */
            for (i = (uvaligned ? 0 : 4); i < width;
                i += 8, pU++, pV++, pUV += 2) {
                makeuvPack(pUV, *pU, *pV);
            }

            /* the subline num is the last line in the block, then copy it out */
            if ((j % (h >> count)) == ((h >> count) - 1)) {
                memcpy((destuv +
                    (j / (h >> count)) * dstPitch * (h >> count)),
                    (unsigned long *)ALIGN_TO((unsigned long)tmpDst, 4),
                    dstPitch * (h >> count));
            }
            src2 += srcPitch2;
            src3 += srcPitch2;
        }

        free(tmpDst);
    } else {
        for (j = 0; j < h; j++) {
            for (i = 0, k = 0; i < w; i += 4, k += 2) {
                *((unsigned long *)(destuv + i)) =
                    src3[k] | (src2[k] << 8) | (src3[k + 1] << 16) | (src2[k +
                    1] << 24);
            }

            destuv += dstPitch;
            src2 += srcPitch2;
            src3 += srcPitch2;
        }
    }

}

static void
SetColorSpace(VIAPtr pVia)
{
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;

    if (!pVidData->ColorSpaceChanged) {
        VIDOutD(ColorSpaceReg_1, ColorSpaceValue_1_3123C0);
        VIDOutD(ColorSpaceReg_2, ColorSpaceValue_2_3123C0);
        VIDOutD(V3_ColorSpaceReg_1, ColorSpaceValue_1_3123C0);
        VIDOutD(V3_ColorSpaceReg_2, ColorSpaceValue_2_3123C0);
    } else {
        VIDOutD(ColorSpaceReg_1, pVidData->ColorSpaceValue1);
        VIDOutD(ColorSpaceReg_2, pVidData->ColorSpaceValue2);
        VIDOutD(V3_ColorSpaceReg_1, pVidData->ColorSpaceValue1);
        VIDOutD(V3_ColorSpaceReg_2, pVidData->ColorSpaceValue2);
    }
}

int
enableVirtualQueue(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    int ret = TRUE;

    pVidData->dwVQUseCount++;

    /* Double check VQ Enable/Disable status */
    if ((!pVidData->dwVideoVQ_Offset)) {
        pVidData->dwVideoVQ_Size = 0x00080000;    /* 512K */

        viaVideoMemFree(pScrn, &pVidData->vidVQMem);
        ret =
            viaVideoMemAlloc(pScrn, &pVidData->vidVQMem,
            pVidData->dwVideoVQ_Size);

        if (ret == BadAlloc) {
            DBG_DD((" Create Video Virtual Queue buffer fail!\n"));
            return FALSE;
        }

        pVidData->dwVideoVQ_Offset =
            ALIGN_TO(pVidData->vidVQMem.bo->offset, 32);

        vidEnableVideoVirtualQueue(pVia, pPriv->videoFlag,
            pVidData->dwVideoVQ_Offset, pVidData->dwVideoVQ_Size);
    }
}

void
disableVirtualQueue(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;

    pVidData->dwVQUseCount--;

    if (pVidData->dwVQUseCount == 0) {
        if (pVidData->dwVideoVQ_Offset) {
            vfHM(pScrn, pPriv, HM_WAIT_VQ_EMPTY);

            viaVideoMemFree(pScrn, &pVidData->vidVQMem);

            pVidData->dwVideoVQ_Offset = 0;
            vidDisableVideoVirtualQueue(pVia);
        }
    } else {
        DBG_DD(("VQ buffer was in used\n"));
    }

    return;
}

/*
  * The value of eng_value indicate the sub-engine id.
  * (V1 or V3, HQV0 or HQV1, and so on...)
  * HAVE_INVALID indicate not avaliable.
  */
void
allocEngine(VIAENGMATRIX *pViaEngineMatrix, unsigned long *eng_value)
{
    unsigned long shift = 0;
    VIAENGMATRIX *pCurrEngMGR = pViaEngineMatrix;

    *eng_value = HAVE_INVALID;

    for (; shift < 32; shift++) {
        if ((pCurrEngMGR->ulEngMask & (1 << shift)) & pCurrEngMGR->
            ulEngStatus) {
            *eng_value = 1 << shift;
            pCurrEngMGR->ulEngStatus &=
                ~(pCurrEngMGR->ulEngMask & *eng_value);
            break;
        }
    }

}

void
releaseEngine(VIAENGMATRIX *pViaEngineMatrix, unsigned long eng_value)
{
    VIAENGMATRIX *pCurrEngMGR = pViaEngineMatrix;

    pCurrEngMGR->ulEngStatus |= pCurrEngMGR->ulEngMask & eng_value;
}

/*
 * Allocate engine and initialize video status flag for engine allocation.
 * If no engine is availabe or fourcc is not correct, return HAVE_INVALID
 */
unsigned long
initEngineStatus(PVIDDATA pVidData, unsigned long *flags)
{
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    LPVIDHWDIFFERENCE lpVideoHWDifference = &pVidData->VideoHWDifference;
    unsigned long video_alloc_value = 0;
    unsigned long hqv_alloc_value = 0;
    int counts = 0;
    int i = 0;

    counts = (viaGfxInfo->screenAttr.uint & SCRN_ATTR_DUO_CLONE_VIEW) ? 2 : 1;

    for (i = 0; i < counts; i++) {
        /*try to allocate video engine */
        allocEngine(&pVidData->ViaEngManager.ViaEngineMatrix[ENGINE_VIDEO],
            &video_alloc_value);
        if (HAVE_VIDEO_1 == video_alloc_value) {
            *flags |= VIDEO_1_INUSE;
            DBG_DD(("  Video 1 allocated\n"));
        } else {
            if (HAVE_VIDEO_3 == video_alloc_value) {
                *flags |= VIDEO_3_INUSE;
                DBG_DD(("  Video 3 allocated\n"));
            } else {
                DBG_DD(("  No more available video engine\n "));
                return FALSE;
            }
        }

        /*try to allocate HQV engine */
        allocEngine(&pVidData->ViaEngManager.ViaEngineMatrix[ENGINE_HQV],
            &hqv_alloc_value);
        if (HAVE_HQV_0 == hqv_alloc_value) {
            *flags |= HQV_0_INUSE | VIDEO_HQV_INUSE;
            DBG_DD(("  HQV 0 allocated\n"));
        } else {
            if (HAVE_HQV_1 == hqv_alloc_value) {
                *flags |= HQV_1_INUSE | VIDEO_HQV_INUSE;
                DBG_DD(("  HQV 1 allocated\n"));
            } else {
                DBG_DD(("  No more available HQV engine\n "));
                return FALSE;
            }
        }
    }

    /*if video VQ enabled */
    if (lpVideoHWDifference->dwSupportVideoVQ == VID_HWDIFF_TRUE) {
        *flags |= VIDEO_VQ_INUSE;
    }
#if  VIA_APPLY_XVOVERLAY_AGP
    /* set the following flag for wait in CR function */
    if (viaGfxInfo->drmEnabled && viaGfxInfo->chipId != VIA_DEVICE_VT3314) {
        /* if video go AGP mode, no need to enable Virtual Queue */
        *flags &= ~VIDEO_VQ_INUSE;
        *flags |= VIDEO_AGP_INUSE;
    }
#endif

    return TRUE;
}

void
freeEngineStatus(PVIDDATA pVidData, viaPortPrivPtr pPriv)
{
    if (pPriv->videoFlag & VIDEO_1_INUSE) {
        releaseEngine(&pVidData->ViaEngManager.ViaEngineMatrix[ENGINE_VIDEO],
            HAVE_VIDEO_1);
        DBG_DD(("  Video 1 freed\n"));
        pPriv->videoFlag &= ~VIDEO_1_INUSE;
    }

    if (pPriv->videoFlag & VIDEO_3_INUSE) {
        releaseEngine(&pVidData->ViaEngManager.ViaEngineMatrix[ENGINE_VIDEO],
            HAVE_VIDEO_3);
        DBG_DD(("  Video 3 freed\n"));
        pPriv->videoFlag &= ~VIDEO_3_INUSE;
    }

    if (pPriv->videoFlag & HQV_0_INUSE) {
        releaseEngine(&pVidData->ViaEngManager.ViaEngineMatrix[ENGINE_HQV],
            HAVE_HQV_0);
        DBG_DD(("  HQV 0 freed\n"));
        pPriv->videoFlag &= ~HQV_0_INUSE;
    }

    if (pPriv->videoFlag & HQV_1_INUSE) {
        releaseEngine(&pVidData->ViaEngManager.ViaEngineMatrix[ENGINE_HQV],
            HAVE_HQV_1);
        DBG_DD(("HQV 1 freed\n"));
        pPriv->videoFlag &= ~HQV_1_INUSE;
    }
}

void __inline
rgbFillBlack(VIAPtr pVia, void *vaddr, int size)
{
    /* For video, we just to using the information from the priamary pVia */
    VIAPtr pVia0 =
        (pVia->IsSecondary) ? VIAPTR(pVia->pVIAEnt->pPrimaryScrn) : pVia;
    unsigned char *ptr = (unsigned char *)vaddr;

    unsigned int ClearValue = 0x0;

    DBG_DD(("  RGBFillBlack()\n"));
    memset(ptr, ClearValue, size);
}

/*
 *  Fill the buffer YUV2 black.
 *   the memory layout looks like
 *   Y00 U00 Y01 V00 Y02 U02 Y03 V02
 *   Y10 U10 Y11 V10 Y12 U12 Y13 V12
 *   Y20 U20 Y21 V20 Y22 U22 Y23 V22
 *   Y30 U30 Y31 V30 Y32 U32 Y33 V32
 * The common conversion formula is:
 * Y = R * 0.299 + G * 0.587 + B * 0.114
 * U = R * -0.169 + G * -0.332 + B * 0.500 + 128;
 * V = R* 0.500 + G * -0.419 + B * -0.0813 + 128;
 */
__inline void
yuvFillBlack(VIAPtr pVia, void *vaddr, int size)
{
    /* For video, we just to using the information from the priamary pVia */
    VIAPtr pVia0 =
    (pVia->IsSecondary) ? VIAPTR(pVia->pVIAEnt->pPrimaryScrn) : pVia;
    unsigned char *ptr = (unsigned char *)vaddr;
    unsigned int ClearValue = 0x80008000;    /*Y=0,U=V=0x80 */
    int i = 0;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    /* Y=0,U=V=0x80, 2 bytes for 1 pixel about YUY2, so size/2 represents
     * the real pitch*height in pixel(not in bytes), 0x80008000 is used to
     * clear 2 pixel, so size/2/2 (=size/4)represents how many 0x80008000 need be used */
    for (i = 0; i < size / 4; i++, ptr++) {
        *ptr = ClearValue;
    }
}

__inline void
yuvFillBlackPCIE(VIAPtr pVia, void *vaddr, int size)
{
    /* For video, we just to using the information from the priamary pVia */
    VIAPtr pVia0 =
    (pVia->IsSecondary) ? VIAPTR(pVia->pVIAEnt->pPrimaryScrn) : pVia;

    unsigned int *ptr = (unsigned int *)vaddr;
    unsigned int ClearValue = 0x80008000;    /*Y=0,U=V=0x80 */
    int i = 0;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    /* Y=0,U=V=0x80, 2 bytes for 1 pixel about YUY2, so size/2 represents
     * the real pitch*height in pixel(not in bytes), 0x80008000 is used to
     * clear 2 pixel, so size/2/2 (=size/4)represents how many 0x80008000 need be used */
    for (i = 0; i < (size / 4); i++, ptr++) {
        *ptr = ClearValue;
    }

    //  viaFlushPCIECache(pVia, offset, size);
}

/*The NV12 memory layout looks like this
 *   Y00  Y01  Y02  Y03
 *   Y10  Y11  Y12  Y13
 *   Y20  Y21  Y22  Y23
 *   Y30  Y31  Y32  Y33
 *   U00  V00  U01  V01
 *   U20  V20  U21  V21
 *
 *The YV12 memory layout looks like this
 *   Y00  Y01  Y02  Y03
 *   Y10  Y11  Y12  Y13
 *   Y20  Y21  Y22  Y23
 *   Y30  Y31  Y32  Y33
 *   U00  U01  U20  U21
 *   V00  V01  V20  V21
 *When clear the 2 surface, we all set Y=0,U=V=0x80.
 */
__inline void
nv12FillBlack(VIAPtr pVia, int offset, int size)
{
    /* For video, we just to using the information from the priamary pVia */
    VIAPtr pVia0 =
        (pVia->IsSecondary) ? VIAPTR(pVia->pVIAEnt->pPrimaryScrn) : pVia;
    unsigned char *ptr = (unsigned char *)(pVia0->FBBase + offset);

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    /* Y=0,U=V=0x80, 3/2 byte for 1 pixel about NV12/YV12, so size*2/3 represents
     * the real pitch*height in pixel(not in bytes)*/
    memset((char *)ptr, 0x00, size * 2 / 3);
    memset((char *)(ptr + size * 2 / 3), 0x80, size / 3);
}

__inline void
nv12FillBlackPCIE(VIAPtr pVia, void *vaddr, int size)
{
    /* For video, we just to using the information from the priamary pVia */
    VIAPtr pVia0 =
    (pVia->IsSecondary) ? VIAPTR(pVia->pVIAEnt->pPrimaryScrn) : pVia;
    unsigned char *ptr = (unsigned char *)vaddr;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    /* Y=0,U=V=0x80, 3/2 byte for 1 pixel about NV12/YV12, so size*2/3 represents
     * the real pitch*height in pixel(not in bytes)*/
    memset((char *)ptr, 0x00, size * 2 / 3);
    memset((char *)(ptr + size * 2 / 3), 0x80, size / 3);

    //  viaFlushPCIECache(pVia, offset, size);
}

static unsigned long
AddHQVSurface(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv)
{
    VIAPtr pVia = VIAPTR(pScrn);

    /* For video, we just to using the information from the priamary pVia */
    VIAPtr pVia0 =
        (pVia->IsSecondary) ? VIAPTR(pVia->pVIAEnt->pPrimaryScrn) : pVia;
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    unsigned int i, swWidth, swHeight, swPitch, swFourcc, format, formatType,
        fbsize;
    unsigned int width, height, pitch, fourcc;
    int ret = TRUE;

    swFourcc = pPriv->pXvSurface->format;
    swWidth = pPriv->pXvSurface->width;
    swHeight = pPriv->pXvSurface->height;
    swPitch = pPriv->pXvSurface->pitch;

    width = swWidth;
    height = swHeight;

    switch (swFourcc) {
    /* If rotate, Format in HQV surface will be YUY2 if 314, RGB16 if not 314,
       they all 2 bytes one pixel */
    case FOURCC_YV12:
    case FOURCC_NV12:
        pitch = swPitch * 2;
        fbsize = ALIGN_TO(pitch * height, 256);
        break;
    case FOURCC_YUY2:
        pitch = swPitch;
        fbsize = ALIGN_TO(pitch * height, 256);
        break;
    default:
        DBG_DD(("  Unknown supported format!\n"));
        return FALSE;
    }

    DBG_DD(("  HQVSurface Size:%08x\n", fbsize));
    /*HQV surface should be unpin first */
    viaVideoMemUnPin(pScrn, &pPriv->hqvMem[pPriv->curIGA - 1]);
    viaVideoMemFree(pScrn, &pPriv->hqvMem[pPriv->curIGA - 1]);
    ret =
        viaVideoMemAlloc(pScrn, &pPriv->hqvMem[pPriv->curIGA - 1],
    fbsize * XV_HQVSURFACE_NUM);

    if (ret == BadAlloc) {
        return FALSE;
    }
    if ((pPriv->pHqvSurface[pPriv->curIGA - 1] =
        (ViaXvSurfacePtr) calloc(1, sizeof(ViaXvSurfaceRec))) == NULL) {
        return FALSE;
    }
    /*add pin for HQV surface, for its HW flip */
    if (viaVideoMemPin(pScrn, &pPriv->hqvMem[pPriv->curIGA - 1])) {
        return FALSE;
    }
    if (viaGfxInfo->igaInfo[pPriv->curIGA - 1].igaRRStatus.unit) {
        if (viaGfxInfo->chipId == VIA_DEVICE_VT3314) {
            format = FOURCC_YUY2;
            formatType = DDPF_FOURCC;
        } else {
            format = RGB16;
            formatType = DDPF_RGB;
        }
    } else {
        format = FOURCC_YUY2;
        formatType = DDPF_FOURCC;
    }

    if (formatType & DDPF_FOURCC) {
        yuvFillBlack(pVia, pPriv->hqvMem[pPriv->curIGA - 1].bo->virtual,
            fbsize * XV_HQVSURFACE_NUM);
    } else {
        rgbFillBlack(pVia, pPriv->hqvMem[pPriv->curIGA - 1].bo->virtual,
            fbsize * XV_HQVSURFACE_NUM);
    }

    pPriv->pHqvSurface[pPriv->curIGA - 1]->format = format;
    pPriv->pHqvSurface[pPriv->curIGA - 1]->formatType = formatType;
    pPriv->pHqvSurface[pPriv->curIGA - 1]->width = width;
    pPriv->pHqvSurface[pPriv->curIGA - 1]->height = height;
    pPriv->pHqvSurface[pPriv->curIGA - 1]->pitch = pitch;

    for (i = 0; i < XV_HQVSURFACE_NUM; i++) {
        pPriv->pHqvSurface[pPriv->curIGA - 1]->offset[i] =
            ALIGN_TO(pPriv->hqvMem[pPriv->curIGA - 1].bo->offset + i * fbsize,
            256);
        pPriv->pHqvSurface[pPriv->curIGA - 1]->vaddr[i] =
            pPriv->hqvMem[pPriv->curIGA - 1].bo->virtual + i * fbsize;
    }
    return TRUE;
}

unsigned long
AddROTSurface(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv)
{
    VIAPtr pVia = VIAPTR(pScrn);

    /* For video, we just to using the information from the priamary pVia */
    VIAPtr pVia0 =
        (pVia->IsSecondary) ? VIAPTR(pVia->pVIAEnt->pPrimaryScrn) : pVia;
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    unsigned int i, hqvWidth, hqvHeight, hqvPitch, hqvFourcc, fbsize;
    unsigned int width, height, pitch_w, pitch_h, fourcc;
    int ret = TRUE;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    hqvFourcc = pPriv->pHqvSurface[pPriv->curIGA - 1]->format;
    hqvWidth = pPriv->pHqvSurface[pPriv->curIGA - 1]->width;
    hqvHeight = pPriv->pHqvSurface[pPriv->curIGA - 1]->height;
    hqvPitch = pPriv->pHqvSurface[pPriv->curIGA - 1]->pitch;

    /* If rotate, Format in HQV surface will be YUY2 if 314, RGB16 if not 314,
     * they all 2 bytes one pixel
     * After rotate, format will be RGB16, it means format in ROT surface always RGB16
     */
    width = hqvWidth;
    pitch_w = ALIGN_TO(width << 1, 256);
    height = hqvHeight;
    pitch_h = ALIGN_TO(height << 1, 256);
    fbsize = max(pitch_w * height, pitch_h * width);
    DBG_DD(("  RotSurface Size:%08x\n", fbsize));

    viaVideoMemFree(pScrn, &pPriv->rotMem[pPriv->curIGA - 1]);
    ret =
        viaVideoMemAlloc(pScrn, &pPriv->rotMem[pPriv->curIGA - 1],
        fbsize * XV_ROTSURFACE_NUM);

    if (ret == BadAlloc) {
        return FALSE;
    }

    rgbFillBlack(pVia, pPriv->rotMem[pPriv->curIGA - 1].bo->virtual,
        fbsize * XV_ROTSURFACE_NUM);

    if ((pPriv->pRotSurface[pPriv->curIGA - 1] =
        (ViaXvSurfacePtr) calloc(1, sizeof(ViaXvSurfaceRec))) == NULL) {
        return FALSE;
    }

    pPriv->pRotSurface[pPriv->curIGA - 1]->format = RGB16;
    pPriv->pRotSurface[pPriv->curIGA - 1]->formatType = DDPF_RGB;

    pPriv->pRotSurface[pPriv->curIGA - 1]->width =
        (viaGfxInfo->igaInfo[pPriv->curIGA - 1].igaRRStatus.rotate_90 ||
    viaGfxInfo->igaInfo[pPriv->curIGA -
        1].igaRRStatus.rotate_270) ? height : width;
    pPriv->pRotSurface[pPriv->curIGA - 1]->height =
        (viaGfxInfo->igaInfo[pPriv->curIGA - 1].igaRRStatus.rotate_90
        || viaGfxInfo->igaInfo[pPriv->curIGA -
        1].igaRRStatus.rotate_270) ? width : height;
    pPriv->pRotSurface[pPriv->curIGA - 1]->pitch =
        (viaGfxInfo->igaInfo[pPriv->curIGA - 1].igaRRStatus.rotate_90
        || viaGfxInfo->igaInfo[pPriv->curIGA -
        1].igaRRStatus.rotate_270) ? pitch_h : pitch_w;

    for (i = 0; i < XV_ROTSURFACE_NUM; i++) {
        pPriv->pRotSurface[pPriv->curIGA - 1]->offset[i] =
            ALIGN_TO(pPriv->rotMem[pPriv->curIGA - 1].bo->offset + i * fbsize,
            256);
        pPriv->pRotSurface[pPriv->curIGA - 1]->vaddr[i] =
            pPriv->rotMem[pPriv->curIGA - 1].bo->virtual + i * fbsize;
    }

    pPriv->pRotSurface[pPriv->curIGA - 1]->cur_idx = 0;

    pPriv->igaRRStatus[pPriv->curIGA - 1] =
        viaGfxInfo->igaInfo[pPriv->curIGA - 1].igaRRStatus.unit;

    return TRUE;
}

unsigned long
viaCreateXvSurface(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv,
    unsigned long id, unsigned long width, unsigned long height)
{
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned long format, formatType, pitch, bufsize;
    int ret = FALSE;
    Bool isplanar = FALSE;
    int i = 0;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    /*For video, we just to using the information from the priamary pVia */
    if (pVia->IsSecondary) {
        pVia = VIAPTR(pVia->pVIAEnt->pPrimaryScrn);
    }

    if (pPriv->pXvSurface) {
        viaDestroyXvSurface(pScrn, pPriv);
    }

    formatType = DDPF_FOURCC;

    if (id != FOURCC_VMI_XV) {
        switch (pVia->ChipId) {
        case VIA_DEVICE_VT3314:
            if ((pPriv->textured || pPriv->redirected) && pPriv->texV3DPath) {
                format = FOURCC_YUY2;
            } else {
                format = ((FOURCC_YV12 == id) ? FOURCC_YV12 : FOURCC_YUY2);
            }
            break;

        default:
            if ((pPriv->textured || pPriv->redirected) && pPriv->texV3DPath) {
                format = FOURCC_YUY2;
            } else {
                format = (((FOURCC_YV12 == id) ||
                    (FOURCC_NV12 == id)) ? FOURCC_NV12 : FOURCC_YUY2);
            }
            break;
        }

        if (pVia->ChipId == VIA_DEVICE_VT3409) {
            /* Issue existed in 409 HQV zoom-out
             * 1. 1/8 < horizontal scale ratio <= 1/16, issue zone is 509~521 1004~1020 1499~1519
             * 2. 1/16 < horizontal scale ratio <= 1/32, issue zone is 509~537 1004~1036 1499~1535*/
            if ((width >= 509 && width <= 537) || (width > 1004
                && width <= 1036) || (width >= 1499 && width <= 1535)) {
                width += 64;
            }
        }

        switch (format) {
        case FOURCC_YV12:
        case FOURCC_NV12:
            isplanar = TRUE;
            pitch = ALIGN_TO(width, 64);
            bufsize = ALIGN_TO((pitch * height * 3 / 2), 256);
            break;
        case FOURCC_YUY2:
            isplanar = FALSE;
            pitch = ALIGN_TO(width << 1, 32);
            bufsize = ALIGN_TO((pitch * height), 256);
            break;
        }
        /* Allocate Video Memory for Xv Texture video surface */
        if ((pVia->ChipId == PCI_CHIP_VT3353)
            || (pVia->ChipId == PCI_CHIP_VT3409)
            || (pVia->ChipId == PCI_CHIP_VT3410)) {
            ret = viaPCIEMemAlloc(pScrn, &pPriv->xvMem,
                bufsize * XV_SURFACE_NUM);

            if (ret == Success) {
                pPriv->xv_refine_using_pcie = TRUE;
            } else {
                pPriv->xv_refine_using_pcie = FALSE;
            }
        } else {
            pPriv->xv_refine_using_pcie = FALSE;
        }
        if (!pPriv->xv_refine_using_pcie) {
            ret = viaVideoMemAlloc(pScrn, &pPriv->xvMem,
                bufsize * XV_SURFACE_NUM);
        }

        if (ret == BadAlloc) {
            return FALSE;
        }

        if (pPriv->xv_refine_using_pcie) {
            /*if BO is in PCIE and CPU will operate it, it should be set cpu domain */
            dri_bo_set_cpu_domain(pPriv->xvMem.bo);
            switch (format) {
            case FOURCC_NV12:
            case FOURCC_YV12:
                for (i = 0; i < XV_SURFACE_NUM; i++)
                    nv12FillBlackPCIE(pVia,
                        pPriv->xvMem.bo->virtual + i * bufsize, bufsize);
                break;
            case FOURCC_YUY2:
            default:
                yuvFillBlackPCIE(pVia, pPriv->xvMem.bo->virtual,
                    bufsize * XV_SURFACE_NUM);
                break;
            }
        } else {
            switch (format) {
            case FOURCC_NV12:
            case FOURCC_YV12:
                for (i = 0; i < XV_SURFACE_NUM; i++)
                    nv12FillBlack(pVia,
                        pPriv->xvMem.bo->virtual + i * bufsize, bufsize);
                break;
            case FOURCC_YUY2:
            default:
                yuvFillBlack(pVia, pPriv->xvMem.bo->virtual,
                    bufsize * XV_SURFACE_NUM);
                break;
            }
        }
    } else {
        /*no need to alloc memory for xv surface, just find the bo passed from vmi */
        pPriv->xv_refine_using_pcie = FALSE;
        format = FOURCC_NV12;
        pitch = ALIGN_TO(width, 32);
        bufsize = ALIGN_TO((pitch * height * 3 / 2), 256);
        pPriv->xvMem.bo =
            dri_bo_open(pVia->bufmgr, pPriv->vmi_data->bo_name,
            VIA_CHROME9_GEM_DOMAIN_VRAM);
        pPriv->xvMem.base = pPriv->xvMem.bo->offset;
        pPriv->xvMem.size = pPriv->xvMem.bo->size;
    }

    if ((pPriv->pXvSurface =
        (ViaXvSurfacePtr) calloc(1, sizeof(ViaXvSurfaceRec))) == NULL) {
        return FALSE;
    }

    pPriv->pXvSurface->format = format;
    pPriv->pXvSurface->formatType = formatType;
    pPriv->pXvSurface->width = width;
    pPriv->pXvSurface->height = height;
    pPriv->pXvSurface->pitch = pitch;

    if (id != FOURCC_VMI_XV) {

        for (i = 0; i < XV_SURFACE_NUM; i++) {
            pPriv->pXvSurface->offset[i] =
                pPriv->xvMem.bo->offset + i * bufsize;
            pPriv->pXvSurface->vaddr[i] =
                pPriv->xvMem.bo->virtual + i * bufsize;
        }
    } else {
        for (i = 0; i < VMI_SURFACE_NUM; i++) {
            pPriv->pXvSurface->offset[i] =
                pPriv->xvMem.bo->offset + i * bufsize;
        }
    }

    pPriv->pXvSurface->cur_idx = 0;
    pPriv->framenum = 0;

    return TRUE;
}

void
viaDestroyXvSurface(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv)
{
    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    if (pPriv->pXvSurface) {

        /* Free Video memory allocated for Xv Texture video surface */
        if (!pPriv->vmi_data) {
            if (pPriv->xv_refine_using_pcie) {
                viaPCIEMemFree(pScrn, &pPriv->xvMem);
                pPriv->xv_refine_using_pcie = FALSE;
            } else {
                viaVideoMemFree(pScrn, &pPriv->xvMem);
            }
        } else {
            dri_bo_unreference(pPriv->xvMem.bo);
        }
        free(pPriv->pXvSurface);
        pPriv->pXvSurface = NULL;
    }
}

unsigned long
viaCreateHQVSurface(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv,
    int id, short width, short height)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    unsigned long igaIndex = 0;
    unsigned long ret = FALSE;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    if (pPriv->pHqvSurface[pPriv->curIGA - 1] != NULL) {
        return TRUE;
    }

    ret = AddHQVSurface(pScrn, pPriv);
    if (ret == FALSE) {
        DBG_DD(("  HQV Memory allocation failed\n"));
        if (pPriv->videoFlag != HAVE_INVALID) {
            freeEngineStatus(pVidData, pPriv);
        }
        return FALSE;
    }

    if (!viaGfxInfo->xrandrEnabled && viaGfxInfo->screenAttr.m1.duoview ||
        viaGfxInfo->xrandrEnabled && viaGfxInfo->screenAttr.m2.clone) {
        igaIndex = pPriv->curIGA;
        pPriv->curIGA = (pPriv->curIGA == IGA1) ? IGA2 : IGA1;

        ret = AddHQVSurface(pScrn, pPriv);
        if (ret == FALSE) {
            DBG_DD(("  HQV Memory allocation failed\n"));
            if (pPriv->videoFlag != HAVE_INVALID) {
                freeEngineStatus(pVidData, pPriv);
            }
            return FALSE;
        }

        pPriv->curIGA = igaIndex;
    }

    return TRUE;
}

unsigned long
viaDestroyHQVSurface(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv,
    unsigned long scrnAttr, unsigned long igaIndex)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    if (igaIndex == 0) {
        return TRUE;
    }

    if (pPriv->pHqvSurface[igaIndex - 1]) {
        /*unpin HQV surface first */
        viaVideoMemUnPin(pScrn, &pPriv->hqvMem[igaIndex - 1]);
        viaVideoMemFree(pScrn, &pPriv->hqvMem[igaIndex - 1]);
        free(pPriv->pHqvSurface[igaIndex - 1]);
        pPriv->pHqvSurface[igaIndex - 1] = NULL;
    } else {
        DBG_DD(("  HQV surface is NULL\n"));
    }

    if (scrnAttr == SCRN_ATTR_DUO_CLONE_VIEW) {
        igaIndex = (igaIndex == IGA1) ? IGA2 : IGA1;

        if (pPriv->pHqvSurface[igaIndex - 1]) {
            viaVideoMemFree(pScrn, &pPriv->hqvMem[igaIndex - 1]);
            free(pPriv->pHqvSurface[igaIndex - 1]);
            pPriv->pHqvSurface[igaIndex - 1] = NULL;
        } else {
            DBG_DD(("  HQV surface is NULL\n"));
        }
    }

    return TRUE;
}

unsigned long
viaDestroyROTSurface(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv,
    unsigned long scrnAttr, unsigned long igaIndex)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    if (igaIndex == 0) {
        return TRUE;
    }

    if (pPriv->pRotSurface[igaIndex - 1]) {
        viaVideoMemFree(pScrn, &pPriv->rotMem[igaIndex - 1]);
        free(pPriv->pRotSurface[igaIndex - 1]);
        pPriv->pRotSurface[igaIndex - 1] = NULL;
        pPriv->igaRRStatus[igaIndex - 1] = 0;
    } else {
        DBG_DD(("  ROT surface is NULL\n"));
    }

    if (scrnAttr == SCRN_ATTR_DUO_CLONE_VIEW) {
        igaIndex = (igaIndex == IGA1) ? IGA2 : IGA1;

        if (pPriv->pRotSurface[igaIndex - 1]) {
            viaVideoMemFree(pScrn, &pPriv->rotMem[igaIndex - 1]);
            free(pPriv->pRotSurface[igaIndex - 1]);
            pPriv->pRotSurface[igaIndex - 1] = NULL;
            pPriv->igaRRStatus[igaIndex - 1] = 0;
        } else {
            DBG_DD(("  ROT surface is NULL\n"));
        }
    }

    return TRUE;
}

unsigned long
viaDestroyOverlaySurface(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv,
    unsigned long igaIndex)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    unsigned long tmpIgaIndex = 0;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    /*Release video and HQV engine */
    freeEngineStatus(pVidData, pPriv);

    viaDestroyXvSurface(pScrn, pPriv);
    viaDestroyHQVSurface(pScrn, pPriv, pPriv->scrnAttr, igaIndex);
    viaDestroyROTSurface(pScrn, pPriv, pPriv->scrnAttr, igaIndex);

    memset(&pPriv->ovlInfo[igaIndex - 1], 0, sizeof(OVERLAYRECORD));

    if (pPriv->scrnAttr == SCRN_ATTR_DUO_CLONE_VIEW) {
        igaIndex = (igaIndex == IGA1) ? IGA2 : IGA1;
        memset(&pPriv->ovlInfo[igaIndex - 1], 0, sizeof(OVERLAYRECORD));
    }

    /* disable VQ should be done before clear the flags
     * otherwise when playing next video right after this one, the system hangs*/
    if (pPriv->videoFlag & VIDEO_VQ_INUSE) {
        disableVirtualQueue(pScrn, pPriv);
    }

    if (pPriv->videoFlag & VIDEO_ACTIVE) {
        pPriv->videoFlag = 0;
    }

    pPriv->fourCC = 0;
    pPriv->framenum = 0;

    return TRUE;
}

void
viaUploadToXVSurface(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv,
    unsigned long id, char *buf, ViaXvSurfacePtr pXvSurface,
    unsigned long width, unsigned long height)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIAPtr pVia0 =
        (pVia->IsSecondary) ? VIAPTR(pVia->pVIAEnt->pPrimaryScrn) : pVia;
    unsigned long srcPitch, srcPitch2, srcYSize, srcUVSize, dstPitch,
        dstPitch2, dstYSize, dstUVSize;
    unsigned long frameIndex = pPriv->pXvSurface->cur_idx;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    /*  Copy image data from system memory to video memory
     *  TODO: use DRM's DMA feature to accelerate data copy */
    /*if BO is in PCIE and CPU will operate it, it should be set cpu domain */
    if (pPriv->xv_refine_using_pcie) {
        dri_bo_set_cpu_domain(pPriv->xvMem.bo);
    }
    dri_bo_wait(pPriv->xvMem.bo);
    switch (id) {
    case FOURCC_YV12:
        srcPitch = ALIGN_TO(width, 4);
        srcPitch2 = ALIGN_TO((width >> 1), 4);;
        srcYSize = srcPitch * height;
        srcUVSize = srcPitch2 * (height >> 1);

        dstPitch = pXvSurface->pitch;
        dstYSize = dstPitch * height;
        dstUVSize = dstYSize >> 2;

        /*  Because in CreateSurface, we unify fourcc to YUY2,
         *  so we use CopyYUV420To422 instead of CopyDataYUV420 */
        if (pXvSurface->format == FOURCC_YUY2) {
            CopyYUV420To422(buf, buf + srcYSize, buf + srcYSize + srcUVSize,
                pXvSurface->vaddr[frameIndex],
                srcPitch, srcPitch2, dstPitch, height, width);
        } else if (pXvSurface->format == FOURCC_YV12) {
            CopyDataYUV420(buf, buf + srcYSize, buf + srcYSize + srcUVSize,
                pXvSurface->vaddr[frameIndex],
                pXvSurface->vaddr[frameIndex] + dstYSize,
                pXvSurface->vaddr[frameIndex] + dstYSize + dstUVSize,
                srcPitch, srcPitch2, dstPitch, height, width);
        } else if (pXvSurface->format == FOURCC_NV12) {
            CopyYUV420ToNV12(buf, buf + srcYSize, buf + srcYSize + srcUVSize,
                pXvSurface->vaddr[frameIndex],
                pXvSurface->vaddr[frameIndex] + dstYSize,
                srcPitch, srcPitch2, dstPitch, height, width,
                pPriv->xv_refine_using_pcie);
        }
        break;

    case FOURCC_I420:

        srcPitch = ALIGN_TO(width, 4);
        srcPitch2 = ALIGN_TO((width >> 1), 4);;
        srcYSize = srcPitch * height;
        srcUVSize = srcPitch2 * (height >> 1);
        dstPitch = pXvSurface->pitch;

        CopyI420To422(buf, buf + srcYSize, buf + srcYSize + srcUVSize,
            pXvSurface->vaddr[frameIndex],
            srcPitch, srcPitch2, dstPitch, height, width);
        break;

    case FOURCC_YUY2:
    default:

        srcPitch = ALIGN_TO(width, 4);
        dstPitch = pXvSurface->pitch;

        CopyDataYUV422(buf, pXvSurface->vaddr[frameIndex],
            srcPitch << 1, dstPitch, height, width << 1);
        break;
    }

    if (pPriv->xv_refine_using_pcie) {
        switch (pXvSurface->format) {
        case FOURCC_YV12:
        case FOURCC_NV12:
            viaFlushPCIECache(pVia,
                (pXvSurface->offset[frameIndex] - pVia0->agpTexBaseOffset),
                (pXvSurface->pitch * pXvSurface->height * 3 / 2));
            break;
        case FOURCC_YUY2:
            viaFlushPCIECache(pVia,
                (pXvSurface->offset[frameIndex] - pVia0->agpTexBaseOffset),
                (pXvSurface->pitch * pXvSurface->height));
            break;
        }
    }
}

/* Find out which video overlay is now being focused.pPriv is the current port
   pointer */
static Bool
viaCheckVideoOnTop(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv, RegionPtr pDrwReg)
{
    VIAPtr pVia = VIAPTR(pScrn);
    viaPortPrivPtr _pPriv = pVia->pPriv[!pPriv->xv_portnum];    /*the other port */
    Bool intersected;
    unsigned long _inRegion;
    Bool onTop = FALSE;
    RegionPtr _pDrwReg, _pInsRegion;
    BoxPtr pbox;

    /* check if both ports have clip region.If only the current port has the clip region,
     * we don't have to check anymore,just return TRUE.That means the other port
     * are not even working yet.*/
    if (!_pPriv || &(_pPriv->clip) == NULL) {
        return TRUE;
    }

    /*reconstruct the other port's drawable region */
    BoxRec _box = { _pPriv->drw_x,
        _pPriv->drw_y,
        _pPriv->drw_x + _pPriv->drw_w,
        _pPriv->drw_y + _pPriv->drw_h
        };
    BoxRec _Insbox = { 0, 0, 0, 0 };

    _pDrwReg = REGION_CREATE(pScrn->pScreen, &_box, 1);
    _pInsRegion = REGION_CREATE(pScrn->pScreen, &_Insbox, 1);

    /*get the overlapping region of the two overlay */
    intersected =
        REGION_INTERSECT(pScrn->pScreen, _pInsRegion, pDrwReg, _pDrwReg);

    /*we have overlapping region. */
    if (intersected) {
        pbox = REGION_EXTENTS(pScrn->pScreen, _pInsRegion);

        DBG_DD(("intersected:%d,x1:%d,y1:%d,x2:%d,y2:%d\n", intersected,
            pbox->x1, pbox->y1, pbox->x2, pbox->y2));

        /*check if the area is in the current port's clip region? */
        _inRegion = RECT_IN_REGION(pScrn->pScreen, &pPriv->clip, pbox);
        if (_inRegion > rgnOUT) {
            onTop = TRUE;
        }
    } else {                   /*no overlapping area */
        onTop = TRUE;
    }

    REGION_DESTROY(pScrn->pScreen, _pDrwReg);
    REGION_DESTROY(pScrn->pScreen, _pInsRegion);

    return onTop;
}

int
viaFixUpOverlayInSAMM(ScrnInfoPtr pScrn, short *drw_x, short *drw_y)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    int viaScrnIndex = 0;

    if (pVia->IsSecondary)
        viaScrnIndex = 1;

    if ((viaGfxInfo->xrandrEnabled == FALSE && viaGfxInfo->screenAttr.m1.samm)) {
        if (viaGfxInfo->igaAttr.iga2_left == TRUE) {
            if ((viaGfxInfo->screenInfo[viaScrnIndex].igaInuse == IGA1)
                && (*drw_x < 0)) {
                return TRUE;
            }
        } else if (viaGfxInfo->igaAttr.iga2_right == TRUE) {
            if ((viaGfxInfo->screenInfo[viaScrnIndex].igaInuse == IGA2)
                && (*drw_x < 0)) {
                return TRUE;
            }
        } else if (viaGfxInfo->igaAttr.iga2_above == TRUE) {
            if ((viaGfxInfo->screenInfo[viaScrnIndex].igaInuse == IGA1)
                && (*drw_y < 0)) {
                return TRUE;
            }
        } else if (viaGfxInfo->igaAttr.iga2_below == TRUE) {
            if ((viaGfxInfo->screenInfo[viaScrnIndex].igaInuse == IGA2)
                && (*drw_y < 0)) {
                return TRUE;
            }
        }
    }

    return FALSE;
}

void
viaFixUpV3OnIGA2Issue(viaGfxInfoPtr viaGfxInfo, viaPortPrivPtr pPriv,
    unsigned long curIGA)
{
    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    if (curIGA == IGA2) {
        if (viaGfxInfo->chipId != VIA_DEVICE_VT3314) {
            if (pPriv->videoFlag & VIDEO_3_INUSE) {
                pPriv->forceEngReAlloc = TRUE;
                pPriv->patchV3OnIga2 = TRUE;
            }
        }
    } else if (curIGA == IGA1) {
        if (viaGfxInfo->chipId != VIA_DEVICE_VT3314) {
            if (pPriv->patchV3OnIga2 == TRUE) {
                pPriv->forceEngReAlloc = TRUE;
                pPriv->patchV3OnIga2 = FALSE;
            }
        }
    }
}

unsigned long
viaAllocReallocEngine(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv,
    Bool * forceUpdate, Bool * forceRedraw)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    unsigned long flags = 0;
    unsigned long ret = FALSE;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    if (!(pPriv->videoFlag & VIDEO_ACTIVE)) {
    /* record the pPriv into pVia for later viaAdjustFrame() or
       VIARand12RUpdateOverlay() path */
    pVia->pPriv[pPriv->xv_portnum] = pPriv;
    ret = initEngineStatus(pVidData, &flags);

    /* init Video status flag */
    pPriv->videoFlag = flags;
    DBG_DD(("  pPriv->videoFlag = %lx\n", pPriv->videoFlag));

    if (ret == FALSE) {
        freeEngineStatus(pVidData, pPriv);
        pPriv->redirected = TRUE;
    } else {
        /* write Color Space Conversion param. */
        SetColorSpace(pVia);

        if (pPriv->videoFlag & VIDEO_VQ_INUSE) {
            enableVirtualQueue(pScrn, pPriv);
        }
    }

    pPriv->videoFlag |= VIDEO_ACTIVE;

    } else if (pPriv->forceEngReAlloc == TRUE) {
        if (pPriv->redirected) {
            /* case 1 : Texture video  ---> Xv Overlay */
            viaDestroyXvSurface(pScrn, pPriv);
        } else {
            /* case 2:  Xv Overlay ---> Xv Overlay */
            StopOVerlay(pScrn, pPriv);
            viaDestroyHQVSurface(pScrn, pPriv, pPriv->scrnAttr,
                pPriv->curIGA);
            viaDestroyROTSurface(pScrn, pPriv, pPriv->scrnAttr,
                pPriv->curIGA);
            freeEngineStatus(pVidData, pPriv);
            pPriv->skipDataCopy = TRUE;
        }
        pVia->pPriv[pPriv->xv_portnum] = pPriv;

        if (!pPriv->patchV3OnIga2) {
            ret = initEngineStatus(pVidData, &flags);
            pPriv->videoFlag |= flags;
            if (ret == FALSE) {
                if (!pPriv->redirected) {
                    pPriv->redirected = TRUE;
                    viaDestroyXvSurface(pScrn, pPriv);
                }
                freeEngineStatus(pVidData, pPriv);
            } else {
                *forceUpdate = TRUE;
                if (pPriv->redirected) {
                    pPriv->redirected = FALSE;
                    *forceRedraw = TRUE;
                }
            }
        } else {
            viaDestroyXvSurface(pScrn, pPriv);
            pPriv->redirected = TRUE;
        }
        pPriv->forceEngReAlloc = FALSE;
    }

    return ret;
}

int
viaDisplayOverlayVideo(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv,
    unsigned long clipChanged, unsigned long forceRedraw,
    unsigned long forceUpdate)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    DrawablePtr pDraw = pPriv->pDraw;
    PixmapPtr pPixmap = pPriv->pPixmap;
    unsigned long flags = 0;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    /* draw color region */
    if ((clipChanged && pPriv->autopaint_colorkey) || forceRedraw) {
        BoxPtr pBox = REGION_EXTENTS(pScrn->pScreen, &pPriv->clip);
        RegionPtr clipBoxes = REGION_CREATE(pScrn->pScreen, pBox, 1);

        REGION_COPY(pScrn->pScreen, clipBoxes, &pPriv->clip);
        if (pDraw->type == DRAWABLE_WINDOW) {
            xf86XVFillKeyHelperDrawable(pDraw, pPriv->colorKey, clipBoxes);
            DamageDamageRegion((DrawablePtr) pPixmap, clipBoxes);
        } else {
            xf86XVFillKeyHelper(pScrn->pScreen, pPriv->colorKey, clipBoxes);
        }
        REGION_DESTROY(pScrn->pScreen, clipBoxes);
    }

    /* extend the current clip to a bigger rectange.The pPriv->clip reflects
     * the actual visible region, but we also want the invisible part to be
     * participated in compution. So the drawable region is used.*/
    if (clipChanged) {
        BoxRec box = { pPriv->drw_rect.left, pPriv->drw_rect.top,
            pPriv->drw_rect.right, pPriv->drw_rect.bottom
        };
        RegionPtr pDrwReg = REGION_CREATE(pScrn->pScreen, &box, 1);

        pPriv->vidOnTop = viaCheckVideoOnTop(pScrn, pPriv, pDrwReg);
        REGION_DESTROY(pScrn->pScreen, pDrwReg);
    }

    if (forceUpdate) {
        static DDUPDATEOVERLAY updateOvlRec;

        /* fill video overlay parameter */
        updateOvlRec.rSrc = pPriv->src_rect;
        updateOvlRec.rDest = pPriv->drw_rect;
        updateOvlRec.dwFlags = DDOVER_SHOW | DDOVER_KEYDEST;
        if (pPriv->vidOnTop) {
            updateOvlRec.dwFlags |= DDOVER_ON_TOP;
        }

        if (UpdateOverlay(pScrn, pPriv, &updateOvlRec) == -1) {
            DBG_DD(("  call updateoverlay fail. \n"));
            return XvBadAlloc;
        }
    } else {
        /* flip */
        Flip(pScrn, pPriv);
    }

    return Success;
}

int
viaPutImageG(ScrnInfoPtr pScrn,
    short src_x, short src_y,
    short drw_x, short drw_y,
    short src_w, short src_h,
    short drw_w, short drw_h,
    int id, unsigned char *buf,
    short width, short height,
    Bool sync, RegionPtr clipBoxes, pointer data, DrawablePtr pDraw)
{
    ScreenPtr pScreen = pScrn->pScreen;
    VIAPtr pVia = VIAPTR(pScrn);
    viaPortPrivPtr pPriv = (viaPortPrivPtr) data;
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    unsigned long curIGA = IGA_NONE;
    Bool clipChanged = FALSE;
    Bool forceUpdate = FALSE;
    Bool forceRedraw = FALSE;           /* Fall back to Ovleray from texture video */
    int ret = Success;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    if (pPriv->xv_portnum >= XV_PORT_NUM_OVERLAY) {
        DBG_DD(("  XV Port exceed the maximum!\n"));
        return BadAlloc;
    }

    DBG_DD(("  Screen[%d]\n", pScrn->scrnIndex));
    DBG_DD(("  FourCC=0x%08x width=%hd height=%hd sync=%d\n", id, width,
        height, sync));
    DBG_DD(("  src_x=%hd src_y=%hd src_w=%hd src_h=%hd colorkey=0x%lx\n",
        src_x, src_y, src_w, src_h, pPriv->colorKey));
    DBG_DD(("  drw_x=%hd drw_y=%hd drw_w=%hd drw_h=%hd\n", drw_x, drw_y,
        drw_w, drw_h));
    DBG_DD(("  pDraw = %p\n", pDraw));

    /*choose the right path */
    if (id == FOURCC_VMI_XV) {
        /* For vmi path, do not need to create xv surface */
        pPriv->vmi_data = (viaVMIDataPtr) buf;
    } else {
        pPriv->vmi_data = (viaVMIDataPtr) NULL;
    }

    /* To avoid the situation when video across two screen when SAMM,
     * As it will call twice viaPutImageG with pScrn->scrnIndex=x and y*/
    if (viaFixUpOverlayInSAMM(pScrn, &drw_x, &drw_y)) {
        return Success;
    }

    /* 1. video/hqv engine management */
    viaAllocReallocEngine(pScrn, pPriv, &forceUpdate, &forceRedraw);

    /* 2. determine current iga, on which video overlay is attached */
    determineCurrentIGAInUse(pScrn, &curIGA, drw_x, drw_y);
    if (curIGA == IGA_NONE) {
        pPriv->curIGA = curIGA;
        DBG_DD(("  current IGA is zero, return\n"));
        return BadAlloc;
    } else {

        viaFixUpV3OnIGA2Issue(viaGfxInfo, pPriv, curIGA);
    }

    /* If there is bandwidth issue, block the H/W overlay */
    if (pVidData->dwRejectOverlay) {
        DBG_DD(("  Bandwidth issue, rejected!\n"));
        return BadAlloc;
    }

    /* 3. redirect to Texture video path in some specific situation */
    if (pPriv->redirected) {
        /* refresh the pPriv->scrnAttr and pPriv->curIGA here ! */
        pPriv->scrnAttr = viaGfxInfo->screenAttr.uint;
        pPriv->curIGA = curIGA;
        return viaPutImageTexturedG(pScrn, src_x, src_y,
            drw_x, drw_y, src_w, src_h, drw_w, drw_h, id, buf,
            width, height, sync, clipBoxes, data, pDraw);
    }

    /* 4. surface management */
    if ((pPriv->width != width) || (pPriv->height != height)) {
        viaDestroyXvSurface(pScrn, pPriv);
        viaDestroyHQVSurface(pScrn, pPriv, pPriv->scrnAttr, pPriv->curIGA);
        viaDestroyROTSurface(pScrn, pPriv, pPriv->scrnAttr, pPriv->curIGA);
    }

    if ((pPriv->curIGA != curIGA)
        || (pPriv->scrnAttr != viaGfxInfo->screenAttr.uint)) {
        viaDestroyHQVSurface(pScrn, pPriv, pPriv->scrnAttr, pPriv->curIGA);
        viaDestroyROTSurface(pScrn, pPriv, pPriv->scrnAttr, pPriv->curIGA);
    }
    /* refresh the pPriv->scrnAttr and pPriv->curIGA here ! */
    if (pPriv->curIGA != curIGA) {
        forceUpdate = TRUE;
    }
    pPriv->scrnAttr = viaGfxInfo->screenAttr.uint;
    pPriv->curIGA = curIGA;
    /*VMI path need a fake Xv Surface */
    if (!pPriv->pXvSurface || id == FOURCC_VMI_XV) {
        if (viaCreateXvSurface(pScrn, pPriv, id, width, height) != TRUE) {
            viaDestroyXvSurface(pScrn, pPriv);
            freeEngineStatus(pVidData, pPriv);
            DBG_DD(("  Xv surface memory allocation failure!\n"));
            return BadAlloc;
        }
        pPriv->skipDataCopy = FALSE;
    }
    if (viaCreateHQVSurface(pScrn, pPriv, id, width, height) != TRUE) {
        DBG_DD(("  HQV surface memory allocation failure!\n"));
        viaDestroyXvSurface(pScrn, pPriv);
        return BadAlloc;
    }

    /* 5. upload video data to Xv surface */
    if (id != FOURCC_VMI_XV) {

        pPriv->pXvSurface->cur_idx = pPriv->framenum % XV_SURFACE_NUM;
        pPriv->framenum++;

        if (pPriv->skipDataCopy) {
            pPriv->skipDataCopy = FALSE;
        } else {
            viaUploadToXVSurface(pScrn, pPriv, id, buf, pPriv->pXvSurface,
                width, height);
        }
    } else {
        pPriv->pXvSurface->cur_idx = pPriv->framenum % VMI_SURFACE_NUM;
        pPriv->framenum++;

        if (pPriv->skipDataCopy)
            pPriv->skipDataCopy = FALSE;

    }

    /* 6. update clip region, and the flags of clipChanged, forceUpdate */
    if (!REGION_EQUAL(pScrn->pScreen, &pPriv->clip, clipBoxes)) {
        REGION_COPY(pScrn->pScreen, &pPriv->clip, clipBoxes);
        clipChanged = TRUE;
        /* if rotate status changes, force update overlay */
        forceUpdate = TRUE;
        DBG_DD(("  clipchanages\n"));
    }

    /* if rotate status changes, force update overlay */
    if (viaGfxInfo->screenAttr.uint & SCRN_ATTR_DUO_CLONE_VIEW) {
        if ((pPriv->igaRRStatus[0] != viaGfxInfo->igaInfo[0].igaRRStatus.unit)
            || (pPriv->igaRRStatus[1] !=
            viaGfxInfo->igaInfo[1].igaRRStatus.unit)) {
            forceUpdate = TRUE;
        }
    } else {
        if ((pPriv->igaRRStatus[pPriv->curIGA - 1] !=
            viaGfxInfo->igaInfo[pPriv->curIGA - 1].igaRRStatus.unit)) {
            forceUpdate = TRUE;
        }
    }

    /*if panning status changes, force update overlay */
    if ((pVidData->panning_x[pPriv->curIGA - 1] !=
        pVidData->panning_old_x[pPriv->curIGA - 1])
        || (pVidData->panning_y[pPriv->curIGA - 1] !=
        pVidData->panning_old_y[pPriv->curIGA - 1])) {

        pVidData->panning_old_x[pPriv->curIGA - 1] =
            pVidData->panning_x[pPriv->curIGA - 1];
        pVidData->panning_old_y[pPriv->curIGA - 1] =
            pVidData->panning_y[pPriv->curIGA - 1];
        forceUpdate = TRUE;
    }

    if ((pPriv->drw_x == drw_x) && (pPriv->drw_y == drw_y) &&
        (pPriv->drw_w == drw_w) && (pPriv->drw_h == drw_h) &&
        (pPriv->src_x == src_x) && (pPriv->src_y == src_y) &&
        (pPriv->src_w == src_w) && (pPriv->src_h == src_h) &&
        (pPriv->videoFlag & VIDEO_ACTIVE)) {
        DBG_DD(("  If the dest rec & src rect & extendFIFO doesn't change, \
                don't do UpdateOverlay\n"));
    } else {
        forceUpdate = TRUE;
    }
    /*this force update is from VIARandR12UpdateOverlay */
    if (pPriv->forceUpdate == TRUE) {
        forceUpdate = TRUE;
        pPriv->forceUpdate = FALSE;
    }
    /* 7. display Xv overlay video */
    if (!pPriv->textured) {
        pPriv->src_rect.left = src_x;
        pPriv->src_rect.top = src_y;
        pPriv->src_rect.right = src_x + src_w;
        pPriv->src_rect.bottom = src_y + src_h;

        pPriv->drw_rect.left = drw_x;
        pPriv->drw_rect.top = drw_y;
        pPriv->drw_rect.right = drw_x + drw_w;
        pPriv->drw_rect.bottom = drw_y + drw_h;

        pPriv->pDraw = pDraw;

        if (pDraw->type == DRAWABLE_WINDOW) {
            pPriv->pPixmap = (*pScreen->GetWindowPixmap) ((WindowPtr) pDraw);
        } else {
            pPriv->pPixmap = (PixmapPtr) pDraw;
        }

        ret =
            viaDisplayOverlayVideo(pScrn, pPriv, clipChanged, forceRedraw,
            forceUpdate);
    }

    BACKUP_PARAMETERS(pPriv, id, src_x, src_y, drw_x, drw_y,
        src_w, src_h, drw_w, drw_h, width, height, buf, sync, pDraw);

    /*VMI path destroy the fake Xv Surface */
    if (id == FOURCC_VMI_XV) {
        viaDestroyXvSurface(pScrn, pPriv);
    }
    return ret;
}

static int
viaReputImageG(ScrnInfoPtr pScrn, short drw_x,
    short drw_y, RegionPtr clipBoxes, pointer data, DrawablePtr pDraw)
{
    viaPortPrivPtr pPriv = (viaPortPrivPtr) data;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    /* 1, it need to re-draw colorkey region when clip */
    /* 2, clean the data staruct clip record */
    REGION_EMPTY(pScrn->pScreen, &pPriv->clip);

    return Success;
}

static int
viaQueryImageAttributesG(ScrnInfoPtr pScrn,
    int id, unsigned short *w, unsigned short *h, int *pitches, int *offsets)
{
    int size, tmp;

    DBG_DD(("  FourCC=0x%x\n", id));
    DBG_DD(("  Screen[%d]\n", pScrn->scrnIndex));

    if ((!w) || (!h))
        return 0;

    if (*w > MAXWIDTH) {
        *w = MAXWIDTH;
    }

    if (*h > MAXHEIGHT) {
        *h = MAXHEIGHT;
    }

    *w = ALIGN_TO(*w, 2);
    if (offsets) {
        offsets[0] = 0;
    }

    switch (id) {
    case FOURCC_YV12:               /*Planar format : YV12 -4:2:0 */
    case FOURCC_I420:
        *h = ALIGN_TO(*h, 2);
        size = ALIGN_TO(*w, 4);

        if (pitches) {
            pitches[0] = size;
        }

        size *= *h;

        if (offsets) {
            offsets[1] = size;
        }

        tmp = ALIGN_TO((*w >> 1), 4);

        if (pitches) {
            pitches[1] = pitches[2] = tmp;
        }

        tmp *= (*h >> 1);
        size += tmp;

        if (offsets) {
            offsets[2] = size;
        }

        size += tmp;
        break;

    case FOURCC_AI44:
    case FOURCC_IA44:
        size = *w * *h;
        if (pitches) {
            pitches[0] = *w;
        }

        if (offsets) {
            offsets[0] = 0;
        }

        break;
    case FOURCC_VDPAU:
        size = sizeof(viaVdpImageDataRec);
        if (pitches)
            pitches[0] = size;
        break;
    case FOURCC_VMI_XV:
        size = sizeof(viaVMIDataRec);
        if (pitches)
            pitches[0] = size;
        break;
    case FOURCC_UYVY:               /*Packed format : UYVY -4:2:2 */
    case FOURCC_YUY2:               /*Packed format : YUY2 -4:2:2 */
    default:
        size = (*w << 1);

        if (pitches) {
            pitches[0] = size;
        }
        size *= *h;
        break;
    }

    if (pitches) {
        DBG_DD(("  pitches[0]=%d, pitches[1]=%d, pitches[2]=%d, ", pitches[0],
            pitches[1], pitches[2]));
    }

    if (offsets) {
        DBG_DD(("  offsets[0]=%d, offsets[1]=%d, offsets[2]=%d, ", offsets[0],
            offsets[1], offsets[2]));
    }

    DBG_DD(("  width=%d, height=%d \n", *w, *h));

    return size;
}

unsigned long
determineCurrentIGAInUse(ScrnInfoPtr pScrn, unsigned long *curIGA, int left,
    int top)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    int viaScrnIndex = 0;

    if (pVia->IsSecondary)
        viaScrnIndex = 1;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    *curIGA = IGA_NONE;

    if (viaGfxInfo->xrandrEnabled == TRUE) {
        if (viaGfxInfo->screenAttr.m1.singleview == TRUE) {
            *curIGA = viaGfxInfo->screenInfo[viaScrnIndex].igaInuse;
        } else if (viaGfxInfo->screenAttr.m2.clone == TRUE) {
            *curIGA = IGA1;
        } else if (viaGfxInfo->screenAttr.m2.extend == TRUE) {
            if (viaGfxInfo->igaAttr.iga2_left == TRUE) {
                if (left >= (int)viaGfxInfo->igaInfo[1].visible_width
                    || top >= (int)viaGfxInfo->igaInfo[1].visible_height) {
                    *curIGA = IGA1;
                } else {
                    *curIGA = IGA2;
                }
            } else if (viaGfxInfo->igaAttr.iga2_right == TRUE) {
                if (left >= (int)viaGfxInfo->igaInfo[0].visible_width
                    || top >= (int)viaGfxInfo->igaInfo[0].visible_height) {
                    *curIGA = IGA2;
                } else {
                    *curIGA = IGA1;
                }
            } else if (viaGfxInfo->igaAttr.iga2_above == TRUE) {
                if (top >= (int)viaGfxInfo->igaInfo[1].visible_height
                    || left > (int)viaGfxInfo->igaInfo[0].visible_width) {
                    *curIGA = IGA1;
                } else {
                    *curIGA = IGA2;
                }
            } else if (viaGfxInfo->igaAttr.iga2_below == TRUE) {
                if (top >= (int)viaGfxInfo->igaInfo[0].visible_height
                    || left > (int)viaGfxInfo->igaInfo[0].visible_width) {
                    *curIGA = IGA2;
                } else {
                    *curIGA = IGA1;
                }
            } else {
                *curIGA = IGA_NONE;
            }
        }
    } else {
        if (viaGfxInfo->screenAttr.m1.duoview == TRUE) {
            *curIGA = IGA1;
        } else if ((viaGfxInfo->screenAttr.m1.singleview == TRUE) ||
            (viaGfxInfo->screenAttr.m1.samm == TRUE)) {
            *curIGA = viaGfxInfo->screenInfo[viaScrnIndex].igaInuse;
        }
    }

    return TRUE;
}

#else
void
viaInitVideo(ScreenPtr pScreen)
{
}
#endif /* !XvExtension */
