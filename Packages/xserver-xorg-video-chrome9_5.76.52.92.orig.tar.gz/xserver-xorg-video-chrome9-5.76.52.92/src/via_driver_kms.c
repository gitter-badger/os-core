/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/poll.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <linux/version.h>

#include "via_driver.h"
#ifndef XSERVER_LIBPCIACCESS
#include "xf86RAC.h"
#endif
#include "xf86Priv.h"
#include "shadowfb.h"
#include "mipointer.h"
#include "mipointrst.h"
#include "inputstr.h"
#include "globals.h"

#include "via_video.h"
#include "hw.h"
#include "via_serial.h"
#include "debug.h"               /* for DBG_DD */
#include "via_eng_regs.h"
#include "via_swov.h"

#ifdef XF86DRI
#include "dri.h"
#endif
#include "via_mergedfb.h"           /*for mergedfb */

#include "via_rotate.h"               /* for rotate feature. */
#include "via_dmabuffer.h"
#include "via_exa_common.h"

#include "via_lcd.h"
#include "via_dp.h"

#include "xf86Crtc.h"
#include "xf86RandR12.h"
#include "via_common.h"
#include "via_modedata.h"
#include "via_display.h"
#include "via_output.h"
#include "via_displcd.h"
/* add for ttm support */
#include "via_bo_gem.h"
#include "drmmode_display.h"
#define DPMS_SERVER

extern int gVIAEntityIndex;
extern unsigned int via_xf86_version_current;
extern Bool VIAnoPanoramiXExtension;
extern NEWVIAGRAPHICINFO NEWVIAGraphicInfo;
extern Bool ad9389_module_loaded;

extern Bool VIADRIFBInit(ScreenPtr pScreen, VIAPtr pVia);
extern void VIAEnableVQ(ScrnInfoPtr pScrn);
extern void VIAARGBCursorInit(ScrnInfoPtr pScrn);

/* query NB to get frame buffer size */
void
VIAGetFBSize_kms(ScrnInfoPtr pScrn)
{
    unsigned long configid, deviceid, FBSize = 0;
    int VideoMemSize;
    Bool DeviceFound = FALSE;
    VIAPtr pVia = VIAPTR(pScrn);

    for (configid = 0x80000000; configid < 0x80010800; configid += 0x100) {
        outl((unsigned long)0xCF8, configid);
        deviceid = (inl((unsigned long)0xCFC) >> 16) & 0xffff;

        switch (deviceid) {
        case VX800_FUNCTION3:
        case VX855_FUNCTION3:
        case VX900_FUNCTION3:
            outl((unsigned long)0xCF8, configid + 0xA0);
            FBSize = inl((unsigned long)0xCFC);
            DeviceFound = TRUE;           /* Found device id */
            break;
            /* Can't set default, otherwise FBSize will be modified incorrectly */
        default:
            break;
        }

        if (DeviceFound) {
            break;               /* Found device id, so exit for loop */
        }
    }

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Device ID = %lx\n",
        deviceid));

    FBSize = FBSize & 0x00007000;
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "FB Size = %lx\n", FBSize));

    switch (FBSize) {
    case 0x00001000:
        VideoMemSize = (8 << 10);      /*8M */
        break;

    case 0x00002000:
        VideoMemSize = (16 << 10);     /*16M */
        break;

    case 0x00003000:
        VideoMemSize = (32 << 10);     /*32M */
        break;

    case 0x00004000:
        VideoMemSize = (64 << 10);     /*64M */
        break;

    case 0x00005000:
        VideoMemSize = (128 << 10);    /*128M */
        break;

    case 0x00006000:
        VideoMemSize = (256 << 10);    /*256M */
        break;

    case 0x00007000:
        VideoMemSize = (512 << 10);    /*512M */
        break;

    default:
        VideoMemSize = (32 << 10);     /*32M */
        break;
    }

    pScrn->videoRam = VideoMemSize;

    return;
}

void
VIAGetdwProjectIDRevision_kms(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    switch (pVia->Chipset) {
    case VIA_VX800:
        pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3353;
        break;
    case VIA_VX855:
        pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3409;
        break;
    case VIA_VX900:
        pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3410;
        break;
    default:
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "VIABIOSInit: Unknown Device ID\n"));
        break;
    }
}

/*
 * check drm mode setting enable or not
 */
Bool
via_kernel_mode_enabled(ScrnInfoPtr pScrn)
{
    struct pci_device *PciInfo;
    EntityInfoPtr pEnt;
    char *busIdString;
    int ret;

    pEnt = xf86GetEntityInfo(pScrn->entityList[0]);
    PciInfo = xf86GetPciInfoForEntity(pEnt->index);

    if (!xf86LoaderCheckSymbol("DRICreatePCIBusID")) {
        xf86DrvMsgVerb(pScrn->scrnIndex, X_INFO, 0,
            "[KMS] No DRICreatePCIBusID symbol, kms false\n");
        return FALSE;
    }

    busIdString = DRICreatePCIBusID(PciInfo);

    ret = drmCheckModesettingSupported(busIdString);
    free(busIdString);

    if (ret) {
        xf86DrvMsgVerb(pScrn->scrnIndex, X_INFO, 0,
            "[KMS] Kernel modesetting is not enabled.\n");
        return FALSE;
    }

    xf86DrvMsgVerb(pScrn->scrnIndex, X_INFO, 0,
        "[KMS] Kernel modesetting is enabled.\n");
    return TRUE;
}

static Bool
viaDrmModeInit(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);

    if (drmmode_pre_init(pScrn, pVia->drmFD,
        pScrn->bitsPerPixel / 8) == FALSE) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Kernel modesetting setup failed\n");
        PreInitCleanup(pScrn);
        return FALSE;
    }
    return TRUE;
}

void
VIAEnableMMIO_kms(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned char val;

    val = VGAIN8(0x3c3);
    VGAOUT8(0x3c3, val | 0x01);
    val = VGAIN8(VGA_MISC_OUT_R);
    VGAOUT8(VGA_MISC_OUT_W, val | 0x01);
    /* Unlock Extended IO Space */
    viaWriteVgaIo(REG_SR10, 0x01);
    /* Unlock CRTC register protect */
    if (VIAGetChipsetRevisionID() >= REVISION_VX855_A1) {
        viaWriteVgaIoBits(REG_CR47, 0, 0x10);
    } else {
        viaWriteVgaIoBits(REG_CR47, 0, 0x01);
    }
#if 0
    /* Save some important register before we change its value */
    VIAPreSaveReg(pScrn);
#endif
    /* Enable MMIO */
    if (pVia->IsSecondary) {
        viaWriteVgaIoBits(REG_SR1A, 0x38, 0x38);
    }
    return;
}

Bool
VIAMapMMIO_kms(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIAMapMMIO_kms\n"));

    pVia->MmioBase = MEMBASE(pVia->PciInfo, 1);

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_PROBED,
        "mapping MMIO @ 0x%lx with size 0x%x\n",
        pVia->MmioBase, VIA_MMIO_REGSIZE));
    /* Notice: pci_device_map_range will return error if there is already a
     * map region which base and size are the same as what you want to map.
     * So in SAMM case, just map these regions only once. */
    /*Map MMIO */
#if XSERVER_LIBPCIACCESS
    pci_device_map_range(pVia->PciInfo,
    pVia->MmioBase,
    VIA_MMIO_REGSIZE, PCI_DEV_MAP_FLAG_WRITABLE, (void **)&pVia->MapBase);
#else
    pVia->MapBase = xf86MapPciMem(pScrn->scrnIndex,
    VIDMEM_MMIO, pVia->PciTag, pVia->MmioBase, VIA_MMIO_REGSIZE);
#endif
    pBIOSInfo->MapBase = pVia->MapBase;
    MMIO_MB1 = pVia->MapBase;
    /*Map Blit space */
    MMIOMapBase = pVia->MapBase + 0x8000;
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_PROBED,
        "mapping BitBlt MMIO @ 0x%lx with size 0x%x\n",
        pVia->MmioBase + VIA_MMIO_BLTBASE, VIA_MMIO_BLTSIZE));

#if XSERVER_LIBPCIACCESS
    pci_device_map_range(pVia->PciInfo,
    pVia->MmioBase + VIA_MMIO_BLTBASE,
    VIA_MMIO_BLTSIZE, PCI_DEV_MAP_FLAG_WRITABLE, (void **)&pVia->BltBase);
#else
    pVia->BltBase = xf86MapPciMem(pScrn->scrnIndex, VIDMEM_MMIO, pVia->PciTag,
    pVia->MmioBase + VIA_MMIO_BLTBASE, VIA_MMIO_BLTSIZE);
#endif
    if (!pVia->MapBase || !pVia->BltBase) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Internal error: cound not map registers\n");
        return FALSE;
    }
    /* Memory mapped IO for Video Engine */
    pVia->VidMapBase = pVia->MapBase + 0x200;
    VIAEnableMMIO_kms(pScrn);

    return TRUE;
}

#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
static Bool
VIACloseScreen_kms(int scrnIndex, ScreenPtr pScreen)
#else
static Bool
VIACloseScreen_kms(ScreenPtr pScreen)
#endif
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "[kms ]VIACloseScreen_kms\n"));
    drmmode_uevent_fini(pScrn, pVia->drmmode);
    viaExitVideo(pScrn);
    WaitIdle();

    if (!pVia->IsSecondary) {
        if (pVia->front_bo) {
            dri_bo_unreference(pVia->front_bo);
            pVia->front_bo = NULL;
        }
    } else {
        if (pVia->FBBase)
            pVia->FBBase = NULL;
    }

    viaExitAccel(pScreen);
    VIADRI2CloseScreen(pScreen);
    drmDropMaster(pVia->bufmgr->drmfd);
    pScreen->CloseScreen = pVia->CloseScreen;
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
    (*pScreen->CloseScreen) (pScrn->scrnIndex, pScreen);
#else
	(*pScreen->CloseScreen) (pScreen);
#endif
    via_bo_bufmgr_decon(pVia->bufmgr);

    return TRUE;
}

static Bool
VIASaveScreen_kms(ScreenPtr pScreen, int mode)
{
}

static void
VIABlockHandler_kms(int i, pointer blockData,
    pointer pTimeout, pointer pReadmask)
{

}


Bool
VIAPreInit_kms(ScrnInfoPtr pScrn, int flags)
{
    EntityInfoPtr pEnt;
    VIAPtr pVia;
    DevUnion *pPriv;
    VIABIOSInfoPtr pBIOSInfo;
    char *busId, *drmDriverName;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "[KMS] VIAPreInit_kms\n"));
    DEBUG(ErrorF("XORG_VERSION_CURRENT = %d\n", XORG_VERSION_CURRENT));
#if XORG_VERSION_CURRENT < XF86_VERSION_NUMERIC(1,5,99,0,0) || \
    XORG_VERSION_CURRENT >= XF86_VERSION_NUMERIC(7,0,0,0,0)
    via_xf86_version_current = xf86GetVersion();
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "XF86_VER=%d\n,Driver Not depending on this anymore\n",
        via_xf86_version_current));
#endif

    if (pScrn->numEntities > 1)
        return FALSE;

    if (flags & PROBE_DETECT)
        return FALSE;

    if (!VIAGetRec(pScrn))
        return FALSE;

    pVia = VIAPTR(pScrn);
    pVia->IsSecondary = FALSE;
    pVia->IsSuspending = FALSE;
    pVia->IsVIAModeInitRunOnceDone = FALSE;

    pBIOSInfo = pVia->pBIOSInfo;
    pBIOSInfo->s3utility = FALSE;
    pBIOSInfo->scrnIndex = pScrn->scrnIndex;

    pEnt = xf86GetEntityInfo(pScrn->entityList[0]);
#ifndef XSERVER_LIBPCIACCESS
    if (pEnt->resources) {
        goto fail;
    }
#endif
    pPriv = xf86GetEntityPrivate(pScrn->entityList[0], gVIAEntityIndex);
    pVia->pVIAEnt = pPriv->ptr;
    pVia->pVIAEnt->pVidData->viaGfxInfo->suspending = FALSE;

    if (xf86IsEntityShared(pScrn->entityList[0])) {
        if (xf86IsPrimInitDone(pScrn->entityList[0])) {
            pVia->pVIAEnt->pSecondaryScrn = pScrn;
            pVia->IsSecondary = TRUE;
            /* If SAMM, Hot key zoom locked
             * pScrn->zoomLocked = TRUE;*/
            pVia->pVIAEnt->pSecondaryScrn->zoomLocked = TRUE;
            pVia->pVIAEnt->pPrimaryScrn->zoomLocked = TRUE;
        } else {
            xf86SetPrimInitDone(pScrn->entityList[0]);
            pVia->pVIAEnt->pPrimaryScrn = pScrn;
            if (pVia->pVIAEnt->HasSecondary)
                pVia->IsSecondary = FALSE;
        }
    }

    if (VIAIsMAMM(pScrn)) {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "MAMM mode enable\n");
        pVia->IsMAMMEnable = TRUE;
    } else {
        pVia->IsMAMMEnable = FALSE;
    }

    pVia->PciInfo = xf86GetPciInfoForEntity(pEnt->index);
    pScrn->monitor = pScrn->confScreen->monitor;

    if (!via_open_drm_master(pScrn)) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "[drm]  failed to open the DRM\n");
        return FALSE;
    }

    /* Detect which chipset we used. */
    VIAProbeChipset(pScrn, pEnt);

    /*
     * We support depths of 8, 16 and 24.
     * We support bpp of 8, 16, and 32.
     */

    if (!xf86SetDepthBpp(pScrn, 0, 0, 0, Support32bppFb)) {
        goto fail;
    } else {
        switch (pScrn->depth) {
        case 8:
        case 16:
        case 24:
        case 32:
            /* OK */
            break;
        default:
            xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "Given depth (%d) is not supported by this driver\n",
                pScrn->depth);
            goto fail;
        }
    }

    xf86PrintDepthBpp(pScrn);

    if (pScrn->depth == 32)
        pScrn->depth = 24;

    if (pScrn->depth > 8) {
        rgb zeros = { 0, 0, 0 };
        if (!xf86SetWeight(pScrn, zeros, zeros)) {
            goto fail;
        } else {
            /* TODO check weight returned is supported */
        }
    }

    if (!xf86SetDefaultVisual(pScrn, -1)) {
        goto fail;
    } else {
        /* We don't currently support DirectColor at > 8bpp */
        if (pScrn->depth > 8 && pScrn->defaultVisual != TrueColor) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Given default visual"
            " (%s) is not supported at depth %d\n",
            xf86GetVisualName(pScrn->defaultVisual), pScrn->depth);
            goto fail;
        }
    }
    /* Set the bits per RGB for 8bpp mode */
    if (pScrn->depth == 8)
        pScrn->rgbBits = 8;
    /* We use a programmable clock */
    pScrn->progClock = TRUE;
    /* Set status word positions based on chip type. */
    switch (pVia->Chipset) {
    case VIA_VX800:
    case VIA_VX855:
    case VIA_VX900:
        pVia->myWaitIdle = WaitIdle_H6Chips;
        break;
    default:
        pVia->myWaitIdle = WaitIdle_H2Chips;
        break;
    }

    /* Because xf86Info.disableRandR is changeful, but it match the option
     * "RandR" in ServerLayout section, so we store it to pVia->useRandR */
#ifdef VIA_RANDR12_SUPPORT
    pVia->useRandR = !xf86Info.disableRandR;
    if (xf86Info.disableRandR) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "[KMS] can not enable kms with randr disabled \n");
        goto fail;
    }
    /* if xorg doesn't support RandR1.2, we can only support old architecture */
#else
    pVia->useRandR = FALSE;
#endif

    /* *_* We process all config file's options in one function *_* */
    VIAProcessCfgOptions(pScrn);

    if (pEnt->device->videoRam != 0) {
        if (!pScrn->videoRam)
            pScrn->videoRam = pEnt->device->videoRam;
        else
            xf86DrvMsg(pScrn->scrnIndex, X_WARNING,
                "Video Memory Size in Option is %d KB, Detect is %d KB!",
                pScrn->videoRam, pEnt->device->videoRam);
    }

    /* FrameBufferBase always represets physical start address for the
     * whole video memory. */
    if (pVia->Chipset == VIA_VX900) {
        pVia->FrameBufferBase = MEMBASE(pVia->PciInfo, 2);
    } else {
        pVia->FrameBufferBase = MEMBASE(pVia->PciInfo, 0);
    }

    /* ScreenBase represents physical start address for each screen */
    if (pVia->Chipset == VIA_VX900) {
        pVia->ScreenBase = MEMBASE(pVia->PciInfo, 2);
    } else {
        pVia->ScreenBase = MEMBASE(pVia->PciInfo, 0);
    }

    if (!VIAMapMMIO_kms(pScrn)) {
        if (pVia->pVbe != NULL)
            goto fail;
    }

    if (!LoadSubModule(pScrn->module, "ad9389", NULL, NULL, NULL, NULL, NULL,
        NULL)) {
        ad9389_module_loaded = FALSE;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Failed to load AD9389 module\n"));
    } else {
        ad9389_module_loaded = TRUE;
        pVia->AD9389SerialPort = DISP_DEFAULT_SETTING;
        pVia->IsAD9389Exist = viaSenseAD9389(&(pVia->AD9389SerialPort));
    }

    VIAGetdwProjectIDRevision_kms(pScrn);
    VIAGetFBSize_kms(pScrn);
    /* Initialize the colormap and this step must be done before calling
       xf86HandleColormaps. */
    Gamma zeros = { 0.0, 0.0, 0.0 };
    if (!xf86SetGamma(pScrn, zeros)) {
        vbeFree(pVia->pVbe);
        goto fail;
    }

    /* Split FB for SAMM */
    /* TODO: For now, split FB into two equal sections. This should
     *        be able to be adjusted by user with a config option. */
    if (pVia->IsSecondary) {
        VIAPtr pVia0;
        int videoram1 = 0;

        if (xf86GetOptValInteger(VIAOptions, OPTION_VIDEORAM1, &videoram1))
            xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
                "Option: VideoRAM1 %dkB\n", videoram1);

        if (videoram1 > 0)
            videoram1 = (videoram1 >> 10) << 10;

        if (videoram1 >= pScrn->videoRam - 16384)
            videoram1 = pScrn->videoRam - 16384;

        if ((videoram1 <= 16384) && (videoram1 > 0))
            videoram1 = 16384;

        if (videoram1)
            pScrn->videoRam = videoram1;
        else
            /* Reserve 11M for second scrn, because 1920x1440x4/2^20 = 10.5M */
            pScrn->videoRam = 11 * 1024;    

        pVia->pVIAEnt->pPrimaryScrn->videoRam -= pScrn->videoRam;
        pVia0 = VIAPTR(pVia->pVIAEnt->pPrimaryScrn);
        /*Rewrite pVia0->videoRambytes here */
        pVia0->videoRambytes = pVia->pVIAEnt->pPrimaryScrn->videoRam << 10;
        pVia->ScreenBase += (pVia->pVIAEnt->pPrimaryScrn->videoRam << 10);
    }

    if (!pVia->IsSecondary) {
        pVia->pVIAEnt->pScreensPublicInfo->VRamSize = pScrn->videoRam << 10;
    }

    /*Init videoRambytes to All Video Memory Size,
      pVia->videoRambytes may rewrite in SAMM mode */
    pVia->videoRambytes = pScrn->videoRam << 10;

    xf86DrvMsg(pScrn->scrnIndex, X_PROBED, "videoram =  %dk\n",
    pScrn->videoRam);

    if (xf86LoadSubModule(pScrn, "fb") == NULL) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Failed to load fb module");
        VIAFreeRec(pScrn);
        return FALSE;
    }

    if (!pVia->NoAccel) {
#ifdef VIA_HAVE_EXA
        if (pVia->useEXA) {
#if (EXA_VERSION_MAJOR >= 2)
            XF86ModReqInfo req;
            int errmaj, errmin;

            memset(&req, 0, sizeof(req));
            req.majorversion = 2;
            req.minorversion = 0;
            if (!LoadSubModule(pScrn->module, "exa", NULL, NULL, NULL, &req,
                &errmaj, &errmin)) {
                LoaderErrorMsg(NULL, "exa", errmaj, errmin);
                VIAFreeRec(pScrn);
                return FALSE;
            }
#else
            if (!xf86LoadSubModule(pScrn, "exa")) {
                VIAFreeRec(pScrn);
                return FALSE;
            }
#endif /* EXA_VERSION */
#endif /* VIA_HAVE_EXA */
        } else {
            if (!xf86LoadSubModule(pScrn, "xaa")) {
                VIAFreeRec(pScrn);
                return FALSE;
            }
        }
    }

    if (!pVia->ForceSWCursor) {
        if (!xf86LoadSubModule(pScrn, "ramdac")) {
            goto fail;
        }
    }

    if (pVia->shadowFB) {
        if (!xf86LoadSubModule(pScrn, "shadowfb")) {
            goto fail;
        }
    }
#ifdef VIA_RANDR12_SUPPORT
    /*============= For RandR v1.2 =======================*/
    if (pVia->useRandR) {
        int i;
        int pitch;

        xf86SetDpi(pScrn, 0, 0);
        if (!viaDrmModeInit(pScrn)) {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "[KMS] can not init drm mode \n");
            goto fail;
        }

        pitch =
            CMDISP_ALIGN_TO(pScrn->virtualX * (pScrn->bitsPerPixel >> 3), 32);
        pScrn->displayWidth = pitch / (pScrn->bitsPerPixel >> 3);
    }
    /*============= End RandR v1.2 =======================*/
#endif

    /* After calling xf86ValidateModes(), pScrn->virtualX(Y) will get the
       final value of virtual size. */
    /* At RandR v1.2, pScrn->virtualX,Y will get value after
       xf86InitialConfiguration */

    /*Refined Rotate process code, pBIOSInfo's item:VirtualX, VirtualY only
     * get the original value of pScrn->virtualX/virtualY
     * And NEVER change it's value in our code. It needs because the XV
     * panning support for setting correct Clipping Windows.
     */
    pBIOSInfo->VirtualX = pScrn->virtualX;
    pBIOSInfo->VirtualY = pScrn->virtualY;

    /* Set up screen parameters. */
    pVia->Bpp = pScrn->bitsPerPixel >> 3;
    pVia->Bpl = pScrn->displayWidth * pVia->Bpp;

    if (pBIOSInfo->MergedFB) {
        /*to set virtul X,Y value while mergedfb */
        if ((pBIOSInfo->Scrn2Position == viaRightOf) ||
            (pBIOSInfo->Scrn2Position == viaLeftOf))
            pScrn->virtualX += pScrn->virtualX;

        if ((pBIOSInfo->Scrn2Position == viaAbove) ||
            (pBIOSInfo->Scrn2Position == viaBelow))
            pScrn->virtualY += pScrn->virtualY;

        pScrn->displayWidth = pScrn->virtualX;
    }

    /* Check what type of cursor (SW/HW) to use. */
    VIACheckCursorTypeToUse(pScrn);
    VIAUnmapMem(pScrn);
    return TRUE;

  fail:
    free(pEnt);
    VIAFreeRec(pScrn);
    return FALSE;
}

#ifdef VIA_HAVE_UXA
Bool
VIACreateScreenResources_kms(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    PixmapPtr ppix;
    struct via_pixmap *vpix;
    rrScrPrivPtr pScrPriv;
    RROutputPtr  output;

    pScreen->CreateScreenResources = pVia->CreateScreenResources;
	
    pScrPriv = rrGetScrPriv(pScrn->pScreen);
    if(pScrPriv){
        output = pScrPriv->outputs[0]; 
        pScrPriv->primaryOutput = output;
    }

    xf86SetDesiredModes(pScrn);

    if (!(*pScreen->CreateScreenResources) (pScreen))
        return FALSE;

    if (pVia->useUXA && !uxa_resources_init(pScreen))
        return FALSE;

    pScreen->CreateScreenResources = VIACreateScreenResources_kms;

    drmmode_uevent_init(pScrn, pVia->drmmode);
    ppix = pScreen->GetScreenPixmap(pScreen);

    if (pVia->driType == DRI_1)
        (pScreen->ModifyPixmapHeader) (ppix, 0, 0, -1, -1,
            CMDISP_ALIGN_TO(pScrn->displayWidth * pScrn->bitsPerPixel / 8,
            32), NULL);

    via_set_pixmap_bo(ppix, pVia->front_bo);

    return TRUE;
}
#endif

static void
via_noaccel_set_pixmap_bo(PixmapPtr pPix, struct generic_bo *bo)
{
    pPix->devPrivate.ptr = bo->virtual;
}
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0, 0))
Bool
VIAScreenInit_kms(int scrnIndex, ScreenPtr pScreen, int argc, char **argv)
#else
Bool
VIAScreenInit_kms(ScreenPtr pScreen, int argc, char **argv)
#endif
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    int ret;
    int i;
    unsigned int TmpSwapValue;
    unsigned int addr;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "[KMS] VIAScreenInit_kms\n"));
/*version usingdef */
#ifdef XORG_VERSION_CURRENT
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "XF86_VER=%d\n, Not using in driver Now.\n",
        via_xf86_version_current));
#if XORG_VERSION_CURRENT <= XF86_VERSION_NUMERIC(2,0,0,0,0)&& \
    XORG_VERSION_CURRENT >= XF86_VERSION_NUMERIC(1,0,0,0,0)
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "XORG_VER=%d\n, Now driver depending only on this.\n",
        XORG_VERSION_CURRENT));
#else
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "WARNING!!XORG_VER Out of (2,0,0,0,0)and(1,0,0,0,0),if =7.0~2,"
        "will ok,or Old version driver no surpport.\n"));
#endif
#else
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "WARNING!!XORG_VER=%d\n,Not Exist,flow may wrong  Now.\n",
        XORG_VERSION_CURRENT));
#endif
/*version using define*/

    /* update out-time nonRandr info frameX and frameY for xv overlay. */
    pScrn->frameX1 = pScrn->virtualX;
    pScrn->frameY1 = pScrn->virtualY;

    /* Initialize TTM buffer manager for device driver */
    if (!pVia->bufmgr) {
        pVia->bufmgr = via_bo_bufmgr_con(pVia->drmFD);
    }
    if (!pVia->bufmgr) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "failed to initialize TTM buffer manager\n"));
        return FALSE;
    }
    if (!VIAMapFB(pScrn))
        return FALSE;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Mem Mapped\n"));

    /* Try to enable DRI2 as default */
    if (pVia->directRenderingEnabled == TRUE) {
        pVia->driType = DRI_2;
        if (!VIADRI2ScreenInit(pScreen)) {
            /* DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIA DRI2 \n")); */
            pVia->driType = DRI_1;
        }
    } else
        pVia->driType = DRI_DISABLED;

#ifdef XF86DRI
    if (pVia->driType == DRI_1) {
        if (!VIADRIScreenInit(pScreen))
            pVia->driType = DRI_DISABLED;
    }
#endif
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Blanked\n"));

    miClearVisualTypes();

    if (pScrn->bitsPerPixel > 8 && !pVia->IsSecondary) {
        if (!miSetVisualTypes(pScrn->depth, TrueColorMask,
            pScrn->rgbBits, pScrn->defaultVisual))
            return FALSE;
        if (!miSetPixmapDepths())
            return FALSE;
    } else {
    if (!miSetVisualTypes(pScrn->depth,
        miGetDefaultVisualMask(pScrn->depth), pScrn->rgbBits,
        pScrn->defaultVisual))
        return FALSE;
    if (!miSetPixmapDepths())
        return FALSE;
    }

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Visuals set up\n"));

    ret = VIAInternalScreenInit(pScrn->scrnIndex, pScreen);

    if (!ret)
        return FALSE;

    xf86SetBlackWhitePixels(pScreen);
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- B & W\n"));

    if (pScrn->bitsPerPixel > 8) {
        VisualPtr visual;

        visual = pScreen->visuals + pScreen->numVisuals;
        while (--visual >= pScreen->visuals) {
            if ((visual->class | DynamicClass) == DirectColor) {
                visual->offsetRed = pScrn->offset.red;
                visual->offsetGreen = pScrn->offset.green;
                visual->offsetBlue = pScrn->offset.blue;
                visual->redMask = pScrn->mask.red;
                visual->greenMask = pScrn->mask.green;
                visual->blueMask = pScrn->mask.blue;
            }
        }
    }

    /* must be after RGB ordering fixed */
    fbPictureInit(pScreen, 0, 0);

    /*for 2D accel fail */
    if (!pVia->NoAccel) {
        if (FALSE == VIAInitAccel(pScreen))
            return FALSE;
    } else {
        /* No Accel path :
         * Sync marker space.
         */
        /* No Accel path :
         * Init the 3D pipeline API for the uniform 3D texture blting interface */
        viaExa3DInit(pScreen);
        viaExa2DInit(pScreen);
        pVia->exa_sync_bo =
            dri_bo_alloc(pVia->bufmgr, "EXA Sync Marker", 32, 0,
            VIA_CHROME9_GEM_DOMAIN_VRAM | VIA_CHROME9_GEM_FLAG_NO_EVICT);
        if (dri_bo_map(pVia->exa_sync_bo, 0)) {
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "can not map the exa sync bo \n"));
            return FALSE;
        }
        pVia->markerOffset = pVia->exa_sync_bo->offset;
        pVia->markerOffset = (pVia->markerOffset + 31) & ~31;
        pVia->markerBuf =
            (volatile CARD32 *)(pVia->exa_sync_bo->virtual +
            (pVia->exa_sync_bo->offset - pVia->markerOffset));
        *pVia->markerBuf = 0;
        pVia->set_pixmap_bo = via_noaccel_set_pixmap_bo;
    }

    ret = VIAHWCursorSpaceAllocate(pScreen);
    if (ret != 0) {
        return FALSE;
    }

    for (i = 0; i < xf86_config->num_crtc; i++)
        drmmode_set_cursor(pScrn, i, pVia->HiBuf_bo[i]);
#ifdef XF86DRI
    /*for VIDEO play memory overlap PIXEL_MAP_CACHE */
    if (pVia->driType == DRI_1
#ifdef DRM_SAMM_VIA
        || pVia->drmSammEnabled
#endif
        ) {
        if (!(VIADRIFBInit(pScreen, pVia))) {
            VIADRICloseScreen(pScreen);
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "[dri] frame buffer initialize failed .\n");
            pVia->driType = DRI_DISABLED;
        }
        xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "[dri] frame buffer initialized done.\n");
    }
#endif

    xf86SetBackingStore(pScreen);
    xf86SetSilkenMouse(pScreen);
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Backing store set up\n"));

    miDCInitialize(pScreen, xf86GetPointerScreenFuncs());
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- SW cursor set up\n"));

    {
#ifdef VIA_RANDR12_SUPPORT
    if (!pVia->ForceSWCursor) {
        if (!xf86_cursors_init(pScreen, MAX_CURS, MAX_CURS,
            (HARDWARE_CURSOR_SOURCE_MASK_INTERLEAVE_64 |
            HARDWARE_CURSOR_AND_SOURCE_WITH_MASK |
            HARDWARE_CURSOR_TRUECOLOR_AT_8BPP |
            HARDWARE_CURSOR_INVERT_MASK |
            HARDWARE_CURSOR_BIT_ORDER_MSBFIRST |
            HARDWARE_CURSOR_ARGB | 0)))
        DEBUG(ErrorF("Fail to initial xf86_cursors_init()\n"));
    }
#endif
    }

    if (pVia->shadowFB) {
        RefreshAreaFuncPtr refreshArea = VIARefreshArea;

        if (pVia->RotateDegree) {
            switch (pScrn->bitsPerPixel) {
            case 8:
                refreshArea = VIARefreshArea8;
                break;
            case 16:
                refreshArea = VIARefreshArea16;
                break;
            case 32:
                refreshArea = VIARefreshArea32;
                break;
            }
        }
        ShadowFBInit(pScreen, refreshArea);
    }
#ifdef VIA_RANDR12_SUPPORT
    if (pVia->useRandR) {
        /* For RandR v1.2 */
        if (!xf86CrtcScreenInit(pScreen)) {
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "xf86CrtcScreenInit Fail\n"));
            return FALSE;
        }
    }
#endif

    if (!miCreateDefColormap(pScreen))
        return FALSE;
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Def Color map set up\n"));

    /* only 3123Ax IGA2 use 6-Bit LUT, others chipset IGA2 use 8-Bit LUT */
    /* So, except 3123Ax, we use 8-Bit LUT as default. */
    pScrn->rgbBits = 8;
    VGAOUT8(0x3C4, SR15);
    VGAOUT8(0x3C5, VGAIN8(0x3C5) | 0x80);
    if (!xf86HandleColormaps(pScreen, 256, 8, VIALoadPalette, NULL,
        CMAP_RELOAD_ON_MODE_SWITCH | CMAP_PALETTED_TRUECOLOR))
        return FALSE;
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Palette loaded\n"));

    /* Remove restart flag file for utility */
    UTRemoveRestartFlag(pBIOSInfo);
    pVia->CloseScreen = pScreen->CloseScreen;
    pScreen->CloseScreen = VIACloseScreen_kms;

    xf86DPMSInit(pScreen, xf86DPMSSet, 0);
    pScreen->SaveScreen = xf86SaveScreen;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- DPMS set up\n"));

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Color maps etc. set up\n"));

#ifdef XF86DRI
    if (pVia->driType == DRI_1
#ifdef DRM_SAMM_VIA
        || pVia->drmSammEnabled
#endif
        )
        if (!VIADRIFinishScreenInit(pScreen))
            pVia->driType = DRI_DISABLED;

    if (pVia->driType != DRI_DISABLED) {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "direct rendering enabled(%s)\n",
            pVia->driType == DRI_1 ? "DRI" : "DRI2");
        VIASet3DSyncInfoParas(pScreen);
    } else {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "direct rendering disabled\n");
    }
#endif

    if (!pVia->NoAccel) {
        viaFinishInitAccel(pScreen);
    } else {
        /* Init Command Buffer for the uniform 3D texture blting interface */
        viaSetupCBuffer(pScrn, &pVia->cb, 0);
    }

    /* Initial VIA Video Driver */
    FillGraphicMemInfo(pScrn);
    if (pVia->useRandR) {
#ifdef VIA_RANDR12_SUPPORT
        FillGraphicInfo_New(pScrn);
#endif
    }

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "libddmpeg: Heap Begin 0x%lx,End 0x%lx\n", viaGfxInfo->vheapbase,
        viaGfxInfo->vheapend));
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "DRMEnabled: 0x%x\n",
        viaGfxInfo->drmEnabled));
    if (viaGfxInfo->igaInfo[IGA1 - 1].actived) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA1 dwWidth: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA1 - 1].desired_width));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA1 dwHeight: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA1 - 1].desired_height));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA1 dwRefreshRate: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA1 - 1].refreshrate));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA1 dwExpand: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA1 - 1].igaStatus.expanded));
    }
    if (viaGfxInfo->igaInfo[IGA2 - 1].actived) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA2 dwWidth: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA2 - 1].desired_width));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA2 dwSaveWidth: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA2 - 1].desired_height));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA2 dwBPP: 0x%lx\n",
            viaGfxInfo->screenInfo[IGA2 - 1].bpp));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA2 dwRefreshRate: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA2 - 1].refreshrate));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA2 dwExpand: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA2 - 1].igaStatus.expanded));
    }

    /*  Init video structure, video flags & HW difference flags */
    vidInitVideoInfo(pVidData);

    viaInitVideo(pScreen);

    if (pBIOSInfo->MergedFB) {
        /* Psuedo xinerama */
        if (pBIOSInfo->UseVIAXinerama) {
            VIAnoPanoramiXExtension = FALSE;
            VIAXineramaExtensionInit(pScrn);
        }
    }

    /* Create a extension handler to receive the request of s3utility. */
    /* XV path and Xext path is co-exists now. */
    VIADisplayExtensionInit(pScrn);

    /* For XV Rotate+panning support, set the correct Clipping window.
     *
     * In NoRandR rotate for 2D, we don't need to swap virtualX/Y,
     * while XV Rotate+panning in noRandR need it.
     * */
    if ((pVia->RotateDegree == VIA_ROTATE_DEGREE_90) ||
        (pVia->RotateDegree == VIA_ROTATE_DEGREE_270)) {
        TmpSwapValue = pScrn->currentMode->HDisplay;
        pScrn->currentMode->HDisplay = pScrn->currentMode->VDisplay;
        pScrn->currentMode->VDisplay = TmpSwapValue;
    }

    if (serverGeneration == 1)
        xf86ShowUnusedOptions(pScrn->scrnIndex, pScrn->options);

/* Only hook this two function when SAMM + DRM enabled.
 * for dealing with DRM lock.
 * Maybe we can do other usefull things in this function.
 */
#ifdef DRM_SAMM_VIA
    if (pVia->drmSammEnabled) {
        pVia->viaBlockHandlerback = pScreen->BlockHandler;
        pScreen->BlockHandler = VIABlockHandler_kms;
        pVia->viaWakeupHandlerback = pScreen->WakeupHandler;
        pScreen->WakeupHandler = VIAWakeupHandler;
    }
#endif

#ifdef VIA_HAVE_UXA
    pVia->CreateScreenResources = pScreen->CreateScreenResources;
    pScreen->CreateScreenResources = VIACreateScreenResources_kms;
#endif

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Done\n"));
    return TRUE;
}

#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
Bool
VIASwitchMode_kms(int scrnIndex, DisplayModePtr mode, int flags)
#else
Bool
VIASwitchMode_kms(ScrnInfoPtr pScrn,DisplayModePtr mode)
#endif
{
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
#endif
    Bool ret;

    ret = xf86SetSingleMode(pScrn, mode, RR_Rotate_0);
    return ret;
}

#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
void
VIAAdjustFrame_kms(int scrnIndex, int x, int y, int flags)
#else
void
VIAAdjustFrame_kms(ScrnInfoPtr pScrn, int x, int y)
#endif
{
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
#else
    int scrnIndex = pScrn->scrnIndex;
#endif
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    viaPortPrivPtr pPriv;
    int i = 0;
    int ret;
    unsigned long curIGA = 0;

    xf86DrvMsg(scrnIndex, X_INFO, "VIAAdjustFrame_kms\n");

    if (x < 0 || y < 0)
        return;

    /* Patch for Duoview panning cases:
     * The panning_x[], panning_y[] are indexed by Iga Index. */
    /* Unifiy the process of panning_x[], panning_y[] for all case: single, duoview and samm. */
    if (viaGfxInfo->screenInfo[scrnIndex].igaInuse & IGA1) {
        if (viaGfxInfo->igaInfo[0].igaStatus.panning) {
            viaGfxInfo->igaInfo[0].start_x = x;
            viaGfxInfo->igaInfo[0].start_y = y;
            /* Restrict the patch for non-randr samm path only. */
            if (!viaGfxInfo->xrandrEnabled && viaGfxInfo->screenAttr.m1.samm) {
                if (viaGfxInfo->igaAttr.iga2_left) {
                    viaGfxInfo->igaInfo[0].start_x =
                        viaGfxInfo->igaInfo[1].visible_width + x;
                }
                if (viaGfxInfo->igaAttr.iga2_above) {
                    viaGfxInfo->igaInfo[0].start_y =
                        viaGfxInfo->igaInfo[1].visible_height + y;
                }
            }
            pVidData->panning_x[0] = x;
            pVidData->panning_y[0] = y;
        }
    }

    if (viaGfxInfo->screenInfo[scrnIndex].igaInuse & IGA2) {
        if (viaGfxInfo->igaInfo[1].igaStatus.panning) {
            viaGfxInfo->igaInfo[1].start_x = x;
            viaGfxInfo->igaInfo[1].start_y = y;
            /* Restrict the patch for non-randr samm path only. */
            if (!viaGfxInfo->xrandrEnabled && viaGfxInfo->screenAttr.m1.samm) {
                if (viaGfxInfo->igaAttr.iga2_right) {
                    viaGfxInfo->igaInfo[1].start_x =
                        viaGfxInfo->igaInfo[0].visible_width + x;
                }
                if (viaGfxInfo->igaAttr.iga2_below) {
                    viaGfxInfo->igaInfo[1].start_y =
                        viaGfxInfo->igaInfo[0].visible_height + y;
                }
            }
            pVidData->panning_x[1] = x;
            pVidData->panning_y[1] = y;
        }
    }

    for (i = XV_PORT_NUM_OVERLAY - 1; i >= 0; i--) {

        if (pVia->pPriv[i] != NULL) {

            if (pVia->pPriv[i]->curIGA != 0) {
                pPriv = pVia->pPriv[i];

                if (pPriv->videoFlag & VIDEO_ACTIVE) {
                    determineCurrentIGAInUse(pScrn, &curIGA, x, y);

                    if (curIGA == pPriv->curIGA) {
                        viaPutImageG(pScrn, pPriv->src_x, pPriv->src_y,
                            pPriv->drw_x, pPriv->drw_y, pPriv->src_w,
                            pPriv->src_h, pPriv->drw_w, pPriv->drw_h,
                            pPriv->fourCC, pPriv->buf, pPriv->width,
                            pPriv->height, pPriv->sync, &pPriv->clip, pPriv,
                            pPriv->pDraw);
                    }
                }
            }
        }
    }

    return;
}
#if XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0)
Bool
VIAEnterVT_kms(ScrnInfoPtr pScrn)
#else
Bool
VIAEnterVT_kms(int scrnIndex, int flags)
#endif
{
#if XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0)
	int scrnIndex = pScrn->scrnIndex;
#else
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
#endif
    DEBUG(xf86DrvMsg(scrnIndex, X_INFO, "VIAEnterVT_kms\n"));

    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    Bool ret;
    int i;
    miPointerScreenPtr PointPriv;
    int x, y;
    VIARegPtr viaSavePtr = &pVia->SavedReg;

    memset(pVia->front_bo->virtual, '\0', pVia->front_bo->size);
    drmSetMaster(pVia->bufmgr->drmfd);
    /* 410 chipset some register setting are lost when suspend from
     * S3, the extended memory access enable/disable bit is the one
     * so enable the bit for we need to access the extended MMIO space
     */
    if (pVia->Chipset == VIA_VX900 && !pVia->IsSecondary) {
        VIAEnableMMIO_kms(pScrn);
    }
    if (pVia->VQEnable && pVia->VQStart)
        VIAEnableVQ(pScrn);
    /* If the screen is under the rotated situation, the OS consider that
     * current mode is a rotated size.
     * For example: 768x1024. So when the OS want to set mode, it will
     * transfer a rotated size to request the driver to set this
     * mode(768x1024). But we should set display
     * timing according to non-rotated size.(e.g. 1024x768).
     * So we have to convert the rotated size to the normal size.
     */
    /* If we just do SW/HW noRandR rotation 90/270 degree for 2D ONLY, we
     * don't need to do this. While, if we need XV support for Rotation,
     * we need to swap pScrn->virtualX/pScrn->virtualY,
     * for XV path cliping window detect.
     */
    swap_height_width_for_CWorCCW(pScrn);

#if XORG_VERSION_CURRENT < XF86_VERSION_NUMERIC(1,5,99,0,0)|| \
    XORG_VERSION_CURRENT >= XF86_VERSION_NUMERIC(7,0,0,0,0)
    /* This is really a patch. patch for ubuntu8.04 os has garbage when resume
     * from S3 it seems the ubuntu os's own behavior. When os behavior right,
     * the patch can be removed.And this patch take no effect on other OS like
     * FCX whose xorg version is > 7.0. but this patch has side effect to
     * xorg<7.0,like suse10.1 suse10.2, when switch console,
     * the cursor disppear. so we take the condision into consideration */
    if (pVia->pVIAEnt->pScreensPublicInfo->UseHwCursor) {
#if XORG_VERSION_CURRENT <= XF86_VERSION_NUMERIC(2,0,0,0,0) && \
    XORG_VERSION_CURRENT >= XF86_VERSION_NUMERIC(1,4,99,0,0)
        PointPriv =
            (miPointerScreenPtr) dixLookupPrivate(&pScrn->pScreen->
            devPrivates, miPointerScreenKey);
#else
        extern int miPointerScreenIndex;

        PointPriv = pScrn->pScreen->devPrivates[miPointerScreenIndex].ptr;
#endif

#if XORG_VERSION_CURRENT <= XF86_VERSION_NUMERIC(2,0,0,0,0) && \
    XORG_VERSION_CURRENT >= XF86_VERSION_NUMERIC(1,4,0,0,0)
        miPointerGetPosition(inputInfo.pointer, &x, &y);
#else
        miPointerPosition(&x, &y);
#endif
        PointPriv->spriteFuncs->SetCursor(pScrn->pScreen, 0, x, y);
    }
#endif

    /* PCIE series new Registers */
    if (pVia->Chipset == VIA_VX800 || pVia->Chipset == VIA_VX855 ||
        pVia->Chipset == VIA_VX900) {
        for (i = 0; i < 10; i++) {
            viaWriteVgaIo((REG_SR66 + i), viaSavePtr->SRRegs[0x66 + i]);
        }

        for (i = 0; i < 3; i++) {
            viaWriteVgaIo((REG_SR79 + i), viaSavePtr->SRRegs[0x79 + i]);
        }

        for (i = 0; i < 6; i++) {
            viaWriteVgaIo((REG_SR70 + i), viaSavePtr->SRRegs[0x70 + i]);
        }
    }

    VIAInitialize3DEngine(pScrn);

    ret = xf86SetDesiredModes(pScrn);

    /* We need to initialize related registers about hardware icon again */
    /* when system resumes, or the cursor will become garbage. */
    if (!pVia->ForceSWCursor) {
        VIAARGBCursorInit(pScrn);
    }
    /* retore video status */
    if (!pVia->IsSecondary) {
        viaRestoreHqv(pScrn);
        viaRestoreVideo(pScrn);
    }

#if XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0)
    VIAAdjustFrame_kms(pScrn,pScrn->frameX0, pScrn->frameY0);
#else
    VIAAdjustFrame_kms(scrnIndex, pScrn->frameX0, pScrn->frameY0, 0);
#endif
    pVia->IsSuspending = FALSE;           /* System has resumed. */
    viaGfxInfo->suspending = FALSE;    /*record for ddmpeg */

    /* Revert to the rotated size.(e.g. 1024x768 -> 768x1024) */
    swap_height_width_for_CWorCCW(pScrn);

    /* Release the DRM lock, or the DRI APs will be pending forever. */
#ifdef XF86DRI
    if (pVia->directRenderingEnabled) {
        DRIUnlock(pScrn->pScreen);
    }
#endif
    return ret;
}
#if XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0)
void 
VIALeaveVT_kms(ScrnInfoPtr pScrn)
#else
void
VIALeaveVT_kms(int scrnIndex, int flags)
#endif
{
#if XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0)
    int scrnIndex = pScrn->scrnIndex;
#else
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
#endif
    VIAPtr pVia = VIAPTR(pScrn);
    int i, rotate_degree;
    VIARegPtr viaSavePtr = &pVia->SavedReg;

    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    DEBUG(xf86DrvMsg(scrnIndex, X_INFO, "VIALeaveVT_kms\n"));

    drmDropMaster(pVia->bufmgr->drmfd);
    /* TODO: take the DRI lock here to avoid accidents */
    /* TODO: unbind the AGP memory ? */
    /* Get DRM Lock to avoid DRI APs run unexpected under non-X situation */
#ifdef XF86DRI
    if (pVia->directRenderingEnabled) {
        DRILock(pScrn->pScreen, 0);
    }
#endif
    /* Unload Timer */
    if (pVia->devicesTimer)
        TimerCancel(pVia->devicesTimer);

    pVia->devicesTimer = NULL;

    /* Wait Hardware Engine idle to exit graphicd mode */
    WaitIdle();

    if (pVia->VQEnable) {
        /* if we use VQ, disable it before we exit */
        switch (pVia->Chipset) {
        case VIA_VX800:
        case VIA_VX855:
        case VIA_VX900:
        default:
            VIASETREG(0x43c, 0x00fe0000);
            VIASETREG(0x440, 0x00000004);
            VIASETREG(0x440, 0x40008c0f);
            VIASETREG(0x440, 0x44000000);
            VIASETREG(0x440, 0x45080c04);
            VIASETREG(0x440, 0x46800408);
            break;
        }
    }

    /* Save video status and turn off all video activities */
    if (!pVia->IsSecondary) {
        viaSaveHqv(pScrn);
        viaSaveVideo(pScrn);
    }

    if (pVia->IsHWRotateEnabled) {
        DisableCBUrotate(pScrn);

        /* Disable CBU HW Rotate.
         * VX855 and VX900 rotation 90 and 270 degree probably has issue
         * but 180 degree doesn't have.
         * So here mimic the behavior of CBU 180
         * The root cause is still unknown.
         */
        if ((pVia->Chipset == VIA_VX855 || pVia->Chipset == VIA_VX900) &&
            (pVia->RotateDegree == VIA_ROTATE_DEGREE_90 ||
            pVia->RotateDegree == VIA_ROTATE_DEGREE_270)) {
            /* Mimic the behavior of rotate 180 */
            rotate_degree = pVia->RotateDegree;
            pVia->RotateDegree = VIA_ROTATE_DEGREE_180;
            EnableCBUrotate(pScrn);
            pVia->RotateDegree = rotate_degree;
            /* Let CBU 180 rotate take effect */
            memset(pVia->FBBase, 0x00,
            (pScrn->displayWidth * pScrn->bitsPerPixel >> 3));

            DisableCBUrotate(pScrn);
        }
    }

    pVia->IsSuspending = TRUE;           /* System will suspend. */
    viaGfxInfo->suspending = TRUE;     /* record for ddmpeg */
    pVia->IsVIAModeInitRunOnceDone = FALSE;

    /* TODO: For vt3353, some registers can't be restore in DRM module, it
     * seems that these registers be modified between DRM resume function and
     * VIAEnterVT function
     * when using "suspend" button shipped with ubuntu 8.04.
     * So we save these registers here and restore them in VIAEnterVT.
     * These registers including: SR66~SR6F, SR70~SR75, SR79~SR7B.
     */
    if (pVia->Chipset == VIA_VX800 || pVia->Chipset == VIA_VX855 ||
        pVia->Chipset == VIA_VX900) {
        for (i = 0; i < 10; i++) {
            viaSavePtr->SRRegs[0x66 + i] = viaReadVgaIo((REG_SR66 + i));
        }

        for (i = 0; i < 6; i++) {
            viaSavePtr->SRRegs[0x70 + i] = viaReadVgaIo((REG_SR70 + i));
        }

        for (i = 0; i < 3; i++) {
            viaSavePtr->SRRegs[0x79 + i] = viaReadVgaIo((REG_SR79 + i));
        }
    }
    /*To fix hang issue when switch VT using 3D desktop */
    viaWriteVgaIo(REG_SR32, 0x00);
}

#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0, 0))
void
VIAFreeScreen_kms(int scrnIndex, int flags)
#else
void
VIAFreeScreen_kms(ScrnInfoPtr pScrn)
#endif
{
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0, 0))
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
#else
	int scrnIndex = pScrn->scrnIndex;
#endif
    VIAPtr pVia = VIAPTR(pScrn);

    xf86DrvMsg(scrnIndex, X_INFO, "VIAFreeScreen_kms\n");

    /*SAMM case, make sure MMIO only unmap once! */
    if (!pVia->IsSecondary) {
        /* delete the memory of VidData */
        if (pVia->pVIAEnt->pVidData) {
            if (pVia->pVIAEnt->pVidData->viaGfxInfo) {
                free((void *)pVia->pVIAEnt->pVidData->viaGfxInfo);
                pVia->pVIAEnt->pVidData->viaGfxInfo = NULL;
            }
            free((void *)pVia->pVIAEnt->pVidData);
            pVia->pVIAEnt->pVidData = NULL;
        }
        VIAUnmapMem(pScrn);
    } else {
        if (pVia->FBBase) {
            pVia->FBBase = NULL;
        }
    }

    VIAFreeRec(pScrn);
}

#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0, 0))
ModeStatus
VIAValidMode_kms(int scrnIndex, DisplayModePtr mode, Bool verbose, int flags)
#else
ModeStatus
VIAValidMode_kms(ScrnInfoPtr pScrn, DisplayModePtr mode, Bool verbose, int flags)
#endif
{
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0, 0))
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
#else
    int scrnIndex = pScrn->scrnIndex;
#endif
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    int ModeIndex;
    CARD32 DesiredModePixelClock;

    DEBUG(xf86DrvMsg(scrnIndex, X_INFO, "VIAValidMode_kms\n"));

    if (!memcmp(mode->name, "PanelMode", 9)) {
        mode->type = M_T_USERDEF;
        VIAGetModeLineTiming(pScrn, mode);
        pBIOSInfo->EDIDType = VIA_DEVICE_LCD;
        pBIOSInfo->LVDSSettingInfo.PanelSizeID =
            VIA_MAKE_ID(mode->HDisplay, mode->VDisplay);
        pBIOSInfo->isPanelModeLine = TRUE;
        return MODE_OK;
    }

    if (!pBIOSInfo->NoDDCValue) {
        /*1.if user don't set modes in config file, we want to use PreferMode,
            so we use PreferModeH  PreferModeV to valid modes.
         * 2.if user set modes in config file, we use EDID can support maxH,
            maxV to valid modes */
        if (pBIOSInfo->IsAutoDectectEnable == TRUE) {
            if ((mode->CrtcHDisplay > pBIOSInfo->CRTSettingInfo.PreferModeH)
                || (mode->CrtcVDisplay >
                pBIOSInfo->CRTSettingInfo.PreferModeV))
                return MODE_BAD_VVALUE;
        } else {
            if ((mode->CrtcHDisplay > pBIOSInfo->CRTSettingInfo.MonitorSizeH)
                || (mode->CrtcVDisplay >
                pBIOSInfo->CRTSettingInfo.MonitorSizeV))
                return MODE_BAD_VVALUE;
        }
    }

    /* DP hardware capabilitye: TU ratio only 15 bits */
    /* may be we have to add code to check DP mode valid */

    /* If the modeline is added by user, pass it. */
    if ((mode->type == M_T_USERDEF) || (mode->type == 0))
        return MODE_OK;

    /* If the modeline is added by monitor, pass it. */
    switch (mode->type) {
    /* Monitor EDID */
    case M_T_DRIVER:
    /* Monitor EDID + Auto-detection */
    case M_T_DRIVER | M_T_USERDEF:
    /* Monitor EDID + Monitor Preferred Mode */
    case M_T_DRIVER | M_T_PREFERRED:
    /* Monitor EDID + Auto-detection + Monitor Preferred Mode */
    case M_T_DRIVER | M_T_USERDEF | M_T_PREFERRED:
        return MODE_OK;
        break;
    }
    /* check modes */
    if (IsValidMode(mode->CrtcHDisplay, mode->CrtcVDisplay) == 0) {
        return MODE_BAD;
    } else {
        return MODE_OK;
    }
}
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
Bool
VIAPMEvent_kms(int scrnIndex, pmEvent event, Bool undo)
#else
Bool
VIAPMEvent_kms(ScrnInfoPtr pScrn, pmEvent event, Bool undo)
#endif
{
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
#else
    int scrnIndex = pScrn->scrnIndex;
#endif
    VIAPtr pVia = VIAPTR(pScrn);

    xf86DrvMsg(X_INFO, scrnIndex, "enter pm event kms\n");
    ErrorF("VIAPMEvent_ksm: received APM event %d\n", event);

    switch (event) {
    case XF86_APM_SYS_SUSPEND:
    case XF86_APM_CRITICAL_SUSPEND: /*do we want to delay a critical suspend? */
    case XF86_APM_USER_SUSPEND:
    case XF86_APM_SYS_STANDBY:
    case XF86_APM_USER_STANDBY:
        if (!undo && !pVia->IsSuspending) {
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
            pScrn->LeaveVT(scrnIndex, 0);
#else
			pScrn->LeaveVT(pScrn);
#endif
            pVia->IsSuspending = TRUE;
            sleep(50);
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
            pScrn->EnterVT(scrnIndex, 0);
#else
			pScrn->EnterVT(pScrn);
#endif
        } else if (undo && pVia->IsSuspending) {
            sleep(1);
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
            pScrn->EnterVT(scrnIndex, 0);
#else
			pScrn->EnterVT(pScrn);
#endif
            pVia->IsSuspending = FALSE;
        }
        break;
    case XF86_APM_STANDBY_RESUME:
    case XF86_APM_NORMAL_RESUME:
    case XF86_APM_CRITICAL_RESUME:
        if (pVia->IsSuspending) {
            sleep(1);
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
            pScrn->EnterVT(scrnIndex, 0);
#else
			pScrn->EnterVT(pScrn);
#endif
            pVia->IsSuspending = FALSE;
        }
        break;
    case XF86_APM_CAPABILITY_CHANGED:
        if (pVia->IsSecondary)
            return TRUE;
        default:
        ErrorF("VIAPMEvent_kms: received APM event %d\n", event);
        return TRUE;
    }
    return TRUE;
}
