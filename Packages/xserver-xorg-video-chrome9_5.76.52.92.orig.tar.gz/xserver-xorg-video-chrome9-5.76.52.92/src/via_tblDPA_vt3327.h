/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _VIA_TBLDPA_VT3327_H_
#define _VIA_TBLDPA_VT3327_H_ 1

/****************************************************************************/
/****************************************************************************/
/* The following DPA setting is for LVDS and TMDS: */

/****************************************************************************/
/*                                   VT3327 DPA Setting                     */
/****************************************************************************/

    /* DVP0,   DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
static GFX_DPA_VALUE VT3327_DEFAULT_DPA[] = {
    /* CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99 */
    {  0x07, 0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x08, 0x04}
};

static GFX_DPA_VALUE VT3327_CLK_50_70M_DPA[] = {
    /* CR96,   SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99 */
    {  0x06,   0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x08, 0x04}
};

static GFX_DPA_VALUE VT3327_CLK_70_100M_DPA[] = {
    /* CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99 */
    {  0x03, 0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x08, 0x04}
};

static GFX_DPA_VALUE VT3327_CLK_100_150M_DPA[] = {
    /* CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99 */
    {  0x03, 0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x01, 0x04}
};

static GFX_DPA_VALUE VT3327_CLK_150M_DPA[] = {
    /* CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99 */
    {  0x01, 0x20,    0x00,    0x10,    0x00,    0x03, 0x00, 0x0D, 0x04}
};

static GFX_DPA_VALUE VT3327_CLK_100_150M_DPA_VT1636[] = {
    /* CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99 */
    {  0x01, 0x20,    0x00,    0x00,    0x00,    0x03, 0x00, 0x01, 0x0C}
};

static GFX_DPA_VALUE VT3327_CLK_150M_DPA_VT1636[] = {
    /* CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99 */
    {  0x01, 0x20,    0x00,    0x10,    0x04,    0x03, 0x00, 0x0D, 0x0C}
};

static GFX_DPA_INFO_TABLE GFX_DPA_VT3327_VT1636[] = {
    {DPA_CLK_RANGE_30M, VT3327_DEFAULT_DPA},
    {DPA_CLK_RANGE_30_50M, VT3327_DEFAULT_DPA},
    {DPA_CLK_RANGE_50_70M, VT3327_CLK_50_70M_DPA},
    {DPA_CLK_RANGE_70_100M, VT3327_CLK_70_100M_DPA},
    {DPA_CLK_RANGE_100_150M, VT3327_CLK_100_150M_DPA_VT1636},
    {DPA_CLK_RANGE_150M, VT3327_CLK_150M_DPA_VT1636}
};

static GFX_DPA_INFO_TABLE GFX_DPA_VT3327_HardwiredLCD[] = {
    {DPA_CLK_RANGE_30M, VT3327_DEFAULT_DPA},
    {DPA_CLK_RANGE_30_50M, VT3327_DEFAULT_DPA},
    {DPA_CLK_RANGE_50_70M, VT3327_CLK_50_70M_DPA},
    {DPA_CLK_RANGE_70_100M, VT3327_CLK_70_100M_DPA},
    {DPA_CLK_RANGE_100_150M, VT3327_CLK_100_150M_DPA},
    {DPA_CLK_RANGE_150M, VT3327_CLK_150M_DPA}
};

/*******************************************************************************/
/*                      LVDS VT1636 DPA Setting                                */
/*******************************************************************************/

/* Note_1:  0xFFFFFF indicate the end of array.*/
/* Note_2:  0xData + Mask + Address            */
/* Example: 0x00   + 0F   + 08 = 0x000F08      */
static CARD32 VT1636_CLK_SEL_ST_16x12_VT3327[] =
    { 0x020F08, 0x011F09, 0xFFFFFF };

static TRANSMITTER_DPA_INFO TRANSMITTER_DPA_VT3327_1636TBL[] = {
    /* Index,        Clock DeSkew Select Stage Setting                    */
    {VIA_640X480, VT1636_CLK_SEL_ST_DEFAULT},	/* For 640x480   */
    {VIA_800X600, VT1636_CLK_SEL_ST_DEFAULT},	/* For 800x600   */
    {VIA_1024X768, VT1636_CLK_SEL_ST_DEFAULT},	/* For 1024x768  */
    {VIA_1280X768, VT1636_CLK_SEL_ST_DEFAULT},	/* For 1280x768  */
    {VIA_1280X1024, VT1636_CLK_SEL_ST_DEFAULT},	/* For 1280x1024 */
    {VIA_1400X1050, VT1636_CLK_SEL_ST_DEFAULT},	/* For 1400x1050 */
    {VIA_1600X1200, VT1636_CLK_SEL_ST_16x12_VT3327},	/* For 1600x1200 */
    {VIA_INVALID, NULL}
};

/****************************************************************************/
/****************************************************************************/

/* The following DPA setting is for TV: */

/**************************************************************************/
/*                     Gfx DPA Settings Table                             */
/**************************************************************************/

static GFX_DPA_VALUE VT1625_DEFAULT_GFX_DPA_VT3327[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x07, 0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x08, 0x03}
};

static GFX_DPA_VALUE VT1625_NTSC_1024X768_VN_GFX_DPA_VT3327[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x06, 0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x08, 0x03}
};

static GFX_DPA_VALUE VT1625_NTSC_1024X768_VF_GFX_DPA_VT3327[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x05, 0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x08, 0x03}
};

static GFX_DPA_VALUE VT1625_PAL_1024X768_VO_GFX_DPA_VT3327[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x06, 0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x08, 0x03}
};

static GFX_DPA_VALUE VT1625_480P_1024X768_VN_GFX_DPA_VT3327[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x06, 0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x08, 0x03}
};

static GFX_DPA_VALUE VT1625_480P_1024X768_VF_GFX_DPA_VT3327[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x05, 0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x08, 0x03}
};

static GFX_DPA_VALUE VT1625_576P_1024X768_VO_GFX_DPA_VT3327[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x01, 0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x08, 0x03}
};

static GFX_DPA_VALUE VT1625_720P_1280X720_VN_GFX_DPA_VT3327[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x01, 0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x08, 0x03}
};

static GFX_DPA_VALUE VT1625_1080I_800X600_VN_GFX_DPA_VT3327[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x02, 0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x08, 0x03}
};

static GFX_DPA_VALUE VT1625_1080I_1920X1080_VN_GFX_DPA_VT3327[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x02, 0x00,    0x00,    0x00,    0x00,    0x03, 0x00, 0x08, 0x03}
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_640X480_VT3327[] = {
    /* Normal Scan,                  FitScan,                       OverScan                                  */
    {{VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	/* NTSC  */
	{VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	/* PAL   */
	{VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	/* 480P  */
	{VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	/* 576P  */
	{VT1625_DEFAULT_GFX_DPA_VT3327, NULL, NULL},	/* 720P  */
	{VT1625_DEFAULT_GFX_DPA_VT3327, NULL, NULL}}	/* 1080I */
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_720X480_VT3327[] = {
    /* Normal Scan,                  FitScan,                       OverScan                                  */
    {{VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	/* NTSC  */
	{NULL, NULL, NULL},	       /* PAL   */
	{VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	/* 480P  */
	{NULL, NULL, NULL},	       /* 476P  */
	{VT1625_DEFAULT_GFX_DPA_VT3327, NULL, NULL},	/* 720P  */
	{VT1625_DEFAULT_GFX_DPA_VT3327, NULL, NULL}}	/* 1080I */
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_720X576_VT3327[] = {
    /* Normal Scan,                  FitScan,                       OverScan                                  */
    {{NULL, NULL, NULL},	       /* NTSC  */
	{VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	/* PAL   */
	{NULL, NULL, NULL},	       /* 480P  */
	{VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	/* 576P  */
	{VT1625_DEFAULT_GFX_DPA_VT3327, NULL, NULL},	/* 720P  */
	{VT1625_DEFAULT_GFX_DPA_VT3327, NULL, NULL}}	/* 1080I */
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_800x600_VT3327[] = {
    /* Normal Scan,                          FitScan,                       OverScan                                  */
    {{VT1625_DEFAULT_GFX_DPA_VT3327,         VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	/* NTSC  */
	{VT1625_DEFAULT_GFX_DPA_VT3327,          VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	/* PAL   */
	{VT1625_DEFAULT_GFX_DPA_VT3327,          VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	/* 480P  */
	{VT1625_DEFAULT_GFX_DPA_VT3327,          VT1625_DEFAULT_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	/* 576P  */
	{VT1625_DEFAULT_GFX_DPA_VT3327,          NULL, NULL},	/* 720P  */
	{VT1625_1080I_800X600_VN_GFX_DPA_VT3327, NULL, NULL}}	/* 1080I */
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_1024X768_VT3327[] = {
    /* Normal Scan,                           FitScan,                                OverScan                                    */
    {{VT1625_NTSC_1024X768_VN_GFX_DPA_VT3327, VT1625_NTSC_1024X768_VF_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	        /* NTSC  */
	{VT1625_DEFAULT_GFX_DPA_VT3327,           VT1625_DEFAULT_GFX_DPA_VT3327,          VT1625_PAL_1024X768_VO_GFX_DPA_VT3327},	/* PAL   */
	{VT1625_480P_1024X768_VN_GFX_DPA_VT3327,  VT1625_480P_1024X768_VF_GFX_DPA_VT3327, VT1625_DEFAULT_GFX_DPA_VT3327},	        /* 480P  */
	{VT1625_DEFAULT_GFX_DPA_VT3327,           VT1625_DEFAULT_GFX_DPA_VT3327,          VT1625_576P_1024X768_VO_GFX_DPA_VT3327},	/* 576P  */
	{VT1625_DEFAULT_GFX_DPA_VT3327,           NULL,                                   NULL},	                                /* 720P  */
	{VT1625_DEFAULT_GFX_DPA_VT3327,           NULL,                                   NULL}}	                                /* 1080I */
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_1280X720_VT3327[] = {
    /* Normal Scan,                       FitScan, OverScan            */
    {{NULL,                                  NULL, NULL},	   /* NTSC  */
	{NULL,                                   NULL, NULL},	   /* PAL   */
	{NULL,                                   NULL, NULL},	   /* 480P  */
	{NULL,                                   NULL, NULL},	   /* 576P  */
	{VT1625_720P_1280X720_VN_GFX_DPA_VT3327, NULL, NULL},	   /* 720P  */
	{NULL,                                   NULL, NULL}}	   /* 1080I */
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_1920X1080_VT3327[] = {
    /* Normal Scan,                        FitScan, OverScan            */
    {{NULL,                                    NULL, NULL},	   /* NTSC  */
	{NULL,                                     NULL, NULL},	   /* PAL   */
	{NULL,                                     NULL, NULL},	   /* 480P  */
	{NULL,                                     NULL, NULL},	   /* 576P  */
	{NULL,                                     NULL, NULL},	   /* 720P  */
	{VT1625_1080I_1920X1080_VN_GFX_DPA_VT3327, NULL, NULL}}	   /* 1080I */
};

/***************************************************************************/
/*                              TV Encoder Patch Table                     */
/***************************************************************************/

/* Note_1:  0xFFFFFFFF indicate the end of array.*/
/* Note_2:  0xData + Mask + Index              */
/* Example: 0x00   + 1E   + 05 = 0x001E05      */
static CARD32 VT1625_PATCH_TBL_PAL_1024X768_VO_VT3327[] =
    { 0x1DFF05, 0xFFFFFFFF };

static TV_DPA_TVTYPE_MAP_TABLE VT1625_PATCH_TBL_1024X768_VT3327[] = {
  /* Normal Scan, Fit Scan, Over Scan              */
    {{NULL,       NULL,     NULL},	                                /* NTSC  */
	{NULL,        NULL,     VT1625_PATCH_TBL_PAL_1024X768_VO_VT3327},	/* PAL */
	{NULL,        NULL,     NULL},	                                /* 480P  */
	{NULL,        NULL,     NULL},	                                /* 576P  */
	{NULL,        NULL,     NULL},	                                /* 720P  */
	{NULL,        NULL,     NULL}}	                                /* 1080I */
};

/*******************************************************************************************************/
/*                              DPA Settings Table Mapping by Mode                                     */
/*******************************************************************************************************/

static TV_DPA_TABLE GFX_DPA_TABLE_VT3327_VT1625[] = {
    /* ModeIndex          GFX DPA Table              VT1625 DPA Patch Table */
    {VIA_640X480,   VT1625_GFX_DPA_640X480_VT3327,   NULL},
    {VIA_720X480,   VT1625_GFX_DPA_720X480_VT3327,   NULL},
    {VIA_720X576,   VT1625_GFX_DPA_720X576_VT3327,   NULL},
    {VIA_800X600,   VT1625_GFX_DPA_800x600_VT3327,   NULL},
    {VIA_1024X768,  VT1625_GFX_DPA_1024X768_VT3327,  VT1625_PATCH_TBL_1024X768_VT3327},
    {VIA_1280X720,  VT1625_GFX_DPA_1280X720_VT3327,  NULL},
    {VIA_1920X1080, VT1625_GFX_DPA_1920X1080_VT3327, NULL},
    {VIA_INVALID, NULL, NULL}	       /* End of table. */
};

#endif
