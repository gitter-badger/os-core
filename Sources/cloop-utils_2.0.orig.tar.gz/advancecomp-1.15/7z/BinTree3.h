#ifndef __BINTREE3__H
#define __BINTREE3__H

#undef BT_CLSID
#define BT_CLSID CLSID_CMatchFinderBT3

#undef BT_NAMESPACE
#define BT_NAMESPACE NBT3

#define HASH_ARRAY_2

#include "BinTreeMF.h"

#undef HASH_ARRAY_2

#endif

