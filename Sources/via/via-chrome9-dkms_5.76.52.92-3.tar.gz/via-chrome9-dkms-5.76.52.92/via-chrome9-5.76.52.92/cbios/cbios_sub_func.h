/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * Programming info contained in this module about chips can be found at:
 *   Chrontel 7301 : http://www.chrontel.com/pdf/7301ds.pdf
 *   silicon 164 : http://www.siliconimage.com/docs/SiI-DS-0021-E-164.pdf
 *   TI tfp410 : http://www.ti.com/lit/ds/symlink/tfp410.pdf
 *   ADI ad9389b : http://www.analog.com/static/imported-files/data_sheets/AD9389B.pdf
 *                 http://ez.analog.com/servlet/JiveServlet/download/1741-8-10790/AD9889B%20Programming%20Guide%20RevB.pdf
 *   EDID info : http://en.wikipedia.org/wiki/Extended_display_identification_data
 */

#ifndef _CBIOS_SUB_FUNC_NEW_H_
#define _CBIOS_SUB_FUNC_NEW_H_

#include "cbios_uma.h"
#include "cbios_vcp.h"

//******************************************************************************
//
// General register definition
//

#define ZCR         0x00
#define ZSR         0x01
#define ZGR         0x02
#define ZAR         0x03
#define ZMISC       0x04

typedef enum {
    CR_00 = 0x0000,
    CR_01 = 0x0001,
    CR_02 = 0x0002,
    CR_03 = 0x0003,
    CR_04 = 0x0004,
    CR_05 = 0x0005,
    CR_06 = 0x0006,
    CR_07 = 0x0007,
    CR_08 = 0x0008,
    CR_09 = 0x0009,
    CR_0A = 0x000A,
    CR_0B = 0x000B,
    CR_0C = 0x000C,
    CR_0D = 0x000D,
    CR_0E = 0x000E,
    CR_0F = 0x000F,
    CR_10 = 0x0010,
    CR_11 = 0x0011,
    CR_12 = 0x0012,
    CR_13 = 0x0013,
    CR_14 = 0x0014,
    CR_15 = 0x0015,
    CR_16 = 0x0016,
    CR_17 = 0x0017,
    CR_18 = 0x0018,
    CR_19 = 0x0019,
    CR_1A = 0x001A,
    CR_1B = 0x001B,
    CR_1C = 0x001C,
    CR_1D = 0x001D,
    CR_1E = 0x001E,
    CR_1F = 0x001F,
    CR_20 = 0x0020,
    CR_21 = 0x0021,
    CR_22 = 0x0022,
    CR_23 = 0x0023,
    CR_24 = 0x0024,
    CR_25 = 0x0025,
    CR_26 = 0x0026,
    CR_27 = 0x0027,
    CR_28 = 0x0028,
    CR_29 = 0x0029,
    CR_2A = 0x002A,
    CR_2B = 0x002B,
    CR_2C = 0x002C,
    CR_2D = 0x002D,
    CR_2E = 0x002E,
    CR_2F = 0x002F,
    CR_30 = 0x0030,
    CR_31 = 0x0031,
    CR_32 = 0x0032,
    CR_33 = 0x0033,
    CR_34 = 0x0034,
    CR_35 = 0x0035,
    CR_36 = 0x0036,
    CR_37 = 0x0037,
    CR_38 = 0x0038,
    CR_39 = 0x0039,
    CR_3A = 0x003A,
    CR_3B = 0x003B,
    CR_3C = 0x003C,
    CR_3D = 0x003D,
    CR_3E = 0x003E,
    CR_3F = 0x003F,
    CR_40 = 0x0040,
    CR_41 = 0x0041,
    CR_42 = 0x0042,
    CR_43 = 0x0043,
    CR_44 = 0x0044,
    CR_45 = 0x0045,
    CR_46 = 0x0046,
    CR_47 = 0x0047,
    CR_48 = 0x0048,
    CR_49 = 0x0049,
    CR_4A = 0x004A,
    CR_4B = 0x004B,
    CR_4C = 0x004C,
    CR_4D = 0x004D,
    CR_4E = 0x004E,
    CR_4F = 0x004F,
    CR_50 = 0x0050,
    CR_51 = 0x0051,
    CR_52 = 0x0052,
    CR_53 = 0x0053,
    CR_54 = 0x0054,
    CR_55 = 0x0055,
    CR_56 = 0x0056,
    CR_57 = 0x0057,
    CR_58 = 0x0058,
    CR_59 = 0x0059,
    CR_5A = 0x005A,
    CR_5B = 0x005B,
    CR_5C = 0x005C,
    CR_5D = 0x005D,
    CR_5E = 0x005E,
    CR_5F = 0x005F,
    CR_60 = 0x0060,
    CR_61 = 0x0061,
    CR_62 = 0x0062,
    CR_63 = 0x0063,
    CR_64 = 0x0064,
    CR_65 = 0x0065,
    CR_66 = 0x0066,
    CR_67 = 0x0067,
    CR_68 = 0x0068,
    CR_69 = 0x0069,
    CR_6A = 0x006A,
    CR_6B = 0x006B,
    CR_6C = 0x006C,
    CR_6D = 0x006D,
    CR_6E = 0x006E,
    CR_6F = 0x006F,
    CR_70 = 0x0070,
    CR_71 = 0x0071,
    CR_72 = 0x0072,
    CR_73 = 0x0073,
    CR_74 = 0x0074,
    CR_75 = 0x0075,
    CR_76 = 0x0076,
    CR_77 = 0x0077,
    CR_78 = 0x0078,
    CR_79 = 0x0079,
    CR_7A = 0x007A,
    CR_7B = 0x007B,
    CR_7C = 0x007C,
    CR_7D = 0x007D,
    CR_7E = 0x007E,
    CR_7F = 0x007F,
    CR_80 = 0x0080,
    CR_81 = 0x0081,
    CR_82 = 0x0082,
    CR_83 = 0x0083,
    CR_84 = 0x0084,
    CR_85 = 0x0085,
    CR_86 = 0x0086,
    CR_87 = 0x0087,
    CR_88 = 0x0088,
    CR_89 = 0x0089,
    CR_8A = 0x008A,
    CR_8B = 0x008B,
    CR_8C = 0x008C,
    CR_8D = 0x008D,
    CR_8E = 0x008E,
    CR_8F = 0x008F,
    CR_90 = 0x0090,
    CR_91 = 0x0091,
    CR_92 = 0x0092,
    CR_93 = 0x0093,
    CR_94 = 0x0094,
    CR_95 = 0x0095,
    CR_96 = 0x0096,
    CR_97 = 0x0097,
    CR_98 = 0x0098,
    CR_99 = 0x0099,
    CR_9A = 0x009A,
    CR_9B = 0x009B,
    CR_9C = 0x009C,
    CR_9D = 0x009D,
    CR_9E = 0x009E,
    CR_9F = 0x009F,
    CR_A0 = 0x00A0,
    CR_A1 = 0x00A1,
    CR_A2 = 0x00A2,
    CR_A3 = 0x00A3,
    CR_A4 = 0x00A4,
    CR_A5 = 0x00A5,
    CR_A6 = 0x00A6,
    CR_A7 = 0x00A7,
    CR_A8 = 0x00A8,
    CR_A9 = 0x00A9,
    CR_AA = 0x00AA,
    CR_AB = 0x00AB,
    CR_AC = 0x00AC,
    CR_AD = 0x00AD,
    CR_AE = 0x00AE,
    CR_AF = 0x00AF,
    CR_B0 = 0x00B0,
    CR_B1 = 0x00B1,
    CR_B2 = 0x00B2,
    CR_B3 = 0x00B3,
    CR_B4 = 0x00B4,
    CR_B5 = 0x00B5,
    CR_B6 = 0x00B6,
    CR_B7 = 0x00B7,
    CR_B8 = 0x00B8,
    CR_B9 = 0x00B9,
    CR_BA = 0x00BA,
    CR_BB = 0x00BB,
    CR_BC = 0x00BC,
    CR_BD = 0x00BD,
    CR_BE = 0x00BE,
    CR_BF = 0x00BF,
    CR_C0 = 0x00C0,
    CR_C1 = 0x00C1,
    CR_C2 = 0x00C2,
    CR_C3 = 0x00C3,
    CR_C4 = 0x00C4,
    CR_C5 = 0x00C5,
    CR_C6 = 0x00C6,
    CR_C7 = 0x00C7,
    CR_C8 = 0x00C8,
    CR_C9 = 0x00C9,
    CR_CA = 0x00CA,
    CR_CB = 0x00CB,
    CR_CC = 0x00CC,
    CR_CD = 0x00CD,
    CR_CE = 0x00CE,
    CR_CF = 0x00CF,
    CR_D0 = 0x00D0,
    CR_D1 = 0x00D1,
    CR_D2 = 0x00D2,
    CR_D3 = 0x00D3,
    CR_D4 = 0x00D4,
    CR_D5 = 0x00D5,
    CR_D6 = 0x00D6,
    CR_D7 = 0x00D7,
    CR_D8 = 0x00D8,
    CR_D9 = 0x00D9,
    CR_DA = 0x00DA,
    CR_DB = 0x00DB,
    CR_DC = 0x00DC,
    CR_DD = 0x00DD,
    CR_DE = 0x00DE,
    CR_DF = 0x00DF,
    CR_E0 = 0x00E0,
    CR_E1 = 0x00E1,
    CR_E2 = 0x00E2,
    CR_E3 = 0x00E3,
    CR_E4 = 0x00E4,
    CR_E5 = 0x00E5,
    CR_E6 = 0x00E6,
    CR_E7 = 0x00E7,
    CR_E8 = 0x00E8,
    CR_E9 = 0x00E9,
    CR_EA = 0x00EA,
    CR_EB = 0x00EB,
    CR_EC = 0x00EC,
    CR_ED = 0x00ED,
    CR_EE = 0x00EE,
    CR_EF = 0x00EF,
    CR_F0 = 0x00F0,
    CR_F1 = 0x00F1,
    CR_F2 = 0x00F2,
    CR_F3 = 0x00F3,
    CR_F4 = 0x00F4,
    CR_F5 = 0x00F5,
    CR_F6 = 0x00F6,
    CR_F7 = 0x00F7,
    CR_F8 = 0x00F8,
    CR_F9 = 0x00F9,
    CR_FA = 0x00FA,
    CR_FB = 0x00FB,
    CR_FC = 0x00FC,
    CR_FD = 0x00FD,
    CR_FE = 0x00FE,
    CR_FF = 0x00FF,

    SR_00 = 0x0100,
    SR_01 = 0x0101,
    SR_02 = 0x0102,
    SR_03 = 0x0103,
    SR_04 = 0x0104,
    SR_05 = 0x0105,
    SR_06 = 0x0106,
    SR_07 = 0x0107,
    SR_08 = 0x0108,
    SR_09 = 0x0109,
    SR_0A = 0x010A,
    SR_0B = 0x010B,
    SR_0C = 0x010C,
    SR_0D = 0x010D,
    SR_0E = 0x010E,
    SR_0F = 0x010F,
    SR_10 = 0x0110,
    SR_11 = 0x0111,
    SR_12 = 0x0112,
    SR_13 = 0x0113,
    SR_14 = 0x0114,
    SR_15 = 0x0115,
    SR_16 = 0x0116,
    SR_17 = 0x0117,
    SR_18 = 0x0118,
    SR_19 = 0x0119,
    SR_1A = 0x011A,
    SR_1B = 0x011B,
    SR_1C = 0x011C,
    SR_1D = 0x011D,
    SR_1E = 0x011E,
    SR_1F = 0x011F,
    SR_20 = 0x0120,
    SR_21 = 0x0121,
    SR_22 = 0x0122,
    SR_23 = 0x0123,
    SR_24 = 0x0124,
    SR_25 = 0x0125,
    SR_26 = 0x0126,
    SR_27 = 0x0127,
    SR_28 = 0x0128,
    SR_29 = 0x0129,
    SR_2A = 0x012A,
    SR_2B = 0x012B,
    SR_2C = 0x012C,
    SR_2D = 0x012D,
    SR_2E = 0x012E,
    SR_2F = 0x012F,
    SR_30 = 0x0130,
    SR_31 = 0x0131,
    SR_32 = 0x0132,
    SR_33 = 0x0133,
    SR_34 = 0x0134,
    SR_35 = 0x0135,
    SR_36 = 0x0136,
    SR_37 = 0x0137,
    SR_38 = 0x0138,
    SR_39 = 0x0139,
    SR_3A = 0x013A,
    SR_3B = 0x013B,
    SR_3C = 0x013C,
    SR_3D = 0x013D,
    SR_3E = 0x013E,
    SR_3F = 0x013F,
    SR_40 = 0x0140,
    SR_41 = 0x0141,
    SR_42 = 0x0142,
    SR_43 = 0x0143,
    SR_44 = 0x0144,
    SR_45 = 0x0145,
    SR_46 = 0x0146,
    SR_47 = 0x0147,
    SR_48 = 0x0148,
    SR_49 = 0x0149,
    SR_4A = 0x014A,
    SR_4B = 0x014B,
    SR_4C = 0x014C,
    SR_4D = 0x014D,
    SR_4E = 0x014E,
    SR_4F = 0x014F,
    SR_50 = 0x0150,
    SR_51 = 0x0151,
    SR_52 = 0x0152,
    SR_53 = 0x0153,
    SR_54 = 0x0154,
    SR_55 = 0x0155,
    SR_56 = 0x0156,
    SR_57 = 0x0157,
    SR_58 = 0x0158,
    SR_59 = 0x0159,
    SR_5A = 0x015A,
    SR_5B = 0x015B,
    SR_5C = 0x015C,
    SR_5D = 0x015D,
    SR_5E = 0x015E,
    SR_5F = 0x015F,
    SR_60 = 0x0160,
    SR_61 = 0x0161,
    SR_62 = 0x0162,
    SR_63 = 0x0163,
    SR_64 = 0x0164,
    SR_65 = 0x0165,
    SR_66 = 0x0166,
    SR_67 = 0x0167,
    SR_68 = 0x0168,
    SR_69 = 0x0169,
    SR_6A = 0x016A,
    SR_6B = 0x016B,
    SR_6C = 0x016C,
    SR_6D = 0x016D,
    SR_6E = 0x016E,
    SR_6F = 0x016F,
    SR_70 = 0x0170,
    SR_71 = 0x0171,
    SR_72 = 0x0172,
    SR_73 = 0x0173,
    SR_74 = 0x0174,
    SR_75 = 0x0175,
    SR_76 = 0x0176,
    SR_77 = 0x0177,
    SR_78 = 0x0178,
    SR_79 = 0x0179,
    SR_7A = 0x017A,
    SR_7B = 0x017B,
    SR_7C = 0x017C,
    SR_7D = 0x017D,
    SR_7E = 0x017E,
    SR_7F = 0x017F,
    SR_80 = 0x0180,
    SR_81 = 0x0181,
    SR_82 = 0x0182,
    SR_83 = 0x0183,
    SR_84 = 0x0184,
    SR_85 = 0x0185,
    SR_86 = 0x0186,
    SR_87 = 0x0187,
    SR_88 = 0x0188,
    SR_89 = 0x0189,
    SR_8A = 0x018A,
    SR_8B = 0x018B,
    SR_8C = 0x018C,
    SR_8D = 0x018D,
    SR_8E = 0x018E,
    SR_8F = 0x018F,
    SR_90 = 0x0190,
    SR_91 = 0x0191,
    SR_92 = 0x0192,
    SR_93 = 0x0193,
    SR_94 = 0x0194,
    SR_95 = 0x0195,
    SR_96 = 0x0196,
    SR_97 = 0x0197,
    SR_98 = 0x0198,
    SR_99 = 0x0199,
    SR_9A = 0x019A,
    SR_9B = 0x019B,
    SR_9C = 0x019C,
    SR_9D = 0x019D,
    SR_9E = 0x019E,
    SR_9F = 0x019F,
    SR_A0 = 0x01A0,
    SR_A1 = 0x01A1,
    SR_A2 = 0x01A2,
    SR_A3 = 0x01A3,
    SR_A4 = 0x01A4,
    SR_A5 = 0x01A5,
    SR_A6 = 0x01A6,
    SR_A7 = 0x01A7,
    SR_A8 = 0x01A8,
    SR_A9 = 0x01A9,
    SR_AA = 0x01AA,
    SR_AB = 0x01AB,
    SR_AC = 0x01AC,
    SR_AD = 0x01AD,
    SR_AE = 0x01AE,
    SR_AF = 0x01AF,
    SR_B0 = 0x01B0,
    SR_B1 = 0x01B1,
    SR_B2 = 0x01B2,
    SR_B3 = 0x01B3,
    SR_B4 = 0x01B4,
    SR_B5 = 0x01B5,
    SR_B6 = 0x01B6,
    SR_B7 = 0x01B7,
    SR_B8 = 0x01B8,
    SR_B9 = 0x01B9,
    SR_BA = 0x01BA,
    SR_BB = 0x01BB,
    SR_BC = 0x01BC,
    SR_BD = 0x01BD,
    SR_BE = 0x01BE,
    SR_BF = 0x01BF,
    SR_C0 = 0x01C0,
    SR_C1 = 0x01C1,
    SR_C2 = 0x01C2,
    SR_C3 = 0x01C3,
    SR_C4 = 0x01C4,
    SR_C5 = 0x01C5,
    SR_C6 = 0x01C6,
    SR_C7 = 0x01C7,
    SR_C8 = 0x01C8,
    SR_C9 = 0x01C9,
    SR_CA = 0x01CA,
    SR_CB = 0x01CB,
    SR_CC = 0x01CC,
    SR_CD = 0x01CD,
    SR_CE = 0x01CE,
    SR_CF = 0x01CF,
    SR_D0 = 0x01D0,
    SR_D1 = 0x01D1,
    SR_D2 = 0x01D2,
    SR_D3 = 0x01D3,
    SR_D4 = 0x01D4,
    SR_D5 = 0x01D5,
    SR_D6 = 0x01D6,
    SR_D7 = 0x01D7,
    SR_D8 = 0x01D8,
    SR_D9 = 0x01D9,
    SR_DA = 0x01DA,
    SR_DB = 0x01DB,
    SR_DC = 0x01DC,
    SR_DD = 0x01DD,
    SR_DE = 0x01DE,
    SR_DF = 0x01DF,
    SR_E0 = 0x01E0,
    SR_E1 = 0x01E1,
    SR_E2 = 0x01E2,
    SR_E3 = 0x01E3,
    SR_E4 = 0x01E4,
    SR_E5 = 0x01E5,
    SR_E6 = 0x01E6,
    SR_E7 = 0x01E7,
    SR_E8 = 0x01E8,
    SR_E9 = 0x01E9,
    SR_EA = 0x01EA,
    SR_EB = 0x01EB,
    SR_EC = 0x01EC,
    SR_ED = 0x01ED,
    SR_EE = 0x01EE,
    SR_EF = 0x01EF,
    SR_F0 = 0x01F0,
    SR_F1 = 0x01F1,
    SR_F2 = 0x01F2,
    SR_F3 = 0x01F3,
    SR_F4 = 0x01F4,
    SR_F5 = 0x01F5,
    SR_F6 = 0x01F6,
    SR_F7 = 0x01F7,
    SR_F8 = 0x01F8,
    SR_F9 = 0x01F9,
    SR_FA = 0x01FA,
    SR_FB = 0x01FB,
    SR_FC = 0x01FC,
    SR_FD = 0x01FD,
    SR_FE = 0x01FE,
    SR_FF = 0x01FF,
} RegGroupIndex;

#define CB_VIDEO_SUBSYSTEM_ENABLE_REG (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03C3) 
#define CB_ATTR_ADDR_REG              (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03C0)
#define CB_ATTR_DATA_WRITE_REG        (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03C0)  
#define CB_ATTR_DATA_READ_REG         (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03C1) 
#define CB_GRAPH_ADDR_REG             (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03CE)  
#define CB_GRAPH_DATA_REG             (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03CF)  
#define CB_INPUT_STATUS_0_REG         (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03C2)
#define CB_INPUT_STATUS_1_REG         (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03DA)
#define CB_ATTR_INITIALIZE_REG        CB_INPUT_STATUS_1_REG
#define CB_MISC_OUTPUT_READ_REG       (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03CC)
#define CB_MISC_OUTPUT_WRITE_REG      (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03C2)
#define CB_DAC_PIXEL_MASK_REG         (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03C6)
#define CB_DAC_ADDR_READ_REG          (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03C7)  
#define CB_DAC_ADDR_WRITE_REG         (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03C8)
#define CB_DAC_DATA_REG               (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03C9)
#define CB_SEQ_ADDR_REG               (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03C4)
#define CB_SEQ_DATA_REG               (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03C5)
#define CB_CRT_ADDR_REG               (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03D4)
#define CB_CRT_DATA_REG               (PVOID)((ULONG_PTR)pcbe->VGAMmioBase + 0x03D5)
#define IN_TV_SHADOW_REG(x)           (PVOID)((ULONG_PTR)pcbe->MmioBase+0xC000+(x))
#define CB_MMIO_OFFSET(x)             (PVOID)((ULONG_PTR)pcbe->MmioBase + (x))

// Add a macro to compute number of elements in an array
#define NELEMS(Array)   ( sizeof(Array)/sizeof(Array[0]) )

// Interrupt information coming from HW
#define HW_INTERRUPT_ENABLED           BIT31 // For MMIO.200[31]
#define HW_LVDS_HPD_INT_ENABLED        BIT30 // MMIO 200[30](LVDS Sense Interrupt of spec)
#define HW_LVDS_HPD_INT_INTERRUPTED    BIT27 // MMIO 200[27](LVDS Sense Interrupt of spec)
#define HW_TMDS_HPD_INT_ENABLED        BIT16 // MMIO 200[16](TMDS Sense Interrupt of spec)
#define HW_TMDS_HPD_INT_INTERRUPTED    BIT0  // MMIO 200[00](TMDS Sense Interrupt of spec)

#if !LINUX_PLATFORM
#define HW_IGA1_VSYNC_INT_ENABLED      BIT19 // MMIO 200[19]
#define HW_IGA2_VSYNC_INT_ENABLED      BIT17 // MMIO 200[17]
#define HW_IGA2_VSYNC_STATUS           BIT15
#define HW_CAPTURE1_VBI_STATUS         BIT14
#define HW_CAPTURE0_VBI_STATUS         BIT13
#define HW_CAPTURE0_ACT_VID_STATUS     BIT12
#define HW_HQV2_STATUS                 BIT10
#define HW_HQV1_STATUS                 BIT9
#define HW_CAPTURE1_ACT_VID_STATUS     BIT8
#define HW_DMA1_TD_STATUS              BIT7
#define HW_DMA1_DESCRIPTOR_TD_STATUS   BIT6
#define HW_DMA0_TD_STATUS              BIT5
#define HW_DMA0_DESCRIPTOR_TD_STATUS   BIT4
#define HW_IGA1_VSYNC_STATUS           BIT3
#define HW_MC_COMPLETE_FRAME_STATUS    BIT2


#define HW_VSYNC_INT_ENABLE_MASK       HW_IGA1_VSYNC_INT_ENABLED+HW_IGA2_VSYNC_INT_ENABLED
#define HW_ALL_INT_STATUS_MASK         HW_LVDS_HPD_INT_INTERRUPTED+HW_IGA2_VSYNC_STATUS+HW_CAPTURE1_VBI_STATUS+HW_CAPTURE0_VBI_STATUS+HW_CAPTURE0_ACT_VID_STATUS+ \
                                       HW_HQV2_STATUS+HW_HQV1_STATUS+HW_CAPTURE1_ACT_VID_STATUS+HW_DMA1_TD_STATUS+HW_DMA1_DESCRIPTOR_TD_STATUS+ \
                                       HW_DMA0_TD_STATUS+HW_DMA0_DESCRIPTOR_TD_STATUS+HW_IGA1_VSYNC_STATUS+HW_MC_COMPLETE_FRAME_STATUS+HW_TMDS_HPD_INT_INTERRUPTED 
#endif
#define HW_DP_HPD_INT_ENABLED          BIT24 // MMIO 1280[24]
#define HW_DP_HPD_INT_INTERRUPTED      BIT11 // MMIO 1280[11]
#define HW_DP2_HPD_INT_ENABLED         BIT26 // MMIO 1280[26]
#define HW_DP2_HPD_INT_INTERRUPTED     BIT13 // MMIO 1280[13]

#define TWO2FORTHY                     1099511627776LL

// digital port related info
typedef enum _DI_TYPE
{
    None = 0,
    CRT_PORT,
    DVP0,
    DVP1,
    DFP_HIGH,
    DFP_LOW,
    DFP_FULL,
    DPPHY,
    DPMUX
} DI_TYPE;

typedef struct _DigitalPortInfo
{
    DI_TYPE          DIType;
    DIPortInfo       PortInfo;
    BOOL             bHPDInterrpted;
    BOOL             bIsEDIDUpdated;
} DigitalPortInfo, *PDigitalPortInfo;

typedef struct _CBIOS_EDID_INFO {
    UCHAR       EDIDVersion;

    //----------block 0 detailed timing---------
    CBIOS_S3MODE_INFO EstTimings[16];
    CBIOS_S3MODE_INFO StdTimings[8];
    EDID_DETAILEDTIMING_INFO DtlTimings[EDID1X_BLOCK0_MAX_DTD_NUM];

    //---------CEA Extansion block timing ---------
    // now only support 1 Extansion block    
    CEA_EXTANSION_EDIDINFO CEABlock_1;
} CBIOS_EDID_INFO, *PCBIOS_EDID_INFO;

// device EDID & EDID info
typedef struct _CBIOS_DEV_EDID {
    CBIOS_EDID_BUFFER   realEDIDbuf;    // real EDID on device
    CBIOS_EDID_BUFFER   fakeEDIDbuf;    // fake EDID on device
    BOOL                bFakeEDID;      // is EDID data fake
    CBIOS_EDID_INFO     EDIDInfo;       // current using EDID info, maybe parser from real or fake
} CBIOS_DEV_EDID, *PCBIOS_DEV_EDID;

//*****************************************************************************
//
// sysbios shadow info
//
#pragma pack(1)
typedef struct _SYSBIOSInfoHeader
{
    BYTE    Version;    // system bios info revision
    BYTE    Reserved;
    BYTE    Length;     // the size of SysBIOSInfo
    BYTE    CheckSum;   // checksum of SysBiosInfo
}SYSBIOSInfoHeader, *PSYSBIOSInfoHeader;

typedef struct _SYSBIOSInfo
{
    // RomImage 64K byte
    // BYTE    RomImage[ROM_SCAN_SIZE];
    SYSBIOSInfoHeader   Header;
    DWORD   BootUpDev;
    DWORD   HDTV_TV_Config;
    DWORD   FBStartingAddr;
    BYTE    LCDPanelID;
    BYTE    FBSize;
    BYTE    DRAMDataRateIdx;
    BYTE    DualMemoCtrl;
    DWORD   AlwaysLightOnDev;
    DWORD   AlwaysLightOnDevMask;
    DWORD   EngineClockModify;
    BYTE    LCD2PanelID;            // BYTE 0x21 in struct
    BYTE    TVLayOut;               // TV HW layout; Added in version 2 (BYTE 0x22 in struct)
    WORD    SSCCtrl;
    WORD    ChipCapability;
    WORD    LowTopAddress;
    DWORD   RemapStartAddress;
    WORD    FSBSpeed;
}SYSBIOSInfo, *PSYSBIOSInfo;
#pragma pack()

#define LCD2_ID_AVAILABLE_LENGTH 0x21
#define SSCCtrl_AVAILABLE_LENGTH 0x24

typedef struct _DPSINK_CAPABILITY
{
    DWORD           LaneNumber;       // 1 ~ 4 lanes
    DWORD           LinkSpeed;        // 162 MHz or 270 MHz
    DWORD           bpc;              // bit per channel
    DWORD           TUSize;           // 32 ~ 64, default to 48
    BYTE            EnhancedMode; 
    BOOL            DualMode;         // 1 (yes), connect to HDMI/DVI via a connector
    BOOL            AsyncMode;        // 1 (yes), asynchronous mode    
    BOOL            IsHDMIDevice;     // 1: HDMI, 0:DVI (EDID data) in dual mode
    BOOL            IsSupportCEA861;  // 1: CEA 861 mode, 0: DVI/LCD in DP mode
    DWORD           ColorFormat;      // 0:RGB 1:YUV422 2:YUV444
    DWORD           DynamicRange;     // 0:VESA range, 1:CEA range
    GFXTimingTable  TimingTbl;
}DPSINK_CAPABILITY, *PDPSINK_CAPABILITY;

#define CBIOS_MAX_DP_DEVICES_NUM        2

//*****************************************************************************
//
// _CBIOS_EXTENSION: main structure of CBIOS
//

typedef struct _CBIOS_EXTENSION
{
    DWORD   SupportDevices;

    //driver&hardware info
    PUCHAR  MmioBase;
    PUCHAR  VGAMmioBase;
    ULONG   PCIDeviceID;
    DWORD   ChipRevision;
#ifdef DOSDLL
    DWORD  ulGenericChipID;
    DWORD  BusType;
    DWORD  ChipID;
    DWORD  FBPhysicalAddress;
    DWORD  AdapterMemorySize;
#endif
    /****************** Scratch Pad Information *********************/

    // Scratch Pad - 01h (CR3B)  DuoView and Active Displays
    struct {
        BYTE    Out_Dev     : 7;            // Output Devices
        BYTE    bDuoView    : 1;
    } sPad_1;

    // Scratch Pad - 02h (CR3D) Memory Data Rate Index & Special Conditions
    struct {
        BYTE    runDOSMode      : 1;
        BYTE    priSecDev       : 1;        // 0 = primary, 1 = secondary
        BYTE    DPMSState       : 1;        // 0 = Off, 1 = On
        BYTE    keepScreenOff   : 1;        // 0 = screen on after set mode, 1 = keep off
        BYTE    Mem_Data_Rate   : 4;
    } sPad_2;

    // Scratch Pad - 03h (CR3E) LVDS / TMDS Transmitter for Digital Interface
    union{
        BYTE    Tx0     : 4;        // DVI-TMDS or LCD2-LVDS
        BYTE    Tx1     : 4;        // LCD-LVDS or DVI2-TMDS
        BYTE    Tx;                 // TX on DVP1
    } sPad_3;

    // Scratch Pad - 04h (CR3F) Flat Panel Size Index and ID
    struct {
        BYTE    LCD_DVI2_PanelID : 4;
        BYTE    DVI_LCD2_PanelID : 4;
    } sPad_4;

    // Scratch Pad - 05h (CR4B) TV Contraction & Dot Crawl Control
    struct {
        BYTE    TV_Contraction  : 3;
        BYTE    b64BitsOS       : 1;
        BYTE    I2C_IOPort      : 1;    // 0:SR26 1:SR31
        BYTE    enableGPIO_I2C  : 1;
        BYTE    TVInputMode     : 1;    // 0:RGB input 1:YcbCr input
        BYTE    enableDotCrawl  : 1;
    } sPad_5;

    // Scratch Pad - 06h (CR4C) HDMI Flat Panel Size & Transmitter for Digital Interface
    struct {
        BYTE    HDMIPanelID    : 4;
        BYTE    HDMITXType     : 2;
        BYTE    reserved       : 2;
    } sPad_6;

    // Scratch Pad - 07h (CR4D) TV Output Connector Type
    struct {
        BYTE    TVOutType   : 7;
        BYTE    HDMIdevBit  : 1;
    } sPad_7;

    // Scratch Pad - 08h (CR4E) TV Type
    struct {
        BYTE    TV_Type     : 4;
        BYTE    bExpansion  : 1;     // 0: Centering 1:Expansion
        BYTE    reserved0   : 1;
        BYTE    bTVAttached : 1;     // 0: Not attached, 1: Attached
        BYTE    reserved1   : 1;
    } sPad_8;

    // Scratch Pad - 09h (SR32) Device Availability Status
    struct {
        BYTE    synchronization : 1;
        BYTE    systemOnDock    : 1;
        BYTE    runMiniPOST     : 1;
        BYTE    systemSecurity  : 1;
        BYTE    LCDkeepOn       : 1;
        BYTE    CRT2SenseStatus : 1;
        BYTE    reserved        : 2;
    } sPad_9;

    // Scratch Pad - 0Ah (SR33) Event Notification Protocols
    struct {
        BYTE    deviceSwitchEvent       : 1;
        BYTE    needDDCDetection        : 1;
        BYTE    DVIHotPlugEvent         : 1;
        BYTE    dispExpansionEvent      : 1;
        BYTE    enableExpansionEvent    : 1;
        BYTE    resumeEvent             : 1;
        BYTE    sBIOSEnableSwitchEvent  : 1;
        BYTE    driverEnableSwitchEvent : 1;
    } sPad_A;

    // Scratch Pad - 0Bh (SR34) Display Switching, Hotkey and DVI Control
    struct {
        BYTE    multiMonitor            : 1;
        BYTE    hotkeyBlocking          : 1;
        BYTE    dispSwitchOriginator    : 1;
        BYTE    devSwitchNotifyAndBlock : 1;
        BYTE    hotkeyDevSwitchNotify   : 1;
        BYTE    DVIPresent              : 1;    // 0 = not present; 1 = present
        BYTE    SAMMNotSupport          : 1;    // 0 = Support, 1 = not support
        BYTE    DVIScaling              : 1;    // 0 = not scaling; 1 = scaling
    } sPad_B;

    // Scratch Pad - 0Ch (SR39) Video Memory Size
    struct {
        BYTE    Mem_Size;   // Video Memory Size( MB) / 4
    } sPad_C;

    // Scratch Pad - 0Dh (SR3A) Digital Interface & Refresh Rate Index
    struct {
        BYTE    CRT_RRIndex     : 4;
        BYTE    CRT2_RRIndex    : 4;
    } sPad_D;

    // Scratch Pad - 0Eh (CR49) Video Mode Number for Primary Display

    // Scratch Pad - 0Fh (CR4A) DVI & LCD Refresh Rate Index
    struct {
        BYTE    LCD_RRIndex     : 4;
        BYTE    DVI_RRIndex     : 4;
    } sPad_F;

    // Scratch Pad - 10h (CR4F) Video Mode Number for Secondary Display

    // Scratch Pad - 11h (CR3C) HDTV Type
    struct {
        BYTE        HDTV_Type       : 3;
        BYTE        HDTVOutputType  : 1;    // 0 �C R/G/B, 1 �C Pr/Y/Pb
        BYTE        LCD2devBit      : 1;
        BYTE        reserved        : 3;
    } sPad_11;

    // Shadow Scratch Pad - 01h (CR3B)
    struct {
        BYTE        SSC_ENABLE         : 1;
        BYTE        SSC_PATH_EXTERNAL  : 1;
        BYTE        SSC_MODE_FIFO      : 1;
        BYTE        SSC_VALID          : 1;		
        BYTE        reserved           : 4;
    } shPad_1;

    // Shadow Scratch Pad - 02h (CR3D)
    struct {
        BYTE        DP1_LINK_SPEED     : 1;
        BYTE        DP1_CONNECTION     : 2;
        BYTE        DP2_LINK_SPEED     : 1;
        BYTE        DP1_LANE_NUMBER    : 2;
        BYTE        DP2_LANE_NUMBER    : 2;
    } shPad_2;

    // Shadow Scratch Pad - 03h (CR3E)
    struct {
        BYTE        HDMI2devBit        : 1;
        BYTE        DPdevBit           : 1;
        BYTE        DP2devBit          : 1;
        BYTE        LCD3devBit         : 1;
        BYTE        reserved           : 4;
    } shPad_3;

    /****************** End of Scratch Pad Information *********************/

    BYTE        RomData[ROM_SCAN_SIZE];
    SYSBIOSInfo SysBiosInfo;
    BOOL        SysBiosInfoValid;
    PVCPInfo    pVCPInfo;

    CBIOS_DEV_EDID  devEDID[DeviceNumber];

    //****************************************************
    //********* Customize timing data structure **********
    //****************************************************
    PCustomizeTimingHead pCustomizeTimingHead;
    PCustomizeTimingEntity pCustomizeTimingEntityBuf;

    // below for CBIOS new interface
    //**************************************************** 
    //*************   IGA info structure  ****************
    //****************************************************
    IGA_Info    IGA1Info;
    IGA_Info    IGA2Info;
    FIFOPatchSetting FIFO_Info;

    //**************************************************** 
    //*********   Digital Port info structure  ***********
    //****************************************************
    DigitalPortInfo DIPort[DigitalPortNUM];

    //****************************************************
    //*******   Device Control info structure  ***********
    //****************************************************
    // used to record current device power state
    // use 1 BYTE to record the power state of one device  
    //  S3PM_STANDBY    = 0x01,
    //  S3PM_SUSPEND    = 0x02,
    //  S3PM_OFF        = 0x04,
    //  S3PM_ON         = 0x08,
    // now there is only two power state  S3PM_ON / S3PM_OFF
    // for each device on /off
    BYTE  devicepowerstate[DeviceNumber];

    //***************************************************
    //***********  Device timing type policy ***********
    //***************************************************
    DWORD devicetimingtype[DeviceNumber];

    //***************************************************
    //******    TV property adjustment     **************
    //****** used to store some adjustment value  ******
    //**************************************************
    // this structure is used for CBIOS to handle utilty 
    // adjust TV requirment
    TVParameter tvparameter;
    // TV function table, contain TV reg table & CRTC timing
    BYTE        TVI2CPort;
    BYTE        TVI2CSubAddr;

    //---------------------------------------------------
    // CBIOS Chip Related Speciality
    //--------------------------------------------------
    struct Caps{
        unsigned tv_two_clk_ctrl_sup : 1;             // TV two clock support
        unsigned PAD_on_off_in_SW_PS : 1;             // PCIE NBs(336/364) data enable bit do not work, So turn off PAD to pull down data&clock
        unsigned VEE_on_off_by_GPIO0 : 1;             // PCIE NBs have no VEE pin for hardwired LVDS, so use GPIO0
        unsigned IGA2Seq_SeparateDI_control : 1;      // support of IGA2 screen on off(by Sequence Control and DI port), for VT3353 and VT3324
        unsigned S1_power_saving_sup : 1;             // support of S1 power saving feature, Now VT-3353 use
        unsigned DIPort_data_ctrl : 1;                // VT3353/VT3324 all DI port data source can be controlled separately
        unsigned for_inside_tmds_sense_fail : 1;    // support Inside TMDS Sense, for pre 353B1
        unsigned for_killnumber_control : 1;        // set SR79 according to sum of IGA1 & IGA2 's bandwidth, aid for VT3353
        
        unsigned for_track_FIFO_Number_control : 1; // set SR21 accordind to the campare result of memory clock and engine clock, for 3D.
        unsigned Inside_TMDS_Sense_SR3E : 1;          // VT3353 will do hot plug sense for internal TMDS
        unsigned S3_device_define_for_324 : 1;        // For 324, we use s3 device define in cbios
        unsigned New_crt_dac_sense_flow : 1;          // For 324/353 and later chips, we use new crt dac sense flow
        unsigned SSC_Enable : 1;                      // whether SSC needs to be enabled
        unsigned SSC_Using_External : 1;              // whether SSC using external SSC
        unsigned SSC_Using_Fifo_Mode : 1;             // whether SSC using fifo mode
        unsigned SSC_PATH_CONTROL : 1;                // 409 needs SSC path control, 353 doesn't
        unsigned SSC_INTERNAL_PATH_CONTROL : 1;       // 410 internal SSC register change, different from 409
        
        unsigned DVP1_DPA_Value_Adjust : 1;           // for 3324 1625 DPA setting,to avoid conflict among PAL, 720p & 1080I
        unsigned INLVDS_Polarity_Control : 1;         // aid for VT3353 IN_LVDS1 IN_LVDS2 polarity control
        //BOOL I2C_NEED_OFF_SCREEN;             // for old AD9389 i2c error on VT3364
        unsigned PLL_USE_409_FORMULA : 1;             //M and N vaulue won't add 2 to calc clock
        unsigned FOR_364_ECLK : 1;                  //364 A6 chip need to set ECK to 275M  
        unsigned GET_ECK_DEPENDON_SYSINFO : 1;        //353 feature, ECK will depend on sysinfo value
        unsigned FOR_409_S3_RESUME_PLL : 1;         //for 409 s3 resume issue, need load vck&lck early
        unsigned FOR_409_TTL_PANEL : 1;             //  for 409 TTL support
        
        unsigned CR6B_ONOFF_SCRN_NOT_IN_VBLANK : 1;   //  for vt3353 IGA2 screen on/of register CR6B not work well   
        unsigned Is_killnumber_409_setting : 1;       // 409 a0 need different values for kill number setting
        unsigned ALWAYS_ON_CR_CLOCK_AFTER_S3 : 1;     // 336&364 chip need to always on CR clock after resume from S3  
        unsigned DISABLE_INTERRUPT_IN_PAD_ONOFF : 1;  // 324 PAD on/off will cause TMDS/LVDS interrupt, so need to disable it.
        unsigned IGA1_Support_Upscale : 1;            // 410 support IGA1 upscaling.
        unsigned IGA12_Support_Downscale : 1;         // 410 support IGA12 downscaling.
        unsigned IGA1_Support_Pixel_Timing : 1;       // 410 support IGA1 timing by pixel when vesa mode.
        unsigned Disable_Free_Run_ECK_In_Idle_Mode : 1; // 353 need to disable free run ECK to pass DTM common stress I/O test
        unsigned VDCLK_Support : 1;                   // 410 and later chip, support Video IP Clock
        unsigned HW_FETCHCNT_ADD24 : 1;         // 410 A0, IGA1 fetch count needs to add additional value
        unsigned NEW_EXTERN_TIMING_LOCK : 1;          // 410 and later chip, separate CRTC timing/clock select register protect
        unsigned InternalDP_Support : 1;              // 410 and later chip, support Internal DP
        unsigned FOR_410_GTI_BURST_LENGTH : 1;      // 410 and later chip, init T-Arbiter to constant value
        unsigned DP_FOR_410_A0_A1 : 1;          // for 410 A0/A1 DP
        unsigned EXTEND_DEVICE_DEFINE : 1;            // 410 and later chip, extend device define to DWORD
        unsigned NEW_PWM_SRC_CLOCK_SEL : 1;           // 410 and later chip, new PWM source clock selection
        unsigned UseEDPOnDP2 : 1;                     // Use EDP on DP2
        unsigned I2C_HWMasteringCR_Mode : 1;          // Use I2C hardware mastering control function(I2C port 31.26.2C)
        unsigned VT3410_HDMI_ENGINE_CLOCK_GATING : 1; // Set MMIO_8430[15] = 1 
        unsigned HDMI_SUPPORT_DUPLICATE_MODE : 1;     // HDMI support duplicate mode or not
        unsigned Filter_EDID_RefreshRate : 1;         // filter out EDID refresh rate
        unsigned EDID_Mode_Only : 1;                  // only report device EDID mode
        unsigned Force_HDMI_to_DVI_Mode : 1;          //Force HDMI to DVI Mode
    } ChipCaps;

    PowerSavingReg S1SavingRegs;
    PowerSavingReg S3SavingRegs;
    DWORD HDMIAD9389Signal;
    //---------------------------------------------------
    // CBIOS callback function
    //--------------------------------------------------
    CALLBACK_cbDelayMicroSeconds    _cbDelayMicroSeconds;
    CALLBACK_cbSleepMicroSeconds    _cbSleepMicroSeconds;
#if DBG
    CALLBACK_cbDbgPrint             _cbDbgPrint;
#endif
    CALLBACK_cbReadUchar            _cbReadUchar;
    CALLBACK_cbWriteUchar           _cbWriteUchar;
    CALLBACK_cbReadUshort           _cbReadUshort;
    CALLBACK_cbWriteUshort          _cbWriteUshort;
#if !LINUX_PLATFORM
    CALLBACK_cbReadMMIOUlong        _cbReadMMIOUlong;
    CALLBACK_cbWriteMMIOUlong       _cbWriteMMIOUlong;
#endif
    //---------------------------------------------------
    // ECK stored value
    //--------------------------------------------------
    DWORD ECK_Freq;
    //---------------------------------------------------
    // VDCK stored value
    //--------------------------------------------------
    DWORD VDCK_Freq;

    DigitalPortInfo TempDiPort;
    BYTE SSC_Spreading_Range;                 // sprading range in which mode
    
    DPSINK_CAPABILITY   DPSinkCaps[CBIOS_MAX_DP_DEVICES_NUM];
    DWORD Internal_HDMI_pclk;                   // used for setting HDAudio parameters

    enum TIMING_PARAMETER_ATTRIBUTE TimingAttr;

    BOOL IsFirstTimeDetecDP2onEDP;

    DWORD   mm200;                            // used for cbios interrupt entry protect

    PVOID   phUSB_BULKREAD;
    PVOID   phUSB_REGWRITE;
    PVOID   phUSB_MEMWRITE;

    BOOL DPPortLastConnectStatus;

    BOOL TurnOnAD9389ing;

	VOID *VIA_GFX_PRIVATE_DATA;
} CBIOS_EXTENSION, *PCBIOS_EXTENSION;

//**********************************************************
//
// TX type definitions
//
#define TX_AUTO_DETECT  0xFF

typedef enum _LCD_DVI_TX_TYPE
{
    TX_NONE        = 0,       //   No transmitter and without LCD function
    VT3191         = 0x01,
    TTL_PANEL      = 0x02,
    VT1636         = 0x03,
    SII170B        = 0x04,    
    ITE6610        = 0x05,    //   ITE6610 (DVI+HDMI)
    IN_TMDS        = 0x06,    //   Internal TMDS
    HARDWIRED_LVDS = 0x07,    //   HARDWIRED LVDS (or no transmitter but with LCD function)
    AD9389B        = 0x08,
    VT3192         = 0x09,
    SIL9022        = 0x0A,
    SII164         = 0x0B,
    SII168         = 0x0C,
    IN_LVDS1       = 0x0D,    //   IN_LVDS1  
    IN_LVDS2       = 0x0E,    //   IN_LVDS2 
    CH7301         = 0x0F,
    INTERNAL_DP    = 0x10,    //   410_INTERNAL_DP
    INTERNAL_DP2   = 0x11,    //   410_INTERNAL_DP2
    TFP410		   = 0x12,
    CH7305_VT1636  = 0x13
} LCD_DVI_TX_TYPE;

typedef enum _TV_ENCODER_TYPE
{
    VT1621     = 0x01,
    VT1622     = 0x02,
    TV_CH7009  = 0x03,
    TV_CH7017  = 0x04,
    TV_SA7108  = 0x05,
    TV_CH7005  = 0x06,
    VT1622A    = 0x07,
    VT1623_3A  = 0x08,
    TV_FS453   = 0x09,
    TV_FS454   = 0x0A,
    TV_CX875   = 0x0B,
    TV_CX875A  = 0x0C,
    TV_VT3271  = 0x0D,
    VT1625_6   = 0x0E,
    VT1625A_6A = 0x0F,
    VT2325     = 0x10,
    IN_TV      = 0x11,
    CRT2Encoder = 0x12
} TV_ENCODER_TYPE;

#define  VT1622_ID         0x03
#define  VT1622A_3_ID      0x10
#define  VT1625_5A_ID      0x50
#define  CH7305_ID          0x81

enum
{
    SDTV525I = 0x00,
    SDTV625I,
    HDTV480P,
    HDTV576P,
    HDTV720P,
    HDTV1080I,
    HDTV1080P
};

typedef enum _TV_Layout
{
    TV_LAYOUT_BIOS_DEFAULT      = 0,
    TV_LAYOUT_CVBS_SVideo       = 1,
    TV_LAYOUT_SVideo_SVideo     = 2,
    TV_LAYOUT_CVBS_RGB          = 3,
    TV_LAYOUT_CVBS_YCbCr        = 4,
    TV_LAYOUT_CVBS_SDTV_RGB     = 5,
    TV_LAYOUT_CVBS_SDTV_YPbPr   = 6,
    TV_LAYOUT_CVBS              = 7,
    TV_LAYOUT_SVideo            = 8,
    TV_LAYOUT_RGB               = 9,
    TV_LAYOUT_YCbCr             = 10,
    TV_LAYOUT_SDTV_RGB          = 11,
    TV_LAYOUT_SDTV_YPbPr        = 12,
    TV_LAYOUT_SVideo_RGB        = 13,
    TV_LAYOUT_SVideo_YCbCr      = 14,
    TV_LAYOUT_CVBS_SVideo_RGB   = 15,
    TV_LAYOUT_CVBS_SVideo_YCbCr = 16,
} TV_Layout;

// TV Type
enum {
    NTSC = 0x00,
    PAL,
    PALM,
    PALN,
    PALNc,
    PALI,
    PALD,
    NTSCJP
};

// TV Scanning Mode
enum {
    TV_V_NORMAL = 0,
    TV_V_FIT,
    TV_V_OVER
};

// TV Function
typedef enum _TV_FUNCTION_TYPE
{
    TV_FUNC = 1,
    RGB_FUNC,
    YCBCR_FUNC,
    SDTV_RGB_FUNC,
    SDTV_YPBPR_FUNC,
    DOTCRAWL_FUNC,
    YCBCR_IN_FUNC
}TV_FUNCTION_TYPE;

enum {
    TV_CVBS     = 0x01,
    TV_SVideo1  = 0x02,
    TV_RGB      = 0x04,
    TV_Ycbcr    = 0x08,
    TV_SDTVRGB  = 0x10,
    TV_SDTVYpbpr= 0x20,
    TV_SVideo2  = 0x40
};

enum
{
    TV_HPOSITION_LEFT_BOUNDARY_REG_VALUE = 0x45,
    TV_HPOSITION_DEFAULT_REG_VALUE = 0x01,
    TV_VPOSITION_CRITICAL_VALUE_OF_REG4F = 0x3F,
    TV_VPOSITION_TOP_BOUNDARY_REG_VALUE = 0xB1,
    TV_VPOSITION_DEFAULT_REG_VALUE = 0x07,
};

typedef struct _MapTVModeIndex{
    VESA_INFO VesaInfo;
    BYTE TvModeIndex;
}MapTVModeIndex, *PMapTVModeIndex;

//------- aspect ratio property ----------
typedef enum _AspectRatio {
    CBIOS_NONE = 0,
    CBIOS_RATIO_4_3 = 1,
    CBIOS_RATIO_5_4 = 2,
    CBIOS_RATIO_16_10 = 3,
    CBIOS_RATIO_16_9 = 4
}AspectRatio;

//------- interlace / progressive property ----------
#define INTERLACE     1
#define PROGRESSIVE   0

typedef struct _HDTVResolutionRR{
    DWORD xRes;
    DWORD yRes;
    DWORD RefreshRate;
    DWORD interlaced;
}HDTVResolutionRR, *PHDTVResolutionRR;


typedef struct _HDMIResolutionRR{
    DWORD xRes;
    DWORD yRes;
    DWORD RefreshRate;
    DWORD interlaced;
}HDMIResolutionRR, *PHDMIResolutionRR;


typedef struct _AD9389BRegSetting{
    BYTE ucIndex;
    BYTE ucData;
    BYTE Reserved;
}AD9389BRegSetting, *PAD9389BRegSetting;

#if !LINUX_PLATFORM
typedef struct _AD9389ModeFilter{
    WORD XRes;
    WORD YRes;
    WORD RRate;
}AD9389ModeFilter, *PAD9389ModeFilter;
#endif

typedef struct _HDAuioWallClockRegSetting{
    DWORD PixelClock;
    DWORD WallClockRatio_L;
    DWORD WallClockRateo_H;
}HDAuioWallClockRegSetting, *PHDAuioWallClockRegSetting;

typedef struct _HDAuioPacketClockRegSetting{
    DWORD SampleRate;
    DWORD PixelClock;
    DWORD PacketClockRatio_L;
    DWORD PacketClockRateo_H;
}HDAuioPacketClockRegSetting, *PHDAuioPacketClockRegSetting;

typedef struct _HDAuioCTSandNRegSetting{
    DWORD SampleRate;
    DWORD PixelClock;
#if (LINUX_PLATFORM | EFI_CBIOS)
    DWORD MM_C294;
    DWORD MM_C298;
    DWORD MM_C29C;
#else
    DWORD CTS;
    DWORD N;
#endif
}HDAuioCTSandNRegSetting, *PHDAuioCTSandNRegSetting;

#if (LINUX_PLATFORM|EFI_CBIOS)
typedef struct _HDAuioSampleRateRegSetting{
    DWORD SampleRate;
    DWORD PixelClock;
    DWORD MM_C400;
    DWORD MM_C404;
    DWORD MM_C410;
    DWORD MM_C414;
}HDAuioSampleRateRegSetting, *PHDAuioSampleRateRegSetting;
#endif

typedef struct _HDAuioMaudNaudRegSetting{
    DWORD SampleRate;
    DWORD PixelClock;
    DWORD Maud;
    DWORD Naud;
}HDAuioMaudNaudRegSetting, *PHDAuioMaudNaudRegSetting;


//**********************************************************
//
// macro definition
//
#define STRUCT_BYTE(structName, byteIndex)      ( ((BYTE*)( &(structName) )) [byteIndex] )
#define ALIGN_32(x)             ( ((x) + 31) & ~31 )
#define MORE_THAN_1BIT(x)       ( (BOOL)( ((x) - 1) & (x) ) )
#define GET_LOWEST_BIT1(x)      ( (x) ^ ((x) & ((x) - 1)))
#define CLEAR_LOWEST_BIT1(x)    ( (x) & ((x) -1))

#ifndef sizeofarray             //add this to fix VMI strange compile error
#define sizeofarray(a)          ( sizeof(a)/sizeof(a[0]) )
#endif

//***********************************************************
// PLL clock range 
//***********************************************************
#define CSR_VCO_UP          600000000
#define CSR_VCO_DOWN        300000000
// PLL DTZ default setting
// default DTZ to 2b'11 for PLL output stable by HW suggestion
// VCK, LCK, ECK all use same value
#define PLL_DTZ_DEFAULT     ( BIT0+BIT1 )

//**************************************************************************
// Bandwidth of 1600X1200 @60Hz 32bpp mode
// Bandwidth = H_TOTAL*V_TOTAL*RRATE*ColorDepth = 2160*1250*60*4 = 648000000
//**************************************************************************
#define BANDWIDTH_UP_BOUND     2240*1089*60*4 // 1680*1050@60Hz 32bpp

// Timing registers type
typedef enum _TIMING_REG_TYPE
{
    H_TOTAL = 0,                // Horizontal Total
    H_DIS_END,                  // Horizontal Display End
    H_BNK_ST,                   // Horizontal Blank Start
    H_BNK_END,                  // Horizontal Blank End
    H_SYNC_ST,                  // Horizontal Sync Start
    H_SYNC_END,                 // Horizontal Sync End
    V_TOTAL,                    // Vertical Total
    V_DIS_END,                  // Vertical Display End
    V_BNK_ST,                   // Vertical Blank Start
    V_BNK_END,                  // Vertical Blank End
    V_SYNC_ST,                  // Vertical Sync Start
    V_SYNC_END,                 // Vertical Sync End
    FETCH_COUNT,                // Fetch Counter
    OFFSET,                     // Offset
    H_SCALING_FACTOR,           // Horizontal Scaling Factor
    V_SCALING_FACTOR,           // Vertical Scaling Factor
    COLOR_DEPTH,                // Color Depth
    LINE_COMPARE,               // Line compare
    POWER_NOW_END_POS,          // Power Now ending posistion
    HVSYNC_Offset2,             // H V sync offset 2 of interlace mode
} TIMING_REG_TYPE;

//*************** for I2C port use*************************
typedef enum _I2C_PORT_TYPE
{
    I2C = 0,
    GPIO
}I2C_PORT_TYPE;

typedef struct _I2C_CONTROL_UMA
{
    BYTE    I2cPort;    // SR31 or SR2C
    BYTE    SlaveAddr;  // slave address
    BYTE    RegIndex;   // register index
    union{
        BYTE    IndexData;    // register data
    struct {
        BYTE    IndexLOData;  // register data
        BYTE    IndexHIData;  // register data
    };
        WORD    IndexWData;   // register data
    };
    BYTE    Flags;      // Special I2c control flag
} I2C_CONTROL_UMA, *PI2C_CONTROL_UMA;

typedef struct _AUX_CONTROL_UMA
{
    BYTE    I2cPort;    // 
    DWORD   Length;
    DWORD   Offset;   // register index
    BYTE    Data[16];  // register data
    BYTE    Function;      // Special I2c control flag
} AUX_CONTROL_UMA, *PAUX_CONTROL_UMA;

typedef struct _HDMI_INFOFRAME
{
    BYTE    PacketHeader[3];
    BYTE    ECCCode;
    BYTE    PacketByte[28];
    BYTE    BCHCode[4];
} HDMI_INFOFRAME, *PHDMI_INFOFRAME;

typedef struct _DP_INFOFRAME
{
    BYTE    PacketHeader[4];
    BYTE    PacketByte[28];
} DP_INFOFRAME, *PDP_INFOFRAME;

enum DPAUXCH_FUNCTION_CONTROL
{
    DP1      = 0,
    DP2      = 1,
};

enum DPAUXCH_FUNCTION_SELECT
{
    I2C_WRITE   = 0x0,
    I2C_READ    = 0x1,
    I2C_MOT     = 0x4,
    AUX_WRITE   = 0x8,
    AUX_READ    = 0x9,
};


enum I2C_SPECIAL_CONTROL
{
    SIL9022_BURST_READ  = 1,
};

enum I2C_FLAGS
{
    VERIFY_CHECKSUM     = 1,
    DATA_FETCH_DELAY    = 2,
    CORRECT_FAIL_EDID   = 4,
};

enum HDMI_DVI_CONNECT_STATUS
{
    NoHDMIDVIConnection = 0,
    DVIConnection       = 1,
    HDMIConnection      = 2,
};
// CBIOS LCD
typedef struct _LCD_Info
{
    BYTE LCD_ID;
    WORD H_Size;
    WORD V_Size;
    BYTE Channel;
    BOOL bDithering;
    // add other information here...
}LCD_Info, *PLCD_Info;

// TV Mode Index
enum TvModeIndex{
    MODE640 = 0x04,
    MODE800,   
    MODE1024,      
    MODE848,    
    MODE720X480,
    MODE720X576,
    MODE1280X720,
    HDTV1920x1080,
    MODE800X480,
    MODE1024X600,
};

// TV table structure
typedef struct _TV_FUNCTION_UMA {
    BYTE    tvFunIndex;                          // TV function index
    PBYTE   pTvFun;                              // TV function table entry
} TV_FUNCTION_UMA, *PTV_FUNCTION_UMA;


#define INVALID_H_SIZE      0xFFFF

#define MAX_H_RES           0xFFFF
#define MAX_V_RES           0xFFFF

#define MAX_PANELID         0xF

// T-Arb(3D) Request Kill #
#define T_Arb_3D_RK         0x0020
// G-Arb(SL&SF) Reqeust Kill #
#define G_Arb_SLSF_RK       0x0020

// We must wait for AD9389 to raise its own HPD pin when HPD, or we might encounter several 
// sense/power on problem caused by non-sync hot plug interrupt.
#define AD9389B_CHK_MAXTRIES    200

// VT1625's CRT DAC frequency is 85Mhz
// we will use this value to filter unsupported mode & refresh rates
// and we found the display of 1280x800@60hz(DCLK:83.5M) was not good,but
// the display of 1280x768@60hz(DCLK:79.47M) was good,so at here,
// we change this value to 80Mhz to prevent unexpected display bad .
#define VT1625_CRTDAC_MAX_FREQ   (80 * 1000000)

// since wben reload TV timing,1625 TV encoder will be stable after
// some milisecond 30 Ms is a experienced value
#define VT1625DelayPeriod 30

// CH7301 can support resolution up to 1920x1200x60
//HTotal 2592, VTotal 1245, RRate 60
#define CH7301_CRTDAC_MAX_FREQ   (2592*1245*60)

// TMDS has HW limitation of max frequency: single link is 165MHz, dual link is 330MHz
#define TMDS_SINGLE_LINK_FREQUENCY  (165 * 1000000)
#define TMDS_DUAL_LINK_FREQUENCY    (TMDS_SINGLE_LINK_FREQUENCY * 2)
// now we can support single link only
#define TMDS_LINK_FREQUENCY         TMDS_SINGLE_LINK_FREQUENCY
// For 353, RAMDAC is 350MHz
#define CRT_RAMDAC_FREQUENCY        (350*1000000)
// IGA max frequency is 350Mhz
#define IGA_MAX_FREQUENCY           (350*1000000)

#define DP_GOLDEN_RATIO             20

#define CRT_ATTACHED_ON             BIT7

// For 410, if cbios has set mode, update IDX_SCRATCH_PAD_E = CR49 to cbios mode number
#define CBIOS_SET_MODE_NUMBER       0xFF

// sync polarity
enum
{
    CBIOS_POSITIVE    = 0,
    CBIOS_NEGATIVE    = 1
};

#define MORE_THAN_1BIT(x)       ( (BOOL)( ((x) - 1) & (x) ) )

//****************device bit position***********************
enum
{
    CRTbit      = 0,    //0x0001
    LCDbit      = 1,    //0x0002
    TVbit       = 2,    //0x0004
    HDTVbit     = 3,    //0x0008
    DVI2bit     = 4,    //0x0010
    DVIbit      = 5,    //0x0020
    CRT2bit     = 6,    //0x0040
    LCD2bit     = 8,    //0x0100
    HDMIbit     = 9,    //0x0200
    DVI3bit     = 10,   //0x0400
    DVI4bit     = 11,   //0x0800
    HDMI1bit    = 12,   //0x1000
    HDMI2bit    = 13,   //0x2000
    HDMI4bit    = 14,   //0x4000
    DPbit       = 15,   //0x8000
    DP2bit      = 16,   //0x10000
    TV2bit      = 18    //0x40000
};


//****************324 vbios device word define***********************
enum
{
    WORD_CRT      = 0x0001,
    WORD_LCD      = 0x0002,
    WORD_TV       = 0x0004,
    WORD_LCD2     = 0x0008,
    WORD_DVI2     = 0x0010,
    WORD_DVI      = 0x0020,
    WORD_HDTV     = 0x0040,
    WORD_CRT2     = 0x0100,
    WORD_HDMI3    = 0x0200,
    WORD_DVI3     = 0x0400,
    WORD_DVI4     = 0x0800,
    WORD_HDMI1    = 0x1000,
    WORD_HDMI2    = 0x2000,
    WORD_HDMI4    = 0x4000,
    WORD_TV2      = 0x8000,
};

//***************HDTV output type**************************
enum {
    HDTV_RGB    = 0,
    HDTV_YPrPb  = 1
};

typedef struct _TxTypeToSubAddr
{
    ULONG TXType;
    BYTE subAddr;
}TxTypeToSubAddr;

//----------------------------------------------------------------------------
// LCD power sequence time divider
//----------------------------------------------------------------------------
#define    TIMEUNIT       572


//********* TMDS transmitter registers define*************
#define    TX_PD          BIT0        // 0=Power down, 1=Normal operation
#define    TX_EDGE        BIT1        // VT1631(0=rise, 1=fall), others(0=fall, 1=rise)
#define    TX_BSEL        BIT2        // VT1631(0=24/24, 1=48/48), others(0=12-bit, 1=24-bit)
#define    TX_DSEL        BIT3        // VT1631(0=SDR(auto), 1=DDR), others(0=SDR, 1=DDR)
#define    TX_HEN         BIT4
#define    TX_VEN         BIT5


/////////////////////////////////////////////////
/**********  New DI & TX definition for UMA **********/
/////////////////////////////////////////////////

// DI Setting
#define _ENABLE         BIT0        // enable control of digital port
#define _DI1_PORT       BIT1        //detail define of GET_DIGITAL_INTERFACE_SETTING return BYTE
#define _DDR_MODE       BIT2
#define _24BIT_MODE     BIT3
#define _12BIT_MODE     0
#define _DITHERING      BIT1
#define _24BIT_DDR_DFP  (_24BIT_MODE + _DDR_MODE)       // 24-bits mode, DDR
#define _24BIT_SDR_DFP  _24BIT_MODE                     // 24-bits mode, SDR
#define _12BIT_DDR_DV0  _DDR_MODE                       // 12-bits mode, DDR, DV0
#define _12BIT_DDR_DV1  (_DDR_MODE + _DI1_PORT)         // 12-bits mode, DDR, DV1

//--------------------------------------------------
//------- structure Used for CBIOS    --------------
//------- own data table for contraction -----------
//--------------------------------------------------
typedef struct _TVTBLDATA_UMA
{
    BYTE tvModeIndex;
    PTV_FUNCTION_UMA ptvNTSC;
    PTV_FUNCTION_UMA ptvPAL;
    PWORD ptvNTSCTiming;
    PWORD ptvPALTiming;
}TVTBLDATA_UMA, *PTVTBLDATA_UMA;

typedef struct _BypassModePatch
{
    BYTE index;
    BYTE value;
}BypassPatch, *pBypassPatch;

//----------------------------------------------------
// According to DDC3.0 spec. we need to retry at least
// one more time before reaching a decision
//-------------------------------------------------
#define DDCMAXTRIES     2
#define RegIndexVal(index, value)   (index), (value)

//**********************************************************

//---------------------------------------------------
// EDID timing type parse data structure
//---------------------------------------------------
// EDID structure is a compact one so we need to use BYTE align one
#pragma pack(1)

typedef struct DetailedTiming
{
    UCHAR PixelClock[2];        // Pixel clock / 10,000 stores LSB first
    UCHAR HActive;              // Pixels, low 8 bits
    UCHAR HBlank;               // Pixels, low 8 bits
    UCHAR HActive_Blank;        // Upper nibble : upper 4 bits of Horizontal Active
                                // Lower nibble : upper 4 bits of Vertical Blanking
    UCHAR VActive;              // Lines, low 8 bits
    UCHAR VBlank;               // Lines, low 8 bits
    UCHAR VActive_Blank;        // Upper nibble : upper 4 bits of Vertical Active
                                // Lower nibble : upper 4 bits of Vertical Blanking
    UCHAR HSyncOffset;          // Pixels, from blanking starts, lower 8 bits           
    UCHAR HSyncWidth;           // Pixels, lower 8 bits 
    UCHAR VSyncOffset_Width;    // Upper nibble : lines, lower 4 bits of vertical sync offset
                                // Lower nibble : lines, lower 4 bits of vertical sync pulse width
    UCHAR HVSyncOffset_Width;   // bits 7,6 : upper 2 bits of Horizontal Sync Offset 
                                // bits 5,4 : upper 2 bits of Horizontal Sync Pulse Width
                                // bits 3,2 : upper 2 bits of Vertical Sync Offset
                                // bits 1,0 : upper 2 bits of Vertical Sync Pulse Width
    UCHAR HImageSize;           // mm, lower 8 bits
    UCHAR VImageSize;           // mm, lower 8 bits
    UCHAR HVImageSize;          // Upper nibble : upper 4 bits of Horizontal Image Size
                                // Lower nibble : upper 4 bits of Vertical Image Size
    UCHAR HBorder;              // Pixels
    UCHAR VBorder;              // Pixels
    UCHAR Flags;                // bit 7 :  function
                                //  0        Non-Interlace
                                //  1        Interlace
                                // bit 4:1 sync polarity
}DETAILEDTIMING, *PDETAILEDTIMING;

typedef struct _EDID_BLOCK0_DATA_UMA {
   UCHAR Header[8];
   UCHAR VendorPID[10];
   UCHAR EDIDVersion[2];
   UCHAR DisplayParams[5];
   UCHAR ColorCharacters[10];
   UCHAR EstTimings[3];
   UCHAR StdTimingIDs[16];
   DETAILEDTIMING DtlTimings[4];
   UCHAR ExtFlag;
   UCHAR Checksum;
   UCHAR Edid2Buffer[128];
}EDID_BLOCK0_DATA_UMA, *PEDID_BLOCK0_DATA_UMA;


// switch to default align definition
#pragma pack()


// 18 BYTE DTD data mask
#define    H_ACTIVE_HIGHTBITS_MASK      0xF0
#define    H_BLANK_HIGHTBITS_MASK       0x0F
#define    H_SYNCOFFSET_HIGHBITS_MASK   (BIT7 + BIT6)
#define    H_SYNCWIDTH_HIGHBITS_MASK    (BIT5 + BIT4)

#define    V_ACTIVE_HIGHTBITS_MASK      0xF0
#define    V_BLANK_HIGHTBITS_MASK       0x0F
#define    V_SYNCOFFSET_LOWBITS_MASK    0xF0
#define    V_SYNCWIDTH_LOWBITS_MASK     0x0F
#define    V_SYNCOFFSET_HIGHBITS_MASK   (BIT3 + BIT2)
#define    V_SYNCWIDTH_HIGHBITS_MASK    (BIT1 + BIT0)

#define    H_IMAGE_HIGHTBITS_MASK       0xF0
#define    V_IMAGE_HIGHTBITS_MASK       0x0F


// CEA extansion attribute mask
#define    NUM_OF_NATIVE_DTD_MASK       0x0F
#define    YCbCr422_CAP_MASK            0x10
#define    YCbCr444_CAP_MASK            0x20
#define    BASIC_AUDIO_CAP_MASK         0x40
#define    UNDERSCAN_CAP_MASK           0x80

// CEA data block tags
#define    AUDIO_DATA_BLOCK_TAG               0x01
#define    VIDEO_DATA_BLOCK_TAG               0x02
#define    VENDOR_SPECIFIC_DATA_BLOCK_TAG     0x03
#define    SPEAKER_ALLOCATION_DATA_BLOCK_TAG  0x04
#define    VESA_DTC_DATA_BLOCK_TAG            0x05

//**************************************************************

//Cbios shared functions between chip specific code
VOID cbDelayMilliSecondsByHW(PCBIOS_EXTENSION pcbe, ULONG  Milliseconds);
BYTE cbReadRegByte(PCBIOS_EXTENSION pcbe, RegGroupIndex groupInx);
void cbWriteRegByte(PCBIOS_EXTENSION pcbe, RegGroupIndex groupInx, BYTE data);
void cbWriteRegBits(PCBIOS_EXTENSION pcbe, RegGroupIndex groupInx, BYTE mask, BYTE data);


//-----------Add for CBIOS New interface------------------
#define GET_CHIP_MRN(is409Formula, _353_MRN)    ( (is409Formula) ? ((_353_MRN)+0x20002) : (_353_MRN) )
DWORD cbGetMRN_UMA(IN BOOL bPLLUse409Formula, IN DWORD ulClock);
CBIOS_STATUS cbSetECLK_UMA(PCBIOS_EXTENSION pcbe, IN ULONG ulPLLMRN);
CBIOS_STATUS cbSetVDCLK_UMA(PCBIOS_EXTENSION pcbe, IN ULONG ulPLLMRN);
CBIOS_STATUS cbSetPixelCLK_UMA(PCBIOS_EXTENSION pcbe, IN ULONG ulPllMRN, IN ULONG IGANumber);
DWORD cbCalcClkFromMRN(PCBIOS_EXTENSION pcbe,
                       IN BYTE M,
                       IN BYTE R,
                       IN BYTE N);
DWORD cbCalcClkFromDWORDMRN(PCBIOS_EXTENSION pcbe,
                       IN DWORD dwMRN);
CBIOS_STATUS cbGetMCLK_UMA(PCBIOS_EXTENSION pcbe, OUT PULONG pClockFreq);
CBIOS_STATUS cbGetPixelCLK_UMA(PCBIOS_EXTENSION pcbe, IN ULONG IGANumber, OUT PULONG pClockFreq);
CBIOS_STATUS cbGetECLK_UMA(PCBIOS_EXTENSION pcbe, OUT PULONG pClockFreq);
BOOL cbGetMonitorSizeFromDDC_EDIDv1(PCBIOS_EXTENSION pcbe, IN DWORD Device, OUT PDWORD pxRes, OUT PDWORD pyRes);
BOOL cbIsDClkOverLimit(PCBIOS_EXTENSION pcbe, IN DWORD dispDev, IN DWORD DClk);
BOOL cbIsDuplicateMode(PCBIOS_EXTENSION pcbe, IN DWORD SVDIndex);
void cbSetTVCLK_PATH_UMA(PCBIOS_EXTENSION pcbe, IN DWORD IGAInfo, IN DWORD Operate);   

//*****************************************************************************
//
// below are new CBIOS sub function Declarations
//

//---------------------Timing setting related--------------------------
void cbTransVESAVPITToTimingTbl(
    IN PVESA_INFO pVESA_Info,
    IN PVESA_VPIT pVESA_VPIT,
    OUT PGFXTimingTable pTimingTbl
);

BOOL cbGetVESAVPITResolutionsBuffer(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD Max_H_Res,
    IN DWORD Max_V_Res,
    OUT DWORD *pResBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize);

BOOL cbGetCEAResolutionsBuffer(
    PCBIOS_EXTENSION pcbe, 
    OUT DWORD *pResBuf,
    IN OUT DWORD *pBufSize);

BOOL cbGetVESAVPITRefreshRatesForResolution(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN DWORD bufSize,
    OUT DWORD *pBufSize);

BOOL cbGetCEARefreshRatesForResolution(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize);

BOOL cbGetVBIOSVesaInfo(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT PVESA_INFO *ppVESA_Info
);

BOOL cbGetCEATypeTimingTbl(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo,
    OUT PGFXTimingTable pTimingTbl
);

BOOL cbGetVBIOSVesaTimingTable(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo,
    IN BOOL bReduceBlk,
    OUT PGFXTimingTable pTimingTbl
);

BOOL cbIsVBIOSVesaTimingTableExsist(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo);

BOOL cbGetCBIOSVesaInfo(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN PVESA_INFO_CBIOS pVESA_Info_CBIOSTbl,
    IN DWORD TableNum,
    OUT PVESA_INFO_CBIOS *ppVESA_Info_CBIOS_Entity
);

BOOL cbGetCBIOSVesaTimingTable(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo,
    IN PVESA_INFO_CBIOS pVESA_Info_CBIOS_Entity,
    IN DWORD TableNum,
    OUT PGFXTimingTable pTimingTbl
);

BOOL cbGetVBIOSPanelTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN DWORD device,
    OUT PGFXTimingTable pTimingTbl);

BOOL cbHDTVIsVBIOSSupportMode(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res, 
    IN DWORD V_Res
);

BOOL cbTransTVandHDTVTimingTbl(
    PCBIOS_EXTENSION pcbe,
    IN PWORD pTvTimingTbl,
    IN DWORD rRateX100,
    OUT PGFXTimingTable pTimingTbl
);

BOOL cbGetVBIOSTVGFXTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN WORD  H_Res,
    IN WORD  V_Res,
    OUT PGFXTimingTable pTimingTbl
);

BOOL cbGetVBIOSTVEncoderTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN WORD  H_Res,
    IN WORD  V_Res,
    OUT PTV_FUNCTION_VCP *ppTVFunc
);

BOOL cbGetVBIOSHDTVGFXTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN WORD  H_Res,
    IN WORD  V_Res,
    OUT PGFXTimingTable pTimingTbl
);

BOOL cbGetVBIOSHDTVEncoderTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN WORD  H_Res,
    IN WORD  V_Res,
    OUT PTV_FUNCTION_VCP *ppHDTVFunc,
    OUT BYTE **ppHDTVPatch
);

BOOL cbGetCBIOSTVGFXTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN WORD  H_Res,
    IN WORD  V_Res,
    OUT PGFXTimingTable pTimingTbl);
    
BOOL cbGetCBIOSTVEncoderTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN WORD  H_Res,
    IN WORD  V_Res,
    OUT PTV_FUNCTION_UMA *ppCBIOSTVFunc);

BOOL cbSetIGA1Timing(
    PCBIOS_EXTENSION pcbe,
    IN PGFXTimingTable pTimingTbl
);

BOOL cbSetIGA1SrcMode(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD H_DisEnd, 
    IN DWORD colorDepth
);

CBIOS_STATUS cbSetIGA1DevMode(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN DWORD colorDepth,
    IN RefreshRateInfo RRateInfo
);

BOOL cbSetIGA1ModeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PCBiosSourceModeParams   pSrc,   // Specify Source Mode to set
    IN PCBiosViewSizeParams     pView,  // Speicfy View Size, from this we can know info such as scale factor.
    IN PCBiosDestTimingParams   pDest   // Specify Destination Timing to set
);

BOOL cbSetIGA1DownscaleSourceTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PCBiosSourceModeParams pSrc,
    IN PCBiosViewSizeParams pView,
    IN PGFXTimingTable pTimingTbl
);

BOOL cbSetIGA1DownscaleTargetTiming(
    PCBIOS_EXTENSION pcbe,
    IN PGFXTimingTable pTimingTbl
);

BOOL cbSetIGA2Timing(
    PCBIOS_EXTENSION pcbe,
    IN PGFXTimingTable pTimingTbl
);

BOOL cbSetIGA2SrcMode(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD H_DisEnd, 
    IN DWORD colorDepth
);

CBIOS_STATUS cbSetIGA2DevMode (
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN DWORD colorDepth,
    IN RefreshRateInfo RRateInfo
);

BOOL cbSetIGA2ModeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PCBiosSourceModeParams   pSrc,   // Specify Source Mode to set
    IN PCBiosViewSizeParams     pView,  // Speicfy View Size, from this we can know info such as scale factor.
    IN PCBiosDestTimingParams   pDest   // Specify Destination Timing to set
);

BOOL cbSetIGA2DownscaleSourceTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PCBiosSourceModeParams pSrc,
    IN PCBiosViewSizeParams pView,
    IN PGFXTimingTable pTimingTbl
);

BOOL cbSetIGA2DownscaleTargetTiming(
    PCBIOS_EXTENSION pcbe,
    IN PGFXTimingTable pTimingTbl
);

BOOL cbSetDaughterCardTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res, 
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo
);

BOOL cbGetTargetGFXTimingTbl(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl
);

BOOL cbGetSpecificGFXTimingTbl(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl
);

void cbSetScalePath(
    PCBIOS_EXTENSION pcbe,
    IN DWORD IGA_Num,
    IN ScaleType SType
);

void cbSetIGAScaleFactor(
    PCBIOS_EXTENSION pcbe,
    IN DWORD IGA_Num,
    IN ScaleType SType,
    IN PScaleFactor pScaleFactor
);

void cbSetScaleFactor(
    PCBIOS_EXTENSION pcbe,
    IN ScaleType SType,
    IN PScaleFactor pScaleFactor
);

void cbDIPortDataCTRL(
    PCBIOS_EXTENSION pcbe,
    IN DWORD Operate, 
    IN DI_TYPE DIType
);

void cbIGA1_FIFO_Setting_UMA(PCBIOS_EXTENSION pcbe, WORD Offset);
void cbIGA2_FIFO_Setting_UMA(PCBIOS_EXTENSION pcbe, WORD Offset);

void cbFillTVFunctionRegs (
    PCBIOS_EXTENSION pcbe,
    IN PTV_FUNCTION_VCP pTVFunc,
    IN TV_FUNCTION_TYPE TVFuncType
);

void cbFillTVFunctionRegs_CBIOS (
    PCBIOS_EXTENSION pcbe,
    IN PTV_FUNCTION_UMA pTVFunc_CBIOS,
    IN TV_FUNCTION_TYPE TVFuncType
);

void cbPatchTVFunctions(
    PCBIOS_EXTENSION pcbe,
    IN PTV_FUNCTION_VCP pTVFunc
);

void cbPatchHDTVFunctions(
    PCBIOS_EXTENSION pcbe,
    IN BYTE *pHDTVPatch
);

void cbPatchTVFunctions_CBIOS(
    PCBIOS_EXTENSION pcbe,
    IN PTV_FUNCTION_UMA pTVFunc_CBIOS
);

//---------------------------Device Power Management-------------------
CBIOS_STATUS SetIGA1screenOnOff(PCBIOS_EXTENSION pcbe, BOOL screenState);
CBIOS_STATUS SetIGA2screenOnOff(PCBIOS_EXTENSION pcbe, BOOL screenState);
CBIOS_STATUS cbenableDevice_UMA(PCBIOS_EXTENSION pcbe, IN DWORD Device);
CBIOS_STATUS cbdisableDevice_UMA(PCBIOS_EXTENSION pcbe, IN DWORD Device);
void cbSetCRTPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate);
void cbsetcrt2powerstate(PCBIOS_EXTENSION pcbe, IN PowerState powerstate);
void cbSetLCDPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate);
void cbSetLCD2PowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate);
void cbPanelOnOffCTRL(PCBIOS_EXTENSION pcbe, IN DWORD device, IN BOOL operate);
void cbPanelTXCTRL(PCBIOS_EXTENSION pcbe, IN LCD_DVI_TX_TYPE TXType, IN BOOL operate);
void cbPanelSWPowerSeqenceCTRL(PCBIOS_EXTENSION pcbe, IN DWORD device, IN BOOL operate, IN BOOL bSetSSC);
void cbPanelSWPowerSeqenceCTRL_LVDS2(PCBIOS_EXTENSION pcbe, IN DWORD device, IN BOOL operate, IN BOOL bSetSSC);
void cbSetDVIPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate);
void cbSetDVI2PowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate);
void cbSetHDMIPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate);
void cbSetHDMI2PowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate);
void cbSetDPPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate);
void cbSetDP2PowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate);
void cbSetTVPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate);
void cbSetHDTVPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate);
void cbSetIGAPower(PCBIOS_EXTENSION pcbe, IN DWORD IGA1Power, IN DWORD IGA2Power);
void cbConfigureIGApath(PCBIOS_EXTENSION pcbe);

//--------------------------HDMI specialed subfunc--------------------
extern DWORD const HDMISupportResolution[];
extern DWORD const HDMI_RESOLUTION_NUM;
extern DWORD const HDMI_REFRESHRATE_NUM;
extern HDMIResolutionRR const HDMIResolutionRefreshRate[]; 

//--------------------------DP special subfunc------------------------
void cbDPDeviceDetect(PCBIOS_EXTENSION pcbe, IN UINT32 detectDev, OUT BOOL *pbAttached);
void cbDPDualModeDetect(PCBIOS_EXTENSION pcbe, DWORD DPIndex);
void cbDPInitEPHY(PCBIOS_EXTENSION pcbe, DWORD DPIndex);
void cbDPSetAuxWriteBuffer(PCBIOS_EXTENSION pcbe, IN PAUX_CONTROL_UMA pAUX, DWORD DPIndex);
void cbDPGetAuxReadBuffer(PCBIOS_EXTENSION pcbe, IN PAUX_CONTROL_UMA pAUX, DWORD DPIndex);
BOOL cbDPAuxChRW(PCBIOS_EXTENSION pcbe, IN PAUX_CONTROL_UMA pAUX, DWORD DPIndex);
void cbDPHWUseAuxCh(PCBIOS_EXTENSION pcbe, DWORD DPIndex);
void cbDPSWAuxRequest(PCBIOS_EXTENSION pcbe, DWORD DPIndex);
void cbDPResetAux(PCBIOS_EXTENSION pcbe, IN DWORD DPIndex);
BOOL cbDPAuxReplyStatus(PCBIOS_EXTENSION pcbe, DWORD DPIndex);
BOOL cbDPLinkTrainingHW(PCBIOS_EXTENSION pcbe, DWORD DPIndex);
BOOL cbDPLinkTrainingSW(PCBIOS_EXTENSION pcbe, DWORD DPIndex);
BOOL cbDPLinkTrainingSW_CR(PCBIOS_EXTENSION pcbe, DWORD DPIndex);
BOOL cbDPLinkTrainingSW_EQ(PCBIOS_EXTENSION pcbe, DWORD DPIndex);
void cbDPLinkTrainginPreset(PCBIOS_EXTENSION pcbe, DWORD DPIndex);
void cbDPSetupMainLink(PCBIOS_EXTENSION pcbe, DWORD DPIndex);
void cbDPInitSettings(PCBIOS_EXTENSION pcbe, DWORD DPIndex);
void cbDPIRQHandler(PCBIOS_EXTENSION pcbe, DWORD DPIndex);
BOOL cbDPGetTrainingData(PCBIOS_EXTENSION pcbe, 
                            DWORD  DPIndex, 
                            DWORD  LaneStatus[4],
                            DWORD* LaneAlign,
                            DWORD  RequestVoltage[4], 
                            DWORD  RequestPreEmph[4]);
BOOL cbDPSetTrainingData(PCBIOS_EXTENSION pcbe, 
                            DWORD DPIndex, 
                            DWORD RequestVoltage[4], 
                            DWORD RequestPreEmph[4]);
void cbDPTuningSettings(PCBIOS_EXTENSION pcbe, 
                            DWORD DPIndex, 
                            DWORD RequestVoltage, 
                            DWORD RequestPreEmph);
BOOL cbDPI2CWriteDDCBytes(PCBIOS_EXTENSION pcbe, DWORD DPIndex, PAUX_CONTROL_UMA pAUX, PBYTE pBuffer, DWORD Length);
BOOL cbDPI2CReadDDCBytes(PCBIOS_EXTENSION pcbe, DWORD DPIndex, PAUX_CONTROL_UMA pAUX, PBYTE pBuffer, DWORD Length);

void cbHDMISetAVIInfoFrame(PCBIOS_EXTENSION pcbe, ULONG device, ULONG FormatNum);
void cbHDMISetAudioInfoFrame(PCBIOS_EXTENSION pcbe, ULONG device);
BYTE cbHDMIInsertBCHCode(BYTE* input, DWORD length);
ULONG cbSetHDAudioCTSandN(PCBIOS_EXTENSION pcbe, DWORD dwSampleRate, DWORD dwPixelClock);
BOOL cbSetHDAudioSampleRate(PCBIOS_EXTENSION pcbe, DWORD dwSampleRate, DWORD dwPixelClock);
BOOL cbSetHDAudioMaudNaud(PCBIOS_EXTENSION pcbe, DWORD dwSampleRate, DWORD dwPixelClock, DWORD DPIndex);
void cbUpdateHDMIEPHYReg(PCBIOS_EXTENSION pcbe, PGFXTimingTable pTimingTbl);
DWORD cbGetHDMIVICByTargetTiming(PCBIOS_EXTENSION pcbe, DWORD H_Res, DWORD V_Res, RefreshRateInfo RRateInfo);
void cbSetHDAudioConnectStatus(PCBIOS_EXTENSION pcbe, BOOL bEnable);

BOOL cbGetCBIOSCEAInfo(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT PCEA_INFO_CBIOS *ppCEA_Info_CBIOS
);

BOOL cbGetCBIOSCEATimingTable(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo,
    OUT PGFXTimingTable pTimingTbl
);

BOOL cbGetHDMITypeTimingTbl(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl);


//--------------------------TV specialed subfunc--------------------
extern DWORD const TVResolutionNTSC[];
extern DWORD const TV_NTSC_RESOLUTION_NUM;
extern DWORD const TVResolutionPAL[];
extern DWORD const TV_PAL_RESOLUTION_NUM;
extern DWORD const HDTVResolution720P[];
extern DWORD const HDTV720P_RESOLUTION_NUM;
extern DWORD const HDTVSupportResolution[];
extern DWORD const HDTV_RESOLUTION_NUM;
extern HDTVResolutionRR const HDTVResolutionRefreshRate[];
extern DWORD const HDTV_REFRESHRATE_NUM; 

void cbTV1625Reset_UMA(
    PCBIOS_EXTENSION pcbe, 
    IN PI2C_CONTROL_UMA pi2c);
    
CBIOS_STATUS cbInitTVencoder1623(
        PCBIOS_EXTENSION pcbe, 
        IN ULONG device);
CBIOS_STATUS cbInitTVencoder1625(
        PCBIOS_EXTENSION pcbe, 
        IN ULONG device);
BOOL cbFillInTVEncoderRegs(PCBIOS_EXTENSION pcbe,PBYTE pTVTable);
CBIOS_STATUS cbInitInTVEncoder(PCBIOS_EXTENSION pcbe);
void cbDisableInTV( PCBIOS_EXTENSION pcbe );
void cbEndResetInTV( PCBIOS_EXTENSION pcbe );
void cbInTVDACSetting( PCBIOS_EXTENSION pcbe, DWORD dispDev );
void cbEnableInTV( PCBIOS_EXTENSION pcbe, DWORD dispDev );
BOOL cbIsNativeTVTiming(PCBIOS_EXTENSION pcbe, 
                      IN DWORD H_Res, 
                      IN DWORD V_Res, 
                      IN DWORD dispDev);

BOOL cb1625AutoSense(
    PCBIOS_EXTENSION pcbe, 
    OUT BOOL *pbAttached);

BOOL cb1622AutoSense(
    PCBIOS_EXTENSION pcbe, 
    OUT BOOL *pbAttached);
void cbStartResetInTV( PCBIOS_EXTENSION pcbe );
BOOL cbInTVSense(PCBIOS_EXTENSION pcbe,OUT BOOL *pbAttached);

void cbPatchforBypassMode(PCBIOS_EXTENSION pcbe, 
                          IN DWORD H_Res, 
                          IN DWORD V_Res, 
                          IN DWORD dispDev);

#define ALL_DAC_OFF  0xFF 
#define SET_DAC_ACCORDING_TVOutType  0x00
#define SET_DAC_ACCORDING_HDTVOutType 0x01
#define BUFFER_2M    0x20

BYTE cbGetTVDACState(PCBIOS_EXTENSION pcbe);
void cbSetTVDACState(PCBIOS_EXTENSION pcbe, BYTE DACState);

CBIOS_STATUS cbSetTVVContraction(
    PCBIOS_EXTENSION pcbe,
    IN ULONG VContractionLevel
    );

CBIOS_STATUS cbSetTVHContraction(
    PCBIOS_EXTENSION pcbe,
    IN ULONG HContractionLevel
    );

CBIOS_STATUS cbSetTVHContraction_1622A(
    PCBIOS_EXTENSION pcbe,
    IN ULONG HContractionLevel
    );
    
CBIOS_STATUS cbSetTVHContraction_1625(
    PCBIOS_EXTENSION pcbe,
    IN ULONG HContractionLevel
    );


//---------------------------Digital Port-----------------------------
BOOL cbGetDIPortInfo(
        PCBIOS_EXTENSION pcbe, 
        OUT PDigitalPortInfo *ppDIportinfo,
        IN DWORD device 
       );

BOOL cbConfigureDigitalPort(
        PCBIOS_EXTENSION pcbe, 
        IN DWORD device, 
        IN DWORD Operate);
        
CBIOS_STATUS cbInitPad(
        PCBIOS_EXTENSION pcbe, 
        IN DI_TYPE PortType, 
        IN DWORD Operate);

BOOL cbSetDVP0DrivingSelect(
        PCBIOS_EXTENSION pcbe, 
        IN DWORD clk); 

BOOL cbSetDVP1DrivingSelect(
        PCBIOS_EXTENSION pcbe, 
        IN DWORD clk); 
        
CBIOS_STATUS cbSetDIPortSource(
        PCBIOS_EXTENSION pcbe,
        IN DI_TYPE PortType, 
        IN DWORD IGA_Num);

CBIOS_STATUS  CBiosSetActiveDisplayDeviceConfiguration_share (
    PVOID pvcbe, 
    IN DWORD dispDevIGA1,
    IN DWORD dispDevIGA2,
    IN DWORD AffectIGAs);
        
BOOL cbSetDeviceDPA(
            PCBIOS_EXTENSION pcbe,
            IN DWORD device,
            IN DWORD clk);

BOOL cbSetPolarity(
        PCBIOS_EXTENSION pcbe, 
        IN DWORD device, 
        IN BYTE HPolarity, 
        IN BYTE VPolarity);

BOOL  cbInitDigitalPortInfo( 
        PCBIOS_EXTENSION pcbe, 
        IN PDIPortInfo src, 
        IN PDIPortInfo des);

CBIOS_STATUS cbGetTXSubAddr(
        PCBIOS_EXTENSION pcbe, 
        IN LCD_DVI_TX_TYPE TXType, 
        OUT PBYTE subAddr); 

BOOL cbGetDITXtype(
        PCBIOS_EXTENSION pcbe, 
        OUT PBYTE ptxtype,
        IN DWORD device);

BOOL cbGetDIEncodertype(
        PCBIOS_EXTENSION pcbe, 
        OUT PULONG pEncodertype,
        IN DWORD device);    

BOOL cbGetExistTXInfo(PCBIOS_EXTENSION pcbe,
    OUT PDIPortInfo pCBE_DIPort,
    IN PDIPortInfo pVCP_DIPort,
    IN PTXTABLEDATA pTxTbl);

//--------------------------------I2C--------------------------------- 
BOOL cbGetDII2Csetting(
        PCBIOS_EXTENSION pcbe, 
        OUT PI2C_CONTROL_UMA pi2c, 
        IN DWORD device);

BOOL cbCheckHDMITXExist(
        PCBIOS_EXTENSION pcbe, 
        IN HDMI_TX_TYPE TXType, 
        IN PTXTABLEDATA *pTxTbl);

BOOL cbGetDeviceDDCPort(
        PCBIOS_EXTENSION pcbe, 
        OUT PI2C_CONTROL_UMA pi2c, 
        IN DWORD device);

CBIOS_STATUS TV_I2CRead_BYTE_UMA(
    PCBIOS_EXTENSION pcbe,
    IN BYTE RegIndex,
    OUT PBYTE pData
    );

CBIOS_STATUS TV_I2CWRITE_BYTE_UMA(
    PCBIOS_EXTENSION pcbe,
    IN BYTE   RegIndex,
    IN BYTE   RegData
    );

UCHAR
InTV_Read_Byte_UMA(
    PCBIOS_EXTENSION pcbe,
    IN UCHAR   index
    );

VOID
InTV_Write_Byte_UMA(
    PCBIOS_EXTENSION pcbe,
    IN UCHAR   index,
    IN UCHAR   data
    );

VOID
InTV_Write_Bits_UMA(
    PCBIOS_EXTENSION pcbe,
    IN UCHAR   index,
    IN UCHAR   data,
    IN UCHAR   mask
    );

I2C_PORT_TYPE IsI2CGPIO(BYTE I2CPort);

//-------------------General EDID info define
#define EDID1_X_BLOCKSIZE   128
#define EDID2_0_BLOCKSIZE   256

//---------------- MACRO define for CEA extansion block----------------------
#define EDID_CEAEXTENSION_TAG 0x02
#define EDID_CEAEXTENSION_VER3 0x03

BOOL cbIsDevEDIDValid(
    PCBIOS_EXTENSION pcbe, 
    DWORD dev,
    PBYTE pEDIDBuf,
    DWORD bufLen);

VOID cbUpdateAllDevRealEDIDOnDIPort(
    PCBIOS_EXTENSION pcbe, 
    PDigitalPortInfo pDIPort,
    PBYTE pEDIDBuf,
    DWORD bufLen);

BOOL cbGetEDID_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PCBIOS_PARAM_GET_EDID pCBParamGetEdid);

BOOL cbClearEDIDBuf(PCBIOS_EXTENSION pcbe, 
                    DWORD device);

BOOL cbEDIDParser_UMA(PCBIOS_EXTENSION pcbe, 
    IN void* EDIDBuffer, 
    IN ULONG Length,
    OUT CBIOS_EDID_INFO* pEDIDInfo);

BOOL cbEDIDDTDParse(PCBIOS_EXTENSION pcbe, 
    OUT PEDID_DETAILEDTIMING_INFO pCBiosDTDInfo,
    IN  PDETAILEDTIMING pDetailedTimingData);

BOOL cbIsDigitalOrAnalogMonitor(
        PCBIOS_EXTENSION pcbe,
        IN DWORD Device,
        OUT PEDID_MONITOR_TYPE ptype);
        
BOOL cbFilterEDIDEstStdByVESAVPIT(
    PCBIOS_EXTENSION pcbe,
    IN PCBIOS_EDID_INFO pEDID);

BOOL cbIsResolutionExistInEDIDDetailedTiming(
    PCBIOS_EXTENSION pcbe,    
    IN PCBIOS_EDID_INFO pEDID, 
    IN WORD XRes, 
    IN WORD YRes);

BOOL cbUpdateLCD_panel_ID(
     PCBIOS_EXTENSION pcbe, 
     IN CBIOS_EDID_INFO* pEDIDTimingInfo,
     IN DWORD device); 

BOOL cbIsResolutionInEDIDEstStdTiming(
    IN PCBIOS_EDID_INFO pEDID, 
    IN WORD XRes, 
    IN WORD YRes);

BOOL cbIsTimingInEDIDDetailedTiming(
     IN PCBIOS_EDID_INFO pEDID,
     IN DWORD XRes, 
     IN DWORD YRes, 
     IN RefreshRateInfo rRateInfo);

BOOL cbGetMaxResolutionFromEDIDTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PCBIOS_EDID_INFO pEDID,
    OUT PDWORD pxRes, 
    OUT PDWORD pyRes);

BOOL cbIsTimingInEDIDEstStdTiming(PCBIOS_EDID_INFO pEDID, WORD XRes, WORD YRes, WORD rrateX100);

BOOL cbIsHDMIOUIExistInEDID(
    PBYTE pEDIDBuf,
    DWORD bufLen);

void cbHDMISet_AV_Mute(PCBIOS_EXTENSION pcbe, 
     IN I2C_CONTROL_UMA i2c);
     
void cbHDMIClear_AV_Mute(PCBIOS_EXTENSION pcbe, 
     IN I2C_CONTROL_UMA i2c);
     
BOOL cbGetEDIDSVDandDTDTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PCBIOS_EDID_INFO pEDID, 
    IN WORD XRes, 
    IN WORD YRes, 
    IN RefreshRateInfo rRateInfo, 
    OUT PGFXTimingTable pTimingTbl);
    
BOOL cbGetTimingFromEDID(
    PCBIOS_EXTENSION pcbe, 
    IN PCBIOS_EDID_INFO pEDID, 
    IN DWORD H_Res, 
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo, 
    IN BOOL bReduceBlk,
    OUT PGFXTimingTable pTimingTbl);
    
BOOL cbGetClosestEDIDTimingResolution(    
    PCBIOS_EXTENSION pcbe,     
    PCBIOS_EDID_INFO pEDID,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT PDWORD pEDIDTargetHRes,
    OUT PDWORD pEDIDTargetVRes);
    
BOOL cbGetRefreshRateBufferInEDIDTiming(
    PCBIOS_EXTENSION pcbe,
    IN DWORD dispDev,
    PCBIOS_EDID_INFO pEDID,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT PRefreshRateInfo pRRatesInfoBuf,
    IN DWORD BufSize,
    OUT PDWORD pRefreshNum);

BOOL cbIsResolutionExistInCustomizeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res);

BOOL cbAdd59HzModes(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN DWORD BufSize,
    IN BYTE bInterlace,
    OUT PRefreshRateInfo pRRatesInfoBuf,
    OUT PDWORD rrNum);

BOOL cbIsTimingExistInSVD(
    PCBIOS_EXTENSION pcbe, 
    IN PCBIOS_EDID_INFO pEDID,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN DWORD RRate);

BOOL cbIsTimingExistInCEAExt(
    PCBIOS_EXTENSION pcbe, 
    IN PCBIOS_EDID_INFO pEDID,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN DWORD RRate,
    IN DWORD PLL_MRN);
    
BOOL cbIsTimingInCustomizeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo);

BOOL cbGetCustomizeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo,
    OUT PGFXTimingTable pTimingTbl);

BOOL cbGetMaxFitResInCustomizeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD EDIDMaxRes_H,
    IN DWORD EDIDMaxRes_V,
    OUT PDWORD pH_Res,
    OUT PDWORD pV_Res);
    
BOOL cbGetClosestCustomizeTimingResolution(    
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT PDWORD pCusTargetHRes,
    OUT PDWORD pCusTargetVRes);

BOOL cbGetRefreshRateBufferInCustomizeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN DWORD BufSize,
    OUT PDWORD pRefreshNum);

BOOL cbGetMaxTimingFromCustomizeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD XRes, 
    IN DWORD YRes,
    IN RefreshRateInfo rRateInfo, 
    OUT PGFXTimingTable pTimingTbl);

BOOL cbTransCustomizeTiming(
    IN PCustomizeTimingEntity pEntityBufferCur,
    OUT PGFXTimingTable pTimingTbl);
    
BOOL cbGetCustomizeTimingResolution(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev, 
    IN DWORD EDIDMaxRes_H,
    IN DWORD EDIDMaxRes_V,
    OUT DWORD *pResBuf,
    IN DWORD pBufSize,
    OUT PDWORD pResNum);
    
BOOL cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(  
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev, 
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize);

BOOL cbGetMaxTarTimingFromEDIDandCusTiming(  
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev, 
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl);

BOOL cbGetCenterTiming(
    IN DWORD SRC_H_Res,
    IN DWORD SRC_V_Res,
    IN OUT PGFXTimingTable pTargetTimingTbl);
    
BOOL cbGetShiftTiming(
    IN PCBiosViewSizeParams pView,
    IN OUT PGFXTimingTable pTargetTimingTbl);

BOOL cbGetIGAScaleFactor(
    IN PCBIOS_EXTENSION pcbe,
    IN DWORD SRC_H_Res,
    IN DWORD SRC_V_Res, 
    IN DWORD DES_H_Res, 
    IN DWORD DES_V_Res,
    IN BYTE  Interlaced,
    OUT PScaleFactor pScaleFactor);

BOOL cbGetKeepAspectRatioExpTiming(
    IN PCBIOS_EXTENSION pcbe,
    IN DWORD srcH,
    IN DWORD srcV,
    IN OUT PGFXTimingTable pTargetTimingTbl,
    OUT PScaleFactor pScaleFactor);

//---------------------------device timing type-------------------------
BOOL cbGetCRTTypeResolutionsBuffer(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    OUT DWORD *pResBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize);

BOOL cbGetCRTTypeRefreshRatesForResolution(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN DWORD bufSize,
    OUT DWORD *pBufSize);

BOOL cbGetCRTTypeTimingTbl(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl);

BOOL cbGetEDIDResolutionsBuffer(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    OUT DWORD *pResBuf,
    IN  DWORD bufSize,
    IN OUT DWORD *pBufSize);

BOOL cbGetEDIDRefreshRatesForResolution(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize);
    
BOOL cbGetEDIDTimingTbl(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl);

BOOL cbGetVESATimingFilterByEDIDTypeResolutionsBuffer(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    OUT DWORD *pResBuf,
    IN  DWORD bufSize,
    IN OUT DWORD *pBufSize);

BOOL cbGetVESATimingFilterByEDIDTypeRefreshRatesForResolution(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize);

BOOL cbGetVESATimingFilterByEDIDTypeTimingTbl(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl);

BOOL cbGetCVTTiming(PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res, 
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo, 
    IN BOOL  IsReducedBlanking,
    OUT PGFXTimingTable pTimingTbl);

BOOL cbGetGTFTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo,
    IN BOOL  bHmargin,
    IN BOOL  bVmargin,
    OUT PGFXTimingTable pTimingTbl);

BOOL cbGetSTDTiming(
    PCBIOS_EXTENSION pcbe, 
    IN BOOL  bReduceBlk,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN DWORD rRateX100,
    OUT PGFXTimingTable pTimingTbl);

BOOL cbGetRefreshRatesForCRT(
    IN PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev, 
    IN DWORD H_Res, 
    IN DWORD V_Res, 
    IN OUT RefreshRateInfo * pRRatesInfoBuf, 
    IN OUT DWORD *pBufSize);

BOOL cbGetRefreshRatesForDVIorHDMI(
    IN PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev, 
    IN DWORD H_Res, 
    IN DWORD V_Res, 
    IN OUT RefreshRateInfo * pRRatesInfoBuf, 
    IN OUT DWORD *pBufSize);

BOOL cbGetRefreshRatesForDP(
    IN PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev, 
    IN DWORD H_Res, 
    IN DWORD V_Res, 
    IN OUT RefreshRateInfo * pRRatesInfoBuf, 
    IN OUT DWORD *pBufSize);

BOOL cbGetRefreshRatesForLCD(
    IN PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev, 
    IN DWORD H_Res, 
    IN DWORD V_Res, 
    IN OUT RefreshRateInfo * pRRatesInfoBuf, 
    IN OUT DWORD *pBufSize);
    
BOOL cbGetRefreshRatesForDVIorHDMI(
    IN PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev, 
    IN DWORD H_Res, 
    IN DWORD V_Res, 
    IN OUT RefreshRateInfo * pRRatesInfoBuf, 
    IN OUT DWORD *pBufSize);

BOOL cbGetRefreshRatesForTVorHDTV(
    IN PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev, 
    IN DWORD H_Res, 
    IN DWORD V_Res, 
    IN OUT RefreshRateInfo * pRRatesInfoBuf, 
    IN OUT DWORD *pBufSize);

    
//---------------------------MISC function------------------------------
void cbTVLoadVT162X_MV(PCBIOS_EXTENSION pcbe, DWORD iMVTypeNO);

//-------------------------POST related function-----------------------
CBIOS_STATUS cbCBIOSInfoInit(PCBIOS_EXTENSION pcbe, IN UINT32 InitializationEvent);

CBIOS_STATUS cbInitHWSupportdevice(PCBIOS_EXTENSION pcbe);

CBIOS_STATUS cbDIInfoInit(PCBIOS_EXTENSION pcbe);

CBIOS_STATUS CbPostRegInit_UMA(PCBIOS_EXTENSION pcbe, IN BOOL bNeedLoadDefECK);

BOOL cbSearchVBIOSInitTable_UMA(PCBIOS_EXTENSION pcbe,
                           IN BYTE type,
                           IN BYTE index,
                           OUT PBYTE pdata);

VOID cbLoadVBIOSInitTable_UMA(
        PCBIOS_EXTENSION pcbe,
        IN PVBINITTBL pRegTable);
        
VOID cbLoadVBIOSInitBitTable_UMA(PCBIOS_EXTENSION pcbe,
                     IN PVBBitINITTBL pBitRegTable);   
                     
VOID cbLoadDefaultEClk(PCBIOS_EXTENSION pcbe);

VOID cbLoadDefaultVDClk(PCBIOS_EXTENSION pcbe);

VOID cbLoadInitLCDTable(PCBIOS_EXTENSION pcbe);

CBIOS_STATUS cbInitOfTX(PCBIOS_EXTENSION pcbe);

CBIOS_STATUS cbInitOfTVencoder(PCBIOS_EXTENSION pcbe);

VOID cbInitExtRegs(PCBIOS_EXTENSION pcbe);

VOID cbInitSSC(PCBIOS_EXTENSION pcbe);

BOOL cbOnOffSSC(PCBIOS_EXTENSION pcbe, BOOL bOn);

BOOL cbIsSSCAvailable(PCBIOS_EXTENSION pcbe);

BOOL cbIsSSCOnNow(PCBIOS_EXTENSION pcbe);

BOOL cbIsLcd1OnNow(PCBIOS_EXTENSION pcbe);

BOOL cbIsLcd2OnNow(PCBIOS_EXTENSION pcbe);

BOOL cbGetDIWidth(
        PCBIOS_EXTENSION pcbe, 
        OUT PWORD pDIWidth,
        IN DWORD device);

CBIOS_STATUS cbInitTMDS(
        PCBIOS_EXTENSION pcbe, 
        IN DWORD Device);

CBIOS_STATUS cbCheck_CH7305orVT1636(
        PCBIOS_EXTENSION pcbe, 
        INOUT PBYTE ptxtype,
        IN PI2C_CONTROL_UMA pi2c);

CBIOS_STATUS cbInitLVDS(
        PCBIOS_EXTENSION pcbe, 
        IN DWORD Device);  

CBIOS_STATUS cbInitEncoder(
        PCBIOS_EXTENSION pcbe, 
        IN ULONG Device);

VOID cbInitExtRegsBits(PCBIOS_EXTENSION pcbe);

BOOL cbGetDeviceAttachedIGAFromHW(
    PCBIOS_EXTENSION pcbe,
    IN DWORD device,
    OUT PDWORD pIGA);

VOID cbRestorePWMFromVBIOS(PCBIOS_EXTENSION pcbe);

typedef struct _CBIOS_PROC_ADDR
{
    const char *str;
    ULONG      strLen;
    CBIOSPROC  funcPointer;
}CBIOS_PROC_ADDR, *pCBIOS_PROC_ADDR;

//*****************************************************************************
//
// below are old CBIOS sub function Declarations
//
extern CBREGISTER UMA_ModeCommon[];
extern MapTVModeIndex TblMapTVModeIndex[];
BOOL cbGetDeviceDDCStatus (PCBIOS_EXTENSION pcbe, IN DWORD Device);
BOOL cbGetTVI2CInfo(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
VOID cbHWResetEnable_UMA(PCBIOS_EXTENSION pcbe);
VOID cbHWResetDisable_UMA(PCBIOS_EXTENSION pcbe);
VOID cbIGA2HWResetEnable_UMA(PCBIOS_EXTENSION pcbe);
VOID cbIGA2HWResetDisable_UMA(PCBIOS_EXTENSION pcbe);
void cbLoadTable_UMA(PCBIOS_EXTENSION pcbe, CBREGISTER *pRegTable);
void cbLoadTimingOnIGA1_UMA(PCBIOS_EXTENSION pcbe, TIMING_REG_TYPE RegType, WORD Data);
void cbProgramDClk1_UMA(PCBIOS_EXTENSION pcbe, BYTE byClk_MValue, BYTE byClk_RValue, BYTE byClk_NValue);
void cbLoadTimingOnIGA2_UMA(PCBIOS_EXTENSION pcbe, TIMING_REG_TYPE RegType, WORD Data);
void cbProgramDClk2_UMA(PCBIOS_EXTENSION pcbe, BYTE byClk_MValue, BYTE byClk_RValue, BYTE byClk_NValue);
WORD cbGetExpandScalingFactor(WORD Resolution, WORD LCDPanelPhysicalSize, enum _TIMING_REG_TYPE Type);
WORD cbGetDownScalingFactor(WORD Resolution, WORD LCDPanelPhysicalSize, enum _TIMING_REG_TYPE Type);
BOOL I2C_Read_Word_INV (PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
BOOL I2C_Write_Word_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
BOOL I2C_Read_Byte_INV (PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
BOOL I2C_Write_Byte_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
BOOL I2C_Write_Bit_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, BYTE Mask);
BOOL I2C_ByteWrite_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, UCHAR ucData);
BOOL I2C_AckRead_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
BOOL I2C_SetDDC2_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
void I2C_StartService_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
void I2C_StopService_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
BOOL I2C_Write_DDCBus_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);

#define LCD                     0x02
#define TV                      0x04
#define LCD2                    0x08
#define DVI2                    0x10
#define HDTV                    0x08
#define HDMI                    0x200

#define VT3191_ADDR             0x70
#define VT3192_ADDR             0x10
#define NULL_ADDR               0x00
#define VT3193_ADDR             0x08
#define SII164_ADDR             0x70
#define SII168_ADDR             0x70
#define AD9389_ADDR             0x72
#define CH7019_ADDR             0xEA
#define CH7305_ADDR             0xEA
#define CH7009_ADDR             0xEA
#define VT1636_ADDR             0x80
#define SIL9022_ADDR            0x72
#define ITE6610_ADDR            0x98
#define TFP410_ADDR             0x70

// CBIOS POST
void cbChipEnable_UMA(PCBIOS_EXTENSION pcbe);
BOOL cbGetVCPInfo_UMA( 
    IN PBYTE pRomData,
    INOUT PVCPInfo* ppVCPInfo);
void cbUnlockExtIO_UMA(PCBIOS_EXTENSION pcbe);
VOID VBE_4F14_0000_QueryChipInfo_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID VBE_4F14_0100_GetBIOSInfo_csr(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID VBE_4F14_0200_GetMiscInfo_csr(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID VBE_4F14_8303_QuerySysBIOSDisplayDeviceConfig_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID VBE_4F14_000D_GetStartAddressOfFB(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID VBE_4F14_0107_GetTVConfig_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID VBE_4F14_0007_SetTVConfig_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID VBE_4F14_0207_GetSupportedTVType_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID VBE_4F14_0307_ContrastControl_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID VBE_4F14_0407_SaturationControl_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID VBE_4F14_0507_HueControl_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments); 
VOID VBE_4F14_0607_BrightnessControl_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID VBE_4F14_0707_FlickerFilterControl_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID VBE_4F14_0B07_PositionControl_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID VBE_4F14_8107_GetTVHDTVConfigFromSysBIOS_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments);

// CBIOS Utility
// below definition are for I2C busnum to I2C portnum converting
#define MAXI2CBUSNUM 5
enum{
     I2CBUSNULL = 0,
     I2CBUS0,
     I2CBUS1,
     I2CBUS2,
     I2CBUS3,
     I2CBUS4
};

BYTE cbGetBitNumbers(PCBIOS_EXTENSION pcbe, IN DWORD data);
BYTE cbGetCheckSum(BYTE *pBuf, DWORD length);
void I2C_StopService_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
UCHAR 
I2C_Data_Request_INV (PCBIOS_EXTENSION pcbe,
    PI2C_CONTROL_UMA pi2c,
    ULONG   Length,
    ULONG   Flags,
    UCHAR   *pBuffer
    );
UCHAR 
I2C_Data_Update_INV (
    PCBIOS_EXTENSION pcbe,
    PI2C_CONTROL_UMA pi2c,
    ULONG   Length,
    ULONG   Flags,
    UCHAR   *pBuffer
    );
BOOL cbConvert_I2CPortNum_to_I2CBusNum(OUT PBYTE BusNum,IN BYTE portnum);
BOOL cbConvert_I2CBusNum_to_I2CPortNum(IN BYTE BusNum,OUT BYTE *portnum);
ULONG 
cbDDCCI_I2C_Stop_INV(PCBIOS_EXTENSION pcbe, 
    PI2C_CONTROL_UMA pi2c
    );
ULONG 
cbDDCCI_I2C_Null_INV(PCBIOS_EXTENSION pcbe, 
    ULONG Flags, 
    PI2C_CONTROL_UMA pi2c
    );
ULONG 
cbDDCCI_I2C_Read_INV(PCBIOS_EXTENSION pcbe, 
    ULONG Flags, 
    PI2C_CONTROL_UMA pi2c
    );
ULONG 
cbDDCCI_I2C_Write_INV(PCBIOS_EXTENSION pcbe, 
    ULONG Flags, 
    PI2C_CONTROL_UMA pi2c
    );
ULONG 
cbDDCCI_I2C_Enable_INV(PCBIOS_EXTENSION pcbe, 
    PI2C_CONTROL_UMA pi2c);
ULONG 
cbDDCCI_I2C_Disable_INV(PCBIOS_EXTENSION pcbe, 
    PI2C_CONTROL_UMA pi2c);

BOOL I2C_Write_Byte_InVB_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
BOOL I2C_Write_Buf_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, BYTE *pBuf, DWORD len);

BOOL cbGetLCDPanelInfo_UMA(PCBIOS_EXTENSION pcbe, IN DWORD device, OUT PLCD_Info pLCDInfo);
    
// CBIOS Data
BOOL cbIsModeAvailable(PCBIOS_EXTENSION pcbe, IN DWORD dispDev, IN PVESA_INFO pVesaInfo);
DWORD cbFilterOneDevice(PCBIOS_EXTENSION pcbe, IN DWORD dev);
BOOL cbGetSysBiosInfo(PCBIOS_EXTENSION pcbe);
void cbCbiosChipCapsInit(PCBIOS_EXTENSION pcbe);
void cbCbiosInterruptInit(PCBIOS_EXTENSION pcbe);

#define Core_Base_Version       0x09    //CastleRock
#define VBIOS_VERSION_OFFSET    0x87
#define MOBILEBIOS              0x00
#define EMBEDDEDBIOS            0x04
#define DESKTOPBIOS             0x08

VOID cbQueryChipInfo_UMA( PCBIOS_EXTENSION pcbe, PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID cbGetBIOSInfo_UMA(PCBIOS_EXTENSION pcbe, PVIDEO_X86_BIOS_ARGUMENTS biosArguments);
VOID cbgetMiscInfo_UMA(PCBIOS_EXTENSION pcbe, PVIDEO_X86_BIOS_ARGUMENTS biosArguments);

// CBIOS CRT2
CBIOS_STATUS cbSensorCRT2_UMA(PCBIOS_EXTENSION pcbe, OUT BOOL *pbAttached);
BOOL cbIsCRT2SkipMode(PCBIOS_EXTENSION pcbe, IN PVESA_INFO pVesaInfo);
BOOL cbIsCRT2SkipRRate(PCBIOS_EXTENSION pcbe, IN PVESA_INFO pVesaInfo,IN BYTE RRValue);

// CBIOS LCD
WORD cbGetCRTCValueFromLCD12Tbl(PCBIOS_EXTENSION pcbe, PLCDInitTbl12 pLCDTbl, TIMING_REG_TYPE RegType);
BOOL cbGetLCD12InitTbl(PCBIOS_EXTENSION pcbe, PLCDInitTbl12 *ppLCDTbl12);

// CBIOS TV
DWORD cbGetTVLayout(PCBIOS_EXTENSION pcbe, WORD HWLayout);
void cbLimitTVConTypeInLayout(BYTE *pTVConType, WORD TVLayout);
VOID cbLimitTVType(BYTE *pTVType, WORD TVTypeCap);
VOID cbLimitHDTVType(BYTE *pHDTVType, BYTE HDTVTypeCap);

CBIOS_STATUS cbGetContrastRegIndex(
        PCBIOS_EXTENSION pcbe, 
        OUT PBYTE pTVContrastRegIndexTbl,
        IN ULONG TblLen);

VOID cbGetContrastRegIndex_1622A_UMA(
      PCBIOS_EXTENSION pcbe, 
      OUT PBYTE TvRegIndexTbl,
      IN ULONG TblLen);
        
VOID cbGetContrastRegIndex_1625_UMA(
      PCBIOS_EXTENSION pcbe, 
      OUT PBYTE TvRegIndexTbl,
      IN ULONG TblLen);

CBIOS_STATUS cbSetContrastControl_UMA(
    PCBIOS_EXTENSION pcbe,
    IN ULONG contrastlevel);
    
CBIOS_STATUS cbGetMaxContrast_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pMaxCon);

CBIOS_STATUS cbSetSaturationControl_UMA(
    PCBIOS_EXTENSION pcbe, 
    IN ULONG satlevel);

CBIOS_STATUS cbGetSaturationRegIndex(
        PCBIOS_EXTENSION pcbe, 
        OUT PBYTE pTVSatRegIndexTbl,
        IN ULONG TblLen);

VOID cbGetSaturationRegIndex_1622A_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen);

VOID cbGetSaturationRegIndex_1625_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen);

VOID cbGetSaturationRegIndex_InTV_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen);

CBIOS_STATUS cbGetMaxSaturation_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PULONG pMaxSat);

CBIOS_STATUS cbSetHueControl_UMA(
    PCBIOS_EXTENSION pcbe, 
    IN ULONG hueangle);

CBIOS_STATUS cbGetMaxHue_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PULONG pMaxHue);

CBIOS_STATUS cbGetHueRegIndex(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE pTVHueRegIndexTbl,
    IN ULONG TblLen);   

VOID cbGetHueRegIndex_1622A_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen);
    
VOID cbGetHueRegIndex_1625_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen);

CBIOS_STATUS cbSetBrightnessControl_UMA(
    PCBIOS_EXTENSION pcbe, 
    IN ULONG BrightLevel);

VOID cbGetBrightnessRegIndex_1622A_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen);    

VOID cbGetBrightnessRegIndex_1625_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE TvRegIndexTbl,
    IN ULONG TblLen);    

CBIOS_STATUS cbGetBrightnessRegIndex(
    PCBIOS_EXTENSION pcbe, 
    OUT PBYTE pTVBrightnessRegIndexTbl,
    IN ULONG TblLen);    
        
CBIOS_STATUS cbGetMaxBrightness_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PULONG pMaxBrightness);

CBIOS_STATUS cbEnableNormFlickerFilter_UMA(
    PCBIOS_EXTENSION pcbe);
    
CBIOS_STATUS cbEnableAdaptiveFlickerFilter_UMA(
    PCBIOS_EXTENSION pcbe);
    
CBIOS_STATUS cbSetPositionControl_UMA(
    PCBIOS_EXTENSION pcbe,
    IN ULONG HPositionAdj, 
    IN ULONG VPositionAdj);
    
CBIOS_STATUS cbGetPositionControl_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPositionAdj, 
    OUT PULONG pVPositionAdj);

CBIOS_STATUS cbGetTVPositionMaxRange_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPositionMax,
    OUT PULONG pVPositionMax);

VOID cbGetTVPositionMaxRange_1622A_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPositionMax, 
    OUT PULONG pVPositionMax);

VOID cbGetTVPositionMaxRange_1625_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPositionMax, 
    OUT PULONG pVPositionMax);

CBIOS_STATUS cbGetTVCurPosition_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPosition,
    OUT PULONG pVPosition);

VOID cbGetTVCurPosition_1622A_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPosition, 
    OUT PULONG pVPosition);
    
VOID cbGetTVCurPosition_1625_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPosition, 
    OUT PULONG pVPosition);

VOID cbGetTVCurPosition_InTV_UMA(
    PCBIOS_EXTENSION pcbe,
    OUT PULONG pHPosition, 
    OUT PULONG pVPosition);

CBIOS_STATUS cbSetTVPosition_1622A_UMA(
    PCBIOS_EXTENSION pcbe, 
    IN ULONG HPositionAdj, 
    IN ULONG VPositionAdj);

CBIOS_STATUS cbSetTVPosition_1625_UMA(
    PCBIOS_EXTENSION pcbe, 
    IN ULONG HPositionAdj, 
    IN ULONG VPositionAdj);

CBIOS_STATUS cbSetTVPosition_InTV_UMA(
    PCBIOS_EXTENSION pcbe, 
    IN ULONG HPositionAdj, 
    IN ULONG VPositionAdj);

LONG SinHueLevel_UMA(IN ULONG level);

LONG CosHueLevel_UMA(IN ULONG level);


CBIOS_STATUS cbUpdateTVparameter(PCBIOS_EXTENSION pcbe);

BOOL cbIsEDIDCKMSame(PCBIOS_EXTENSION pcbe, DWORD Device, OUT PCBIOS_PARAM_GET_EDID pCBParamGetEdid);

void cbControlVDDSignalForEDP(PCBIOS_EXTENSION pcbe, BOOL isTurnOn);

void cbControlBLSignalForEDP(PCBIOS_EXTENSION pcbe, BOOL isTurnOn);

// CBIOS Device
void cbLoadTimingOnIGA1_UMA(PCBIOS_EXTENSION pcbe, TIMING_REG_TYPE RegType, WORD Data);
void cbLoadPixelTimingOnIGA1_UMA(PCBIOS_EXTENSION pcbe, TIMING_REG_TYPE RegType, WORD Data);
void cbLoadTimingOnIGA2_UMA(PCBIOS_EXTENSION pcbe, TIMING_REG_TYPE RegType, WORD Data);
VOID cbUpdateHWDispDeviceBits(IN PCBIOS_EXTENSION pcbe);
ULONG ConvertRRValuetoRRIndex_CSR(ULONG Frequency);
ULONG cbRoundDown(
    IN ULONG dividend, 
    IN ULONG divisor);
DWORD cbGetLowestBitPos(IN DWORD x);

ULONG cbGetVsyncWidth(
    IN ULONG XRes,
    IN ULONG YRes);

BOOL cbIsAlwaysOnDevice(PCBIOS_EXTENSION pcbe, DWORD device);
BOOL cbIsDeviceCombinationValid(IN DWORD device);
DWORD cbGetPrimaryDevice(IN DWORD device);
BOOL cbTranslateWordDefineToS3Define(PCBIOS_EXTENSION pcbe, 
                                     IN OUT DWORD *pDevice);

BOOL cbTranslateS3DefineToWordDefine(PCBIOS_EXTENSION pcbe, 
                                     IN OUT DWORD *pDevice);

BOOL cbDIPortHPDIntProcess(
    PCBIOS_EXTENSION pcbe,
    IN PDigitalPortInfo PDIPort);

VOID cbGetUnsupportedDevCombBuf(
    PCBIOS_EXTENSION pcbe,
    OUT DWORD *pDevBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize);

VOID cbGetHotKeySwitchDevCombBuf(
    IN PCBIOS_EXTENSION pcbe,
    OUT DWORD *pDevBuf,
    IN DWORD bufSize,
    OUT DWORD *pBufSize);

// HDMI function required 
void cbAD9389HDMIChangeSignal(PVOID pvcbe, ULONG ulHDMISignal);
void cbAD9389AudioEnable(PVOID pvcbe, BOOL bAudioEnabled);
#if !LINUX_PLATFORM
BOOL cbAD9389VesaModeFilter(PCBIOS_EXTENSION pcbe,IN DWORD dispDev, WORD XRes, WORD YRes, WORD RRate);
#endif
BOOL cbHDMITxDeviceDetect(PCBIOS_EXTENSION pcbe, IN UINT32 detectDev, OUT BOOL *pbAttached);
BOOL cbIsDeviceConnectOnAD9389(PCBIOS_EXTENSION pcbe, PDigitalPortInfo PDIPort);
BOOL cbGetFourBlockEDID(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, PDigitalPortInfo PDIPort, ULONG flags, PCBIOS_PARAM_GET_EDID pCBParamGetEdid);
void cbLoadAD9389BInitTbl(PCBIOS_EXTENSION pcbe, BYTE I2CPort, BYTE I2CAddr);
BOOL cbHDMII2CReadByte(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
BOOL cbHDMII2CReadBytes(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, PBYTE EDIDBuffer, DWORD length);
BOOL cbHDMII2CReadDDCBytes(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, PBYTE EDIDBuffer, DWORD length);
BOOL cbHDMII2CWriteByte(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
BOOL cbHDMII2CWriteDDCBytes(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, PBYTE DataBuffer, DWORD Length);

BOOL cbHDMII2CWriteDDC(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c);
BOOL cbHDMII2CStatus(PCBIOS_EXTENSION pcbe, DWORD checkbits, BOOL condition);

// Vblank related functions
BOOL cbIsInVBlank(PCBIOS_EXTENSION pcbe, DWORD iga_num);
void cbWaitVBlank(PCBIOS_EXTENSION pcbe, DWORD iga_num);

//******Call Back function *********
//******* these functions must be implemented outside *******

//******** time delay functions ********************************
#define cbDelayMicroSeconds     pcbe->_cbDelayMicroSeconds
#define cbSleepMicroSeconds     pcbe->_cbSleepMicroSeconds
//******** Debug Print functions *******************************
#if DBG
    #define cbDbgPrint          pcbe->_cbDbgPrint
    void cbDbgPrintNull(IN ULONG DebugPrintLevel, IN LPSTR DebugMessage, ...);
#else /*else DBG*/
    #define cbDbgPrint
#endif

void cbDelayNull(IN int time);
void cbSleepNull(IN int time);

//******** general VGA reg access functions ********************
//use MMIO to access VGA registers under NT platforms
//RegisterPort: register port address offset, based on MMIO Base address.
//general VGA reg access function, can be mmio or portio function
//for mmio access: the pcbe->VGAMmioBase has VGA mmio base
//for portio: the pcbe->VGAMmioBase must be 0
#define cbReadUchar             pcbe->_cbReadUchar
#define cbWriteUchar            pcbe->_cbWriteUchar
#define cbReadUshort            pcbe->_cbReadUshort
#define cbWriteUshort           pcbe->_cbWriteUshort

#define efiReadUchar             pcbe->_cbReadUchar
#define efiWriteUchar            pcbe->_cbWriteUchar
#define efiReadUshort           pcbe->_cbReadUshort
#define efiWriteUshort          pcbe->_cbWriteUshort

#if EFI_CBIOS
#define ReadUchar(addr) efiReadUchar(pcbe->VIA_GFX_PRIVATE_DATA, (ULONG)addr)
#define WriteUchar(addr, data) efiWriteUchar(pcbe->VIA_GFX_PRIVATE_DATA, (ULONG)addr, data)

#define ReadUshort(addr) efiReadUshort(pcbe->VIA_GFX_PRIVATE_DATA, (ULONG)addr)
#define WriteUshort(addr, data) efiWriteUshort(pcbe->VIA_GFX_PRIVATE_DATA, (ULONG)addr, data)
#else
#define ReadUchar(addr) cbReadUchar(addr)
#define WriteUchar(addr, data) cbWriteUchar(addr, data)

#define ReadUshort(addr) cbReadUshort(addr)
#define WriteUshort(addr, data) cbWriteUshort(addr, data)
#endif



#if !LINUX_PLATFORM
#define cbReadMMIOUlong          pcbe->_cbReadMMIOUlong
#define cbWriteMMIOUlong         pcbe->_cbWriteMMIOUlong
#define efiReadMMIOUlong         pcbe->_cbReadMMIOUlong
#define efiWriteMMIOUlong        pcbe->_cbWriteMMIOUlong
#else
DWORD cbReadMMIOUlong(PUCHAR RegOffset);
void  cbWriteMMIOUlong(PUCHAR RegOffset, DWORD data);
#endif

#if EFI_CBIOS
#define ReadMMIOUlong(addr) efiReadMMIOUlong(pcbe->VIA_GFX_PRIVATE_DATA, (ULONG)addr)
#define WriteMMIOUlong(addr, data) efiWriteMMIOUlong(pcbe->VIA_GFX_PRIVATE_DATA, (ULONG)addr, data)
#else
#define ReadMMIOUlong(addr) cbReadMMIOUlong(addr)
#define WriteMMIOUlong(addr, data) cbWriteMMIOUlong(addr, data)
#endif


#define InterruptControlReg     0x200

void  cbWriteMMIOUlongBits(PCBIOS_EXTENSION pcbe, DWORD MMIOIndex, DWORD mask, DWORD data);
#endif // _CBIOS_SUB_FUNC_NEW_H_


