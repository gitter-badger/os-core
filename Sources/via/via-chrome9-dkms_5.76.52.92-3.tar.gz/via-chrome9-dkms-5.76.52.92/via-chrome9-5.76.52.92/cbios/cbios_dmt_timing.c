/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * All DMT, establised timing, CEA861 timing refer to
 * xorg-server-1.12.2\hw\xfree86\modes\xf86EdidModes.c
 */

#include "cbios_sub_func.h"
#include "cbios_vesa_vpit.h"

static VESA_VPIT Mode640x480_RefreshRate_Buf[] = 
            {{DCLK_25_2M,   60, ATT_NHS+ATT_NVS,               800,  656,  752,  525,  490,  492},   // by CEA
             {DCLK_31_5M,   72, ATT_NHS+ATT_NVS,               832,  664,  704,  520,  489,  492},   // by CEA
             {DCLK_31_5M,   75, ATT_NHS+ATT_NVS,               840,  656,  720,  500,  481,  484}};  // by CEA
#define Mode640x480_RefreshRateNUM  (sizeof(Mode640x480_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT Mode800x600_RefreshRate_Buf[] = 
            {{DCLK_36M,     56, ATT_PHS+ATT_PVS,               1024,  824, 896,  625,  601,  603},   // by DMT
             {DCLK_40M,     60, ATT_PHS+ATT_PVS,               1056,  840, 968,  628,  601,  605},   // by DMT
             {DCLK_50M,     72, ATT_PHS+ATT_PVS,               1040,  856, 976,  666,  637,  643},   // by DMT
             {DCLK_49_5M,   75, ATT_PHS+ATT_PVS,               1056,  816, 896,  625,  601,  604}};  // by DMT
#define Mode800x600_RefreshRateNUM  (sizeof(Mode800x600_RefreshRate_Buf) / sizeof(VESA_VPIT))
 
static VESA_VPIT Mode1024x768_RefreshRate_Buf[] = 
            {{DCLK_65M,     60, ATT_NHS+ATT_NVS,               1344, 1048, 1184,  806,  771,  777},   // by DMT
             {DCLK_75M,     70, ATT_NHS+ATT_NVS,               1328, 1048, 1184,  806,  771,  777},   // by DMT
             {DCLK_78_75M,  75, ATT_PHS+ATT_PVS,               1312, 1040, 1136,  800,  769,  772}};  // by DMT
#define Mode1024x768_RefreshRateNUM  (sizeof(Mode1024x768_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT Mode1280x1024_RefreshRate_Buf[] = 
            {{DCLK_135M,    75, ATT_PHS+ATT_PVS,               1688, 1296, 1440, 1066, 1025, 1028}};  // by DMT
#define Mode1280x1024_RefreshRateNUM  (sizeof(Mode1280x1024_RefreshRate_Buf) / sizeof(VESA_VPIT)) 


//-----------------------------------------------------------------------
// VESA DMT timing table used for EDID established timing block (only for VESA standard)
//      1. 640x480  @ 60Hz  VGA
//      2. 640x480  @ 72Hz  VESA
//      3. 640x480  @ 75Hz  VESA
//      4. 800x600  @ 56Hz  VESA
//      5. 800x600  @ 60Hz  VESA
//      6. 800x600  @ 72Hz  VESA
//      7. 800x600  @ 75Hz  VESA
//      8. 1024x768 @ 60Hz  VESA
//      9. 1024x768 @ 70Hz  VESA
//     10. 1024x768 @ 75Hz  VESA
//     11. 1280x1024 @ 75Hz VESA
//----------------------------------------------------------------------
VESA_INFO_CBIOS VESA_DMT_TABLE[CBIOS_DMT_MODESUPPORT_NUM] =  
               {{{ 640,  480, 0x101, 0x111, 0x112, Mode640x480_RefreshRateNUM},   Mode640x480_RefreshRate_Buf},
                {{ 800,  600, 0x103, 0x114, 0x115, Mode800x600_RefreshRateNUM},   Mode800x600_RefreshRate_Buf},
                {{1024,  768, 0x105, 0x117, 0x118, Mode1024x768_RefreshRateNUM},  Mode1024x768_RefreshRate_Buf},
                {{1280, 1024, 0x107, 0x11A, 0x11B, Mode1280x1024_RefreshRateNUM}, Mode1280x1024_RefreshRate_Buf}};

//----------------------------------------------------------------------
// below table is for 409 and later PLL
//----------------------------------------------------------------------
static VESA_VPIT Mode640x480_RefreshRate_Buf_409[] = 
            {{DCLK_25_2M_409,   60, ATT_NHS+ATT_NVS,               800,  656,  752,  525,  490,  492},   // by CEA
             {DCLK_31_5M_409,   72, ATT_NHS+ATT_NVS,               832,  664,  704,  520,  489,  492},   // by CEA
             {DCLK_31_5M_409,   75, ATT_NHS+ATT_NVS,               840,  656,  720,  500,  481,  484}};  // by CEA
#define Mode640x480_RefreshRateNUM_409  (sizeof(Mode640x480_RefreshRate_Buf_409) / sizeof(VESA_VPIT))

static VESA_VPIT Mode800x600_RefreshRate_Buf_409[] = 
            {{DCLK_36M_409,     56, ATT_PHS+ATT_PVS,               1024,  824, 896,  625,  601,  603},   // by DMT
             {DCLK_40M_409,     60, ATT_PHS+ATT_PVS,               1056,  840, 968,  628,  601,  605},   // by DMT
             {DCLK_50M_409,     72, ATT_PHS+ATT_PVS,               1040,  856, 976,  666,  637,  643},   // by DMT
             {DCLK_49_5M_409,   75, ATT_PHS+ATT_PVS,               1056,  816, 896,  625,  601,  604}};  // by DMT
#define Mode800x600_RefreshRateNUM_409  (sizeof(Mode800x600_RefreshRate_Buf_409) / sizeof(VESA_VPIT))
 
static VESA_VPIT Mode1024x768_RefreshRate_Buf_409[] = 
            {{DCLK_65M_409,     60, ATT_NHS+ATT_NVS,               1344, 1048, 1184,  806,  771,  777},   // by DMT
             {DCLK_75M_409,     70, ATT_NHS+ATT_NVS,               1328, 1048, 1184,  806,  771,  777},   // by DMT
             {DCLK_78_75M_409,  75, ATT_PHS+ATT_PVS,               1312, 1040, 1136,  800,  769,  772}};  // by DMT
#define Mode1024x768_RefreshRateNUM_409  (sizeof(Mode1024x768_RefreshRate_Buf_409) / sizeof(VESA_VPIT))

static VESA_VPIT Mode1280x1024_RefreshRate_Buf_409[] = 
            {{DCLK_135M_409,    75, ATT_PHS+ATT_PVS,               1688, 1296, 1440, 1066, 1025, 1028}};  // by DMT
#define Mode1280x1024_RefreshRateNUM_409  (sizeof(Mode1280x1024_RefreshRate_Buf_409) / sizeof(VESA_VPIT)) 


//-----------------------------------------------------------------------
// VESA DMT timing table used for EDID established timing block (only for VESA standard)
//      1. 640x480  @ 60Hz  VGA
//      2. 640x480  @ 72Hz  VESA
//      3. 640x480  @ 75Hz  VESA
//      4. 800x600  @ 56Hz  VESA
//      5. 800x600  @ 60Hz  VESA
//      6. 800x600  @ 72Hz  VESA
//      7. 800x600  @ 75Hz  VESA
//      8. 1024x768 @ 60Hz  VESA
//      9. 1024x768 @ 70Hz  VESA
//     10. 1024x768 @ 75Hz  VESA
//     11. 1280x1024 @ 75Hz VESA
//----------------------------------------------------------------------
VESA_INFO_CBIOS VESA_DMT_TABLE_409[CBIOS_DMT_MODESUPPORT_NUM] =  
               {{{ 640,  480, 0x101, 0x111, 0x112, Mode640x480_RefreshRateNUM_409},   Mode640x480_RefreshRate_Buf_409},
                {{ 800,  600, 0x103, 0x114, 0x115, Mode800x600_RefreshRateNUM_409},   Mode800x600_RefreshRate_Buf_409},
                {{1024,  768, 0x105, 0x117, 0x118, Mode1024x768_RefreshRateNUM_409},  Mode1024x768_RefreshRate_Buf_409},
                {{1280, 1024, 0x107, 0x11A, 0x11B, Mode1280x1024_RefreshRateNUM_409}, Mode1280x1024_RefreshRate_Buf_409}};

