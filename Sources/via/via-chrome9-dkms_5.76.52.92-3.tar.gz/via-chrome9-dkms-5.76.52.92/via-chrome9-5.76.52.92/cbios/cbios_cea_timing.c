/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * CEA 861 timing refer to
 * xorg-server-1.12.2/hw/xfree86/modes/xf86EdidModes.c
 *
*/
#include "cbios_cea_timing.h"
#include "cbios_sub_func.h"
#include "cbios_vesa_vpit.h"

// CEA 861 support resolution table
const DWORD CEA861_FormatResTbl[CEA861_FORMAT_RES_NUM]=
{
    640, 480,             
    720, 480,
    720, 576,
    1280, 720,
    1920, 1080,
};

// CEA_861 supported format table 
const CEA861_FORMAT_RES  CEA861_FormatTbl[CEA861_FORMAT_NUM] =
{                                         
    //ID Code H_Res   V_Res  Refresh Rate  Inter/Prog
    {   1,     640,     480,     6000,       PROGRESSIVE  },
    {   2,     720,     480,     6000,       PROGRESSIVE  },
    {   3,     720,     480,     6000,       PROGRESSIVE  },
    {   4,    1280,     720,     6000,       PROGRESSIVE  },
    {   5,    1920,    1080,     6000,        INTERLACE   },
    {   6,     720,     480,     6000,        INTERLACE   },
    {   7,     720,     480,     6000,        INTERLACE   },
    {   8,     720,     240,     6000,       PROGRESSIVE  },
    {   9,     720,     240,     6000,       PROGRESSIVE  },
    {  10,     2880,    480,     6000,        INTERLACE   },
    {  11,     2880,    480,     6000,        INTERLACE   },
    {  12,     2880,    240,     6000,       PROGRESSIVE  },
    {  13,     2880,    240,     6000,       PROGRESSIVE  },
    {  14,     1440,    480,     6000,       PROGRESSIVE  },    // format 14, 15 
    {  15,     1440,    480,     6000,       PROGRESSIVE  },    // we use 1440/2 = 720pixel/line format
    {  16,    1920,    1080,     6000,       PROGRESSIVE  },
    {  17,     720,     576,     5000,       PROGRESSIVE  },
    {  18,     720,     576,     5000,       PROGRESSIVE  },
    {  19,    1280,     720,     5000,       PROGRESSIVE  },
    {  20,    1920,    1080,     5000,        INTERLACE   },
    {  21,     720,     576,     5000,        INTERLACE   },
    {  22,     720,     576,     5000,        INTERLACE   },
    {  23,     720,     288,     5000,       PROGRESSIVE  },
    {  24,     720,     288,     5000,       PROGRESSIVE  },
    {  25,     2880,    576,     5000,        INTERLACE   },
    {  26,     2880,    576,     5000,        INTERLACE   },
    {  27,     2880,    288,     5000,       PROGRESSIVE  },
    {  28,     2880,    288,     5000,       PROGRESSIVE  },
    {  29,     1440,    576,     5000,       PROGRESSIVE  },    // format 29, 30 
    {  30,     1440,    576,     5000,       PROGRESSIVE  },    // we use 1440/2 = 720pixel/line format
    {  31,    1920,    1080,     5000,       PROGRESSIVE  },
    {  32,    1920,    1080,     2400,       PROGRESSIVE  },    
    {  33,    1920,    1080,     2500,       PROGRESSIVE  },    
    {  34,    1920,    1080,     3000,       PROGRESSIVE  },
    {  35,     2880,    480,     6000,       PROGRESSIVE  },
    {  36,     2880,    480,     6000,       PROGRESSIVE  },
    {  37,     2880,    576,     5000,       PROGRESSIVE  },
    {  38,     2880,    576,     5000,       PROGRESSIVE  },
    {  39,    1920,    1080,     5000,        INTERLACE   },
    {  40,    1920,    1080,    10000,        INTERLACE   },
    {  41,    1280,     720,    10000,       PROGRESSIVE  },
    {  42,     720,     576,    10000,       PROGRESSIVE  },
    {  43,     720,     576,    10000,       PROGRESSIVE  },
    {  44,     720,     576,    10000,        INTERLACE   },
    {  45,     720,     576,    10000,        INTERLACE   },
    {  46,    1920,    1080,    12000,        INTERLACE   },
    {  47,    1280,     720,    12000,       PROGRESSIVE  },
    {  48,     720,     480,    12000,       PROGRESSIVE  },
    {  49,     720,     480,    12000,       PROGRESSIVE  },
    {  50,     720,     480,    12000,        INTERLACE   },
    {  51,     720,     480,    12000,        INTERLACE   },
    {  52,     720,     576,    20000,       PROGRESSIVE  },
    {  53,     720,     576,    20000,       PROGRESSIVE  },
    {  54,     720,     576,    20000,        INTERLACE   },
    {  55,     720,     576,    20000,        INTERLACE   },
    {  56,     720,     480,    24000,       PROGRESSIVE  },
    {  57,     720,     480,    24000,       PROGRESSIVE  },
    {  58,     720,     480,    24000,        INTERLACE   },
    {  59,     720,     480,    24000,        INTERLACE   },
};

const WORD CEA_DUPLICATED_MODE[] =
{
     6,  7,  8,  9, 10,
    11, 12, 13, 14, 15,
    21, 22, 23, 24, 25,
    26, 27, 28, 29, 30,
    35, 36, 37, 38, 44,
    45, 50, 51, 54, 55,
    58, 59
};
const DWORD CEA_DUPLICATED_MODE_NUM = ( sizeof(CEA_DUPLICATED_MODE) / sizeof(WORD) );

//******************************************************************************
// according to CEA861,
//    For 60Hz formats, displays respond automatically to either 60Hz or 59.94 
// Hz. 480P format are typically 59.94Hz, and the HDTV formats are typically 60Hz 
// so our CBIOS will just support 1, refresh rate for each format
//******************************************************************************

// timing table for CEA 861 format 
CEA_861_Timing_Tbl CEA861_FormatTimingTbl[CEA861_FORMAT_NUM] = {
    // Format 1 640x480P @ 60Hz 4:3
    {    1,                                   // Video ID Code 
         6000,                                // RefreshRate
         25200000,                            // HW PLL SEED
         DCLK_25_2M,                          // 353 PLL
         ATT_NHS,                             // H Sync Polarity
         ATT_NVS,                             // V Sync Polarity  
         CBIOS_RATIO_4_3,                           // Format Aspect Ratio
         800,                                 // HTotal     
         640,                                 // HDisEnd    
         640,                                 // HBlankStart    
         800 ,                                // HBlankEnd      
         656,                                 // HSyncStart 
         752,                                 // HSyncEnd   
         525,                                 // VTotal     
         480,                                 // VDisEnd    
         480,                                 // VBlankStart    
         525,                                 // VBlankEnd      
         0,                                   // VSyncOffset (in pixel clock cycle)
         490,                                 // VSyncStart 
         492,                                 // VSyncEnd   
         PROGRESSIVE                          // Interlace / Progressive 
         
    },
    // Format 2 720x480P @ 59.94Hz 4:3
    {
         2,                                   // Video ID Code 
         6000,                                // RefreshRate
         27000000,                            // HW PLL SEED
         DCLK_27M,                            // 353 PLL
         ATT_NHS,                             // H Sync Polarity
         ATT_NVS,                             // V Sync Polarity  
         CBIOS_RATIO_4_3,                           // Format Aspect Ratio
         858,                                 // HTotal     
         720,                                 // HDisEnd    
         720,                                 // HBlankStart    
         858,                                 // HBlankEnd      
         736,                                 // HSyncStart 
         798,                                 // HSyncEnd   
         525,                                 // VTotal     
         480,                                 // VDisEnd    
         480,                                 // VBlankStart    
         525,                                 // VBlankEnd      
         0,                                   // VSyncOffset (in pixel clock cycle)
         489,                                 // VSyncStart 
         495,                                 // VSyncEnd 
         PROGRESSIVE                          // Interlace / Progressive 
    },            
    // Format 3 720x480P @ 59.94Hz 16:9
    {
         3,                                   // Video ID Code 
         6000,                                // RefreshRate
         27000000,                            // HW PLL SEED
         DCLK_27M,                            // 353 PLL
         ATT_NHS,                             // H Sync Polarity
         ATT_NVS,                             // V Sync Polarity
         CBIOS_RATIO_16_9,                          // Format Aspect Ratio
         858,                                 // HTotal     
         720,                                 // HDisEnd    
         720,                                 // HBlankStart    
         858,                                 // HBlankEnd      
         736,                                 // HSyncStart 
         798,                                 // HSyncEnd   
         525,                                 // VTotal     
         480,                                 // VDisEnd    
         480,                                 // VBlankStart    
         525,                                 // VBlankEnd      
         0,                                   // VSyncOffset (in pixel clock cycle)
         489,                                 // VSyncStart 
         495,                                 // VSyncEnd 
         PROGRESSIVE                          // Interlace / Progressive 
    },            
    // Format 4 1280x720P @ 60Hz 16:9
    {
         4,                                  // Video ID Code 
         6000,                               // RefreshRate
         74270000,                           // HW PLL SEED
         DCLK_74_27M,                        // 353 PLL
         ATT_PHS,                            // H Sync Polarity
         ATT_PVS,                            // V Sync Polarity 
         CBIOS_RATIO_16_9,                         // Format Aspect Ratio
         1650,                               // HTotal     
         1280,                               // HDisEnd    
         1280,                               // HBlankStart    
         1650,                               // HBlankEnd      
         1390,                               // HSyncStart 
         1430,                               // HSyncEnd   
         750,                                // VTotal     
         720,                                // VDisEnd    
         720,                                // VBlankStart    
         750,                                // VBlankEnd      
         0,                                  // VSyncOffset (in pixel clock cycle)
         725,                                // VSyncStart 
         730,                                // VSyncEnd 
         PROGRESSIVE                         // Interlace / Progressive 
    },
    // Format 5 1920x1080I @ 60Hz 16:9
    {
         5,                                  // Video ID Code 
         6000,                               // RefreshRate
         74270000,                           // HW PLL SEED
         DCLK_74_27M,                        // 353 PLL
         ATT_PHS,                            // H Sync Polarity
         ATT_PVS,                            // V Sync Polarity 
         CBIOS_RATIO_16_9,                         // Format Aspect Ratio
         2200,                               // HTotal     
         1920,                               // HDisEnd    
         1920,                               // HBlankStart    
         2200,                               // HBlankEnd      
         2008,                               // HSyncStart 
         2052,                               // HSyncEnd   
         562,                                // VTotal     
         540,                                // VDisEnd    
         540,                                // VBlankStart    
         562,                                // VBlankEnd      
         1100,                               // VSyncOffset (in pixel clock cycle)
         542,                                // VSyncStart 
         547,                                // VSyncEnd 
         INTERLACE                           // Interlace / Progressive 
    },
    // Format 6 720(1440)x480I @ 59.94Hz 4:3
    {
         6,                                 // Video ID Code 
         6000,                              // RefreshRate
         27000000,                          // HW PLL SEED 
         DCLK_27M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         1716,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1716,                              // HBlankEnd      
         1478,                              // HSyncStart 
         1602,                              // HSyncEnd   
         262,                               // VTotal     
         240,                               // VDisEnd    
         240,                               // VBlankStart    
         262,                               // VBlankEnd      
         22,                                // VSyncOffset (in pixel clock cycle)
         244,                               // VSyncStart 
         247,                               // VSyncEnd 
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 7 720(1440)x480I @ 59.94Hz 16:9
    {
         7,                                 // Video ID Code 
         6000,                              // RefreshRate
         27000000,                          // HW PLL SEED
         DCLK_27M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity 
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         1716,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1716,                              // HBlankEnd      
         1478,                              // HSyncStart 
         1602,                              // HSyncEnd   
         262,                               // VTotal     
         240,                               // VDisEnd    
         240,                               // VBlankStart    
         262,                               // VBlankEnd      
         22,                                // VSyncOffset (in pixel clock cycle)
         244,                               // VSyncStart 
         247,                               // VSyncEnd 
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 8 720(1440)x240P @ 60Hz 4:3 (mode 1)
    {
         8,                                 // Video ID Code 
         6000,                              // RefreshRate
         27000000,                          // HW PLL SEED
         DCLK_27M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity 
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         1716,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1716,                              // HBlankEnd      
         1478,                              // HSyncStart 
         1602,                              // HSyncEnd   
         262,                               // VTotal     
         240,                               // VDisEnd    
         240,                               // VBlankStart    
         262,                               // VBlankEnd      
         0,                                 // VSyncOffset (in pixel clock cycle)
         244,                               // VSyncStart 
         247,                               // VSyncEnd 
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 9 720(1440)x240P @ 60Hz 16:9 (mode 1)
    {
         9,                                 // Video ID Code 
         6000,                              // RefreshRate
         27000000,                          // HW PLL SEED
         DCLK_27M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity 
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         1716,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1716,                              // HBlankEnd      
         1478,                              // HSyncStart 
         1602,                              // HSyncEnd   
         262,                               // VTotal     
         240,                               // VDisEnd    
         240,                               // VBlankStart    
         262,                               // VBlankEnd      
         0,                                 // VSyncOffset (in pixel clock cycle)
         244,                               // VSyncStart 
         247,                               // VSyncEnd 
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 10 2880x480I @ 59.94Hz 4:3 
    {
         10,                                // Video ID Code 
         5994,                              // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity 
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         3432,                              // HTotal     
         2880,                              // HDisEnd    
         2880,                              // HBlankStart    
         3432,                              // HBlankEnd      
         2956,                              // HSyncStart 
         3204,                              // HSyncEnd   
         262,                               // VTotal     
         240,                               // VDisEnd    
         240,                               // VBlankStart    
         262,                               // VBlankEnd      
         22,                                // VSyncOffset (in pixel clock cycle)
         244,                               // VSyncStart 
         247,                               // VSyncEnd
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 11 2880x480I @ 59.94Hz 16:9
    {
         11,                                // Video ID Code 
         5994,                              // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         3432,                              // HTotal     
         2880,                              // HDisEnd    
         2880,                              // HBlankStart    
         3432,                              // HBlankEnd      
         2956,                              // HSyncStart 
         3204,                              // HSyncEnd   
         262,                               // VTotal     
         240,                               // VDisEnd    
         240,                               // VBlankStart    
         262,                               // VBlankEnd      
         22,                                // VSyncOffset (in pixel clock cycle)
         244,                               // VSyncStart 
         247,                               // VSyncEnd 
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 12 2880x240P @ 60Hz 4:3 (mode 1)
    {
         12,                                // Video ID Code 
         6000,                              // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity 
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         3432,                              // HTotal     
         2880,                              // HDisEnd    
         2880,                              // HBlankStart    
         3432,                              // HBlankEnd      
         2956,                              // HSyncStart 
         3204,                              // HSyncEnd   
         262,                               // VTotal     
         240,                               // VDisEnd    
         240,                               // VBlankStart    
         262,                               // VBlankEnd      
         0,                                 // VSyncOffset (in pixel clock cycle)
         244,                               // VSyncStart 
         247,                               // VSyncEnd 
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 13 2880x240P @ 60Hz 16:9 (mode 1)
    {
         13,                                // Video ID Code 
         6000,                              // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity 
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         3432,                              // HTotal     
         2880,                              // HDisEnd    
         2880,                              // HBlankStart    
         3432,                              // HBlankEnd      
         2956,                              // HSyncStart 
         3204,                              // HSyncEnd   
         262,                               // VTotal     
         240,                               // VDisEnd    
         240,                               // VBlankStart    
         262,                               // VBlankEnd      
         0,                                 // VSyncOffset (in pixel clock cycle)
         244,                               // VSyncStart 
         247,                               // VSyncEnd 
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 14 1440x480P @ 59.94Hz 4:3 
    {
         14,                                // Video ID Code 
         5994,                              // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         1716,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1716,                              // HBlankEnd      
         1472,                              // HSyncStart 
         1596,                              // HSyncEnd   
         525,                               // VTotal     
         480,                               // VDisEnd    
         480,                               // VBlankStart    
         525,                               // VBlankEnd      
         0,                                 // VSyncOffset (in pixel clock cycle)
         489,                               // VSyncStart 
         495,                               // VSyncEnd 
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 15 1440x480P @ 59.94Hz 16:9
    {
         15,                                // Video ID Code 
         5994,                              // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity 
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         1716,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1716,                              // HBlankEnd      
         1472,                              // HSyncStart 
         1596,                              // HSyncEnd   
         525,                               // VTotal     
         480,                               // VDisEnd    
         480,                               // VBlankStart    
         525,                               // VBlankEnd      
         0,                                 // VSyncOffset (in pixel clock cycle)
         489,                               // VSyncStart 
         495,                               // VSyncEnd 
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 16 1920x1080P @ 60Hz 16:9 
    {
         16,                                // Video ID Code 
         6000,                              // RefreshRate
         148500000,                         // HW PLL SEED
         DCLK_148_5M,                       // 353 PLL
         ATT_PHS,                           // H Sync Polarity
         ATT_PVS,                           // V Sync Polarity 
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         2200,                              // HTotal     
         1920,                              // HDisEnd    
         1920,                              // HBlankStart    
         2200 ,                             // HBlankEnd      
         2008,                              // HSyncStart 
         2052 ,                             // HSyncEnd   
         1125,                              // VTotal     
         1080,                              // VDisEnd    
         1080,                              // VBlankStart    
         1125,                              // VBlankEnd      
         0,                                 // VSyncOffset (in pixel clock cycle)
         1084,                              // VSyncStart 
         1089,                              // VSyncEnd 
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 17  720x576P @ 50Hz 4:3
    {
         17,                                // Video ID Code           
         5000,                              // RefreshRate
         27000000,                          // HW PLL SEED
         DCLK_27M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity 
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         864,                               // HTotal     
         720,                               // HDisEnd    
         720,                               // HBlankStart    
         864,                               // HBlankEnd      
         732,                               // HSyncStart 
         796 ,                              // HSyncEnd   
         625,                               // VTotal     
         576,                               // VDisEnd    
         576,                               // VBlankStart    
         625,                               // VBlankEnd      
         0,                                 // VSyncOffset (in pixel clock cycle)
         581,                               // VSyncStart 
         586,                               // VSyncEnd 
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 18  720x576P @ 50Hz 16:9
    {
         18,                               // Video ID Code           
         5000,                             // RefreshRate
         27000000,                         // HW PLL SEED
         DCLK_27M,                         // 353 PLL
         ATT_NHS,                          // H Sync Polarity
         ATT_NVS,                          // V Sync Polarity 
         CBIOS_RATIO_16_9,                       // Format Aspect Ratio
         864,                              // HTotal     
         720,                              // HDisEnd    
         720,                              // HBlankStart    
         864,                              // HBlankEnd      
         732,                              // HSyncStart 
         796 ,                             // HSyncEnd   
         625,                              // VTotal     
         576,                              // VDisEnd    
         576,                              // VBlankStart    
         625,                              // VBlankEnd      
         0,                                // VSyncOffset (in pixel clock cycle)
         581,                              // VSyncStart 
         586,                              // VSyncEnd 
         PROGRESSIVE                       // Interlace / Progressive 
    },
    // Format 19  1280x720P  @ 50Hz 16:9                 
    {
         19,                                // Video ID Code           
         5000,                              // RefreshRate
         74270000,                          // HW PLL SEED
         DCLK_74_27M,                       // 353 PLL
         ATT_PHS,                           // H Sync Polarity
         ATT_PVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         1980,                              // HTotal     
         1280,                              // HDisEnd    
         1280,                              // HBlankStart    
         1980,                              // HBlankEnd      
         1720,                              // HSyncStart 
         1760 ,                             // HSyncEnd   
         750,                               // VTotal     
         720,                               // VDisEnd    
         720,                               // VBlankStart    
         750,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         725,                               // VSyncStart 
         730,                               // VSyncEnd 
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 20 1920x1080I @ 50Hz 16:9
    {
         20,                                // Video ID Code           
         5000,                              // RefreshRate
         74270000,                          // HW PLL SEED
         DCLK_74_27M,                       // 353 PLL
         ATT_PHS,                           // H Sync Polarity
         ATT_PVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         2640,                              // HTotal     
         1920,                              // HDisEnd    
         1920,                              // HBlankStart    
         2640,                              // HBlankEnd      
         2448,                              // HSyncStart 
         2492,                              // HSyncEnd   
         562,                               // VTotal     
         540,                               // VDisEnd    
         540,                               // VBlankStart    
         562,                               // VBlankEnd 
         1320,                              // VSyncOffset (in pixel clock cycle)
         542,                               // VSyncStart
         547,                               // VSyncEnd    
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 21 720(1440)x576I @ 50Hz 4:3
    {
         21,                                // Video ID Code           
         5000,                              // RefreshRate
         27000000,                          // HW PLL SEED
         DCLK_27M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         1728,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1728,                              // HBlankEnd      
         1464,                              // HSyncStart 
         1590,                              // HSyncEnd   
         312,                               // VTotal     
         288,                               // VDisEnd    
         288,                               // VBlankStart    
         312,                               // VBlankEnd 
         864,                               // VSyncOffset (in pixel clock cycle)
         290,                               // VSyncStart
         293,                               // VSyncEnd     
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 22 720(1440)x576I @ 50Hz 16:9
    {
         22,                                // Video ID Code           
         5000,                              // RefreshRate
         27000000,                          // HW PLL SEED
         DCLK_27M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         1728,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1728,                              // HBlankEnd      
         1464,                              // HSyncStart 
         1590,                              // HSyncEnd   
         312,                               // VTotal     
         288,                               // VDisEnd    
         288,                               // VBlankStart    
         312,                               // VBlankEnd 
         864,                               // VSyncOffset (in pixel clock cycle)
         290,                               // VSyncStart
         293,                               // VSyncEnd     
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 23 720(1440)x288P @ 50Hz 4:3 (mode 1)
    {
         23,                                // Video ID Code           
         5000,                              // RefreshRate
         27000000,                          // HW PLL SEED
         DCLK_27M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity 
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         1728,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1728,                              // HBlankEnd      
         1464,                              // HSyncStart 
         1590,                              // HSyncEnd   
         312,                               // VTotal     
         288,                               // VDisEnd    
         288,                               // VBlankStart    
         312,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         290,                               // VSyncStart
         293,                               // VSyncEnd  
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 24 720(1440)x288P @ 50Hz 16:9 (mode 1)
    {
         24,                                // Video ID Code           
         5000,                              // RefreshRate
         27000000,                          // HW PLL SEED
         DCLK_27M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         1728,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1728,                              // HBlankEnd      
         1464,                              // HSyncStart 
         1590,                              // HSyncEnd   
         312,                               // VTotal     
         288,                               // VDisEnd    
         288,                               // VBlankStart    
         312,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         290,                               // VSyncStart
         293,                               // VSyncEnd   
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 25 2880x576I @ 50Hz 4:3
    {
         25,                                // Video ID Code           
         5000,                              // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         3456,                              // HTotal     
         2880,                              // HDisEnd    
         2880,                              // HBlankStart    
         3456,                              // HBlankEnd      
         2928,                              // HSyncStart 
         3180,                              // HSyncEnd   
         312,                               // VTotal     
         288,                               // VDisEnd    
         288,                               // VBlankStart    
         312,                               // VBlankEnd 
         1728,                              // VSyncOffset (in pixel clock cycle)
         290,                               // VSyncStart
         293,                               // VSyncEnd     
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 26 2880x576I @ 50Hz 16:9
    {
         26,                                // Video ID Code           
         5000,                              // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity          
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         3456,                              // HTotal     
         2880,                              // HDisEnd    
         2880,                              // HBlankStart    
         3456,                              // HBlankEnd      
         2928,                              // HSyncStart 
         3180,                              // HSyncEnd   
         312,                               // VTotal     
         288,                               // VDisEnd    
         288,                               // VBlankStart    
         312,                               // VBlankEnd 
         1728,                              // VSyncOffset (in pixel clock cycle)
         290,                               // VSyncStart
         293,                               // VSyncEnd     
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 27 2880x288P @ 50Hz 4:3 (mode 1)
    {
         27,                                // Video ID Code           
         5000,                              // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity 
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         3456,                              // HTotal     
         2880,                              // HDisEnd    
         2880,                              // HBlankStart    
         3456,                              // HBlankEnd      
         2928,                              // HSyncStart 
         3180,                              // HSyncEnd   
         312,                               // VTotal     
         288,                               // VDisEnd    
         288,                               // VBlankStart    
         312,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         290,                               // VSyncStart
         293,                               // VSyncEnd   
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 28 2880x288P @ 50Hz 16:9 (mode 1)
    {
         28,                                // Video ID Code           
         5000,                              // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity 
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         3456,                              // HTotal     
         2880,                              // HDisEnd    
         2880,                              // HBlankStart    
         3456,                              // HBlankEnd      
         2928,                              // HSyncStart 
         3180,                              // HSyncEnd   
         312,                               // VTotal     
         288,                               // VDisEnd    
         288,                               // VBlankStart    
         312,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         290,                               // VSyncStart
         293,                               // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 29 1440x576P @ 50Hz  4:3
    {
         29,                                // Video ID Code           
         5000,                              // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         1728,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1728,                              // HBlankEnd      
         1464,                              // HSyncStart 
         1592,                              // HSyncEnd   
         625,                               // VTotal     
         576,                               // VDisEnd    
         576,                               // VBlankStart    
         625,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         581,                               // VSyncStart
         586,                               // VSyncEnd  
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 30 1440x576P @ 50Hz  16:9
    {
         30,                                // Video ID Code           
         5000,                              // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         1728,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1728,                              // HBlankEnd      
         1464,                              // HSyncStart 
         1592,                              // HSyncEnd   
         625,                               // VTotal     
         576,                               // VDisEnd    
         576,                               // VBlankStart    
         625,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         581,                               // VSyncStart
         586,                               // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 31 1920x1080P @ 50Hz 16:9
    {
         31,                                // Video ID Code           
         5000,                              // RefreshRate
         148500000,                         // HW PLL SEED
         DCLK_148_5M,                       // 353 PLL
         ATT_PHS,                           // H Sync Polarity
         ATT_PVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         2640,                              // HTotal     
         1920,                              // HDisEnd    
         1920,                              // HBlankStart    
         2640,                              // HBlankEnd      
         2448,                              // HSyncStart 
         2492,                              // HSyncEnd   
         1125,                              // VTotal     
         1080,                              // VDisEnd    
         1080,                              // VBlankStart    
         1125,                              // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         1084,                              // VSyncStart
         1089,                              // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 32 1920x1080P @ 24Hz 16:9
    {
         32,                                // Video ID Code           
         2400,                              // RefreshRate
         74270000,                          // HW PLL SEED
         DCLK_74_27M,                       // 353 PLL
         ATT_PHS,                           // H Sync Polarity
         ATT_PVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         2750,                              // HTotal     
         1920,                              // HDisEnd    
         1920,                              // HBlankStart    
         2750,                              // HBlankEnd      
         2558,                              // HSyncStart 
         2602,                              // HSyncEnd   
         1125,                              // VTotal     
         1080,                              // VDisEnd    
         1080,                              // VBlankStart    
         1125,                              // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         1084,                              // VSyncStart
         1089,                              // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 33 1920x1080P @ 25Hz 16:9
    {
         33,                                // Video ID Code           
         2500,                              // RefreshRate
         74270000,                          // HW PLL SEED
         DCLK_74_27M,                       // 353 PLL
         ATT_PHS,                           // H Sync Polarity
         ATT_PVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         2640,                              // HTotal     
         1920,                              // HDisEnd    
         1920,                              // HBlankStart    
         2640,                              // HBlankEnd      
         2448,                              // HSyncStart 
         2492,                              // HSyncEnd   
         1125,                              // VTotal     
         1080,                              // VDisEnd    
         1080,                              // VBlankStart    
         1125,                              // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         1084,                              // VSyncStart
         1089,                              // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 34 1920x1080P @ 30Hz 16:9
    {
         34,                                // Video ID Code           
         3000,                              // RefreshRate
         74270000,                          // HW PLL SEED
         DCLK_74_27M,                       // 353 PLL
         ATT_PHS,                           // H Sync Polarity
         ATT_PVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         2200,                              // HTotal     
         1920,                              // HDisEnd    
         1920,                              // HBlankStart    
         2200,                              // HBlankEnd      
         2008,                              // HSyncStart 
         2052,                              // HSyncEnd   
         1125,                              // VTotal     
         1080,                              // VDisEnd    
         1080,                              // VBlankStart    
         1125,                              // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         1084,                              // VSyncStart
         1089,                              // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 35 2880x480P @ 59.94Hz 4:3
    {
         35,                                // Video ID Code           
         5994,                              // RefreshRate
         108000000,                         // HW PLL SEED
         DCLK_108M,                         // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         3432,                              // HTotal     
         2880,                              // HDisEnd    
         2880,                              // HBlankStart    
         3432,                              // HBlankEnd      
         2944,                              // HSyncStart 
         3192,                              // HSyncEnd   
         525,                               // VTotal     
         480,                               // VDisEnd    
         480,                               // VBlankStart    
         525,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         489,                               // VSyncStart
         495,                               // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 36 2880x480P @ 59.94Hz 16:9
    {
         36,                                // Video ID Code           
         5994,                              // RefreshRate
         108000000,                         // HW PLL SEED
         DCLK_108M,                         // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         3432,                              // HTotal     
         2880,                              // HDisEnd    
         2880,                              // HBlankStart    
         3432,                              // HBlankEnd      
         2944,                              // HSyncStart 
         3192,                              // HSyncEnd   
         525,                               // VTotal     
         480,                               // VDisEnd    
         480,                               // VBlankStart    
         525,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         489,                               // VSyncStart
         495,                               // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 37 2880x576P @ 50Hz 4:3
    {
         37,                                // Video ID Code           
         5000,                              // RefreshRate
         108000000,                         // HW PLL SEED
         DCLK_108M,                         // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         3456,                              // HTotal     
         2880,                              // HDisEnd    
         2880,                              // HBlankStart    
         3456,                              // HBlankEnd      
         2928,                              // HSyncStart 
         3184,                              // HSyncEnd   
         625,                               // VTotal     
         576,                               // VDisEnd    
         576,                               // VBlankStart    
         625,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         581,                               // VSyncStart
         586,                               // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 38 2880x576P @ 50Hz 16:9
    {
         38,                                // Video ID Code           
         5000,                              // RefreshRate
         108000000,                         // HW PLL SEED
         DCLK_108M,                         // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         3456,                              // HTotal     
         2880,                              // HDisEnd    
         2880,                              // HBlankStart    
         3456,                              // HBlankEnd      
         2928,                              // HSyncStart 
         3184,                              // HSyncEnd   
         625,                               // VTotal     
         576,                               // VDisEnd    
         576,                               // VBlankStart    
         625,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         581,                               // VSyncStart
         586,                               // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 39 1920x1080I @ 50Hz (1250 Total)16:9
    {
         39,                                // Video ID Code           
         5000,                              // RefreshRate
         72300000,                          // HW PLL SEED
         DCLK_72_3M,                        // 353 PLL
         ATT_PHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         2304,                              // HTotal     
         1920,                              // HDisEnd    
         1920,                              // HBlankStart    
         2304,                              // HBlankEnd      
         1952,                              // HSyncStart 
         2120,                              // HSyncEnd   
         625,                               // VTotal     
         540,                               // VDisEnd    
         540,                               // VBlankStart    
         625,                               // VBlankEnd 
         1152,                              // VSyncOffset (in pixel clock cycle)
         563,                               // VSyncStart
         568,                               // VSyncEnd     
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 40 1920x1080I @ 100Hz 16:9
    {
         40,                                // Video ID Code           
         10000,                             // RefreshRate
         148500000,                         // HW PLL SEED
         DCLK_148_5M,                       // 353 PLL
         ATT_PHS,                           // H Sync Polarity
         ATT_PVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         2640,                              // HTotal     
         1920,                              // HDisEnd    
         1920,                              // HBlankStart    
         2640,                              // HBlankEnd      
         2448,                              // HSyncStart 
         2492,                              // HSyncEnd   
         562,                               // VTotal     
         540,                               // VDisEnd    
         540,                               // VBlankStart    
         562,                               // VBlankEnd 
         1320,                              // VSyncOffset (in pixel clock cycle)
         542,                               // VSyncStart
         547,                               // VSyncEnd     
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 41 1280x720P @ 100Hz 16:9
    {
         41,                                // Video ID Code           
         10000,                             // RefreshRate
         148500000,                         // HW PLL SEED
         DCLK_148_5M,                       // 353 PLL
         ATT_PHS,                           // H Sync Polarity
         ATT_PVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         1980,                              // HTotal     
         1280,                              // HDisEnd    
         1280,                              // HBlankStart    
         1980,                              // HBlankEnd      
         1720,                              // HSyncStart 
         1760,                              // HSyncEnd   
         750,                               // VTotal     
         720,                               // VDisEnd    
         720,                               // VBlankStart    
         750,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         725,                               // VSyncStart
         730,                               // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 42 720x576P @ 100Hz 4:3
    {
         42,                                // Video ID Code           
         10000,                             // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         864,                               // HTotal     
         720,                               // HDisEnd    
         720,                               // HBlankStart    
         864,                               // HBlankEnd      
         732,                               // HSyncStart 
         796,                               // HSyncEnd   
         625,                               // VTotal     
         576,                               // VDisEnd    
         576,                               // VBlankStart    
         625,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         581,                               // VSyncStart
         586,                               // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 43 720x576P @ 100Hz 16:9
    {
         43,                                // Video ID Code           
         10000,                             // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         864,                               // HTotal     
         720,                               // HDisEnd    
         720,                               // HBlankStart    
         864,                               // HBlankEnd      
         732,                               // HSyncStart 
         796,                               // HSyncEnd   
         625,                               // VTotal     
         576,                               // VDisEnd    
         576,                               // VBlankStart    
         625,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         581,                               // VSyncStart
         586,                               // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 44 720(1440)x576I @ 100Hz 4:3
    {
         44,                                // Video ID Code           
         10000,                             // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         1728,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1728,                              // HBlankEnd      
         1464,                              // HSyncStart 
         1590,                              // HSyncEnd   
         312,                               // VTotal     
         288,                               // VDisEnd    
         288,                               // VBlankStart    
         312,                               // VBlankEnd 
         864,                               // VSyncOffset (in pixel clock cycle)
         290,                               // VSyncStart
         293,                               // VSyncEnd    
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 45 720(1440)x576I @ 100Hz 16:9
    {
         45,                                // Video ID Code           
         10000,                             // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         1728,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1728,                              // HBlankEnd      
         1464,                              // HSyncStart 
         1590,                              // HSyncEnd   
         312,                               // VTotal     
         288,                               // VDisEnd    
         288,                               // VBlankStart    
         312,                               // VBlankEnd 
         864,                               // VSyncOffset (in pixel clock cycle)
         290,                               // VSyncStart
         293,                               // VSyncEnd  
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 46 1920x1080I @ 120Hz 16:9
    {
         46,                                // Video ID Code           
         12000,                             // RefreshRate
         148500000,                         // HW PLL SEED
         DCLK_148_5M,                       // 353 PLL
         ATT_PHS,                           // H Sync Polarity
         ATT_PVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         2200,                              // HTotal     
         1920,                              // HDisEnd    
         1920,                              // HBlankStart    
         2200,                              // HBlankEnd      
         2008,                              // HSyncStart 
         2052,                              // HSyncEnd   
         562,                               // VTotal     
         540,                               // VDisEnd    
         540,                               // VBlankStart    
         562,                               // VBlankEnd 
         1100,                              // VSyncOffset (in pixel clock cycle)
         542,                               // VSyncStart
         547,                               // VSyncEnd    
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 47 1280x720P @ 120Hz 16:9
    {
         47,                                // Video ID Code           
         12000,                             // RefreshRate
         148500000,                         // HW PLL SEED
         DCLK_148_5M,                       // 353 PLL
         ATT_PHS,                           // H Sync Polarity
         ATT_PVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         1650,                              // HTotal     
         1280,                              // HDisEnd    
         1280,                              // HBlankStart    
         1650,                              // HBlankEnd      
         1390,                              // HSyncStart 
         1430,                              // HSyncEnd   
         750,                               // VTotal     
         720,                               // VDisEnd    
         720,                               // VBlankStart    
         750,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         725,                               // VSyncStart
         730,                               // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 48 720x480P @ 119.88Hz 4:3
    {
         48,                                // Video ID Code           
         12000,                             // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         858,                               // HTotal     
         720,                               // HDisEnd    
         720,                               // HBlankStart    
         858,                               // HBlankEnd      
         736,                               // HSyncStart 
         798,                               // HSyncEnd   
         525,                               // VTotal     
         480,                               // VDisEnd    
         480,                               // VBlankStart    
         525,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         489,                               // VSyncStart
         495,                               // VSyncEnd     
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 49 720x480P @ 119.88Hz 16:9
    {
         49,                                // Video ID Code           
         12000,                             // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         858,                               // HTotal     
         720,                               // HDisEnd    
         720,                               // HBlankStart    
         858,                               // HBlankEnd      
         736,                               // HSyncStart 
         798,                               // HSyncEnd   
         525,                               // VTotal     
         480,                               // VDisEnd    
         480,                               // VBlankStart    
         525,                               // VBlankEnd 
         0,                                 // VSyncOffset (in pixel clock cycle)
         489,                               // VSyncStart
         495,                               // VSyncEnd   
         PROGRESSIVE                        // Interlace / Progressive 
    },
    // Format 50 720(1440)x480I @ 119.88Hz 4:3
    {
         50,                                // Video ID Code           
         12000,                             // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_4_3,                         // Format Aspect Ratio
         1716,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1716,                              // HBlankEnd      
         1478,                              // HSyncStart 
         1602,                              // HSyncEnd   
         262,                               // VTotal     
         240,                               // VDisEnd    
         240,                               // VBlankStart    
         262,                               // VBlankEnd 
         1134,                              // VSyncOffset (in pixel clock cycle)
         244,                               // VSyncStart
         247,                               // VSyncEnd     
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 51 720(1440)x480I @ 119.88Hz 16:9
    {
         51,                                // Video ID Code           
         12000,                             // RefreshRate
         54000000,                          // HW PLL SEED
         DCLK_54M,                          // 353 PLL
         ATT_NHS,                           // H Sync Polarity
         ATT_NVS,                           // V Sync Polarity
         CBIOS_RATIO_16_9,                        // Format Aspect Ratio
         1716,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1716,                              // HBlankEnd      
         1478,                              // HSyncStart 
         1602,                              // HSyncEnd   
         262,                               // VTotal     
         240,                               // VDisEnd    
         240,                               // VBlankStart    
         262,                               // VBlankEnd 
         1134,                              // VSyncOffset (in pixel clock cycle)
         244,                               // VSyncStart
         247,                               // VSyncEnd     
         INTERLACE                          // Interlace / Progressive 
    },
    // Format 52 720x576P @ 200Hz 4:3
    {
         52,                               // Video ID Code           
         20000,                            // RefreshRate
         108000000,                        // HW PLL SEED
         DCLK_108M,                        // 353 PLL
         ATT_NHS,                          // H Sync Polarity
         ATT_NVS,                          // V Sync Polarity
         CBIOS_RATIO_4_3,                        // Format Aspect Ratio
         864,                              // HTotal     
         720,                              // HDisEnd    
         720,                              // HBlankStart    
         864,                              // HBlankEnd      
         732,                              // HSyncStart 
         796,                              // HSyncEnd   
         625,                              // VTotal     
         576,                              // VDisEnd    
         576,                              // VBlankStart    
         625,                              // VBlankEnd 
         0,                                // VSyncOffset (in pixel clock cycle)
         581,                              // VSyncStart
         586,                              // VSyncEnd  
         PROGRESSIVE                       // Interlace / Progressive 
    },
    // Format 53 720x576P @ 200Hz 16:9
    {
         53,                               // Video ID Code           
         20000,                            // RefreshRate
         108000000,                        // HW PLL SEED
         DCLK_108M,                        // 353 PLL
         ATT_NHS,                          // H Sync Polarity
         ATT_NVS,                          // V Sync Polarity
         CBIOS_RATIO_16_9,                       // Format Aspect Ratio
         864,                              // HTotal     
         720,                              // HDisEnd    
         720,                              // HBlankStart    
         864,                              // HBlankEnd      
         732,                              // HSyncStart 
         796,                              // HSyncEnd   
         625,                              // VTotal     
         576,                              // VDisEnd    
         576,                              // VBlankStart    
         625,                              // VBlankEnd 
         0,                                // VSyncOffset (in pixel clock cycle)
         581,                              // VSyncStart
         586,                              // VSyncEnd     
         PROGRESSIVE                       // Interlace / Progressive 
    },
    // Format 54 720(1440)x576I @ 200Hz 4:3
    {
         54,                               // Video ID Code           
         20000,                            // RefreshRate
         108000000,                        // HW PLL SEED
         DCLK_108M,                        // 353 PLL
         ATT_NHS,                          // H Sync Polarity
         ATT_NVS,                          // V Sync Polarity 
         CBIOS_RATIO_4_3,                        // Format Aspect Ratio
         1728,                             // HTotal     
         1440,                             // HDisEnd    
         1440,                             // HBlankStart    
         1728,                             // HBlankEnd      
         1464,                             // HSyncStart 
         1590,                             // HSyncEnd   
         312,                              // VTotal     
         288,                              // VDisEnd    
         288,                              // VBlankStart    
         312,                              // VBlankEnd 
         864,                              // VSyncOffset (in pixel clock cycle)
         290,                              // VSyncStart
         293,                              // VSyncEnd     
         INTERLACE                         // Interlace / Progressive 
    },    
    // Format 55 720(1440)x576I @ 200Hz 16:9
    {
         55,                               // Video ID Code           
         20000,                            // RefreshRate
         108000000,                        // HW PLL SEED
         DCLK_108M,                        // 353 PLL
         ATT_NHS,                          // H Sync Polarity
         ATT_NVS,                          // V Sync Polarity 
         CBIOS_RATIO_16_9,                       // Format Aspect Ratio
         1728,                              // HTotal     
         1440,                              // HDisEnd    
         1440,                              // HBlankStart    
         1728,                              // HBlankEnd      
         1464,                              // HSyncStart 
         1590,                              // HSyncEnd   
         312,                              // VTotal     
         288,                              // VDisEnd    
         288,                              // VBlankStart    
         312,                              // VBlankEnd 
         864,                              // VSyncOffset (in pixel clock cycle)
         290,                              // VSyncStart
         293,                              // VSyncEnd     
         INTERLACE                         // Interlace / Progressive 
    },
    // Format 56 720x480P @ 239.76Hz 4:3
    {
         56,                               // Video ID Code           
         24000,                            // RefreshRate
         108000000,                        // HW PLL SEED
         DCLK_108M,                        // 353 PLL
         ATT_NHS,                          // H Sync Polarity
         ATT_NVS,                          // V Sync Polarity 
         CBIOS_RATIO_4_3,                        // Format Aspect Ratio
         858,                              // HTotal     
         720,                              // HDisEnd    
         720,                              // HBlankStart    
         858,                              // HBlankEnd      
         736,                              // HSyncStart 
         798,                              // HSyncEnd   
         525,                              // VTotal     
         480,                              // VDisEnd    
         480,                              // VBlankStart    
         525,                              // VBlankEnd 
         0,                                // VSyncOffset (in pixel clock cycle)
         489,                              // VSyncStart
         495,                              // VSyncEnd     
         PROGRESSIVE                       // Interlace / Progressive 
    },
    // Format 57 720x480P @ 239.76Hz 16:9
    {
         57,                               // Video ID Code           
         24000,                            // RefreshRate
         108000000,                        // HW PLL SEED
         DCLK_108M,                        // 353 PLL
         ATT_NHS,                          // H Sync Polarity
         ATT_NVS,                          // V Sync Polarity 
         CBIOS_RATIO_16_9,                       // Format Aspect Ratio
         858,                              // HTotal     
         720,                              // HDisEnd    
         720,                              // HBlankStart    
         858,                              // HBlankEnd      
         736,                              // HSyncStart 
         798,                              // HSyncEnd   
         525,                              // VTotal     
         480,                              // VDisEnd    
         480,                              // VBlankStart    
         525,                              // VBlankEnd 
         0,                                // VSyncOffset (in pixel clock cycle)
         489,                              // VSyncStart
         495,                              // VSyncEnd     
         PROGRESSIVE                       // Interlace / Progressive 
    },
    // Format 58 720(1440)x480I @ 239.76Hz 4:3
    {
         58,                               // Video ID Code           
         24000,                            // RefreshRate
         108000000,                        // HW PLL SEED
         DCLK_108M,                        // 353 PLL
         ATT_NHS,                          // H Sync Polarity
         ATT_NVS,                          // V Sync Polarity 
         CBIOS_RATIO_4_3,                        // Format Aspect Ratio
         1716,                             // HTotal     
         1440,                             // HDisEnd    
         1440,                             // HBlankStart    
         1716,                             // HBlankEnd      
         1478,                             // HSyncStart 
         1602,                             // HSyncEnd    
         262,                              // VTotal     
         240,                              // VDisEnd    
         240,                              // VBlankStart    
         262,                              // VBlankEnd 
         1134,                             // VSyncOffset (in pixel clock cycle)
         244,                              // VSyncStart
         247,                              // VSyncEnd     
         INTERLACE                         // Interlace / Progressive 
    },
    // Format 59 720(1440)x480I @ 239.76Hz 16:9
    {
         59,                               // Video ID Code           
         24000,                            // RefreshRate
         108000000,                        // HW PLL SEED
         DCLK_108M,                        // 353 PLL
         ATT_NHS,                          // H Sync Polarity
         ATT_NVS,                          // V Sync Polarity 
         CBIOS_RATIO_16_9,                       // Format Aspect Ratio
         1716,                             // HTotal     
         1440,                             // HDisEnd    
         1440,                             // HBlankStart    
         1716,                             // HBlankEnd      
         1478,                             // HSyncStart 
         1602,                             // HSyncEnd    
         262,                              // VTotal     
         240,                              // VDisEnd    
         240,                              // VBlankStart    
         262,                              // VBlankEnd 
         1134,                             // VSyncOffset (in pixel clock cycle)
         244,                              // VSyncStart
         247,                              // VSyncEnd     
         INTERLACE                         // Interlace / Progressive 
    },
};







