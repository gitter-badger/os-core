/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _CBIOSVER_NEW_H_
#define _CBIOSVER_NEW_H_

#define CBIOS_VERSION_BRANCH                   0    // CBios Branch code: trunk
#if defined (_WIN64)
#define CBIOS_VERSION_MAJOR                    1    // Big change: 64 bit CBIOS
#define CBIOS_VERSION_FEATURE                  0    // 64 bit: Version Number High Byte
#define CBIOS_VERSION_MINOR                    6    // 64 bit: Version Number Low Byte 
#define CBIOS_INTERNAL_PRODUCTVERSION_STR      "00.01.00.06"
#elif defined(__linux__)
#define CBIOS_VERSION_MAJOR                    0    // Big change: 32 bit CBIOS
#define CBIOS_VERSION_FEATURE                  0    // 32 bit: Version Number High Byte
#define CBIOS_VERSION_MINOR                    18   // 32 bit: Version Number Low Byte 
#define CBIOS_INTERNAL_PRODUCTVERSION_STR      "04.00.00.18"
#else
#define CBIOS_VERSION_MAJOR                    0    // Big change: 32 bit CBIOS
#define CBIOS_VERSION_FEATURE                  0    // 32 bit: Version Number High Byte
#define CBIOS_VERSION_MINOR                    6    // 32 bit: Version Number Low Byte 
#define CBIOS_INTERNAL_PRODUCTVERSION_STR      "00.00.00.06"
#endif


#define CBIOS_PREFIX_VERSION            CBIOS_VERSION_BRANCH,CBIOS_VERSION_MAJOR,CBIOS_VERSION_FEATURE,CBIOS_VERSION_MINOR

//
//  These undefines are used to replace with S3 version specific definitions
//  below, or in the modules that include this header file.
//
#undef VER_COMPANYNAME_STR
#undef VER_PRODUCTVERSION
#undef VER_PRODUCTVERSION_STR
#undef VER_PRODUCTNAME_STR
#undef  __BUILDMACHINE__            //To remove "built by:xxxDDK" string in file version description

#if defined (__linux__)
#define VER_LEGALCOPYRIGHT_YEARS    "2012"
#else
#define VER_LEGALCOPYRIGHT_YEARS    "2012"
#endif
#define VER_COMPANYNAME_STR         "S3 Graphics Co., Ltd."
#define VER_LEGALCOPYRIGHT_STR      "Copyright (c) " VER_LEGALCOPYRIGHT_YEARS  " by " VER_COMPANYNAME_STR
#define VER_PRODUCTVERSION          CBIOS_PREFIX_VERSION
#define VER_PRODUCTVERSION_STR      CBIOS_INTERNAL_PRODUCTVERSION_STR
#define VER_FILEVERSION_STR         CBIOS_INTERNAL_PRODUCTVERSION_STR 
#define VER_PRODUCTNAME_STR         "S3 Graphics UMA-series CBIOS"
#define VER_FILEDESCRIPTION_STR     L"S3 Graphics CBIOS Export Driver"

#ifndef __LINUX__
    #if defined (_WIN64)
        #define CBIOS_EXPORT_DRIVER_NAME              L"ucb_64.sys"
    #else
        #define CBIOS_EXPORT_DRIVER_NAME              L"ucb_32.sys"
    #endif

#define VER_INTERNALNAME_STR        CBIOS_EXPORT_DRIVER_NAME
#define VER_ORIGINALFILENAME_STR    CBIOS_EXPORT_DRIVER_NAME
#endif

#endif

